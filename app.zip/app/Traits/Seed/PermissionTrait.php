<?php
namespace App\Traits\Seed;

use App\Models\PermissionGroup;
use App\Models\Permission;
use Illuminate\Support\Str;
use DB;

trait PermissionTrait
{
    /**
     * seedAndCheckPermission function
     * seed permissions and check existing permission
     * @return void
     */
    public function seedAndCheckPermission()
    {

        // start user management

        //  permission group table
        $g = (new PermissionGroup())->where('name', 'user')->first();
        if (!$g) {
            $g = PermissionGroup::create([
                'name' => 'user',
                'category' => 'admin',
            ]);
        }
        //  permission  table
        $permissions = [
            [
                'name' => 'user_list'
            ],
            [
                'name' => 'user_create'
            ],
            [
                'name' => 'user_edit'
            ],
            [
                'name' => 'user_view'
            ],
            [
                'name' => 'user_delete'
            ],
            [
                'name' => 'user_report'
            ]
        ];
        foreach ($permissions as $key => $value) {
            $p = (new Permission())->where('name', $value)->first();
            if (!$p) {
                $p = Permission::create($value);
                // $g->permissions()->sync($p->id, false);
                $g->permissions()->attach($p->id, ['id' => Str::uuid()->toString()]);

            }
        }
        //end
        //  permission group table

        $g = (new PermissionGroup())->where('name', 'role')->first();
        if (!$g) {
            $g = PermissionGroup::create([
                'name' => 'role',
                'category' => 'admin',
            ]);
        }
        //  permission  table
        $permissions = [
            [
                'name' => 'role_list'
            ],
            [
                'name' => 'role_create'
            ],
            [
                'name' => 'role_edit'
            ],
            [
                'name' => 'role_view'
            ],
            [
                'name' => 'role_delete'
            ],
            [
                'name' => 'role_report'
            ]
        ];
        foreach ($permissions as $key => $value) {
            $p = (new Permission())->where('name', $value)->first();
            if (!$p) {
                $p = Permission::create($value);
                // $g->permissions()->sync($p->id, false);
                $g->permissions()->attach($p->id, ['id' => Str::uuid()->toString()]);

            }
        }
        // project Role

        $g = (new PermissionGroup())->where('name', 'project')->first();
        if (!$g) {
            $g = PermissionGroup::create([
                'name' => 'project',
                'category' => 'admin',
            ]);
        }
        //  permission  table
        $permissions = [
            [
                'name' => 'project_list'
            ],
            [
                'name' => 'project_create'
            ],
            [
                'name' => 'project_edit'
            ],
            [
                'name' => 'project_view'
            ],
            [
                'name' => 'project_delete'
            ],
            [
                'name' => 'project_report'
            ]
        ];
        foreach ($permissions as $key => $value) {
            $p = (new Permission())->where('name', $value)->first();
            if (!$p) {
                $p = Permission::create($value);
                // $g->permissions()->sync($p->id, false);
                $g->permissions()->attach($p->id, ['id' => Str::uuid()->toString()]);

            }
        }
        // Order permission
        $g = (new PermissionGroup())->where('name', 'order')->first();
        if (!$g) {
            $g = PermissionGroup::create([
                'name' => 'order',
                'category' => 'admin',
            ]);
        }
        //  permission  table
        $permissions = [
            [
                'name' => 'order_list'
            ],
            [
                'name' => 'order_create'
            ],
            [
                'name' => 'order_edit'
            ],
            [
                'name' => 'order_view'
            ],
            [
                'name' => 'order_delete'
            ],
            [
                'name' => 'order_report'
            ]
        ];
        foreach ($permissions as $key => $value) {
            $p = (new Permission())->where('name', $value)->first();
            if (!$p) {
                $p = Permission::create($value);
                // $g->permissions()->sync($p->id, false);
                $g->permissions()->attach($p->id, ['id' => Str::uuid()->toString()]);

            }
        }
        // invoice permission
        $g = (new PermissionGroup())->where('name', 'invoice')->first();
        if (!$g) {
            $g = PermissionGroup::create([
                'name' => 'invoice',
                'category' => 'admin',
            ]);
        }
        //  permission  table
        $permissions = [
            [
                'name' => 'invoice_list'
            ],
            [
                'name' => 'invoice_create'
            ],
            [
                'name' => 'invoice_edit'
            ],
            [
                'name' => 'invoice_view'
            ],
            [
                'name' => 'invoice_delete'
            ],
            [
                'name' => 'invoice_report'
            ]
        ];
        foreach ($permissions as $key => $value) {
            $p = (new Permission())->where('name', $value)->first();
            if (!$p) {
                $p = Permission::create($value);
                // $g->permissions()->sync($p->id, false);
                $g->permissions()->attach($p->id, ['id' => Str::uuid()->toString()]);

            }
        }
        //end

        // end user management


        //  permission group table

        //end


        //receipt

        $g = (new PermissionGroup())->where('name', 'receipt')->first();
        if (!$g) {
            $g = PermissionGroup::create([
                'name' => 'receipt',
                'category' => 'admin',
            ]);
        }
        //  permission  table
        $permissions = [
            [
                'name' => 'receipt_list'
            ],
            [
                'name' => 'receipt_create'
            ],
            [
                'name' => 'receipt_edit'
            ],
            [
                'name' => 'receipt_view'
            ],
            [
                'name' => 'receipt_delete'
            ],
            [
                'name' => 'receipt_report'
            ]
        ];
        foreach ($permissions as $key => $value) {
            $p = (new Permission())->where('name', $value)->first();
            if (!$p) {
                $p = Permission::create($value);
                // $g->permissions()->sync($p->id, false);
                $g->permissions()->attach($p->id, ['id' => Str::uuid()->toString()]);

            }
        }
        //end receipt
        //payment

        $g = (new PermissionGroup())->where('name', 'payment')->first();
        if (!$g) {
            $g = PermissionGroup::create([
                'name' => 'payment',
                'category' => 'admin',
            ]);
        }
        //  permission  table
        $permissions = [
            [
                'name' => 'payment_list'
            ],
            [
                'name' => 'payment_create'
            ],
            [
                'name' => 'payment_edit'
            ],
            [
                'name' => 'payment_view'
            ],
            [
                'name' => 'payment_delete'
            ],
            [
                'name' => 'payment_report'
            ]
        ];
        foreach ($permissions as $key => $value) {
            $p = (new Permission())->where('name', $value)->first();
            if (!$p) {
                $p = Permission::create($value);
                // $g->permissions()->sync($p->id, false);
                $g->permissions()->attach($p->id, ['id' => Str::uuid()->toString()]);

            }
        }
        //end payment
        //currency

        $g = (new PermissionGroup())->where('name', 'currency')->first();
        if (!$g) {
            $g = PermissionGroup::create([
                'name' => 'currency',
                'category' => 'admin',
            ]);
        }
        //  permission  table
        $permissions = [
            [
                'name' => 'currency_list'
            ],
            [
                'name' => 'currency_create'
            ],
            [
                'name' => 'currency_edit'
            ],
            [
                'name' => 'currency_view'
            ],
            [
                'name' => 'currency_delete'
            ],
            [
                'name' => 'currency_report'
            ]
        ];
        foreach ($permissions as $key => $value) {
            $p = (new Permission())->where('name', $value)->first();
            if (!$p) {
                $p = Permission::create($value);
                // $g->permissions()->sync($p->id, false);
                $g->permissions()->attach($p->id, ['id' => Str::uuid()->toString()]);

            }
        }
        //end currency
        //rate

        $g = (new PermissionGroup())->where('name', 'rate')->first();
        if (!$g) {
            $g = PermissionGroup::create([
                'name' => 'rate',
                'category' => 'admin',
            ]);
        }
        //  permission  table
        $permissions = [
            [
                'name' => 'rate_list'
            ],
            [
                'name' => 'rate_create'
            ],
            [
                'name' => 'rate_edit'
            ],
            [
                'name' => 'rate_view'
            ],
            [
                'name' => 'rate_delete'
            ],
            [
                'name' => 'rate_report'
            ]
        ];
        foreach ($permissions as $key => $value) {
            $p = (new Permission())->where('name', $value)->first();
            if (!$p) {
                $p = Permission::create($value);
                // $g->permissions()->sync($p->id, false);
                $g->permissions()->attach($p->id, ['id' => Str::uuid()->toString()]);

            }
        }
        //end rate
        //company

        $g = (new PermissionGroup())->where('name', 'company')->first();
        if (!$g) {
            $g = PermissionGroup::create([
                'name' => 'company',
                'category' => 'admin',
            ]);
        }
        //  permission  table
        $permissions = [
            [
                'name' => 'company_list'
            ],
            [
                'name' => 'company_create'
            ],
            [
                'name' => 'company_edit'
            ],
            [
                'name' => 'company_view'
            ],
            [
                'name' => 'company_delete'
            ],
            [
                'name' => 'company_report'
            ]
        ];
        foreach ($permissions as $key => $value) {
            $p = (new Permission())->where('name', $value)->first();
            if (!$p) {
                $p = Permission::create($value);
                // $g->permissions()->sync($p->id, false);
                $g->permissions()->attach($p->id, ['id' => Str::uuid()->toString()]);

            }
        }
        //end company
         

       // $g = (new PermissionGroup())->where('name', 'location')->first();
       // if (!$g) {
       //     $g = PermissionGroup::create([
       //         'name' => 'location',
       //         'category' => 'admin',
       //     ]);
       // }
       // //  permission  table
       // $permissions = [
       //     [
       //         'name' => 'location_list'
       //     ],
       //     [
       //         'name' => 'location_create'
       //     ],
       //     [
       //         'name' => 'location_edit'
       //     ],
       //     [
       //         'name' => 'location_view'
       //     ],
       //     [
       //         'name' => 'location_delete'
       //     ],
       //     [
       //         'name' => 'location_report'
       //     ]
       // ];
       // foreach ($permissions as $key => $value) {
       //     $p = (new Permission())->where('name', $value)->first();
       //     if (!$p) {
       //         $p = Permission::create($value);
       //         // $g->permissions()->sync($p->id, false);
       //         $g->permissions()->attach($p->id, ['id' => Str::uuid()->toString()]);

       //     }
       // }
        //end backup
        //expense

        $g = (new PermissionGroup())->where('name', 'expense')->first();
        if (!$g) {
            $g = PermissionGroup::create([
                'name' => 'expense',
                'category' => 'admin',
            ]);
        }
        //  permission  table
        $permissions = [
            [
                'name' => 'expense_list'
            ],
            [
                'name' => 'expense_create'
            ],
            [
                'name' => 'expense_edit'
            ],
            [
                'name' => 'expense_view'
            ],
            [
                'name' => 'expense_delete'
            ],
            [
                'name' => 'expense_report'
            ]
        ];
        foreach ($permissions as $key => $value) {
            $p = (new Permission())->where('name', $value)->first();
            if (!$p) {
                $p = Permission::create($value);
                // $g->permissions()->sync($p->id, false);
                $g->permissions()->attach($p->id, ['id' => Str::uuid()->toString()]);

            }
        }
        //end expense
        //expense_category

        $g = (new PermissionGroup())->where('name', 'expense_category')->first();
        if (!$g) {
            $g = PermissionGroup::create([
                'name' => 'expense_category',
                'category' => 'admin',
            ]);
        }
        //  permission  table
        $permissions = [
            [
                'name' => 'category_list'
            ],
            [
                'name' => 'category_create'
            ],
            [
                'name' => 'category_edit'
            ],
            [
                'name' => 'category_view'
            ],
            [
                'name' => 'category_delete'
            ],
            [
                'name' => 'category_report'
            ]
        ];
        foreach ($permissions as $key => $value) {
            $p = (new Permission())->where('name', $value)->first();
            if (!$p) {
                $p = Permission::create($value);
                // $g->permissions()->sync($p->id, false);
                $g->permissions()->attach($p->id, ['id' => Str::uuid()->toString()]);

            }
        }
        //end expense_category
        //report
        $g = (new PermissionGroup())->where('name', 'report')->first();
        if (!$g) {
            $g = PermissionGroup::create([
                'name' => 'report',
                'category' => 'admin',
            ]);
        }
        //  permission  table
        $permissions = [
            [
                'name' => 'report_list'
            ],
            [
                'name' => 'general_report'
            ],
            [
                'name' => 'receipts_report'
            ],
            [
                'name' => 'payments_report'
            ],
            [
                'name' => 'expenses_report'
            ],
            [
                'name' => 'orders_report'
            ],
            [
                'name' => 'invoices_report'
            ],
            [
                'name' => 'all_report'
            ],
            [
                'name' => 'projects_report'
            ],
            [
                'name' => 'balance_sheet'
            ],
            //  [
            //      'name' => 'general_report'
            //  ],
            //  [
            //      'name' => 'expenses_report'
            //  ],
            //  [
            //      'name' => 'receipts_report'
            //  ],
            //  [
            //      'name' => 'payments_report'
            //  ],
            //  [
            //      'name' => 'orders_report'
            //  ],
            //  [
            //      'name' => 'invoices_report'
            //  ],
            //  [
            //      'name' => 'all_report'
            //  ]
        ];
        foreach ($permissions as $key => $value) {
            $p = (new Permission())->where('name', $value)->first();
            if (!$p) {
                $p = Permission::create($value);
                // $g->permissions()->sync($p->id, false);
                $g->permissions()->attach($p->id, ['id' => Str::uuid()->toString()]);

            }
        }
        //end report

        //start contra

        $g = (new PermissionGroup())->where('name', 'cash_drop')->first();
        if (!$g) {
            $g = PermissionGroup::create([
                'name' => 'cash_drop',
                'category' => 'admin',
            ]);
        }
        //  permission  table
        $permissions = [
            [
                'name' => 'cash_drop_list'
            ],
            [
                'name' => 'cash_drop_create'
            ],
            [
                'name' => 'cash_drop_edit'
            ],
            [
                'name' => 'cash_drop_view'
            ],
            [
                'name' => 'cash_drop_delete'
            ],
            [
                'name' => 'cash_drop_report'
            ]
        ];
        foreach ($permissions as $key => $value) {
            $p = (new Permission())->where('name', $value)->first();
            if (!$p) {
                $p = Permission::create($value);
                // $g->permissions()->sync($p->id, false);
                $g->permissions()->attach($p->id, ['id' => Str::uuid()->toString()]);

            }
        }
        //end cash_drop
        //dashboard
        $g = (new PermissionGroup())->where('name', 'dashboard')->first();
        if (!$g) {
            $g = PermissionGroup::create([
                'name' => 'dashboard',
                'category' => 'admin',
            ]);
        }
        //  permission  table
        $permissions = [
            [
                'name' => 'dashboard_show'
            ],
            [
                'name' => 'organization_dashboard',
            ],
            [
                'name' => 'admin_dashboard',
            ],
        ];
        foreach ($permissions as $key => $value) {
            $p = (new Permission())->where('name', $value)->first();
            if (!$p) {
                $p = Permission::create($value);
                // $g->permissions()->sync($p->id, false);
                $g->permissions()->attach($p->id, ['id' => Str::uuid()->toString()]);

            }
        }
        //end dashboard

        // Location 
        $g = (new PermissionGroup())->where('name', 'location')->first();
        if (!$g) {
            $g = PermissionGroup::create([
                'name' => 'location',
                'category' => 'admin',
            ]);
        }
        //  permission  table
        $permissions = [
             [
                'name' => 'location_list'
            ],
            [
                'name' => 'location_create'
            ],
            [
                'name' => 'location_edit'
            ],
            [
                'name' => 'location_view'
            ],
            [
                'name' => 'location_delete'
            ],
            [
                'name' => 'location_report'
            ]
        ];
        foreach ($permissions as $key => $value) {
            $p = (new Permission())->where('name', $value)->first();
            if (!$p) {
                $p = Permission::create($value);
                // $g->permissions()->sync($p->id, false);
                $g->permissions()->attach($p->id, ['id' => Str::uuid()->toString()]);

            }
        }
    }
}

?>
