<?php

namespace App\Http\Controllers\Report;

use App\Exports\FinalReport;
use App\Http\Controllers\Controller;
use App\Models\Project;
use Illuminate\Http\Request;
use App\Models\Invoice;
use App\Models\Company;
use App\Models\Order;
use App\Models\Receipt;
use App\Models\Expense;
use App\Models\Payment;
 use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use Maatwebsite\Excel\Facades\Excel;

class ReportController extends Controller
{
    protected $expense;
    protected $invoice;
    
    public function __construct(Expense $expense, Invoice $invoice) {
        $this->expense = $expense;
        $this->invoice = $invoice;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        
        if($request->ajax()) {
            if ($request->type == 'commessions'){
                $companies = DB::table('companies')->get();
                $companies = $companies->map(function($company)
                {
                    $query = DB::table('companies')
                    ->leftjoin('invoice_details','invoice_details.company_id','companies.id')
                    ->selectRaw(
                        'companies.id,
                        companies.name,
                        sum(invoice_details.total_amount) as total_commession'
                    )->groupBy('companies.id', 'companies.name', 'companies.created_at')
                    ->where('invoice_details.company_id', $company->id)
                    ->whereNotNull('invoice_details.service_fee_percent')
                    ->whereNotNull('invoice_details.service_fee_amount')
                    ->first();
                    
                    if($query) {
                        
                        return [
                            "id" =>$query->id,
                            "name" =>$query->name,
                            'total_commession' => $query->total_commession
                        ];
                    } else {
                        return [
                            "id" => $company->id,
                            "name" =>$company->name,
                            'total_commession' => 0
                        ];
                    }
                });
                
                return $companies;
            }
        }
        if($request->ajax())
            return $this->expense->report($request);
        $totalInvoices   = DB::table('invoices')->leftjoin('transactions','transactions.id','invoices.transaction_id')->where('invoices.company_id', auth()->user()->current_company)->selectRaw("sum(transactions.amount)as amount")->whereIn('invoices.location_id', json_decode(auth()->user()->location_id, true))->value('amount');

        $totalPayments   = DB::table('payments')->leftjoin('transactions','transactions.id','payments.transaction_id')->where('payments.company_id', auth()->user()->current_company)->selectRaw("sum(transactions.amount)as amount")->whereIn('payments.location_id', json_decode(auth()->user()->location_id, true))->value('amount');

        $totalReceipts   = DB::table('receipts')->leftjoin('receipt_details','receipt_details.receipt_id','receipts.id')->where('receipts.company_id', auth()->user()->current_company)->selectRaw("sum(receipt_details.amount)as amount")->whereIn('receipts.location_id', json_decode(auth()->user()->location_id, true))->value('amount');

        $commissions         = Invoice::leftjoin('invoice_details','invoice_details.invoice_id','invoices.id')
                                        ->where('invoices.type','!=','principle')->sum('total_amount');
                                        
                                        
        $totalExpenses   = DB::table('expenses')->leftjoin('transactions','transactions.id','expenses.transaction_id')->where('expenses.company_id', auth()->user()->current_company)->selectRaw("sum(transactions.amount)as amount")->whereIn('expenses.location_id', json_decode(auth()->user()->location_id, true))->value('amount');
        $totalOrder      = DB::table('orders')->leftjoin('order_details','order_details.order_id','orders.id')->where('orders.company_id', auth()->user()->current_company)->selectRaw('sum(order_details.quantity*order_details.price)as total')->whereIn('orders.location_id', json_decode(auth()->user()->location_id, true))->value('total');
        $projects   = DB::table('projects')->where('projects.company_id', auth()->user()->current_company)->count('id');
        $totalIncomes  = $commissions - $totalExpenses;
        $user_type = auth()->user()->type;

         return view('reports.index',[
            'totalInvoices' =>$totalInvoices,
            'totalReceipts' =>$totalReceipts,
            'totalExpenses' =>$totalExpenses,
            'totalPayments' =>$totalPayments,
            'totalIncomes'  =>$totalIncomes,
            'projects'      =>$projects,
            'totalOrder'    =>$totalOrder,
            'user_type'     =>$user_type
     ]);
    }
    
    public function reportInvoices(Request $request) {
         
        if ($request->ajax()) {
            return $this->invoice->companyInvoices($request);
        }
        $company_id = $request->get('company_id');
        $company = Company::find($company_id);
        $company_name = $company->name." ".__('lang.pending_invoices');
        return view('reports.report_invoices', compact('company_id', 'company_name'));
    }

    /**
     * @method all report for calculating debit and credit of companies .
     *
     * @return \Illuminate\Http\Response
     */
    public function allReport()
    {
        if(auth()->user()->type == 'province')
            $companies   = DB::table('companies')->where('id',auth()->user()->current_company)->get();
        else
           $companies   = DB::table('companies')->get();
        $companies= $companies->map(function($company)
        {
            $usdReceipt  = DB::table('transactions')->where('transactions.company_id',$company->id)->where('transactions.currency','USD')->where('transactions.account_name','Income Account')->sum('amount');

            $afnReceipt  = DB::table('transactions')->where('transactions.company_id',$company->id)->where('transactions.currency','AFN')->where('transactions.account_name','Income Account')->sum('amount');

            $afnInvoices  = DB::table('transactions')->where('transactions.company_id',$company->id)->where('transactions.currency','AFN')->where('transactions.account_name','Invoice Account')->sum('amount');

            $usdInvoices  = DB::table('transactions')->where('transactions.company_id',$company->id)->where('transactions.currency','USD')->where('transactions.account_name','Invoice Account')->sum('amount');

            return [
                "usdDR" =>$usdInvoices,
                "usdCr" =>$usdReceipt,
                'afnDR' => $afnInvoices,
                "afnCr" =>$afnReceipt,
                'name'  => $company->name,
                'company_id'=> $company->id
            ];
            // return [
            //     "usdDR" =>abs($usdInvoices-$usdReceipt),
            //     "usdCr" =>$usdReceipt,
            //     'afnDR' => abs($afnInvoices-$afnReceipt),
            //     "afnCr" =>$afnReceipt,
            //     'name'  => $company->name,
            //     'company_id'=> $company->id
            // ];
            // return [
            //     "usdDR" =>abs($usdReceipt-$usdInvoices),
            //     "usdCr" =>($usdInvoices<=0)?$usdReceipt:0,
            //     'afnDR' => abs($afnReceipt-$afnInvoices),
            //     "afnCr" =>($afnReceipt<=0)?$afnReceipt:0,
            //     'name'  => $company->name
            // ];
        });
        return $companies;
        // return $report->map(function($rep, $key)
        // {
        //     return [
        //         "dr"=>$rep->amount,
        //         "cr"=>$rep->amount_cr,
        //         "cr_currency"=>$rep->currency_cr,
        //         "dr_currency"=>$rep->currency,
        //         "cr_company"=>$rep->company_cr,
        //         "dr_company"=>$rep->company_id,
        //         "company"=>$rep->name,
        //     ];
        // });
    }
    public function getReportPermission()
    {
        return DB::table('permission_groups')
            ->leftJoin('permission_permission_groups','permission_permission_groups.permission_group_id','permission_groups.id')
            ->leftJoin('permissions','permissions.id','permission_permission_groups.permission_id')
            ->leftJoin('role_permissions','permissions.id','role_permissions.permission_id')
            // ->leftJoin('roles','role_permissions.role_id','roles.id')
            ->leftJoin('user_roles','user_roles.role_id','role_permissions.role_id')
            ->where('user_roles.user_id',auth()->id())
            ->where('permission_groups.name','report')
            ->get('permissions.name');
    }

    public function finalReport($id){
        $project    = Project::find($id);
        $file_name  = $project->name.' Final Report.'.'xlsx';
        return Excel::download(new FinalReport($id), $file_name);
    }
    /**
     * get all location
     *
     * @return \Illuminate\Http\Response
     */
    public function location(Request $request)
    {
        return DB::table('provinces')->where('zone_id', $request->id)->get();
    }
    public function zone()
    {
        return DB::table('zones')->get();
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
