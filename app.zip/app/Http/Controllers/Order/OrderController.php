<?php

namespace App\Http\Controllers\Order;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\OrderDetails;
use App\Models\Project;
use App\Models\Company;
use App\Models\Currency;
use App\Models\HomeCurrency;

class OrderController extends Controller
{
 
    protected $order; 
    protected $order_details; 
    protected $home_currency; 


    public function __construct(Order $order, OrderDetails $order_details, HomeCurrency $home_currency)
    {
        $this->order            = $order; 
        $this->order_details    = $order_details; 
        $this->home_currency    = $home_currency; 
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {  
        if ($request->ajax()) {
            return $this->order->orders($request);
        }
        return view('orders.index');

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $projects     = Project::where('company_id', auth()->user()->current_company)->get(['name','id', 'location_id']);
        $company        = Company::where('id', auth()->user()->current_company)->first();
        $home_currency = $this->home_currency->where('company_id', auth()->user()->current_company)->first();
        // dd($home_currency->code);
        $currencies   = Currency::get(['id',
        'name',
        'code',
        'symbol',
        'exchange_rate as rate',
        'exchange_rate']);
        return view('orders.create',compact('projects','company','currencies', 'home_currency'));
    } 

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($request->all());

        $order = $this->order->create([
            'number'            => 1,
            'organization_id'   => $request->company,
            'project_id'        => $request->project,
            'from_date'         => $request->from_date,
            'to_date'           => $request->to_date,
            'currency'          => ($request->currency == null) ? 'USD' : $request->currency,
            'exchange_rate'     => $request->exchange_rate,
            'ref_no'            => $request->ref_no,
            'description'       => $request->desc,
            'status'            => false,
            'user_id'           => auth()->user()->id,
            'company_id'        => auth()->user()->current_company,
            'location_id'       => $request->location_id
        ]);
        if($order){
            for($x=0; $x<count($request->party); $x++){
                if($request->price[$x] != null && $request->quantity[$x] != null){
                    $this->order_details->create([
                        'order_id'      => $order->id,
                        'party'         => $request->party[$x],
                        'quantity'      => $request->quantity[$x],
                        'price'         => $request->price[$x],
                        'company_id'    => auth()->user()->current_company,
                        'location_id'   => $request->location_id
                    ]);
                }
            }
        }

        return redirect()->route('order.index');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $order = $this->order->find($id);
        $order_details  = $order->orderDetails()->get();
        $project        = Project::find($order->project_id);
        $company        = Company::find($order->organization_id);
        $currency       = Currency::where('code', $order->currency)->first();

        return view('orders.show',compact('order','order_details', 'project', 'company', 'currency'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // dd($id);
        $order = $this->order->find($id);
        // dd($order);
        // dd($order->orderDetails()->get());
        $order_details = $order->orderDetails()->get();
        $projects     = Project::where('company_id', auth()->user()->current_company)->get(['name','id', 'location_id']);
        $company        = Company::where('id', auth()->user()->current_company)->first();
        // $home_currency = $this->home_currency->first();
        // dd($home_currency->code);
        $currencies   = Currency::get(['id',
        'name',
        'code',
        'symbol',
        'exchange_rate as rate',
        'exchange_rate']);
        return view('orders.edit',compact('projects','company','currencies', 'order', 'order_details'));

    } 

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // dd($request->all());
        $order = $this->order->find($id);
        $order->update([
            'number'            => 1,
            'organization_id'   => $request->company,
            'project_id'        => $request->project,
            'from_date'         => $request->from_date,
            'to_date'           => $request->to_date,
            'currency'          => ($request->currency == null) ? 'USD' : $request->currency,
            'exchange_rate'     => $request->exchange_rate,
            'ref_no'            => $request->ref_no,
            'description'       => $request->desc,
            'status'            => false,
            'user_id'           => auth()->user()->id,
            'location_id'       => $request->location_id
        ]);

        $this->order_details->where('order_id', $id)->delete();
        
        if($order){
            for($x=0; $x<count($request->party); $x++){
                if($request->price[$x] != null && $request->quantity[$x] != null){
                    $this->order_details->create([
                        'order_id'      => $order->id,
                        'party'         => $request->party[$x],
                        'quantity'      => $request->quantity[$x],
                        'price'         => $request->price[$x],
                        'company_id'    => auth()->user()->current_company,
                        'location_id'   => $request->location_id
                    ]);
                }
            }
        }

        return redirect()->route('order.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id){

            // $related_tables = ['invoices', 'orders', 'payments'];
            $count = 0;
            try {

                if(count($request->ids) > 0){

                    $orders = $this->order->whereIn('id', $request->ids)->get();
                    DB::beginTransaction();

                    foreach ($orders as $key => $value) {

                        $this->order_details->where('order_id', $value->id)->delete();
                        deleteRecord('orders', 'id', $value->id);

                    }
                    DB::commit();
                        
                    return ['result' => 1, 'message' => __('message.success')];
                } else {
                    // DB::beginTransaction();
                        $this->order_details->where('order_id', $id)->delete();
                        $order = $this->order->find($id);
                        deleteRecord('orders', 'id', $order->id);
                        return ['result' => 1, 'message' => __('message.success')];
                    // DB::commit();
                }
                
                // return ['result' => 0, 'message' => 'First Delete Related Data'];
            } catch (\Exception $e) {
                DB::rollBack();
                return response()->json(['message' => __('message.error')], 422);
            }

        }
}
