<?php

namespace App\Http\Controllers\PDF;

use App\Http\Controllers\Controller;
use App\Models\Client\AttempToEndLife;
use App\Models\Client\Client;
use App\Models\Client\ClientSession;
use App\Models\Client\ClientWellBeing;
use App\Models\Client\ClinicalAS;
use App\Models\Client\EmergencyContact;
use App\Models\Client\Epilepsy;
use App\Models\Company;
use App\Models\InvoiceDetails;
use App\Models\Project;
use App\Models\Referral;
use App\Models\Invoice;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;

class PDFController extends Controller
{
    public function pdf(Request $request)
    {

        $data = json_decode($request->data, true);
        $type = $request->type;
        $collection = collect($data);
        if ($request->type == 'paid_invoice' || $request->type == 'unpaid_invoice') {
            $pdf = PDF::loadView('reports.pdf.invoices', [
                'data' => $data,
                'type' => $request->type,
            ])->setPaper('A5')
                ->setOption('page-width', '300')
                ->setOption('page-height', '250.7');
                $customPaper = array(0,0,780,780);
                $pdf->set_paper($customPaper);
            return $pdf->download($request->type . '.' . 'pdf');
        }
        else if ($request->type == 'pending_project' || $request->type == 'started_project' || $request->type == 'finish_project' || $request->type == 'projects') {

            $collection = collect($data);
            $newData   = $collection->map(function ($datad, $key) {

                $paidBinificiaries  = (new Project())->paidBinificiaries($datad['id']);
                $paidAmount  = (new Project())->paidAmount($datad['id']);
                $start_date   = explode(' ', $datad['start_date']);
                $end_date     = explode(' ', $datad['end_date']);
                $myArray = [
                    'no'            => ++$key,
                    'Code'          => $datad['code'],
                    'Name'          => $datad['name'],
                    'Start_Date'    => $start_date[0],
                    'End_Date'      => $end_date[0],
                    'Province'      => $datad['location'],
                    'Total_Beneficiary'   => $datad['total_beneficiary'],
                    'Budget'             => $datad['budget'],
                    'Paid_Binificiaries'  => $paidBinificiaries ? $paidBinificiaries : 0,
                    'Paid_Amount'          => $paidAmount ? $paidAmount : 0,
                ];
                return $myArray;
            });
            $pdf = PDF::loadView('reports.pdf.project', [
                'data' => $newData,
                'type' => $request->type,
            ])->setPaper('A5')
                ->setOption('page-width', '700')
                ->setOption('page-height', '250.7');
                 $customPaper = array(0,0,780,780);
                $pdf->set_paper($customPaper);
            return $pdf->download($request->type . '.' . 'pdf');

        } else if ($type == 'single_project' || $type == 'all_project') {
            $newData   = $collection->map(function ($datad, $key) {
                $paidBinificiaries  = (new Project())->paidBinificiaries($datad['id']);
                $paidAmount  = (new Project())->paidAmount($datad['id']);
                $start_date   = explode(' ', $datad['start_date']);
                $end_date     = explode(' ', $datad['end_date']);
                $myArray = [
                    'no'                  => ++$key,
                    'Code'                => $datad['code'],
                    'Name'                => $datad['name'],
                    'Start_Date'          => $start_date[0],
                    'End_Date'            => $end_date[0],
                    'Province'            => $datad['location'],
                    'Total_Beneficiary'   => $datad['total_beneficiary'],
                    'Budget'              => $datad['budget'],
                    'Paid_Binificiaries'  => $paidBinificiaries ? $paidBinificiaries : 0,
                    'Paid_Amount'          => $paidAmount ? $paidAmount : 0,
                ];
                return $myArray;
            });
            $pdf = PDF::loadView('reports.pdf.project', [
                'data' => $newData,
                'type' => $request->type,
            ])->setPaper('A5')
                ->setOption('page-width', '500')
                ->setOption('page-height', '250.7');
                 $customPaper = array(0,0,780,780);
                $pdf->set_paper($customPaper);
            return $pdf->download($request->type . '.' . 'pdf');
        }


        else if ($type == 'all_beneficiary') {
            $newData   = $collection->map(function ($datad, $key) {
                $myArray = [
                    'no'            => ++$key,
                    'project'       => $datad['name'],
                    'location'      => $datad['location'],
                    'amount'        => $datad['total_beneficiary'],
                ];
                return $myArray;
            });
            $pdf = PDF::loadView('reports.pdf.all_benificiary', [
                'data' => $newData,
                'type' => $request->type,
            ])->setPaper('A5')
                ->setOption('page-width', '500')
                ->setOption('page-height', '250.7');
                 $customPaper = array(0,0,780,780);
                $pdf->set_paper($customPaper);
            return $pdf->download($request->type . '.' . 'pdf');
        }


        else if ($type == 'invoices' || $type == 'all_invoice' || $type == 'single_invoice' ) {
            $data = collect($data);
            $new_data =  $data->map(function ($d, $key) {
                return [
                    'code'          => ++$key,
                    'invoice_no'    => $d['invoice_no'],
                    'company'       => $d['company'],
                    'project'       => $d['project'],
                    'currency'      => $d['currency'],
                    'amount'        => $d['amount'],
                    'date'          => $d['date']
                ];
            });
            $pdf = PDF::loadView('reports.pdf.report_invoices', [
                'data' => $new_data,
                'type' => $request->type,
            ])->setPaper('A5')
                ->setOption('page-width', '300')
                ->setOption('page-height', '250.7');
                $customPaper = array(0,0,780,780);
                $pdf->set_paper($customPaper);
            return $pdf->download($request->type . '.' . 'pdf');
        } else if ($request->type == 'orders') {
            $data = collect($data);
            $new_data =  $data->map(function ($d, $key) {
                return [
                    'code'          => ++$key,
                    'number'        => $d['number'],
                    'company'       => $d['company'],
                    'project'       => $d['project'],
                    'currency'      => $d['currency'],
                    'amount'        => $d['amount'],
                    'date'          => $d['date']
                ];
            });
            $pdf = PDF::loadView('reports.pdf.report_orders', [
                'data' => $new_data,
                'type' => $request->type,
            ])->setPaper('A5')
                ->setOption('page-width', '300')
                ->setOption('page-height', '250.7');
            return $pdf->download($request->type . '.' . 'pdf');
        } else if ($request->type == 'expenses') {
            $data = collect($data);
            $new_data =  $data->map(function ($d, $key) {
                return [
                    'code'          => ++$key,
                    'category'      => $d['category'],
                    'amount'        => $d['amount'],
                    'description'   => $d['description'],
                    'date'          => $d['date']
                ];
            });
            $pdf = PDF::loadView('reports.pdf.report_expenses', [
                'data' => $new_data,
                'type' => $request->type,
            ])->setPaper('A5')
                ->setOption('page-width', '300')
                ->setOption('page-height', '250.7');
            return $pdf->download($request->type . '.' . 'pdf');
        }else if ($type == 'payments') {
            $data = collect($data);
            $new_data =  $data->map(function ($d, $key) {
                return [
                    'code'          => ++$key,
                    'date'          => $d['date'],
                    'amount'        => $d['amount'],
                    'project'       => $d['project'],
                    'location'      => $d['location'],
                    'description'    => $d['description'],
                ];
            });
            // $pdf = \PDF::loadView('reports.pdf.report_payments', [
            //     'data' => $new_data,
            //     'type' => $request->type,
            // ])->setPaper('A5')
            //     ->setOption('page-width', '300')
            //     ->setOption('page-height', '250.7');

            // return $pdf->download($request->type . '.' . 'pdf');

            $pdf = PDF::loadView('reports.pdf.report_payments', [
                'data' => $new_data,
                'type' => $request->type,
            ])->setPaper('A5')
                ->setOption('page-width', '300')
                ->setOption('page-height', '250.7');
                $customPaper = array(0,0,780,780);
                $pdf->set_paper($customPaper);
            return $pdf->download($request->type . '.' . 'pdf');
        }else if ($type == 'receipts') {
            $data = collect($data);
            $new_data =  $data->map(function ($d, $key) {
                return [
                    'code'          => ++$key,
                    'date'          => $d['date'],
                    'amount'        => $d['amount'],
                    'description'    => $d['description'],
                ];
            });
            $pdf = PDF::loadView('reports.pdf.report_receipts', [
                'data' => $new_data,
                'type' => $request->type,
            ])->setPaper('A5')
                ->setOption('page-width', '300')
                ->setOption('page-height', '250.7');
                $customPaper = array(0,0,780,780);
                $pdf->set_paper($customPaper);
                return $pdf->download($request->type . '.' . 'pdf');
        }else if ($type == 'all_report') {
            $data = collect($data);
            // return ["dddddddddd"=>$data];
            $new_data =  $data->map(function ($d, $key) {
                return [
                    'code'          => ++$key,
                    'name'          => $d['name'],
                    'afnDR'        => $d['afnDR'],
                    'usdDR'    => $d['usdDR'],
                    'afnCr'        => $d['afnCr'],
                    'usdCr'        => $d['usdCr'],
                ];
            });
            $pdf = PDF::loadView('reports.pdf.all_report', [
                'data' => $new_data,
                'type' => $request->type,
            ])->setPaper('A5')
                ->setOption('page-width', '300')
                ->setOption('page-height', '250.7');
                $customPaper = array(0,0,780,780);
                $pdf->set_paper($customPaper);
                return $pdf->download($request->type . '.' . 'pdf');
        }
    }

    public function invoicesPDF(Request $request,$invoice_id){
        $companyName = Company::where('id', auth()->user()->current_company)->value('name');
        $view = '';
        if (stripos($companyName, 'unhcr cbi') !== false) {
            $view = 'invoice.exports.unhcr-cbi-excel';
        } elseif (stripos($companyName, 'who') !== false) {
            $view = 'invoice.exports.who-excel';
        } elseif (stripos($companyName, 'wfp') !== false) {
            $view = 'invoice.exports.wfp-excel';
        } elseif (stripos($companyName, 'unhcr admin') !== false) {
            $view = 'invoice.exports.unhcr-admin-excel';
        }
        $invoice =(new Invoice())->invoiceReport($invoice_id);
        $pdf = PDF::loadView($view, [
            'invoice' => $invoice,
            'invoice_details' => (new InvoiceDetails())->getInvoiceDetails($invoice_id),
        ])->setPaper('A3', 'landscape');

        return $pdf->download('Invoice no'.$invoice->invoice_no.'  .'.'pdf');

    }
}
