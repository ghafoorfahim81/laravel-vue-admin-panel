<?php

namespace App\Http\Controllers;

use App\Models\Account;
use App\Models\Transaction;
use Illuminate\Http\Request;
use App\Models\Expense;
use App\Models\ExpenseDetails;
use App\Models\HomeCurrency;

class ExpenseController extends Controller
{

    protected $expense;
    protected $expense_details;
    protected $home_currency;

    public function __construct(Expense $expense, ExpenseDetails $expense_details, HomeCurrency $home_currency)
    {
        $this->expense          = $expense;
        $this->expense_details  = $expense_details;
        $this->home_currency    = $home_currency;
    }

    public function index(Request $request)
    {
        
        if($request->ajax())
            return $this->expense->expenseList($request);
        return view('expenses.index');
    }

    public function create()
    {
        $home_currency = $this->home_currency->where('company_id')->first();
        return view('expenses.create', compact('home_currency'));
    }
    public function store(Request $request)
    {
        $account       = (new Account())->getAccountByName('Expense Account');
        // dd($account);
        $expense_total = 0;
        for($x = 0; $x<count($request->amount); $x++){
            if($request->amount[$x] !=null){
                $expense_total +=$request->amount[$x] ;
            }}
        $remark = $request->details?$request->details:'Expenses';

        $transaction   = pushTransaction($account->id,$account->name,$expense_total,$request->currency,$request->rate,'dr',$remark,$request->date);
        $location_id = json_decode(auth()->user()->location_id,true)[0];
        $expense = $this->expense->create([
            'date'=>$request->date,
            'description'=>$request->details,
            'category_id'=>$request->category_id,
            'location_id'=>$location_id,
            'transaction_id'=>$transaction->id,
            'company_id'    => auth()->user()->current_company
        ]);
        for ($i=0; $i < count($request->amount) ; $i++) {
           if($request->amount[$i] !=null)
                $this->expense_details->create([
                    'expense_id'=>$expense->id,
                    'amount'=>$request->amount[$i],
                    'description'=>$request->description[$i],
                    'company_id'=> auth()->user()->current_company
                ]);
        }
        return redirect('expense');

    //    0ea23fca-ec5c-4763-8043-f98aea100f94
    }

    public function edit($id)
    {
        $expense= $this->expense->edit($id);
        // dd($expense);
        return view('expenses.edit', compact('expense','id'));
    }
  public function show($id)
    {
        $expense= $this->expense->edit($id);
        // dd($expense);
        return view('expenses.show', compact('expense','id'));
    }
    public function update(Request $request, $id)
    {
        // dd($request->all());
        $expense = $this->expense->find($id);
        $this->expense_details->where('expense_id', $id)->delete();
        $expense_total = 0;
        (new Transaction())->destroy($expense->transaction_id);
        for($x = 0; $x<count($request->amount); $x++){
            if($request->amount[$x] !=null){
                $expense_total +=$request->amount[$x] ;
            }}
        $remark = $request->details?$request->details:'Expenses';
        $account       = (new Account())->getAccountByName('Expense Account');

        $transaction   = pushTransaction($account->id,$account->name,$expense_total,$request->currency,$request->rate,'dr',$remark,$request->date);

        $expense = $expense->update([
            'date'        =>$request->date,
            'description'    =>$request->details,
            'category_id'    =>($request->category_id != null) ? $request->category_id : $expense->category_id,
            'transaction_id' =>$transaction->id,
            'company_id'    => auth()->user()->current_company
        ]);
        
        for ($i=0; $i < count($request->amount) ; $i++) {
           if($request->amount[$i] !=null)
                $this->expense_details->create([
                    'expense_id'=>$id,
                    'amount'=>$request->amount[$i],
                    'description'=>$request->description[$i],
                    'company_id'=> auth()->user()->current_company
                ]);
        }
        
        return redirect('expense');
    }


    public function destroy(Request $request, $id){

        // $related_tables = ['invoices', 'orders', 'payments', 'receipt_details', 'accounts'];
        // $count = 0;
        try {

            if(count($request->ids) > 0){

                $expenses = $this->expense->whereIn('id', $request->ids)->get();
                \DB::beginTransaction();

                foreach ($expenses as $key => $value) {

                    Transaction::destroy($value->transaction_id);
                    $this->expense_details->where('expense_id', $value->id);
                    deleteRecord('expenses', 'id', $value->id);

                }
                \DB::commit();

                return ['result' => 1, 'message' => __('message.success')];

            } else {
                // DB::beginTransaction();
                $expense = $this->expense->find($id);
                Transaction::destroy($expense->transaction_id);
                $this->expense_details->where('expense_id', $id)->delete();
                deleteRecord('expenses', 'id', $id);

                return ['result' => 1, 'message' => __('message.success')];

                // DB::commit();
            }

            return ['result' => 0, 'message' => 'First Delete Related Data'];
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json(['message' => __('message.error')], 422);
        }

    }

}
