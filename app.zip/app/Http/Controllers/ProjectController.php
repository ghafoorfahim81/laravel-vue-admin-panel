<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Project;
use App\Models\Province;
use App\Models\HomeCurrency;
use App\Models\Currency;
use Illuminate\Support\Facades\DB;
use Storage;

class ProjectController extends Controller
{
    

    protected $project;
    protected $home_currency;
    protected $province; 

    public function __construct(Project $project, Province $province, HomeCurrency $home_currency)
    {
        $this->project    = $project;
        $this->province   = $province;
        $this->home_currency   = $home_currency;
    }


    public function index(Request $request){

        if ($request->ajax()) {
            return $this->project->projectList($request);
        }
        
        $provinces = $this->province->get(['id' ,'name']);
        return view('project.index', compact('provinces'));
    }

    public function create(){
        $provinces = $this->province->get(['id' ,'name']);
        $home_currency  = $this->home_currency->where('company_id', auth()->user()->current_company)->first();
        $currencies     = Currency::get(['id',
            'name',
            'code']); 
        return view('project.create', compact('provinces', 'currencies', 'home_currency'));
    }
    public function all(){

        return $this->project->where('company_id', auth()->user()->current_company)->get(['id','name']);
    }

    public function store(Request $request){

        $attachments = [];

        if($request->has('attach_file')){
            for($x=0; $x<count($request->attach_file); $x++){
                $store_file_name = '';
                $file = $request->file('attach_file')[$x];
                $fullName = $file->getClientOriginalName();
                $filename = pathinfo($fullName,PATHINFO_FILENAME);
                $fileExtension = $file->getClientOriginalExtension();
                $store_file_name = $filename.'-'.time().'.'.$fileExtension;
                $path = $file->storeAs('project_attachments',$store_file_name);

                array_push($attachments, ['file'=> $store_file_name]);
            }
        }

        $this->project->create([
            'code'          => $request->code,
            'name'          => $request->pro_name,
            'start_date'    => $request->from_date,
            'end_date'      => $request->to_date,
            'province_id'   => $request->province,
            'description'   => $request->desc,
            'budget'        => $request->budget,
            'currency'      => $request->currency,
            'total_beneficiary' => $request->total_beneficiary,
            'status'        => $request->status,
            'attachments'   => (count($attachments) > 0) ? json_encode($attachments) : null,
            'user_id'       => auth()->user()->id,
            'company_id'    => auth()->user()->current_company,
            'location_id'   => $request->province
        ]);

        return redirect()->route('project.index');
    }

    public function closeProject($id){

        $project = $this->project->find(trim($id));
        // dd($project);
        if($project){
            $project->update(['status'=> 'finished']);
        }

        return redirect()->route('project.index');
    }
    public function checkNameAndCode(Request $request)
    { 
        $name = strtolower($request->name);
        $code = strtolower($request->code);
        $total_beneficiary = $request->total_beneficiary;
        $province_id = $request->province_id;
        $project_province = DB::table('projects')->whereRaw("lower(code) = '$code' AND lower(name) = '$name' AND total_beneficiary = '$total_beneficiary' AND province_id='$province_id'")->first();
        $result =null;
        $message =null;
        
        if($project_province){
            
            $message  = 'Project for this province already exist do want to continue?';
        }
        
        return $message; 
}

    public function newFiles(Request $request){
    
        $project        = $this->project->find($request->project_id);
        $old_attachments = ($project->attachments != null) ? json_decode($project->attachments) : [];
        $attachments = [];
    
        for($y=0; $y<count($old_attachments); $y++){
    
            array_push($attachments, ['file'=> $old_attachments[$y]->file]);
        }
    
        if($request->has('attach_file')){
            foreach($request->attach_file as $file){
                $store_file_name = '';
                $fullName = $file->getClientOriginalName();
                $filename = pathinfo($fullName,PATHINFO_FILENAME);
                $fileExtension = $file->getClientOriginalExtension();
                $store_file_name = $filename.'-'.time().'.'.$fileExtension;
                $path = $file->storeAs('project_attachments',$store_file_name);
    
                array_push($attachments, ['file'=> $store_file_name]);
            }
        }
    
        $project->update([
            'attachments'   => (count($attachments) > 0) ? json_encode($attachments) : null,
        ]);
    
        return redirect()->back();
    
    }
    
    public function show($id){
            
        $project = $this->project->find($id);
        $province = $this->province->find($project->province_id);
        $attachments = ($project->attachments != null) ? json_decode($project->attachments) : [];
        $files = [];
        $paidBinificiaries  = $this->project->paidBinificiaries($id);
        $paidAmount  = $this->project->paidAmount($id); 
        
        for($x=0; $x<count($attachments); $x++){
    
            $file_name = substr($attachments[$x]->file, 0, strpos($attachments[$x]->file, '.'));
            $file = strrev($attachments[$x]->file);
            $file = substr($file, 0, strpos($file, '.')+1) . '' . substr($file, strpos($file, '-'));
            array_push($files, ['file'=> strrev($file), 'main_name'=> $file_name]);
        }
        
        $files = json_encode($files);
        return view('project.show', compact('project', "province", 'files','paidBinificiaries','paidAmount'));
    }
    
    public function downloadFile($name, $id)
    {
        if($name){
    
            $project        = $this->project->find($id);
            $attachments = ($project->attachments != null) ? json_decode($project->attachments) : [];
            $files = [];
    
            for($x=0; $x<count($attachments); $x++){
    
                $file = substr($attachments[$x]->file, 0, strpos($attachments[$x]->file, '.'));
                if($file == $name){
                    return response()->download(storage_path('app/project_attachments/'.$attachments[$x]->file));
                }
            }
        }
        else{
            return redirect()->back();
        }
    }
    
    public function edit($id)
    {
        $project = $this->project->find($id);
        $provinces = $this->province->get(['id' ,'name']);
        $currencies     = Currency::get(['id',
            'name',
            'code']);
    
        $attachments = ($project->attachments != null) ? json_decode($project->attachments) : [];
        $files = [];
    
        for($x=0; $x<count($attachments); $x++){
    
            $file = strrev($attachments[$x]->file);
            $file = substr($file, 0, strpos($file, '.')+1) . '' . substr($file, strpos($file, '-'));
                // dd(strrev($file));
            array_push($files, ['file'=> strrev($file), 'main_name'=> $attachments[$x]->file]);
        }
            // dd($project);
        $files = json_encode($files);
        $home_currency  = $this->home_currency->where('company_id', auth()->user()->current_company)->first();
            // dd($project->attachments);
            // dd('yes');
    
        return view('project.edit', compact('provinces', 'project', 'files', 'currencies', 'home_currency'));
    }
    
    public function update(Request $request, $id){
    
            // dd($request->all());
        $project = $this->project->find($id);
        $old_attachments = ($project->attachments != null) ? json_decode($project->attachments) : [];
        $attachments = [];
    
        if($request->has('attach_file')){
            foreach($request->attach_file as $file){
                    // dd($file);
                $store_file_name = '';
                $fullName = $file->getClientOriginalName();
                $filename = pathinfo($fullName,PATHINFO_FILENAME);
                $fileExtension = $file->getClientOriginalExtension();
                $store_file_name = $filename.'-'.time().'.'.$fileExtension;
                $path = $file->storeAs('public/project_attachments',$store_file_name);
    
                array_push($attachments, ['file'=> $store_file_name]);
            }
        }
    
    
    
        for($y=0; $y<count($old_attachments); $y++){
            $check = true;
    
            for($x=0; $x<count($request->old_file); $x++){
    
                if($request->old_file[$x] != null){
    
                    if($request->old_file[$x] == $old_attachments[$y]->file){
    
                        $check = false;
                        array_push($attachments, ['file'=> $request->old_file[$x]]);
                    }
                }
            }
    
            if($check){
                Storage::delete('public/project_attachments/'. $old_attachments[$y]->file);
            }
        }
    
    
    
            // dd($id);
        $project->update([
            'code'          => $request->code,
            'name'          => $request->pro_name,
            'start_date'    => $request->from_date,
            'end_date'      => $request->to_date,
            'province_id'   => $request->province,
            'description'   => $request->desc,
            'budget'        => $request->budget,
            'currency'      => $request->currency,
            'total_beneficiary' => $request->total_beneficiary,
            'status'        => $request->status,
            'attachments'   => (count($attachments) > 0) ? json_encode($attachments) : null,
            'description'   => $request->desc,
            'location_id'   => $request->province
        ]);
    
        return redirect()->route('project.index');
    }
    
    public function destroy(Request $request, $id){
    
        $related_tables = ['invoices', 'orders', 'payments'];
        $count = 0;
        try {
            if(count($request->ids) > 0){
    
                $projects = $this->project->whereIn('id', $request->ids)->get();
                DB::beginTransaction();
    
                foreach ($projects as $key => $value) {
    
                    if(checkForDelete($related_tables, 'project_id', $value->id) == false){
    
                        deleteRecord('projects', 'id', $value->id);
                    }else {
                        $count += 1;
                    }
    
                }
                DB::commit();
                if($count > 0){
                    return ['result' => 0, 'message' => 'First Delete Related Data'];
                } else {
                    return ['result' => 1, 'message' => __('message.success')];
                }
            } else {
                if(checkForDelete($related_tables, 'project_id', $id) == false){
    
                    deleteRecord('projects', 'id', $id);
                    return ['result' => 1, 'message' => __('message.success')];
                }
            }
    
            return ['result' => 0, 'message' => 'First Delete Related Data'];
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => __('message.error')], 422);
        }
    
    }
}
