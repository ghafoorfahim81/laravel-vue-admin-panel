<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PDF extends Controller
{
    //
}
