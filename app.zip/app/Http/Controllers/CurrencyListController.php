<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CurrencyListController extends Controller
{
    //
}
