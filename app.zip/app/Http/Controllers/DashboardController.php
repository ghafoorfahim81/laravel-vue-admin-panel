<?php

namespace App\Http\Controllers;

use App\Models\Client\Client;
use App\Models\Dashboard;
use App\Models\InvoiceDetails;
use App\Models\PaymentDetails;
use App\Models\Province;
use App\Models\Invoice;
use App\Models\Order;
use App\Models\Receipt;
use App\Models\Expense;
use App\Models\Payment;
use App\Models\Project;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{

    function __construct() {
        // $this->data_client = new Client(); // access to model
    }

    public function index(Request $request)
    { 
        if(hasPermission(['dashboard_show']) && auth()->user()->type =='main' || hasPermission(['organization_dashboard'])){
            $totalInvoices            = \DB::table('invoices')->leftjoin('transactions','transactions.id','invoices.transaction_id')->selectRaw("sum(transactions.amount)/transactions.rate as amount")->value('amount') ?? 0;
            $paid_invoices_amount     = \DB::table('invoices')->leftjoin('transactions','transactions.id','invoices.transaction_id')->selectRaw("sum(transactions.amount)/transactions.rate as amount")->where('invoices.status',1)->value('amount');
            $unpaid_invoices_amount   = \DB::table('invoices')->leftjoin('transactions','transactions.id','invoices.transaction_id')->selectRaw("sum(transactions.amount)/transactions.rate as amount")->where('invoices.status',0)->value('amount');
            $totalPayments   = \DB::table('payments')->leftjoin('transactions','transactions.id','payments.transaction_id')->selectRaw("sum(transactions.amount)/transactions.rate as amount")->value('amount');
            $totalReceipts    = \DB::table('receipts')->leftjoin('receipt_details','receipt_details.receipt_id','receipts.id')
                ->leftjoin('transactions','transactions.id','receipt_details.transaction_id')
                ->selectRaw('sum(transactions.amount) as amount')
                ->value('amount');
            $totalExpenses   = \DB::table('expenses')->leftjoin('transactions','transactions.id','expenses.transaction_id')->selectRaw("sum(transactions.amount)/transactions.rate as amount")->value('amount');
            $provinces   = Province::get(['name','id']);
            $commissions         = Invoice::leftjoin('invoice_details','invoice_details.invoice_id','invoices.id')
                                        ->where('invoices.type','!=','principle')->sum('total_amount');
                                        
            $income  = $commissions-$totalExpenses;
            $started_projects  = Project::where('status','started')->count('id');
            $started_project_amount  = Project::where('status','started')->sum('budget');
            $pending_project_amount  = Project::where('status','pending')->sum('budget');
            $finished_project_amount  = Project::where('status','finished')->sum('budget');
            $pending_projects  = Project::where('status','pending')->count('id');
            $finished_projects  = Project::where('status','finished')->count('id');
            $paidInvoices      = Invoice::where('status',1)->count('id');
            $unPaidInvoices      = Invoice::where('status',0)->count('id');
            $binificiaries      = Project::sum('total_beneficiary');
            $projects           = DB::table('projects')->leftjoin('provinces','provinces.id','projects.province_id')
                ->selectRaw('projects.*,provinces.name as location')->get();
            $invoices = DB::table('invoices')->leftJoin('invoice_details', 'invoice_details.invoice_id', 'invoices.id')
                ->leftJoin('companies', 'companies.id', 'invoices.organization_id')
                ->leftJoin('projects', 'projects.id', 'invoices.project_id')
                ->leftjoin('transactions', 'transactions.id', 'invoices.transaction_id')
                ->selectRaw('invoices.id,
            invoices.invoice_no,
            (transactions.amount) as amount,
            projects.name as project,
            companies.name as company,
            invoices.currency,
            invoices.status,
            invoices.date,
            invoices.created_at')->get();
            return view('dashboard.dashboard',[
                'totalInvoices' =>$totalInvoices,
                'totalReceipts' =>$totalReceipts,
                'income'        =>$income,
                'totalExpenses' =>$totalExpenses,
                'totalPayments' =>$totalPayments,
                'provinces'     =>$provinces,
                'started_projects'     =>$started_projects,
                'pending_projects'     =>$pending_projects,
                'finished_projects'     =>$finished_projects,
                'paidInvoices'       =>$paidInvoices,
                'unPaidInvoices'     =>$unPaidInvoices,
                'binificiaries'     =>$binificiaries,
                'commissions'     =>$commissions,
                'projects'        =>$projects,
                'started_project_amount'        =>$started_project_amount,
                'pending_project_amount'        =>$pending_project_amount,
                'finished_project_amount'       =>$finished_project_amount,
                'paid_invoices_amount'          =>$paid_invoices_amount,
                'unpaid_invoices_amount'        =>$unpaid_invoices_amount,
                'invoices'        =>$invoices,
            ]);
        }

        if(auth()->user()->type =='province'){
             $company_id = auth()->user()->current_company;
             
            $totalInvoices  = \DB::table('invoices')->leftjoin('transactions','transactions.id','invoices.transaction_id')
                ->selectRaw("sum(transactions.amount)/transactions.rate as amount")
                ->where('invoices.company_id',$company_id)
                ->whereIn('invoices.location_id',  json_decode(auth()->user()->location_id,true))
                ->value('amount');

            $totalPayments  = \DB::table('payments')->leftjoin('transactions','transactions.id','payments.transaction_id')
                ->selectRaw("sum(transactions.amount)/transactions.rate as amount")
                ->where('payments.company_id',$company_id)
                ->whereIn('payments.location_id',  json_decode(auth()->user()->location_id,true))
                ->value('amount');
            $totalExpenses   = \DB::table('expenses')->leftjoin('transactions','transactions.id','expenses.transaction_id')
                ->selectRaw("sum(transactions.amount)/transactions.rate as amount")
                ->where('expenses.company_id',$company_id)
                ->whereIn('expenses.location_id',  json_decode(auth()->user()->location_id,true))
                ->value('amount');
                
        $totalReceipts    = \DB::table('receipts')->leftjoin('receipt_details','receipt_details.receipt_id','receipts.id')
                ->leftjoin('transactions','transactions.id','receipt_details.transaction_id')
                ->selectRaw('sum(transactions.amount) as amount')
                ->where('receipts.company_id',$company_id)
                ->whereIn('receipts.location_id',  json_decode(auth()->user()->location_id,true))
                ->value('amount'); 
            $totalProject  = Project::whereIn('projects.location_id',  json_decode(auth()->user()->location_id,true))
            ->where('company_id',$company_id)
            ->count('id');
            return view('dashboard.users-dashboard',[
            'totalInvoices'        => $totalInvoices,
            'totalProject'         => $totalProject,
            'totalExpenses'        => $totalExpenses,
            'totalReceipts'        => $totalReceipts,
            'totalPayments'        => $totalPayments,
            ]);

        }

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
        public function dashboardData(Request $request)
    {

 
                    $provinces = (new Province())->get();
                    $clientCountByProvince = (new Project())->getProjectByProvince();


                    $total=0;
                    $terminataTotal=0;
                    $ongoingTotal=0;
                    $onHoldTotal=0;



                    return [
                        'province'=>$provinces,
                        'clientCountByProvince'=>$clientCountByProvince,
                        'clientsTotalAllPro' => $total,

                        ]; 

         
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Dashboard  $dashboard
     * @return \Illuminate\Http\Response
     */
    public function show(Dashboard $dashboard)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Dashboard  $dashboard
     * @return \Illuminate\Http\Response
     */
    public function edit(Dashboard $dashboard)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Dashboard  $dashboard
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Dashboard $dashboard)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Dashboard  $dashboard
     * @return \Illuminate\Http\Response
     */
    public function destroy(Dashboard $dashboard)
    {
        //
    }

    public function totalClientByGender()
    {

    }





}
