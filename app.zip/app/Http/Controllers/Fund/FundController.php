<?php

namespace App\Http\Controllers\Fund;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Item;

class FundController extends Controller
{
    public function search(Request $request){
        $type   = $request->type;

        if($type && $type =='item'){
            return Item::selectRaw("name,id,null as quantity,null as price")->get();
        }
        if($type && $type =='homeCurrency'){
            return homeCurrency();
        }
        if($type && $type =='selectedCompany'){
            return selectedCompany();
        }
    }
}
