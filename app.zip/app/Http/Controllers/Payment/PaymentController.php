<?php

namespace App\Http\Controllers\Payment;

use App\Http\Controllers\Controller;
use App\Models\HomeCurrency;
use Illuminate\Http\Request;
use App\Models\Currency;
use App\Models\Province;
use App\Models\Project;
use App\Models\Payment;
use App\Models\Transaction;
use App\Models\Account;
use App\Models\PaymentDetails;

class PaymentController extends Controller
{
    protected $payment;

    public function __construct(Payment $payment)
    {
        $this->payment = $payment;
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            return $this->payment->payments($request);
        }
        return view('payments.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $projects = Project::where('company_id', auth()->user()->current_company)->get(['name', 'id', 'location_id']);
        $provinces = Province::get(['name', 'id']);
        $currencies = Currency::where('company_id', auth()->user()->current_company)->get(['id',
            'name',
            'code',
            'symbol',
            'exchange_rate as rate',
            'exchange_rate']);
        $selected_currency = HomeCurrency::where('company_id', auth()->user()->current_company)->first();
        return view('payments.create', compact('projects', 'provinces', 'currencies', 'selected_currency'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $paymentDetails = json_decode($request->payment);
        $paymentItem = json_decode($request->items);
        $totalPayment = 0;
//        return $paymentItem[$x]->item->amount;
        for ($x = 0; $x < count($paymentItem); $x++) {
            if ($paymentItem[$x]->item->amount > 0) {
                $totalPayment += $paymentItem[$x]->item->amount * $paymentItem[$x]->item->quantity;
            }
        }
        $account = (new Account())->getAccountByName('Payment Account');
        $homeCurrency = homeCurrency()['code'];
        $remark = 'Pyament' . $paymentDetails->date;
        $currency = Currency::where('code', $request->currency)->first();

        $transaction = pushTransaction($account->id, $account->name, $totalPayment, $homeCurrency, 1, 'dr', $remark, $request->date);

        $payment = $this->payment->create([
            'project_id'     => $paymentDetails->project_id,
            'date'           => $paymentDetails->date,
            'transaction_id' => $transaction->id,
            'company_id'     => auth()->user()->current_company,
            'province_id'    => $request->location_id
        ]);
        if ($payment) {
            for ($i = 0; $i < count($paymentItem); $i++) {
                if ($paymentItem[$i]->item->amount > 0 && $paymentItem[$i]->item->quantity > 0) {
                    $payment->paymentDetails()->create([
                        'amount' => $paymentItem[$i]->item->amount,
                        'quantity' => $paymentItem[$i]->item->quantity,
                        'company_id' => auth()->user()->current_company,
                        'location_id'    => $request->location_id
                    ]);
                }
            }
            $paidBinificiaries  = (new Project())->paidBinificiaries($paymentDetails->project_id);
            $paidAmount  = (new Project())->paidAmount($paymentDetails->project_id);

            return ['paidBinificiaries'=>$paidBinificiaries,'paidAmount'=>$paidAmount];
        }
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $payment         = $this->payment->find($id);
        $paymentDetails  = $payment->paymentDetails()->get();
        return view('payments.edit',compact('payment','paymentDetails'));
//        return ['payment'=>$payment,'payment_details'=>$paymentDetails];
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $payment        = $this->payment->find($id);
        Transaction::where('id', $payment->transaction_id)->delete();
        $payment->paymentDetails()->delete();

        $totalPayment = 0;
        for ($x = 0; $x < count($request->quantity); $x++) {
            if ($request->amount[$x] > 0) {
                $totalPayment += $request->amount[$x] * $request->quantity[$x];
            }
        }
        $account = (new Account())->getAccountByName('Payment Account');
        $homeCurrency = homeCurrency()['code'];
        $remark = 'Pyament' . $request->date;

        $transaction = pushTransaction($account->id, $account->name, $totalPayment, $homeCurrency, 1, 'dr', $remark, $request->date);

        $paymentUpdate = $payment->update([
            'project_id' => $request->project_id,
            'date' => $request->date,
            'transaction_id' => $transaction->id,
            'company_id' => auth()->user()->current_company,
        ]);
        if ($paymentUpdate) {
            for ($x = 0; $x < count($request->quantity); $x++) {
                if ($request->amount[$x] > 0 && $request->quantity[$x] > 0) {
                    $payment->paymentDetails()->create([
                        'amount' => $request->amount[$x],
                        'quantity' => $request->quantity[$x],
                        'company_id' => auth()->user()->current_company,
                        'location_id'    => $request->location_id
                    ]);
                }
            }
            return redirect()->route('project.show',$request->project_id);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
//        try {

            if (count($request->ids) > 0) {

                $payments = $this->payment->whereIn('id', $request->ids)->get();
                \DB::beginTransaction();

                foreach ($payments as $key => $value) {
                    Transaction::destroy($value->transaction_id);
                    PaymentDetails::where('payment_id', $value->id)->delete();
                    deleteRecord('payments', 'id', $value->id);
                }
                \DB::commit();

                return ['result' => 1, 'message' => __('message.success')];

            } else {
//                \DB::beginTransaction();
                $payment = $this->payment->find($id);
                Transaction::destroy($payment->transaction_id);
                PaymentDetails::where('payment_id', $id)->delete();
                $payment->delete();
                deleteRecord('payments', 'id', $id);

                return ['result' => 1, 'message' => __('message.success')];

//                \DB::commit();
            }

            return ['result' => 0, 'message' => 'First Delete Related Data'];
//        } catch (\Exception $e) {
//            \DB::rollBack();
//            return response()->json(['message' => __('message.error')], 422);
//        }
    }
}
