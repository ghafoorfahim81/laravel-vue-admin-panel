<?php

namespace App\Http\Controllers\CashDrop;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Account;
use App\Models\Company;
use App\Models\CashDrop;
use App\Models\Currency;
use App\Models\HomeCurrency;
use App\Models\Project;
use App\Models\Province;
use App\Models\Transaction;
class CashDropController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $cash_drop;

    public function __construct(CashDrop $cash_drop)
    {
        $this->cash_drop = $cash_drop;
    }
 
    public function index(Request $request)
    {
        if ($request->ajax()) {
            return $this->cash_drop->cash_drops($request);
        }
        return view('cash_drops.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $companies = Company::where('id', auth()->user()->current_company)->first(['name', 'id'])->toArray();
        $projects = Project::where('company_id', auth()->user()->current_company)->get(['name', 'id']);
        $provinces = Province::get(['name', 'id']);
        $currencies = Currency::get(['id',
            'name',
            'code',
            'symbol',
            'exchange_rate as rate',
            'exchange_rate']);
        $selected_currency = HomeCurrency::where('company_id', auth()->user()->current_company)->first(['code', 'exchange_rate as rate']);
        return view('cash_drops.create', compact('projects', 'provinces', 'currencies', 'selected_currency', 'companies'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    { 
        $attachments  = [];
        if($request->has('attach_file')){  
            for($x=0; $x<count($request->attach_file); $x++){
                $store_file_name = '';
                $file = $request->attach_file[$x];
                $fullName = $file->getClientOriginalName();
                $filename = pathinfo($fullName,PATHINFO_FILENAME);
                $fileExtension = $file->getClientOriginalExtension();
                $store_file_name = $filename.'-'.time().'.'.$fileExtension;
                $path = $file->storeAs('public/cash_drop_attachments',$store_file_name);

                array_push($attachments, ['file'=> $store_file_name]);
            }
        }

        $account = (new Account())->getAccountByName('Contra Account');
        $homeCurrency = homeCurrency()['code'];
        $remark = 'Contra' . $request->date;
        $currency = Currency::where('code', $request->currency)->first();
        $transaction = pushTransaction($account->id, $account->name, $request->amount, $request->currency, $request->rate, 'dr', $remark, $request->date);
        $cash_drop = $this->cash_drop->create([
            'company_id' => auth()->user()->current_company,
            'transaction_id' => $transaction->id,
            'request_id' => $request->request_id,
            'receipt_no' => $request->receipt_no,
            'province_id' => $request->province,
            'attachments'   => (count($attachments) > 0) ? json_encode($attachments) : null,
            'date' => $request->date,
            'purpose' => $request->purpose,
        ]);

        if ($cash_drop) {
            return redirect()->route('cash_drop.index');
        }
    }

    public function newFiles(Request $request){

        // dd($request->cash_drop_id);
        $cash_drop        = $this->cash_drop->find($request->cash_drop_id);
    
        $old_attachments = ($cash_drop->attachments != null) ? json_decode($cash_drop->attachments) : [];
        $attachments = [];
    
        for($y=0; $y<count($old_attachments); $y++){
    
            array_push($attachments, ['file'=> $old_attachments[$y]->file]);
        }
    
        if($request->has('attach_file')){
            foreach($request->attach_file as $file){
                    // dd($file);
                $store_file_name = '';
                $fullName = $file->getClientOriginalName();
                $filename = pathinfo($fullName,PATHINFO_FILENAME);
                $fileExtension = $file->getClientOriginalExtension();
                $store_file_name = $filename.'-'.time().'.'.$fileExtension;
                $path = $file->storeAs('public/cash_drop_attachments',$store_file_name);
    
                array_push($attachments, ['file'=> $store_file_name]);
            }
        }
    
        $cash_drop->update([
            'attachments'   => (count($attachments) > 0) ? json_encode($attachments) : null,
        ]);
    
        return redirect()->back();
    
    }
    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $cashDrop = $this->cash_drop->find($id);

        $attachments = ($cashDrop->attachments != null) ? json_decode($cashDrop->attachments) : [];
        $files = [];
        for($x=0; $x<count($attachments); $x++){
    
            $file_name = substr($attachments[$x]->file, 0, strpos($attachments[$x]->file, '.'));
            $file = strrev($attachments[$x]->file);
            $file = substr($file, 0, strpos($file, '.')+1) . '' . substr($file, strpos($file, '-'));
                // dd(strrev($file));
            array_push($files, ['file'=> strrev($file), 'main_name'=> $file_name]);
        } 
        $files = json_encode($files);

        $cash_drop =$this->cash_drop->getCash_drops($id);
        $invoice_detail   = $this->cash_drop->getCashDropInvoiceDetails($id); 
        return view('cash_drops.show',compact('cash_drop','invoice_detail','files'));
    }

    public function downloadFile($name, $id)
    {
        if($name){
            $cash_drop        = $this->cash_drop->find($id);
            $attachments = ($cash_drop->attachments != null) ? json_decode($cash_drop->attachments) : [];
            $files = []; 
            for($x=0; $x<count($attachments); $x++){

                $file = substr($attachments[$x]->file, 0, strpos($attachments[$x]->file, '.'));
                if($file == $name){
                    return response()->download(storage_path('app/public/cash_drop_attachments/'.$attachments[$x]->file));
                }
            }
        }
        else{
            return redirect()->back();
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $companies = Company::where('id', auth()->user()->current_company)->first(['name', 'id'])->toArray();
        $projects = Project::where('company_id', auth()->user()->current_company)->get(['name', 'id']);
        $cash_drop = $this->cash_drop->getCash_drops($id);
        $provinces = Province::get(['name', 'id']);
        $currencies = Currency::get(['id',
            'name',
            'code',
            'symbol',
            'exchange_rate as rate',
            'exchange_rate']);
        $selected_currency = HomeCurrency::where('company_id', auth()->user()->current_company)->first(['code', 'exchange_rate as rate']);
        return view('cash_drops.edit', compact('projects', 'provinces', 'currencies', 'selected_currency', 'companies', 'cash_drop'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $cash_drop = $this->cash_drop->find($id);
        $account = (new Account())->getAccountByName('Contra Account');
        $homeCurrency = homeCurrency()['code'];
        $remark = 'Contra' . $request->date;
        Transaction::destroy($cash_drop->transaction_id);
        $transaction = pushTransaction($account->id, $account->name, $request->amount, $request->currency, $request->rate, 'dr', $remark, $request->date);
        $cash_dropUpdate = $cash_drop->update([
            'company_id' => auth()->user()->current_company,
            'transaction_id' => $transaction->id,
            'request_id' => $request->request_id,
            'province_id' => $request->province,
            'date' => $request->date,
            'purpose' => $request->purpose,
        ]);

        if ($cash_dropUpdate) {
            return redirect()->route('cash_drop.index');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
        try {

            if(count($request->ids) > 0){

                $cash_drops = $this->cash_drop->whereIn('id', $request->ids)->get();
                \DB::beginTransaction();

                foreach ($cash_drops as $key => $value) {
                    Transaction::destroy($value->transaction_id);
                    deleteRecord('cash_drops', 'id', $value->id);
                }
                \DB::commit();

                return ['result' => 1, 'message' => __('message.success')];

            } else {
//                \DB::beginTransaction();
                $cash_drop = $this->cash_drop->find($id);
                Transaction::destroy($cash_drop->transaction_id);
                deleteRecord('cash_drops', 'id', $id);

                return ['result' => 1, 'message' => __('message.success')];

//                \DB::commit();
            }

            return ['result' => 0, 'message' => 'First Delete Related Data'];
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json(['message' => __('message.error')], 422);
        }
    }
}
