<?php

namespace App\Http\Controllers\Excel;

use App\Exports\InvoiceExport;
use App\Exports\ProjectExport;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\ExportExcel;
use App\Exports\GeneralSample;
use App\Models\Project;
use App\Models\Invoice;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use function Symfony\Component\ErrorHandler\Exception\getTrace;

class ExcelController extends Controller
{
    public function export(Request $request)
    {

        $type = $request->type;
        $data = json_decode($request->data);
        $collection = collect($data);
        $lenght   = count($data);
        $myArray  = [];
        $newCount = null;
        // return $data;
        if($type =='single_project')
        {
            $newData   = $collection->map(function ($datad, $key) {
                $paidBinificiaries  = (new Project())->paidBinificiaries($datad->id);
                $paidAmount  = (new Project())->paidAmount($datad->id);
                $start_date   = explode(' ',$datad->start_date);
                $end_date     = explode(' ',$datad->end_date);
                $myArray = [
                    'no'                  => ++$key,
                    'Code'                => $datad->code,
                    'Name'                => $datad->name,
                    'Start_Date'          => $start_date[0],
                    'End_Date'            => $end_date[0],
                    'Province'            => $datad->location,
                    'Total_Beneficiary'   => $datad->total_beneficiary,
                    'Budget'              => $datad->budget,
                    'Paid_Binificiaries'  => $paidBinificiaries?$paidBinificiaries:0,
                    'Paid_Amount'          => $paidAmount?$paidAmount:0,
                ];
                return $myArray;
            });

            $header = [
                'No',
                'Code',
                'Name',
                'Start Date',
                'End Date',
                'Province',
                'Total Beneficiary',
                'Budget',
                'Paid Binificiaries',
                'Paid Amount',
            ];

            // return $newData;
            $column_size = [5,10,15,15,15,16,17,18,18,18];
            $export = new GeneralSample([$newData], $lenght, $type, $header, $column_size);
            return Excel::download($export, 'project.xlsx');
        }

        else if($type =='all_project' || $type =='pending_project' || $type =='started_project' || $type =='finish_project'|| $type =='projects')
        {
            $newData   = $collection->map(function ($datad, $key) {
                $paidBinificiaries  = (new Project())->paidBinificiaries($datad->id);
                $paidAmount  = (new Project())->paidAmount($datad->id);
                $start_date   = explode(' ',$datad->start_date);
                $end_date     = explode(' ',$datad->end_date);
                $myArray = [
                    'no'            => ++$key,
                    'Code'          => $datad->code,
                    'Name'          => $datad->name,
                    'ُStart_Date'    => $start_date[0],
                    'ُEnd_Date'      => $end_date[0],
                    'Province'      => $datad->location,
                    'Total_Beneficiary'   => $datad->total_beneficiary,
                    'Budget'             => $datad->budget,
                    'Paid_Binificiaries'  => $paidBinificiaries?$paidBinificiaries:0,
                    'Paid_Amount'          => $paidAmount?$paidAmount:0,
                ];
                return $myArray;
            });

            $header = [
                'No',
                'Code',
                'Name',
                'Start Date',
                'End Date',
                'Province',
                'Total Beneficiary',
                'Budget',
                'Paid Binificiaries',
                'Paid Amount',
            ];

            // return $newData;
            $column_size = [5,10,15,15,15,16,17,18,18,18];
            $export = new GeneralSample([$newData], $lenght, $type, $header, $column_size);
            return Excel::download($export, 'project.xlsx');
        }

        else if($type =='unpaid_invoice' || $type =='paid_invoice')
        {
            $newData   = $collection->map(function ($datad, $key) {
                $date   = explode(' ',$datad->created_at);
                $myArray = [
                    'no'            => ++$key,
                    'Code'          => $datad->invoice_no,
                    'Organization'  => $datad->company,
                    'Project'       => $datad->project,
                    'Currency'      => $datad->currency,
                    'Amount'        => $datad->amount,
                    'Date'          => $date[0]
                ];
                return $myArray;
            });

            $header = [
                'No',
                'Code',
                'Organization',
                'Project',
                'Currency',
                'Amount',
                'Date'
            ];

            // return $newData;
            $column_size = [5,10,20,20,8,10,12];
            $export = new GeneralSample([$newData], $lenght, $type, $header, $column_size);
            return Excel::download($export, 'project.xlsx');
        }

        else if($type =='single_invoice' || $type =='all_invoice' || $type =='invoices' )
        {
            $newData   = $collection->map(function ($datad, $key) {
                $invoices  = (new Invoice())->invoiceReport($datad->id);
                $myArray = [
                    'no'            => ++$key,
                    'Invoice_No'    => $invoices->invoice_no,
                    'date'          => $invoices->date,
                    'Project'       => $invoices->project,
                    'amount'        => $invoices->amount,
                    'currency'      => $invoices->currency,
                    'purpose'       => $invoices->purpose,
                    'type'          => $invoices->type,
                ];
                return $myArray;
            });

            $header = [
                'No',
                'Invoice No',
                'date',
                'Project',
                'Amount',
                'Currency',
                'purpose',
                'type',
            ];

            // return $newData;
            $column_size = [5,10,15,15,15,16,24,18];
            $export = new GeneralSample([$newData], $lenght, $type, $header, $column_size);
            return Excel::download($export, 'project.xlsx');
        }
        else if($type =='all_beneficiary' )
        {
            $newData   = $collection->map(function ($datad, $key) {
                $myArray = [
                    'no'            => ++$key,
                    'Project'       => $datad->name,
                    'location'      => $datad->location,
                    'amount'        => $datad->total_beneficiary,
                ];
                return $myArray;
            });

            $header = [
                'No',
                'Project',
                'location',
                'Amount',
            ];

            // return $newData;
            $column_size = [5,30,20,15];
            $export = new GeneralSample([$newData], $lenght, $type, $header, $column_size);
            return Excel::download($export, 'project.xlsx');
        }
        else if($type =='expenses' )
        {
            $data = json_decode($request->data, true);
            $collection = collect($data);
            $newData   = $collection->map(function ($d, $key) {
                $myArray = [
                    'no'            => ++$key,
                    'category'    => $d['category'],
                    'amount'        => $d['amount'],
                    'description'       => $d['description'],
                    'date'      => $d['date'],
                ];
                return $myArray;
            });

            $header = [
                'No',
                'Category',
                'Amount',
                'Description',
                'Date',
            ];

            // return $newData;
            $column_size = [5,15,15,25,25];
            $export = new GeneralSample([$newData], $lenght, $type, $header, $column_size);
            return Excel::download($export, 'expenses.xlsx');
        }
        else if($type =='orders' )
        {
            $data = json_decode($request->data, true);
            $collection = collect($data);
            $newData   = $collection->map(function ($d, $key) {
                $myArray = [
                    'no'            => ++$key,
                    'category'    => $d['category'],
                    'amount'        => $d['amount'],
                    'description'       => $d['description'],
                    'date'      => $d['date'],
                ];
                return $myArray;
            });

            $header = [
                'No',
                'Category',
                'Amount',
                'Description',
                'Date',
            ];

            // return $newData;
            $column_size = [5,15,15,25,25];
            $export = new GeneralSample([$newData], $lenght, $type, $header, $column_size);
            return Excel::download($export, 'orders.xlsx');
        }
        else if($type =='payments' )
        {
            $data = json_decode($request->data, true);
            $collection = collect($data);
            $newData   = $collection->map(function ($d, $key) {
                $myArray = [
                    'no'            => ++$key,
                    'date'    => $d['date'],
                    'amount'        => $d['amount'],
                    'project'       => $d['project'],
                    'location'      => $d['location'],
                    'description'      => $d['description'],
                ];
                return $myArray;
            });

            $header = [
                'No',
                'Date',
                'Amount',
                'Project',
                'Location',
                'Description',
            ];

            // return $newData;
            $column_size = [5,25,15,15,15,25];
            $export = new GeneralSample([$newData], $lenght, $type, $header, $column_size);
            return Excel::download($export, 'payments.xlsx');
        }
        else if($type =='receipts' )
        {
            $data = json_decode($request->data, true);
            $collection = collect($data);
            $newData   = $collection->map(function ($d, $key) {
                $myArray = [
                    'no'          => ++$key,
                    'date'          => $d['date'],
                    'amount'        => $d['amount'],
                    'description'    => $d['description'],
                ];
                return $myArray;
            });

            $header = [
                'No',
                'Date',
                'Amount',
                'Description',
            ];

            // return $newData;
            $column_size = [5,25,15,25];
            $export = new GeneralSample([$newData], $lenght, $type, $header, $column_size);
            return Excel::download($export, 'receipts.xlsx');
        }
    }

//    Export a project
    public function exportInvoice($invoice){
        $invoiceFind  = (New Invoice())->find($invoice);
        $file_name  = 'Invoice '.$invoiceFind->invoice_no.'.'.'xlsx';
//        dd($file_name);
        return Excel::download(new InvoiceExport($invoice), $file_name);
    }
}
