<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Log;
use Session;
use Storage;

use Artisan;
use File;


use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;

use Illuminate\Pagination\Paginator;
use Illuminate\Support\Collection;
use Illuminate\Pagination\LengthAwarePaginator;

class BackupController extends Controller
{
    public function __construct()
    {

    }

    public function index(Request $request)
    {
        $search_keyword = $request->input('search_keyword');
        $per_page = $request->input('per_page');
        $current_page = $request->input('current_page');
        if ($request->ajax()) {
            $disk = Storage::disk(config('backup.backup.destination.disks')[0]);

            $files = $disk->files('/' . config('backup.backup.name') . '/');


            $backups = [];
            foreach ($files as $k => $f) {


                if (substr($f, -4) == '.zip' && $disk->exists($f)) {


                    $date = date('Y-m-d', $disk->lastModified($f));
                    $backups[] = [
                        'file_path' => $f,
                        'file_name' => str_replace(config('backup.backup.name') . '/', '', $f),
                        'file_size' => $disk->size($f),
                        'human_file_size' => humanFileSize($disk->size($f)),
                        'last_modified' => $disk->lastModified($f),
                        'date' => convertDate($date),
                    ];


                }
            }


            $backups = array_reverse($backups);

            $backups = $this->paginate($backups);

            return $backups;
        }


        return view("backup.index");
    }


    public function create()
    {
        $this->setMenu(['add#backup' => 'backup/create']);

        return view('backup.create');
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
        ]);


        $name = $request->get('name');
        \Config::set('backup.backup.destination.filename_prefix', $name . '-');

        try {

            /* only database backup*/
            Artisan::call('backup:run --only-db --disable-notifications');
            /* all backup */
            /* Artisan::call('backup:run'); */
            $output = Artisan::output();


            return ['result' => 1, 'message' => __('message.success'), 'text' => $output];

        } catch (Exception $e) {
            return response()->json(['message' => __('message.error')], 422);
        }
    }

    public function download(Request $request, $file_name)
    {


        $file = config('backup.backup.name') . '/' . $file_name;
        $disk = Storage::disk(config('backup.backup.destination.disks')[0]);


        if ($disk->exists($file)) {

            return response()->download(storage_path('app/' . $file));

            $fs = Storage::disk(config('backup.backup.destination.disks')[0])->getDriver();
            $stream = $fs->readStream($file);

            return \Response::stream(function () use ($stream) {
                fpassthru($stream);
            }, 200, [
                "Content-Type" => $fs->getMimetype($file),
                "Content-Length" => $fs->getSize($file),
                "Content-disposition" => "attachment; filename=\"" . basename($file) . "\"",
            ]);


        } else {
            abort(404, "Backup file doesn't exist.");
        }


    }

    public function destroy(Request $request, $file_name)
    {
        try {

            $disk = Storage::disk(config('backup.backup.destination.disks')[0]);
            if ($disk->exists(config('backup.backup.name') . '/' . $file_name)) {
                $disk->delete(config('backup.backup.name') . '/' . $file_name);

            } else {
                return response()->json(['message' => __('message.error')], 422);
            }

            return ['result' => 1, 'message' => __('message.success')];
        } catch (\Exception $e) {
            return response()->json(['message' => __('message.error')], 422);
        }
    }


    public function syncUpload()
    {
        $ftp_server = env('FTP_SERVER');
        $ftp_user_name = env('FTM_USERNAME');
        $ftp_user_pass = "&1~RB[^(#HC6";
        $file = env('LOCAL_FILE');//tobe uploaded
        $remote_file = env('REMOTE_FILE');


        // set up basic connection
        $conn_id = ftp_connect($ftp_server);

        // login with username and password
        $login_result = ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);

        // upload a file
        if (ftp_put($conn_id, $remote_file, $file, FTP_ASCII)) {
            echo "successfully uploaded $file\n";
            unlink($file);
            exit;
        } else {
            echo "There was a problem while uploading $file\n";
            exit;
        }
        // close the connection
        ftp_close($conn_id);

        $file = public_path('bat\orders.sql');
        if (File::exists($file)) {
            File::delete($file);
        }


    }

    public function backupSync()
    {
        // $this->takeDump();
        $this->syncUpload();

        // $ressult=$this->syncRestore();
        // dd($ressult);
        //$this->syncUpload();

    }

    public function takeDump()
    {
        $process = new Process(['C:\xampp\htdocs\aliadaDB\public\bat\backup.sh']);

        $process->run();

        // executes after the command finishes
        if (!$process->isSuccessful()) {

            throw new ProcessFailedException($process);
        }


        return $process->getOutput();

    }

    public function syncRestore()
    {

        \Schema::dropIfExists('orders');


        $process = new Process(['C:\xampp\htdocs\aliadaDB\public\bat\restore.sh']);

        $process->run();

        // executes after the command finishes
        if (!$process->isSuccessful()) {
            throw new ProcessFailedException($process);
        }

        return $process->getOutput();

    }

    // pagination for array
    public function paginate($items, $perPage = 5, $page = null, $options = [])
    {
        $page = $page ?: (Paginator::resolveCurrentPage() ?: 1);
        $items = $items instanceof Collection ? $items : Collection::make($items);
        return new LengthAwarePaginator($items->forPage($page, $perPage), $items->count(), $perPage, $page, $options);
    }

    // set active menu
    public function setMenu($whichMenu = array(), $replace = false)
    {
        $defaultMenu = ['general_component' => 'backup', 'backup' => 'backup'];
        $menus = array();
        if ($replace) {
            $menus = $whichMenu;
        } else {
            $menus = array_merge($defaultMenu, $whichMenu);
        }

        setActiveMenu($menus);
    }
}
