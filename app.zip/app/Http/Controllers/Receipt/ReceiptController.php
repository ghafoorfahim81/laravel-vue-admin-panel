<?php

namespace App\Http\Controllers\Receipt;

use App\Http\Controllers\Controller;
use App\Models\InvoiceDetails;
use App\Models\ReceiptDetails;
use App\Models\Transaction;
use Illuminate\Http\Request;
use App\Models\Receipt;
use App\Models\Account;
use App\Models\Currency;
use App\Models\Invoice;
use Carbon\Carbon;
class ReceiptController extends Controller
{

    protected $receipt;
    protected $account;

    public function __construct(receipt $receipt, Account $account)
    {
        $this->receipt = $receipt;
        $this->account = $account;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            return $this->receipt->receipts($request);
        }
        return view('receipts.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $invoices = (new Invoice())->getInvoicesByStatus(false);

        $invoices = $invoices->map(function ($invoice)
        {
            $receiptsAm   = ReceiptDetails::where('invoice_id', $invoice->id)->sum('amount');
            return[
                'id'              => $invoice->id,
                'project'         => $invoice->project,
                'province_id'     => $invoice->province_id,
                'amount'          => $receiptsAm>0?$invoice->amount-$receiptsAm:$invoice->amount,
                'invoice_no'      => $invoice->invoice_no,
                'transaction_id'  => $invoice->transaction_id,
                'pay_date'        =>  date('Y-m-d'),
                'currency'        => $invoice->currency,
                'status'          => ($invoice->status) ? true : false
            ];
        });
        // dd($invoices)
        return view('receipts.create', compact( 'invoices'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($request->all());
        $account = $this->account->getAccountByName('Income Account');
        $receiptTotal = 0;

        $location_id = json_decode(auth()->user()->location_id,true)[0];
        $data = [
            'date' => $request->date,
            'location_id'=>$location_id,
            'company_id' => auth()->user()->current_company,
            'description' => $request->description,
            'receipt_no'        => $request->receipt_no,
        ];
        // return $location_id['id'];
        $receipt = $this->receipt->create($data);
        if ($receipt) {
            for ($i = 0; $i < count($request->status); $i++) {
                if ($request->status[$i]=='true' && $request->amount[$i]) {
                    $invoice = (new Invoice())->where('invoice_no', $request->invoice_no[$i])->first();
                    $transactionAm = (new Transaction())->where("id", $invoice->transaction_id)->first();
                    $invoiceAm = (new ReceiptDetails())->where('invoice_no', $request->invoice_no[$i])->sum('amount');
                    if ($invoiceAm + $request->amount[$i] == $transactionAm->amount) {
                        $invoice->update([
                            'status' => true
                        ]);
                    }
                    $transaction   = Transaction::where('id',$request->transaction_id[$i])->first();
                    $remark = 'receipt from Invoice'.'   '.$request->invoice_no[$i].'  '.$request->date;
                    $transaction = pushTransaction($account->id, $account->name, $request->amount[$i], $transaction->currency, $transaction->rate, 'dr', $remark, $request->date);

                    $receipt->receiptDetails()->create([
                        'invoice_no'    => $request->invoice_no[$i],
                        'invoice_id'    => $request->invoice_id[$i],
                        'pay_date'      => $request->pay_date[$i],
                        'amount'        => $request->amount[$i],
                        'currency'      => $request->currency[$i],
                        'transaction_id'=> $transaction->id,
                        'company_id'    => auth()->user()->current_company,
                    ]);
                }
            }
        }
        return redirect()->route('receipt.index');

    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $receipt  = $this->receipt->find($id);
        $receiptDetails  =(new ReceiptDetails())->getDetails($id);

        return view('receipts.show',compact('receipt','receiptDetails'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $invoices  = $this->receipt->editReceiptDetails($id);
        $receipt   = $this->receipt->find($id);
       // dd($receipt);
        $invoices = $invoices->map(function ($invoice)
        { 
            $receipt_data   = ReceiptDetails::where('invoice_no', $invoice->invoice_no)->first();
            return[
                'id'              => $invoice->id,
                'project'         => $invoice->project,
                'province_id'     => $invoice->province_id,
                'amount'          => $invoice->amount,
                'invoice_no'      => $invoice->invoice_no,
                'detail_id'       => $invoice->detail_id,
                'transaction_id'  => $invoice->transaction_id,
                'pay_date'        => $receipt_data->pay_date,
                'currency'        => $invoice->currency,
                'status'          => $invoice->status
            ];
        });
        return view('receipts.edit', compact( 'invoices','receipt'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $receipt   = $this->receipt->find($id);
        $location_id = json_decode(auth()->user()->location_id,true)[0];

        if ($receipt) {
            for ($i = 0; $i < count($request->status); $i++) {
                    $invoice       = (new Invoice())->where('id', $request->invoice_id[$i])->first();
                    $transactionAm = (new Transaction())->where("id", $invoice->transaction_id)->first();
                    $invoiceAm     = (new ReceiptDetails())->where('invoice_id', $request->invoice_id[$i])->sum('amount');

                if ($request->status[$i]=='true' && $request->amount[$i]) {
                    // dd($request->all());
                    $receiptDetails    = ReceiptDetails::where('id',$request->detail_id[$i])->first();
                    if (($invoiceAm + $request->amount[$i])-($invoiceAm - $request->amount[$i]) == $transactionAm->amount) {
                        $invoice->update([
                            'status' => true
                        ]);
                    }
                    $transaction       = Transaction::where('id',$request->transaction_id[$i])->first();
                    $transaction->update([
                        'amount'   => $request->amount[$i]
                    ]);
                    $receiptDetails->update([
                        'pay_date'      => $request->pay_date[$i],
                        'amount'        => $request->amount[$i],
                    ]);
                }
                else{
                    if ($invoice->status == true) {
                        $invoice->update([
                            'status' => false
                        ]);
                    }
                    $transaction       = Transaction::where('id',$request->transaction_id[$i])->delete();
                    $details           = ReceiptDetails::where('id',$request->detail_id[$i])->delete();
                }
            }

            $receipt->update([
                'date' => $request->date,
                'location_id'=>$location_id,
                'company_id' => auth()->user()->current_company,
                'description' => $request->description,
                'receipt_no'        => $request->receipt_no,
            ]);
        }
        return redirect()->route('receipt.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        // return ['result' => 1, 'message' => 'for test'];
        try {
            if(count($request->ids) > 0){ 
                $receipts = $this->receipt->whereIn('id', $request->ids)->get();
                \DB::beginTransaction();

                foreach ($receipts as $key => $value) {
                    Transaction::destroy($value->transaction_id);
                    ReceiptDetails::where('receipt_id', $value->id)->delete();
                    deleteRecord('receipts', 'id', $value->id);
                }
                \DB::commit();

                return ['result' => 1, 'message' => __('message.success')];

            } else { 
                \DB::beginTransaction();
                $receipt = $this->receipt->find($id);
                $receiptDetails  = ReceiptDetails::where('receipt_id', $receipt->id)->get();
                foreach ($receiptDetails as $details){
                    $invoice              = Invoice::where('id', $details->invoice_id)->first();
                    $invoiceTransactionAm = Transaction::where('id', $invoice->transaction_id)->first(['amount']);
                    $receiptAmount        = (new ReceiptDetails())->where('invoice_id', $invoice->id)->sum('amount'); 
                    if($invoiceTransactionAm->amount ===$receiptAmount){
                        $invoice->update([
                            'status' => false
                        ]);
                    }
                Transaction::destroy($details->transaction_id);
                }
                ReceiptDetails::where('receipt_id', $id)->delete();
                deleteRecord('receipts', 'id', $id);
                \DB::commit();
                return ['result' => 1, 'message' => __('message.success')];
            }

            return ['result' => 0, 'message' => 'First Delete Related Data'];
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json(['message' => __('message.error')], 422);
        }
    }
}
