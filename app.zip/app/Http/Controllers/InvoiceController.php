<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Invoice;
use App\Models\InvoiceDetails;
use App\Models\Project;
use App\Models\Company;
use App\Models\Currency;
use App\Models\HomeCurrency;
use App\Models\Province;
use App\Models\Account;
use App\Models\Transaction;
use Illuminate\Support\Facades\DB;
use Storage;

class InvoiceController extends Controller
{

    protected $invoice;
    protected $invoice_details;
    protected $home_currency;
    protected $province;
    protected $project;

    public function __construct(Invoice $invoice, InvoiceDetails $invoice_details, HomeCurrency $home_currency, Province $province, Project $project)
    {
        $this->invoice          = $invoice;
        $this->invoice_details  = $invoice_details;
        $this->home_currency    = $home_currency;
        $this->province         = $province;
        $this->project          = $project;
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            return $this->invoice->invoices($request);
        }
        return view('invoice.index');
    }
    
    public function checkInvoiceNumber(Request $request)
    {
        
        $invoice = $this->invoice->where('invoice_no', $request->invoice_no)->where('company_id',auth()->user()->current_company)->first();
        
        if($invoice){
            $last_invoice = $this->invoice->latest()->first();
            return response()->json(['status'=> 200, 'invoice'=> $invoice, 'last_invoice'=>$last_invoice]);
        }
        
        return response()->json(['status'=> 404]);
    }

    public function create(Request $request)
    {

        $projects = DB::table('projects')->where('company_id', auth()->user()->current_company)->selectRaw("IF(name IS NULL OR name = '', CONCAT(name, '', CASE WHEN LENGTH(code) > 8 THEN CONCAT(SUBSTRING(code, 1, 8), '...') ELSE code END), name) AS name,id,location_id,budget,total_beneficiary")->get();
        $selected_project = null;
        $is_cash_drop       = 'no-cache';
        $location_id        = null;
        $cash_drop_amount   = null;
        $cashe_id           = null;
        
        if (isset($request->project_id)){

            $selected_project   = $request->project_id;
            $is_cash_drop       = 'project'; 
        } else {

            $selected_project = count($projects) > 0 ? $projects[0]->id : null;
        }  

        if($request->has('cash_drop_province')){
            
            $selected_project = null;
            $is_cash_drop     = 'yes';
            $location_id      = $request->cash_drop_province;
            $cash_drop_amount = $request->cash_drop_amount;
            $cashe_id         = $request->cashe_id;
        }
         
        $paid_binificiaries  = $this->project->paidBinificiariesInvoice($selected_project);
        $paid_amount         = $paid_binificiaries->amount;
        $paid_binificiaries  = $paid_binificiaries->quantity;
        $company        = Company::where('id', auth()->user()->current_company)->first();
        $home_currency  = $this->home_currency->where('company_id', auth()->user()->current_company)->first();
        $provinces      = $this->province->get(['id', 'name']);
        $invoices       = $this->invoice->invoiceNoParents();
        $invoice_desc   = Company::find(auth()->user()->current_company)->invoice_desc;
        $invoice_propuse = Company::find(auth()->user()->current_company)->invoice_propuse;
        
        $currencies     = Currency::get([
            'id',
            'name',
            'code',
            'symbol',
            'exchange_rate as rate',
            'exchange_rate'
        ]);
        
        $all_invoice = 1;
        // dd($this->invoice->max('invoice_no'));
        $last_invoice = $this->invoice->latest()->first();
        
        if($last_invoice) {
            $all_invoice = $last_invoice->invoice_no + 1;
        }
        
        return view('invoice.create', compact('projects','all_invoice', 'currencies', 'home_currency', 'provinces', 'invoices', 'invoice_desc', 'company', 'invoice_propuse', 'selected_project', 'paid_binificiaries', 'paid_amount', 'is_cash_drop', 'location_id', 'cash_drop_amount', 'cashe_id'));
    }
    
    public function paidBinificiariesFunc($id)
    {
        return $this->project->paidBinificiaries($id);
    }
    
    public function store(Request $request)
    {
        // dd($request->all());
        $attachments = [];

        if ($request->has('attach_file')) {
            for ($x = 0; $x < count($request->attach_file); $x++) {
                $store_file_name = '';
                $file = $request->attach_file[$x];
                $fullName = $file->getClientOriginalName();
                $filename = pathinfo($fullName, PATHINFO_FILENAME);
                $fileExtension = $file->getClientOriginalExtension();
                $store_file_name = $filename . '-' . time() . '.' . $fileExtension;
                $path = $file->storeAs('public/attachments', $store_file_name);

                array_push($attachments, ['title' => $request->title[$x], 'file' => $store_file_name]);
            }
        }

        $account       = (new Account())->getAccountByName('Invoice Account');
        $type = null;
        if($request->check_principle != 'false'){
            $type = 'commission_principle';
        } else {
            $type          = ($request->is_comission != 'false') ? 'commission' : 'principle';
        }
        
        $invoice_total = 0;
        for ($x = 0; $x < count($request->location); $x++) {
            
            if($request->check_principle != 'false'){
                $invoice_total += ($request->total[$x] != null) ? $request->total[$x] : 0;
                $invoice_total += ($request->total_priciple[$x] > 0) ? $request->total_priciple[$x] : 0;
            }else {
                $invoice_total += ($request->total[$x] != null) ? $request->total[$x] : 0;
            }
        }  

        $remark = 'Invoice' . $request->invoice_number;
        $transaction   = pushTransaction($account->id, $account->name, $invoice_total, $request->currency, $request->exchange_rate, 'dr', $remark, $request->date, $request->location_id);

        $invoice = $this->invoice->create([
            'organization_id'   => $request->company,
            'project_id'        => ($request->is_cashe == 'cache') ? $request->cash_id : $request->project,
            'invoice_no'        => $request->invoice_number,
            'transaction_id'    => $transaction->id,
            'date'              => $request->date,
            'status'            => false,
            'vol_rep'           => $request->vol_rep,
            'description'       => $request->desc,
            'purpose'           => $request->purpose,
            'attachment'        => (count($attachments) > 0) ? json_encode($attachments) : null,
            'exchange_rate'     => $request->exchange_rate,
            'currency'          => ($request->currency == null) ? 'USD' : $request->currency,
            'exchange_currency' => $request->exchange_currency,
            'exchange_rate_second' => $request->exchange_rate_second,
            'parent_id'         => $request->parent_id,
            'company_id'        => auth()->user()->current_company,
            'location_id'       => $request->location_id,
            'type'              => ($request->is_cashe == 'cache' && $request->check_principle == 'false') ? 'cashe' : $type,
            'is_show'           => ($request->has('is_show')) ? true : false
        ]);  
        if ($invoice) {
            for ($x = 0; $x < count($request->location); $x++) {

                if (($request->has_location == 'false' && ($request->total[$x]>0) ) || $request->location[$x]!=null) {
                    $this->invoice_details->create([
                        'invoice_id'            => $invoice->id,
                        'location'              => $request->has_location == 'true'?$request->location[$x]:null,
                        'household'             => $request->household[$x],
                        'amount'                => ($request->has_amount == 'true') ? ($request->amount[$x] > 0 ? $request->amount[$x] : $request->total[$x]) : 0,
                        'service_fee_percent'   => ($request->has('service_amount')) ? $request->service_fee_percent[$x]?$request->service_fee_percent[$x]: null :null,
                        'service_fee_amount'    => ($request->has('service_amount')) ? $request->service_amount[$x]?$request->service_amount[$x]:null : null,
                        'total_amount'          => $request->total[$x],
                        'total'                 => ($request->check_principle != 'false') ? $request->total_priciple[$x] : (($request->amount[$x] > 0)?($request->amount[$x] * $request->household[$x]) : $request->total[$x]),
                        'date'                  => $request->date_d[$x],
                        'purchase_order'        => $request->purchase_order[$x],
                        'company_id'            => auth()->user()->current_company,
                        'location_id'           => $request->location_id
                    ]);
                }
            }
        }

        return redirect()->route('invoice.index');
    }

    public function show($id)
    {

        $invoice        = $this->invoice->find($id);
        $invoice_details = $this->invoice_details->getInvoiceDetails($id);
        $project        = Project::find($invoice->project_id);
        $company        = Company::find($invoice->organization_id);
        $attachments = ($invoice->attachment != null) ? json_decode($invoice->attachment) : [];
        $files = [];

        for ($x = 0; $x < count($attachments); $x++) {

            $file = substr($attachments[$x]->file, strpos($attachments[$x]->file, '.'));
            array_push($files, ['title' => $attachments[$x]->title, 'file' => $attachments[$x]->file, 'file_name' => $file]);
        }
        
        $attachments = json_encode($files);

        return view('invoice.show', compact('invoice', 'invoice_details', 'company', 'project', 'attachments'));
    }

    public function downloadFile($name, $id)
    {
        if ($name) {

            $invoice        = $this->invoice->find($id);
            $attachments = ($invoice->attachment != null) ? json_decode($invoice->attachment) : [];
            $files = [];

            for ($x = 0; $x < count($attachments); $x++) {

                $file = substr($attachments[$x]->file, strpos($attachments[$x]->file, '.'));
                if ($file == $name) {
                    return response()->download(storage_path('app/public/attachments/' . $attachments[$x]->file));
                }
            }
        } else {
            return redirect()->back();
        }
    }
    
    public function getInvoiceCommission($id){
        
        $invoice = $this->invoice->find($id);
        $invoice_details = $invoice->invoiceDetails()->get();
        $all_invoice = $this->invoice->count()+1;
        $attachments = ($invoice->attachment != null) ? json_decode($invoice->attachment) : [];
        $files = [];

        for ($x = 0; $x < count($attachments); $x++) {

            $file = strrev($attachments[$x]->file);
            $file = substr($file, 0, strpos($file, '.') + 1) . '' . substr($file, strpos($file, '-'));
            array_push($files, ['title' => $attachments[$x]->title, 'file' => strrev($file), 'main_name' => $attachments[$x]->file]);
        }
        
        $attachments = $files;
        
        return response()->json(['invoice'=>$invoice, 'invoice_details'=>$invoice_details, 'attachments'=>$attachments,'all_invoice'=>$all_invoice]);
    }

    public function edit($id)
    {
        $invoice = $this->invoice->find($id);
        $paid_binificiaries  = $this->project->paidBinificiariesInvoice($invoice->project_id);
        $paid_amount         = $paid_binificiaries->amount;
        $paid_binificiaries  = $paid_binificiaries->quantity;
        $invoice_details = $invoice->invoiceDetails()->get();
        // $projects     = Project::where('company_id', auth()->user()->current_company)->get(['name', 'id', 'location_id', 'budget', 'total_beneficiary']);
        $projects = DB::table('projects')->where('company_id', auth()->user()->current_company)->selectRaw("IF(name IS NULL OR name = '', CONCAT(name, '', CASE WHEN LENGTH(code) > 8 THEN CONCAT(SUBSTRING(code, 1, 8), '...') ELSE code END), name) AS name,id,location_id,budget,total_beneficiary")->get();
        $company        = Company::where('id', auth()->user()->current_company)->first();
        $provinces = $this->province->get(['id', 'name']);
        $invoices = $this->invoice->invoiceNoParents();
        $currencies   = Currency::get([
            'id',
            'name',
            'code',
            'symbol',
            'exchange_rate as rate',
            'exchange_rate'
        ]);

        $attachments = ($invoice->attachment != null) ? json_decode($invoice->attachment) : [];
        $files = [];

        for ($x = 0; $x < count($attachments); $x++) {

            $file = strrev($attachments[$x]->file);
            $file = substr($file, 0, strpos($file, '.') + 1) . '' . substr($file, strpos($file, '-'));
            array_push($files, ['title' => $attachments[$x]->title, 'file' => strrev($file), 'main_name' => $attachments[$x]->file]);
        }
        
        $invoice_desc = $invoice->description;
        $invoice_propuse = $invoice->purpose;
        $attachments = json_encode($files);
        
        return view('invoice.edit', compact('projects', 'company', 'currencies', 'invoice', 'invoice_details', 'paid_amount', 'provinces', 'attachments', 'invoices','paid_binificiaries','invoice_desc', 'invoice_propuse'));
    }

    public function print($id)
    {

        $print =  $this->invoice->print($id);
        foreach ($print as $key =>$value) {
            
            if($value->type=='cashe') {
                $value->house_amount = ($value->house_amount>0 && $value->house_amount !=null)?$value->house_amount:1;
                $value->amount = ($value->amount>0 && $value->amount !=null)?($value->amount-(($value->service_fee_amount >0 || $value->service_fee_amount!=null)?$value->service_fee_amount:0)):($value->total_amount-(($value->service_fee_amount >0 || $value->service_fee_amount!=null)?$value->service_fee_amount:0));

            }
            if($value->type=='commission') {
                $value->household = ($value->household>0 && $value->household !=null)?$value->household:0;
                $value->house_amount = ($value->house_amount>0 && $value->house_amount !=null)?$value->house_amount:0;
                $value->amount = ($value->amount>0 && $value->amount !=null && $value->house_amount>0)?($value->household * $value->house_amount):$value->total;
                
            }
            if($value->type=='commission_principle') {
                $value->household = ($value->household>0 && $value->household !=null)?$value->household:0;
                $value->house_amount = ($value->house_amount>0 && $value->house_amount !=null)?$value->house_amount:$value->total;
                $value->amount = $value->total;
            }
            if($value->type =="principle") {
                $value->amount = ($value->amount>0 && $value->amount !=null) ? $value->amount : $value->total_amount;
                $value->house_amount = ($value->house_amount>0 && $value->house_amount !=null) ? $value->house_amount : 0;
            }
        }
        return $print;
    }

    public function update(Request $request, $id)
    {
        // dd($request->all());
        
        $invoice = $this->invoice->find($id);
        // dd($invoice);
        $old_attachments = ($invoice->attachment != null) ? json_decode($invoice->attachment) : [];
        $attachments = [];

        for ($y = 0; $y < count($old_attachments); $y++) {
            $check = true;

            for ($x = 0; $x < count($request->old_file); $x++) {

                if ($request->old_file[$x] != null) {

                    if ($request->old_file[$x] == $old_attachments[$y]->file) {

                        $check = false;
                        array_push($attachments, ['title' => $request->title[$x], 'file' => $request->old_file[$x]]);
                    }
                }
            }

            if ($check) {
                Storage::delete('public/attachments/' . $old_attachments[$y]->file);
            }
        }

        if ($request->has('attach_file')) {

            foreach ($request->attach_file as $key => $file)
                for ($x = 0; $x < count($request->attach_file); $x++) {

                    $store_file_name = '';
                    $fullName = $file->getClientOriginalName();
                    $filename = pathinfo($fullName, PATHINFO_FILENAME);
                    $fileExtension = $file->getClientOriginalExtension();
                    $store_file_name = $filename . '-' . time() . '.' . $fileExtension;
                    $path = $file->storeAs('public/attachments', $store_file_name);

                    array_push($attachments, ['title' => $request->title[$key], 'file' => $store_file_name]);
                }
        }

        if ($invoice) {

            Transaction::destroy($invoice->transaction_id);
            $account       = (new Account())->getAccountByName('Invoice Account');
            $type = null;
            
            if($request->check_principle != 'false'){
                $type = 'commission_principle';
            } else {
                $type          = ($request->is_comission != 'false') ? 'commission' : 'principle';
            }

            $invoice_total = 0;
            
            for ($x = 0; $x < count($request->location); $x++) {
                
                if($request->check_principle != 'false'){
                    $invoice_total += ($request->total[$x] != null) ? $request->total[$x] : 0;
                    $invoice_total += ($request->total_priciple[$x] > 0) ? $request->total_priciple[$x] : 0;
                }else {
                    
                    $invoice_total += ($request->total[$x] != null) ? $request->total[$x] : 0;
                }
            }

            $remark = 'Invoice' . $request->invoice_number;
            $transaction   = pushTransaction($account->id, $account->name, $invoice_total, $request->currency, $request->exchange_rate, 'dr', $remark, $request->date, $request->location_id);

            $invoice->update([
                'organization_id'   => $request->company,
                'project_id'        => ($request->is_cashe == 'cache') ? $request->cash_id : $request->project,
                'invoice_no'        => $request->invoice_number,
                'transaction_id'    => $transaction->id,
                'date'              => $request->date,
                'currency'          => $request->currency,
                'exchange_rate'     => $request->exchange_rate,
                'exchange_currency' => $request->exchange_currency,
                'exchange_rate_second' => $request->exchange_rate_second,
                'vol_rep'           => $request->vol_rep,
                'description'       => $request->desc,
                'purpose'           => $request->purpose,
                'attachment'        => (count($attachments) > 0) ? json_encode($attachments) : null,
                'parent_id'         => $request->parent_id,
                'location_id'       => $request->location_id,
                'type'              => ($request->is_cashe == 'cache' && $request->check_principle == 'false') ? 'cashe' : $type,
                'is_show'           => ($request->has('is_show')) ? true : false
            ]);

            $this->invoice_details->where('invoice_id', $id)->delete();
            
            for ($x = 0; $x < count($request->location); $x++) {

                if (($request->has_location == 'false' && ($request->total[$x]>0) ) || $request->location[$x]!=null)  {
                    $this->invoice_details->create([
                        'invoice_id'            => $invoice->id,
                        'location'              => $request->has_location == 'true'?$request->location[$x]:null,
                        'household'             => $request->household[$x],
                        'amount'                => ($request->has_amount == 'true') ? ($request->amount[$x] > 0 ? $request->amount[$x] : $request->total[$x]) : 0,
                        'service_fee_percent'   => ($request->has('service_amount')) ? $request->service_fee_percent[$x]?$request->service_fee_percent[$x]: null :null,
                        'service_fee_amount'    => ($request->has('service_amount')) ? $request->service_amount[$x]?$request->service_amount[$x]:null : null,
                        'total_amount'          => $request->total[$x],
                        'total'                 => ($request->check_principle != 'false') ? $request->total_priciple[$x] : (($request->amount[$x] > 0)?($request->amount[$x] * $request->household[$x]) : $request->total[$x]),
                        'date'                  => $request->date_d[$x],
                        'purchase_order'        => $request->purchase_order[$x],
                        'company_id'            => auth()->user()->current_company,
                        'location_id'           => $request->location_id
                    ]);
                }
            }
        }

        return redirect()->route('invoice.index');
    }

    public function destroy(Request $request, $id)
    {

        $count = 0;
        try {

            if (count($request->ids) > 0) {

                $invoices = $this->invoice->whereIn('id', $request->ids)->get();
                DB::beginTransaction();

                foreach ($invoices as $key => $value) {

                    $this->invoice_details->where('invoice_id', $value->id)->delete();
                    Transaction::destroy($value->transaction_id);
                    deleteRecord('invoices', 'id', $value->id);
                }
                DB::commit();

                return ['result' => 1, 'message' => __('message.success')];
            } else {
                // DB::beginTransaction();
                $this->invoice_details->where('invoice_id', $id)->delete();
                $invoice = $this->invoice->find($id);
                Transaction::destroy($invoice->transaction_id);
                deleteRecord('invoices', 'id', $invoice->id);
                return ['result' => 1, 'message' => __('message.success')];
                // DB::commit();
            }

            // return ['result' => 0, 'message' => 'First Delete Related Data'];
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => __('message.error')], 422);
        }
    }
}
