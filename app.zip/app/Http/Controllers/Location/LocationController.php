<?php

namespace App\Http\Controllers\Location;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Province;
use Illuminate\Support\Facades\DB;

class LocationController extends Controller
{
    protected $location;
    function __construct(Province $location) {
        $this->location = $location;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $zones   = DB::table('zones')->get();
        if($request->ajax())
        {
            return $this->location->getLocations($request);
        }
        return view('locations.index',compact('zones'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = [
            'name'                   => $request->name,
            'dashboard_client_code'  => $request->dashboard_client_code,
            'code'                   => $request->code,
            'zone_id'                => $request->zone_id,
        ];
        $this->location->create($data);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return $this->location->find($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $location = $this->location->find($id);
        $data = [
            'name'                   => $request->name,
            'dashboard_client_code'  => $request->dashboard_client_code,
            'code'                   => $request->code,
            'zone_id'                => $request->zone_id,
        ];
        $location->update($data);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
        $related_tables = ['invoices'];
        $count = 0;
        try {
            if(count($request->ids) > 0){
                $locations = $this->location->whereIn('id', $request->ids)->get();
                DB::beginTransaction();

                foreach ($locations as $key => $value) {
                    $project    = DB::table('projects')->where('province_id',$value->id)->first();
                    $invoice    = DB::table('invoices')->where('location_id',$value->id)->first();
                    $cash_drop  = DB::table('cash_drops')->where('province_id',$value->id)->first();
                    $invoice_detail  = DB::table('invoice_details')->where('location',$value->id)->first();
                    $cash_drop  = DB::table('payments')->where('province_id',$value->id)->first();
                    if($project || $invoice || $cash_drop || $invoice_detail){
                        $count += 1;
                    }else {
                        deleteRecord('provinces', 'id', $value->id);
                    }

                }
                DB::commit();
                if($count > 0){
                    return ['result' => 0, 'message' => 'First Delete Related Data'];
                } else {

                    return ['result' => 1, 'message' => __('message.success')];
                }
            } else {
                 DB::beginTransaction();
                $category = $this->location->find($id);

                if(checkForDelete($related_tables, 'location_id', $id) == false){

                    // $this->crd->where('currency_id', $id)->delete();
                    deleteRecord('provinces', 'id', $id);
                    return ['result' => 1, 'message' => __('message.success')];
                }
                // DB::commit();
            }

            return ['result' => 0, 'message' => 'First Delete Related Data'];
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => __('message.error')], 422);
        }
    }
}
