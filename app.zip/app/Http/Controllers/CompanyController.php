<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Company;
use App\Models\HomeCurrency;
use App\Models\CurrencyList;
use App\Models\Currency;
use App\Models\Account;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Auth;
use App\Jobs\CompanyCreate;
use Artisan;

class CompanyController extends Controller
{

    protected $company;
    protected $home_currency;

    public function __construct(Company $company, HomeCurrency $home_currency)
    {
        $this->company = $company;
        $this->home_currency = $home_currency;
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            return $this->company->companies($request);
        }
        return view('company.index');
    }

    public function create()
    {
        $currencies = CurrencyList::get();
        return view('company.create', compact('currencies'));
    }


    public function store(Request $request)
    {

        $companies = $this->company->get(['id']);
        $companies_number = count($companies);
        $is_first = true;
        if ($companies_number > 0) {
            $is_first = false;
        }

        $company_logo = 'logo.png';
        if ($request->has('photo')) {
            $store_file_name = '';
            $file = $request->photo;
            $fullName = $file->getClientOriginalName();
            $filename = pathinfo($fullName, PATHINFO_FILENAME);
            $fileExtension = $file->getClientOriginalExtension();
            $store_file_name = $filename . '-' . time() . '.' . $fileExtension;
            $path = $file->storeAs('public/logos', $store_file_name);
            $company_logo = $store_file_name;

        }

        $company = $this->company->create([
            'name'      => $request->name,
            'address'   => $request->address,
            'phone'     => $request->phone,
            'logo'      => $company_logo,
            'lang'      => 'en',
            'email'     => $request->email,
            'desc'      => $request->desc,
            'invoice_desc'      => $request->invoice_desc,
            'invoice_propuse'   => $request->purpose,
            'is_main'   => $is_first
        ]);

        if ($company) {

            $currency = CurrencyList::where('code', $request->currency)->first();

            $this->home_currency->create([
                'currency_id' => $currency->id,
                'code' => $currency->code,
                'symbol' => $currency->symbol,
                'exchange_rate' => 1,
                'company_id' => $company->id
            ]);

            if ($companies_number == 0) {

                $currencies = Currency::selectRaw("*")->get();

                for ($x = 0; $x < count($currencies); $x++) {
                    $currencies[$x]->update(['company_id' => $company->id]);
                }

                $accounts = Account::selectRaw("*")->get();

                for ($x = 0; $x < count($accounts); $x++) {
                    $accounts[$x]->update(['company_id' => $company->id]);
                }


                $user = User::find(auth()->id());
                $companies = $this->company->get([
                    'id', 'is_main'
                ]);
                $companies = $companies->toarray();
                $user->update([
                    'company_id' => $company->id,
                    'companies' => json_encode($companies),
                    'current_company' => $company->id
                ]);

            } else {

                $user = User::find(auth()->id());
                $companies = $this->company->get([
                    'id', 'is_main'
                ]);
                $companies = $companies->toarray();
                $user->update([
                    'companies' => json_encode($companies)
                ]);
            }
        }

        return redirect()->route('company.index');
    }

    public function show($id){

        $contras   = \DB::table('transactions')
            ->selectRaw("sum(transactions.amount)/transactions.rate as amount")->where('transactions.company_id', $id)
            ->where('account_name','Contra Account')
            ->value('amount');
        $receipts   = \DB::table('transactions')
            ->selectRaw("sum(transactions.amount)/transactions.rate as amount")->where('transactions.company_id', $id)
            ->where('account_name','Income Account')
            ->value('amount');
        $balance = $receipts - $contras;
        $company   = $this->company->where('id', $id)->first();
        return view('company.profile',compact('company','balance'));
    }

    public function edit($id)
    {
        $company = $this->company->find($id);
        $currencies = CurrencyList::get();
        $home_currency = $this->home_currency->where('company_id', $company->id)->first();
        return view('company.edit', compact('currencies', 'company', 'home_currency'));
    }


    public function update(Request $request, $id)
    {

        $company = $this->company->find($id);
        $company_logo = 'logo.png';
        
        if ($request->has('photo')) {
            if(file_exists(public_path('storage/logos/'.$company->logo))){
                unlink(public_path('storage/logos/'.$company->logo));
            }
            $store_file_name = '';
            $file = $request->photo;
            $fullName = $file->getClientOriginalName();
            $filename = pathinfo($fullName, PATHINFO_FILENAME);
            $fileExtension = $file->getClientOriginalExtension();
            $store_file_name = $filename . '-' . time() . '.' . $fileExtension;
            $path = $file->storeAs('public/logos', $store_file_name);
            $company_logo = $store_file_name;

        } else {
            $company_logo = $company->logo;
        }

        if ($company) {
            $company = $company->update([
                'name'      => $request->name,
                'address'   => $request->address,
                'phone'     => $request->phone,
                'logo'      => $company_logo,
                'email'     => $request->email,
                'desc'      => $request->desc,
                'invoice_desc'      => $request->invoice_desc,
                'invoice_propuse'   => $request->purpose
            ]);

            $home_currency = $this->home_currency->where('company_id', $id)->first();

            if ($home_currency->code != $request->currency) {

                $currency = CurrencyList::where('code', $request->currency)->first();
                $home_currency->update([
                    'currency_id' => $currency->id,
                    'code' => $currency->code,
                    'symbol' => $currency->symbol
                ]);
            }

        }
        return redirect()->route('company.index');
    }


    public function switchCompany($id)
    {
        $user = User::find(auth()->id());
        // dd($id);
        $user->update([
            'current_company' => $id
        ]);

        // dd('yes');
        return redirect()->route('dashboard');
    }

    public function profile()
    {
        $contras   = \DB::table('transactions')
            ->selectRaw("sum(transactions.amount)/transactions.rate as amount")->where('transactions.company_id',auth()->user()->current_company)
            ->where('account_name','Contra Account')
            ->value('amount');
        $receipts   = \DB::table('transactions')
            ->selectRaw("sum(transactions.amount)/transactions.rate as amount")->where('transactions.company_id',auth()->user()->current_company)
            ->where('account_name','Income Account')
            ->value('amount');
        $balance = $receipts - $contras;
        $company   = $this->company->where('id',\auth()->user()->current_company)->first();
        return view('company.profile',compact('company','balance'));
    }


}
