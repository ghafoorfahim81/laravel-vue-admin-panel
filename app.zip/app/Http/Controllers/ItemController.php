<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Item;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use App\Mail\MailNotify;
use Illuminate\Support\Facades\Mail;
use Artisan;

class ItemController extends Controller
{
     
    protected $item;

    public function __construct(Item $item)
    {
        $this->item    = $item;

    }

    public function index(Request $request){
        
        // setDB();
        // $items = $this->item->get(['id', 'name', 'description']);
        // dd(auth()->user()->companies);
        // $items = json_encode($items);
        // dd($items);
        // return $items;
        if ($request->ajax()) {
            // setDB();
            $items = $this->item->itemList($request);
            
            return $items;
        }
        Artisan::call('optimize:clear');
        Config::set("database.connections.mysql", [
            'driver' => 'mysql',
            'host' => '127.0.0.1',
            'port' => '3306',
            'database' => 'ngo',
            'username' => 'root'
        ]);
        DB::purge('mysql');
        return view('item.index');
    }

    public function create(){
        // dd('yes');
        return view('item.create');
    }

    public function store(Request $request){

        // return $request->all();
        $this->item->create([
            'name'          => $request->name,
            'description'   => $request->desc,
            'user_id'       => auth()->user()->id,
        ]);

        return 'successfully';
    }

    public function edit(Request $request){
        $item = $this->item->find($request->id);
        return $item;
    }

    public function update(Request $request){

        $item = $this->item->find($request->id);
        $item->update([
            'name'          => $request->name,
            'description'   => $request->desc
        ]);

        return 'successfully';
    }

    public function getItems(){
        
        $items = $this->item->get(['id', 'name']);
        return $items;
    }


    public function sendMail(){
        
        $data = [
            'subject'   => 'Welcome mail',
            'body'      => 'Title How to Send Email using Gmail SMTP Server in Laravel 9 
                            In Laravel Framework provide Mail class that allow to send email from web app. We are required only configuration and add a few settings to activate this feature.'
        ];

        try {
            Mail::to('ramazanshakibani96@gmail.com')->send(new MailNotify($data));

            dd('yes');
        } catch (Exception $e) {
            dd($e);   
        }
    }
}
