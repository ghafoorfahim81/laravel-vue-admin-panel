<?php

namespace App\Http\Controllers;

use App\Models\Account;
use Illuminate\Http\Request;

class AccountController extends Controller
{
    protected $account;

    public function __construct(Account $account)
    {
        $this->account = $account;
    }

    public function index(Request $request)
    {
        if($request->ajax())
            return $this->account->accountList($request);
        return view('account.index');
    }

    public function create()
    {
        return view('account.create');
    }
    public function store(Request $request)
    {
        // return $request->all();
        $data = [
            'name'=>$request->name,
            'station'=>$request->station,
            'account_no'=>$request->account_number,
            'address'=>$request->address,
            'contact_person'=>$request->contact_person,
            'phone_no'=>$request->phone,
            'email'=>$request->email,
            'currency'=>$request->currency,
            'swift'=>$request->swift,
            'user_id'=>auth()->id(),
            'company_id'=> auth()->user()->current_company
        ];
        $this->account->create($data);
        return redirect('account');

    }
    public function edit($id)
    {
        $account = $this->account->find($id);
        return view('account.edit', compact('account'));
    }

    public function update(Request $request, $id)
    {
        $account = $this->account->find($id);
        $data = [
            'name'=>$request->name,
            'station'=>$request->station,
            'account_no'=>$request->account_number,
            'address'=>$request->address,
            'contact_person'=>$request->contact_person,
            'phone_no'=>$request->phone,
            'email'=>$request->email,
            'currency'=>$request->currency,
            'swift'=>$request->swift,
            'user_id'=>auth()->id()
        ];
        $account->update($data);
        return redirect('account');
    }
}
