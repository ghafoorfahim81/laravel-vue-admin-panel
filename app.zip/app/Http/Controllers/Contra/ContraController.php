<?php

namespace App\Http\Controllers\Contra;

use App\Http\Controllers\Controller;
use App\Models\Account;
use App\Models\Company;
use App\Models\Contra;
use App\Models\Currency;
use App\Models\HomeCurrency;
use App\Models\Project;
use App\Models\Province;
use App\Models\Transaction;
use Illuminate\Http\Request;

class ContraController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $contra;

    public function __construct(Contra $contra)
    {
        $this->contra = $contra;
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            return $this->contra->contras($request);
        }
        return view('cash_drops.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $companies = Company::where('id', auth()->user()->current_company)->first(['name', 'id'])->toArray();
        $projects = Project::where('company_id', auth()->user()->current_company)->get(['name', 'id']);
        $provinces = Province::get(['name', 'id']);
        $currencies = Currency::get(['id',
            'name',
            'code',
            'symbol',
            'exchange_rate as rate',
            'exchange_rate']);
        $selected_currency = HomeCurrency::where('company_id', auth()->user()->current_company)->first(['code', 'exchange_rate as rate']);
        return view('cash_drops.create', compact('projects', 'provinces', 'currencies', 'selected_currency', 'companies'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $account = (new Account())->getAccountByName('Contra Account');
        $homeCurrency = homeCurrency()['code'];
        $remark = 'Contra' . $request->date;
        $currency = Currency::where('code', $request->currency)->first();
        $transaction = pushTransaction($account->id, $account->name, $request->amount, $request->currency, $request->rate, 'dr', $remark, $request->date);
        $contra = $this->contra->create([
            'company_id' => auth()->user()->current_company,
            'transaction_id' => $transaction->id,
            'request_id' => $request->request_id,
            'receipt_no' => $request->receipt_no,
            'date' => $request->date,
            'purpose' => $request->purpose,
        ]);

        if ($contra) {
            return redirect()->route('contra.index');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $companies = Company::where('id', auth()->user()->current_company)->first(['name', 'id'])->toArray();
        $projects = Project::where('company_id', auth()->user()->current_company)->get(['name', 'id']);
        $contra = $this->contra->getContra($id);
        $provinces = Province::get(['name', 'id']);
        $currencies = Currency::get(['id',
            'name',
            'code',
            'symbol',
            'exchange_rate as rate',
            'exchange_rate']);
        $selected_currency = HomeCurrency::where('company_id', auth()->user()->current_company)->first(['code', 'exchange_rate as rate']);
        return view('cash_drops.edit', compact('projects', 'provinces', 'currencies', 'selected_currency', 'companies', 'contra'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $contra = $this->contra->find($id);
        $account = (new Account())->getAccountByName('Contra Account');
        $homeCurrency = homeCurrency()['code'];
        $remark = 'Contra' . $request->date;
        Transaction::destroy($contra->transaction_id);
        $transaction = pushTransaction($account->id, $account->name, $request->amount, $request->currency, $request->rate, 'dr', $remark, $request->date);
        $contraUpdate = $contra->update([
            'company_id' => auth()->user()->current_company,
            'transaction_id' => $transaction->id,
            'request_id' => $request->request_id,
            'receipt_no' => $request->receipt_no,
            'date' => $request->date,
            'purpose' => $request->purpose,
        ]);

        if ($contraUpdate) {
            return redirect()->route('contra.index');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
        try {

            if(count($request->ids) > 0){

                $contras = $this->contra->whereIn('id', $request->ids)->get();
                \DB::beginTransaction();

                foreach ($contras as $key => $value) {
                    Transaction::destroy($value->transaction_id);
                    deleteRecord('cash_drops', 'id', $value->id);
                }
                \DB::commit();

                return ['result' => 1, 'message' => __('message.success')];

            } else {
//                \DB::beginTransaction();
                $contra = $this->contra->find($id);
                Transaction::destroy($contra->transaction_id);
                deleteRecord('cash_drops', 'id', $id);

                return ['result' => 1, 'message' => __('message.success')];

//                \DB::commit();
            }

            return ['result' => 0, 'message' => 'First Delete Related Data'];
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json(['message' => __('message.error')], 422);
        }
    }
}
