<?php

namespace App\Models;

use App\Traits\Uuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;

class Payment extends Model
{
    use HasFactory, Uuids;

    protected $fillable = [
        'project_id',
        'organization_id',
        'currency',
        'number',
        'date',
        'location_id',
        'transaction_id',
        'cheque_no',
        'description',
        'company_id',
        'province_id'
    ];

    public function payments($request)
    {
        $filter = $request->input('filter');
        $per_page = $request->input('per_page');
        $current_page = $request->input('current_page');
        $sort_by = $request->input('sort_by');
        $descending = $request->input('descending');
        $query = null;
        $project_id  = $request->project_id;

        if(auth()->user()->type == 'province'){
            $query = $this->leftJoin('transactions', 'transactions.id', 'payments.transaction_id')
                ->leftJoin('payment_details', 'payment_details.payment_id', 'payments.id')
                ->selectRaw('transactions.amount as amount,sum(payment_details.quantity) as beneficiaries,
                payments.*')
                ->groupBy('payment_details.payment_id')
                ->where('payments.company_id', auth()->user()->current_company)
                ->where('payments.project_id', $request->project_id);
        } else {
            $query = $this->leftJoin('transactions', 'transactions.id', 'payments.transaction_id')
                ->join('payment_details', 'payment_details.payment_id', 'payments.id')
                ->selectRaw('transactions.amount as amount,sum(payment_details.quantity) as beneficiaries,
                payments.*')
                ->groupBy('payment_details.payment_id')
                ->where('payments.project_id', $request->project_id)
                ->where('payments.company_id', auth()->user()->current_company);
        }

        if ($filter != '') {
            $query = $query->where('payments.name', 'like', '%' . $filter . '%')
                ->orwhere('companies.number', 'like', '%' . $filter . '%')
                ->orwhere('companies.name', 'like', '%' . $filter . '%') ;
        }

        // if ($descending === "true") {
        //      $query = $query->orderBy($sort_by, 'desc');
        //  } else {
        //      $query = $query->orderBy($sort_by, 'asc');
        //  }
        Paginator::currentPageResolver(function () use ($current_page) {
            return $current_page;
        });
        return $query->paginate($per_page);
    }

    public function paymentDetails()
    {
        return $this->hasMany('App\Models\PaymentDetails', 'payment_id');
    }

//    edit payment function
    public function editPayment($id){
        return $this->leftjoin('payment_details','payment_details.payment_id','payments.id')
                    ->selectRaw('payments.*,payments.id as id,payment_details.*')
                    ->where('payments.id',$id)
                    ->groupBy('payment_details.payment_id')
                    ->get();
    }
}
