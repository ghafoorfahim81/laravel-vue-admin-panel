<?php

namespace App\Models;

use App\Traits\Uuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;

class CashDrop extends Model
{
    use HasFactory, Uuids;

    protected $fillable = [
        'company_id',
        'transaction_id',
        'request_id',
        'province_id',
        'date',
        'purpose',
        'attachments',
        'location_id',
    ];
    public function cash_drops($request)
    {
        $filter     = $request->input('search_keyword');
        $per_page   = $request->input('per_page') ? $request->input('per_page') : 10;
        $start_page = $request->input('current_page');
        $order_by   = $request->input('order_by');
        $order_direction = $request->input('order_direction');
        $type       = $request->input('type');
        $company_id = auth()->user()->current_company;

        if($type == 'invoiced'){

            $query = $this->join('invoices','invoices.project_id','cash_drops.id')
                ->leftjoin('transactions','transactions.id','cash_drops.transaction_id')
                ->leftjoin('provinces','provinces.id','cash_drops.province_id')
                ->selectRaw('transactions.amount,transactions.currency,provinces.name as location,cash_drops.*')
                ->where('cash_drops.company_id', $company_id);
            if ($order_direction != '' || $order_by != '') {
                $query = $query->orderBy($order_by, $order_direction);
            }
            if ($filter != '') {
                $query = $query->where('cash_drops.request_id', 'like', '%' . $filter . '%')
                    ->orwhere('cash_drops.receipt_no', 'like', '%' . $filter . '%')
                    ->cash_drop('cash_drops.purpose', 'like', '%' . $filter . '%')
                    ->orwhere('transactions.currency', 'like', '%' . $filter . '%');
            }
            Paginator::currentPageResolver(function () use ($start_page) {
                return $start_page;
            });
            return $query->paginate($per_page);
        } else {

            $query = $this->leftjoin('transactions','transactions.id','cash_drops.transaction_id')
                ->leftjoin('provinces','provinces.id','cash_drops.province_id')
                ->selectRaw('transactions.amount,transactions.currency,provinces.name as location,cash_drops.*')
                ->where('cash_drops.company_id', $company_id)
                ->whereNotExists(function($query){
                    $query->select(DB::raw('invoices.project_id'))
                        ->from('invoices')
                        ->whereRaw('invoices.project_id = cash_drops.id');
                });
            if ($order_direction != '' || $order_by != '') {
                $query = $query->orderBy($order_by, $order_direction);
            }
            if ($filter != '') {
                $query = $query->where('cash_drops.request_id', 'like', '%' . $filter . '%')
                    ->orwhere('cash_drops.receipt_no', 'like', '%' . $filter . '%')
                    ->cash_drop('cash_drops.purpose', 'like', '%' . $filter . '%')
                    ->orwhere('transactions.currency', 'like', '%' . $filter . '%');
            }
            Paginator::currentPageResolver(function () use ($start_page) {
                return $start_page;
            });
            return $query->paginate($per_page);
        }


    }

    public function getCash_drops($id){
        return $this->leftjoin('transactions','transactions.id','cash_drops.transaction_id')
            ->leftjoin('provinces','provinces.id','cash_drops.province_id')
            ->leftjoin('companies','companies.id','cash_drops.company_id')
            ->selectRaw('transactions.amount,transactions.currency,transactions.rate,cash_drops.id as id,cash_drops.*,companies.name as company,provinces.name as province')
            ->where('cash_drops.id',$id)
            ->first();
    }

    public function getCashDropInvoiceDetails($id)
    {
        $query = $this->leftjoin('invoices','invoices.project_id','cash_drops.id')
                      ->leftjoin('invoice_details','invoice_details.invoice_id','invoices.id')
                      ->leftjoin('provinces','provinces.id','invoice_details.location')
                      ->selectRaw('invoice_details.*,provinces.name as location')
                      ->where('invoices.project_id',$id)
                      ->get();
            return $query;
    }
}
