<?php

namespace App\Models;

use App\Traits\Uuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExpenseDetails extends Model
{
    use HasFactory,Uuids;
    protected $fillable = ['description','amount','expense_id', 'company_id', 'location_id'];
}
