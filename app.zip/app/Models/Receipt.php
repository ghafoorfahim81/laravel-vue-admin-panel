<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\Uuids;
use Illuminate\Pagination\Paginator;

class Receipt extends Model
{
    use HasFactory,Uuids;
    protected $fillable = [
        'organization_id',
        'date',
        'type',
        'supplier_id',
        'description',
        'user_id',
        'company_id',
        'receipt_no',
        'location_id'
    ];
    public function receipts($request){
        $filter = $request->search_keyword;
        $per_page = $request->input('per_page');
        $current_page = $request->input('current_page');
        $sort_by = $request->input('sort_by');
        $descending = $request->input('descending');
        $query = null;
//  return $request->all();
        if(auth()->user()->type == 'province'){

            $query = $this->leftJoin('receipt_details','receipt_details.receipt_id','receipts.id')
            ->selectRaw('receipts.*,sum(receipt_details.amount) as amount')
            ->groupBy('receipt_details.receipt_id')
            ->whereIn('receipt_details.location_id', json_decode(auth()->user()->location_id,true));
        } else {

            $query = $this->leftJoin('receipt_details','receipt_details.receipt_id','receipts.id')
            ->selectRaw('receipts.*,sum(receipt_details.amount) as amount')
            ->groupBy('receipt_details.receipt_id')
            ->where('receipts.company_id', auth()->user()->current_company);
        }
        if ($filter != '') {

            $query = $query->where('receipts.receipt_no', 'like', '%' . $filter . '%')  ;
        }

        // if ($descending === "true") {
        //     $query = $query->orderBy($sort_by, 'desc');
        // } else {
        //     $query = $query->orderBy($sort_by, 'asc');
        // }
        Paginator::currentPageResolver(function () use ($current_page) {
            return $current_page;
        });
        return $query->paginate($per_page);
    }
    public function receiptDetails(){
        return $this->hasMany('App\Models\ReceiptDetails', 'receipt_id');
    }

    public function editReceiptDetails($id){
        return  $this->leftJoin('receipt_details','receipt_details.receipt_id','receipts.id')
            ->leftjoin('invoices', 'invoices.invoice_no', 'receipt_details.invoice_no')
            ->leftjoin('projects', 'projects.id', 'invoices.project_id')
            ->selectRaw('invoices.*,
                    invoices.id as id,
                    projects.name as project,
                    projects.province_id,
                    receipt_details.transaction_id as transaction_id,
                    receipt_details.id as detail_id,
                    receipt_details.amount as amount,
                    receipt_details.currency')
            ->where('receipts.id',$id)
            ->get();
    }

}
