<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;
use App\Traits\Uuids;

class InvoiceDetails extends Model
{
    use HasFactory, Uuids;

    protected $table = "invoice_details";

    protected $fillable = [
        'invoice_id',
        'location',
        'household',
        'amount',
        'service_fee_percent',
        'service_fee_amount',
        'total_amount',
        'total',
        'date',
        'purchase_order',
        'company_id',
        'location_id',
        'invoice_id',
    ];


    public function getInvoiceDetails($invoice_id){

        return DB::table('invoice_details')
                ->leftjoin('provinces', 'provinces.id', 'invoice_details.location')
                ->select(
                    'provinces.name as province',
                    'invoice_details.household',
                    'invoice_details.amount',
                    'invoice_details.total',
                    'invoice_details.service_fee_percent',
                    'invoice_details.service_fee_amount',
                    'invoice_details.total_amount',
                    )
                ->where('invoice_details.invoice_id', $invoice_id)
                ->get();
    }
}
