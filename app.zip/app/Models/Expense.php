<?php

namespace App\Models;

use App\Traits\Uuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;
use Mockery\Undefined;

class Expense extends Model
{
    use HasFactory, Uuids;
    protected $fillable = ['category_id', 'transaction_id', 'date', 'description', 'company_id', 'location_id'];
    public function expenseList($request)
    {
        $filter = $request->input('search_keyword');
        $per_page = $request->per_page;
        // $per_page = $request->input('per_page') ? $request->input('per_page') : 10;
        $start_page = $request->input('current_page');
        $order_by = $request->input('order_by');
        $order_direction = $request->input('order_direction');
        $query = DB::table('expenses')
            ->leftJoin('categories', 'categories.id', 'expenses.category_id')
            ->leftJoin('expense_details', 'expense_details.expense_id', 'expenses.id')
            ->selectRaw('expenses.id, expenses.date, expenses.description,categories.name as category, sum(expense_details.amount) as amount') 
            ->whereIn('expenses.location_id', json_decode(auth()->user()->location_id, true))
            ->groupBy('expenses.id');
        if ($order_direction != '' || $order_by != '') {
            $query = $query->orderBy($order_by, $order_direction);
        }
        if ($filter != '') {
            $query = $query->where('expenses.date', 'like', '%' . $filter . '%');
            // ->orwhere('expenses.code', 'like', '%' . $filter . '%')
            // ->orwhere('expenses.symbol', 'like', '%' . $filter . '%')
            // ->orwhere('expenses.format', 'like', '%' . $filter . '%')
            // ->orwhere('expenses.exchange_rate', 'like', '%' . $filter . '%');
        }
        Paginator::currentPageResolver(function () use ($start_page) {
            return $start_page;
        });

        return $query->paginate($per_page);
    }
    public function edit($id)
    {
        return DB::table('expenses')
            ->leftJoin('transactions', 'transactions.id', 'expenses.transaction_id')
            ->leftJoin('expense_details', 'expense_details.expense_id', 'expenses.id')
            ->selectRaw('expenses.date, expenses.id, expenses.description as details, expenses.category_id,expense_details.amount, expense_details.description, transactions.currency, transactions.rate')
            ->where('expenses.id', $id)
            ->get();
    }

    public function report($request)
    {
        $filter = $request->input('search_keyword');
        $per_page = $request->input('per_page') ? $request->input('per_page') : 10;
        $start_page = $request->input('current_page');
        $order_by = $request->input('order_by');
        $order_direction = $request->input('order_direction');
        $type = $request->type;
        $from = $request->from;
        $to = $request->to;
        $selected_type = $request->selected_type;
        $location = $request->selected_location;
        $zone = $request->selected_zone;

        if ($type == 'expenses') {
            $query = DB::table('expenses')
                ->leftJoin('categories', 'categories.id', 'expenses.category_id')
                ->leftJoin('expense_details', 'expense_details.expense_id', 'expenses.id')
                ->selectRaw('expenses.id, expenses.date, expenses.description,categories.name as category, sum(expense_details.amount) as amount')
                ->groupBy('expenses.id')
                ->whereIn('expenses.location_id', json_decode(auth()->user()->location_id, true));
            // if (auth()->user()->type == 'province')
                $query = $query->where('expenses.company_id', auth()->user()->current_company);
            if ($from != "null" && $to != "null") {
                $query = $query->whereBetween('expenses.created_at', [$from, $to]);
            }
            if ($selected_type != 'undefined') {
                $query = $query->where('categories.id', $selected_type);
            }
            if ($order_direction != '' || $order_by != '') {
                $query = $query->orderBy($order_by, $order_direction);
            }
            if ($filter != '') {
                $query = $query->where('expenses.date', 'like', '%' . $filter . '%');
                // ->orwhere('expenses.code', 'like', '%' . $filter . '%')
                // ->orwhere('expenses.symbol', 'like', '%' . $filter . '%')
                // ->orwhere('expenses.format', 'like', '%' . $filter . '%')
                // ->orwhere('expenses.exchange_rate', 'like', '%' . $filter . '%');
            }
            Paginator::currentPageResolver(function () use ($start_page) {
                return $start_page;
            });

            return $query->paginate($per_page);
        } elseif ($type == 'receipts') {
            // $query = DB::table('receipts')->leftJoin('receipt_details', 'receipts.id', 'receipt_details.receipt_id')
            // ->leftJoin('transactions', 'transactions.id', 'receipt_details.transaction_id')
            //     ->selectRaw('receipts.*,transactions.amount')
            //     ->where('receipts.company_id', auth()->user()->current_company);
            $query='';
            if(auth()->user()->type == 'province'){

                $query = DB::table('receipts')->leftJoin('receipt_details','receipt_details.receipt_id','receipts.id')
                ->selectRaw('receipts.*,sum(receipt_details.amount) as amount')
                ->groupBy('receipt_details.receipt_id') 
                ->where('receipts.company_id', auth()->user()->current_company)
                ->whereIn('receipt_details.location_id', json_decode(auth()->user()->location_id,true));
            } else {
    
                $query = DB::table('receipts')->leftJoin('receipt_details','receipt_details.receipt_id','receipts.id')
                ->selectRaw('receipts.*,sum(receipt_details.amount) as amount')
                ->groupBy('receipt_details.receipt_id')
                ->where('receipts.company_id', auth()->user()->current_company);
            }
            if ($filter != '') {
                $query = $query->where('receipts.receipt_no', 'like', '%' . $filter . '%')  ;
            }
            if ($from != "null" && $to != "null") {
                $query = $query->whereBetween('receipts.created_at', [$from, $to]);
            }
            

            if ($order_direction != '' || $order_by != '') {
                $query = $query->orderBy($order_by, $order_direction);
            }
            // if ($descending === "true") {
            //     $query = $query->orderBy($sort_by, 'desc');
            // } else {
            //     $query = $query->orderBy($sort_by, 'asc');
            // }
            Paginator::currentPageResolver(function () use ($start_page) {
                return $start_page;
            });
            return $query->paginate($per_page);
        } elseif ($type == 'payments') {
            $query = '';
            if(auth()->user()->type == 'province'){
                $query = DB::table('payments')->leftJoin('transactions', 'transactions.id', 'payments.transaction_id')
                    ->leftJoin('payment_details', 'payment_details.payment_id', 'payments.id')
                    ->leftJoin('projects', 'projects.id', 'payments.project_id')
                    ->leftJoin('provinces', 'provinces.id', 'projects.location_id')
                    ->selectRaw('transactions.amount as amount,sum(payment_details.quantity) as beneficiaries,
                    payments.*, projects.name as project, provinces.name as location')
                    ->groupBy('payment_details.payment_id')
                    ->where('payments.company_id', auth()->user()->current_company)
                    // ->where('payments.project_id', $request->project_id)
                    ->whereIn('payments.province_id', json_decode(auth()->user()->location_id,true));
            } else {
                $query = DB::table('payments')->leftJoin('transactions', 'transactions.id', 'payments.transaction_id')
                    ->join('payment_details', 'payment_details.payment_id', 'payments.id')
                    ->leftJoin('projects', 'projects.id', 'payments.project_id')
                    ->leftJoin('provinces', 'provinces.id', 'projects.location_id')
                    ->selectRaw('transactions.amount as amount,sum(payment_details.quantity) as beneficiaries,
                    payments.*, projects.name as project, provinces.name as location')
                    ->groupBy('payment_details.payment_id')
                    // ->where('payments.project_id', $request->project_id)
                    ->where('payments.company_id', auth()->user()->current_company);
            }
            // $query = DB::table('payments')->leftJoin('companies', 'companies.id', 'payments.company_id')
            //     ->leftJoin('projects', 'projects.id', 'payments.project_id')
            //     ->leftJoin('transactions', 'transactions.id', 'payments.transaction_id')
            //     ->leftJoin('provinces', 'payments.location_id', 'provinces.id')
            //     ->selectRaw('transactions.amount as amount,projects.name as project,payments.*,provinces.name as location')
            //     ->whereIn('payments.location_id', json_decode(auth()->user()->location_id, true));
            // if (auth()->user()->type == 'province')
            //     $query = $query->where('payments.company_id', auth()->user()->current_company);
            if ($from != "null" && $to != "null") {
                $query = $query->whereBetween('payments.created_at', [$from, $to]);
            }
            if ($selected_type != 'undefined') {
                $query = $query->where('projects.id', $selected_type);
            }
            if ($filter != '') {
                $query = $query->where('payments.name', 'like', '%' . $filter . '%')
                    ->orwhere('companies.number', 'like', '%' . $filter . '%')
                    ->orwhere('companies.name', 'like', '%' . $filter . '%')
                    ->orwhere('projects.name', 'like', '%' . $filter . '%');
            }
            if ($order_direction != '' || $order_by != '') {
                $query = $query->orderBy($order_by, $order_direction);
            }
            // if ($descending === "true") {
            //      $query = $query->orderBy($sort_by, 'desc');
            //  } else {
            //      $query = $query->orderBy($sort_by, 'asc');
            //  }
            Paginator::currentPageResolver(function () use ($start_page) {
                return $start_page;
            });
            return $query->paginate($per_page);
        } elseif ($type == 'orders') {

            $query = DB::table('orders')->leftJoin('order_details', 'order_details.order_id', 'orders.id')
                ->leftJoin('companies', 'companies.id', 'orders.organization_id')
                ->leftJoin('projects', 'projects.id', 'orders.project_id')
                ->selectRaw('orders.id, 
                  orders.number,
                  sum((order_details.quantity*order_details.price) * orders.exchange_rate ) as amount,
                  projects.name as project,
                  companies.name as company, 
                  orders.currency,
                  orders.created_at as date')
                ->groupBy('orders.id', 'orders.number', 'projects.name', 'companies.name', 'orders.created_at')
                ->whereIn('orders.location_id', json_decode(auth()->user()->location_id, true));
            // if (auth()->user()->type == 'province')
                $query = $query->where('orders.company_id', auth()->user()->current_company);
            if ($from != "null" && $to != "null") {
                $query = $query->whereBetween('orders.created_at', [$from, $to]);
            }
            if ($selected_type != 'undefined') {
                $query = $query->where('projects.id', $selected_type);
            }
            if ($filter != '') {
                $query = $query->where('orders.currency', 'like', '%' . $filter . '%')
                    ->orwhere('companies.name', 'like', '%' . $filter . '%')
                    ->orwhere('projects.name', 'like', '%' . $filter . '%');
            }

            if ($order_direction != '' || $order_by != '') {
                $query = $query->orderBy($order_by, $order_direction);
            }
            Paginator::currentPageResolver(function () use ($start_page) {
                return $start_page;
            });

            return $query->paginate($per_page);
        } elseif ($type == 'invoices') {

            $query = DB::table('invoices')->leftJoin('invoice_details', 'invoice_details.invoice_id', 'invoices.id')
                ->leftJoin('companies', 'companies.id', 'invoices.organization_id')
                ->leftJoin('projects', 'projects.id', 'invoices.project_id')
                ->leftJoin('provinces', 'provinces.id', 'projects.location_id')
                ->leftjoin('transactions', 'transactions.id', 'invoices.transaction_id')
                ->selectRaw('invoices.id,
                invoices.invoice_no,
                (transactions.amount)/transactions.rate as amount,
                projects.name as project,
                companies.name as company,
                invoices.currency,
                provinces.name as location,
                (CASE 
                    WHEN invoices.parent_id != "" THEN "comission" 
                    ELSE "principle" 
                END) AS type,
                DATE_FORMAT(invoices.date, "%Y-%m-%d") as date,
                invoices.created_at')
                ->groupBy('invoices.id', 'invoices.invoice_no', 'projects.name', 'companies.name', 'invoices.created_at')
                ->whereIn('invoices.location_id', json_decode(auth()->user()->location_id, true));
            // if (auth()->user()->type == 'province')
                $query = $query->where('invoices.company_id', auth()->user()->current_company);
            if ($from != "null" && $to != "null") {
                $query = $query->whereBetween('invoices.created_at', [$from, $to]);
            }
            if ($selected_type != 'undefined') {
                $query = $query->where('projects.id', $selected_type);
            }
            if ($filter != '') {
                $query = $query->where('invoices.currency', 'like', '%' . $filter . '%')
                    ->orwhere('companies.name', 'like', '%' . $filter . '%')
                    ->orwhere('projects.name', 'like', '%' . $filter . '%');
            }

            if ($order_direction != '' || $order_by != '') {
                $query = $query->orderBy($order_by, $order_direction);
            }
            Paginator::currentPageResolver(function () use ($start_page) {
                return $start_page;
            });

            return $query->paginate($per_page);
        } elseif ($type == 'projects') {
            $query = DB::table('projects')
                ->leftjoin('provinces', 'provinces.id', 'projects.province_id')
                ->select(
                    'projects.id',
                    'projects.code',
                    'projects.name',
                    'projects.start_date',
                    'projects.end_date',
                    'projects.description',
                    'provinces.name as location',
                    'projects.total_beneficiary',
                    'projects.budget',
                    'projects.created_at'
                )
                ->whereIn('projects.location_id', json_decode(auth()->user()->location_id, true));
            // if (auth()->user()->type == 'province')
                $query = $query->where('projects.company_id', auth()->user()->current_company);
            if ($from != "null" && $to != "null") {
                $query = $query->whereBetween('projects.created_at', [$from, $to]);
            }
            if ($location != 'undefined') {
                $query = $query->where('provinces.id', $location);
            }
            if ($zone != 'undefined') {
                $query = $query->where('provinces.zone_id', $zone);
            }
            if ($filter && $filter != '') {

                $query = $query->where(function ($where) use ($filter) {
                    $where->where('projects.name', 'like', '%' . $filter . '%')
                        ->orWhere('projects.description', 'like', '%' . $filter . '%')
                        ->orWhere('provinces.name', 'like', '%' . $filter . '%');
                });
            }

            if ($order_direction != '' || $order_by != '') {
                $query = $query->orderBy($order_by, $order_direction);
            }


            Paginator::currentPageResolver(function () use ($start_page) {
                return $start_page;
            });

            return $query->paginate($per_page);
        }
    }

    public function allReport()
    {
        // return 1;
        // return DB::table('transactions')->selectRaw("sum(transactions.amount)/transactions.rate as amount")->where('transactions.currency','usd')->where('transactions.account_name','Receipt Account')->get();
       $first_q = DB::table('companies')
            ->leftJoin(DB::raw('(SELECT sum(transactions.amount) as amount, transactions.company_id , transactions.currency FROM transactions WHERE transactions.account_name="Invoice Account" AND transactions.currency="USD" AND WHERE transactions.company_id= '.auth()->user()->current_company.' GROUP BY  transactions.company_id , transactions.currency) as transactions_dr'), function ($join) {
                $join->on('transactions_dr.company_id', '=', 'companies.id');
            })
            ->leftJoin(DB::raw('(SELECT sum(transactions.amount) as amount_cr, transactions.company_id as company_cr, transactions.currency as currency_cr FROM transactions WHERE transactions.account_name="Income Account" AND transactions.currency="USD" AND WHERE transactions.company_id= '.auth()->user()->current_company.'  GROUP BY  transactions.company_id , transactions.currency) as transactions_cr'), function ($join) {
                $join->on('transactions_cr.company_cr', '=', 'companies.id');
            })
            // ->where('companies.id', auth()->user()->current_company)
            ->selectRaw('transactions_dr.*, transactions_cr.*, companies.name');
        return DB::table('companies')
            ->leftJoin(DB::raw('(SELECT sum(transactions.amount) as amount, transactions.company_id , transactions.currency FROM transactions WHERE transactions.account_name="Invoice Account" AND transactions.currency="AFN" AND WHERE transactions.company_id= '.auth()->user()->current_company.' GROUP BY  transactions.company_id , transactions.currency) as transactions_dr'), function ($join) {
                $join->on('transactions_dr.company_id', '=', 'companies.id');
            })
            ->leftJoin(DB::raw('(SELECT sum(transactions.amount) as amount_cr, transactions.company_id as company_cr, transactions.currency as currency_cr FROM transactions WHERE transactions.account_name="Income Account" AND transactions.currency="AFN" AND WHERE transactions.company_id= '.auth()->user()->current_company.' GROUP BY  transactions.company_id , transactions.currency) as transactions_cr'), function ($join) {
                $join->on('transactions_cr.company_cr', '=', 'companies.id');
            })
            // ->where('companies.id', auth()->user()->current_company)
            ->selectRaw('transactions_dr.*, transactions_cr.*, companies.name')
            ->union($first_q)
            ->get();


        // return DB::table('companies')
        //         // ->leftJoin('invoices', 'invoices.company_id' , 'companies.id')
        //         ->leftJoin(DB::raw('(SELECT SUM(invoice_details.total_amount) as invoice, invoice_details.company_id , invoice_tb.currency FROM invoice_details LEFT JOIN (SELECT invoices.id, invoices.currency from invoices) as invoice_tb on invoice_details.invoice_id = invoice_tb.id GROUP BY invoice_details.company_id , invoice_tb.currency) as invoice_details_tb'), function($join){
        //             $join->on('invoice_details_tb.company_id', '=', 'companies.id');
        //         })
        //         ->leftJoin(DB::raw('(SELECT SUM(receipt_details.amount) as receipt, receipt_details.currency as re_currency, receipt_details.company_id FROM receipt_details LEFT JOIN (SELECT receipts.id, receipts.date FROM receipts) AS receipts_tb ON receipt_details.receipt_id = receipts_tb.id GROUP BY receipt_details.company_id, receipt_details.currency) AS receipt_details_tb'), function($join){
        //             $join->on('receipt_details_tb.company_id', '=', 'companies.id');
        //         })
        //         ->selectRaw('invoice_details_tb.*, receipt_details_tb.*, CONCAT(receipt_details_tb.receipt, " ", receipt_details_tb.re_currency) as credit, CONCAT((receipt_details_tb.receipt-invoice_details_tb.invoice)," ", receipt_details_tb.re_currency) as debit, companies.name')->get();
    }
}
