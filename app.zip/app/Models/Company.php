<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;
use App\Traits\Uuids;

class Company extends Model
{ 
    use HasFactory, Uuids;

    protected $table = "companies";

    protected $fillable = [
        'name',
        'address',
        'phone',
        'logo',
        'lang',
        'email',
        'desc',
        'invoice_desc',
        'invoice_propuse',
        'is_main'
    ];

    public function companies($request){
        $filter = $request->input('search_keyword');
        $per_page = $request->input('per_page');
        $current_page = $request->input('current_page');
        $order_by = $request->input('order_by');
        $order_direction = $request->input('order_direction');
        
        $query = DB::table('companies')
                  ->selectRaw('
                        companies.id, 
                        companies.name,
                        companies.phone,
                        companies.email,
                        companies.address,
                        companies.created_at');
        if ($filter != '') {
            $query = $query->where('companies.address', 'like', '%' . $filter . '%')
                ->orwhere('companies.name', 'like', '%' . $filter . '%');
        }

        if ($order_direction != '' || $order_by != '') {
            $query = $query->orderBy($order_by, $order_direction);
        }
      Paginator::currentPageResolver(function () use ($current_page) {
        return $current_page;
        });
        return $query->paginate($per_page);
    }
}
