<?php

namespace App\Models\Client;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ClientWellBeing extends Model
{
    use HasFactory;
    protected $table = 'client_wellbeings';

    protected $fillable = [
      'wellbeing_id',
      'client_id',
      'score',
      'type',
    ];

    public function getUpdatedAtAttribute($value)
    {
        if($value)
        {
            return date("d-m-Y", strtotime($value));
//            return $value->format('U = Y-m-d');
        }
    }

    public function getClientWellbeings($id)
    {
        return $this->leftjoin('wellbeings','wellbeings.id','wellbeing_id')
            ->selectRaw('client_wellbeings.*,wellbeings.*')
            ->where('client_wellbeings.client_id',$id)
            ->get();
    }
    public  function getLastUpdate($id,$type)
    {
        return $this
            ->selectRaw('client_wellbeings.updated_at,sum(client_wellbeings.score) as total')
            ->where('client_wellbeings.client_id',$id)
            ->where('client_wellbeings.type',$type)
            ->orderBy('client_wellbeings.updated_at','DESC')
            ->first();
    }


}
