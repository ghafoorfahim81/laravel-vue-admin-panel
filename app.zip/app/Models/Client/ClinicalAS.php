<?php

namespace App\Models\Client;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ClinicalAS extends Model
{
    use HasFactory;
    protected $table = 'clinical_assessments';


    public function client(){
        return $this->belongsTo(Client::class);
    }


    public function epilepsyDetails(){
        return $this->hasOne(Epilepsy::class,'clinical_assessment_id','id');
    }
}
