<?php

namespace App\Models\Client;

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;
use App\Models\Referral;


class Client extends Model
{
    use HasFactory;

    protected $guarded = [];
    protected $primaryKey = 'id';
    protected $fillable = [
        'general_judgment_baseline',
        'general_judgment_endline'
    ];


    public function clinicalAS()
    {
        return $this->hasOne(ClinicalAS::class);
    }

    public function attempt_to_end_life()
    {
        return $this->hasOne(AttempToEndLife::class, 'client_id', 'id');
    }

    public function province()
    {
        return $this->belongsTo(Province::class);
    }

    public function emergenct_contact()
    {
        return $this->hasMany(EmergencyContact::class);
    }

//    convert registration date
    public function getCreatedAtAttribute($value)
    {
        if ($value) {
            return date("d-m-Y", strtotime($value));
        }
    }

    public function clients($request)
    {
        $search_keyword = $request->input('search_keyword');
        $per_page = $request->input('per_page');

        $current_page = $request->input('current_page');
        $order = ($request->input('order') ? $request->input('order') : 'desc');
        $table = $request->input('table');
        $age = $request->input('age');
        $province = $request->input('province');
        $lang = $request->input('lang');
        $province_code = $request->input('province_code');
        $name = $request->get('name');
        $date = $request->input('date');
        $code = explode(',', $request->input('code'));
        $phone = $request->input('phone');
        $household_status = $request->input('household_status');
        $adult = $request->input('adult');
        $child = $request->input('child');
        $ideal = $request->input('ideal');
        $type = $request->input('type');
        $gender = $request->input('gender');
        $no_session = $request->input('no_session');
        $followUp = $request->input('followUp');
        $therapist = $request->input('therapist');
        $order_by = $request->input('order_by');
        $user = auth()->user()->psychologist;
        $order_direction = $request->input('order_direction');
        $query = $this->leftJoin('provinces', 'provinces.id', 'province_id')
            ->leftjoin('client_sessions', 'client_sessions.client_id', 'client_id')
            ->leftjoin('psychologists', 'psychologists.id', 'client_sessions.psychologist_id')
            ->leftjoin('users', 'users.id', 'psychologists.user_id')
            ->selectRaw('
                 clients.*,
                 count(client_sessions.id) as no_session,
                provinces.code as pCode,
                users.id as user_id,
                client_sessions.followed_up_by,
                provinces.name as province'
            )->groupBy('clients.id');

        if ($type == 'all') {
            $query = $query;
        }
        if ($type == 'TerminateCases') {
            $query = $query->where('clients.status', 'terminate');
        }
        if ($type == 'newCases') {
            $query = $query->whereNotExists(function ($query) {
                $query->select(\DB::raw(1))
                    ->from('client_sessions')
                    ->whereRaw('clients.id = client_sessions.client_id');
            });
        }
        if ($type == 'existenceCases') {
            $query = $query->whereExists(function ($query) {
                $query->select(\DB::raw(1))
                    ->from('client_sessions')
                    ->whereRaw('clients.id = client_sessions.client_id');
            });
        }
        if ($search_keyword != '') {
            $query = $query->where('clients.name', 'like', '%' . $search_keyword . '%')
                ->orwhere('provinces.code', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.last_name', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.marital_status', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.project_code', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.education', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.nic', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.job', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.district', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.address', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.phone', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.native_language', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.household_status', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.disabilities', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.referral_type', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.age', 'like', '%' . $search_keyword . '%');
        }
        if ($order_direction != '' || $order_by != '') {
            $query = $query->orderBy($order_by, $order_direction);
        } else {
            $query = $query->orderBy('clients.created_at', 'desc');
        }

        if ($followUp) {
            if ($followUp == 'both')
                $query = $query->whereExists(function ($query) {
                    $query->select(\DB::raw(1))
                        ->from('client_sessions')
                        ->whereRaw('clients.id = client_sessions.client_id');
                });
            else {
                $query = $query->whereExists(function ($query) use ($followUp) {
                    $query->select(\DB::raw(1))
                        ->from('client_sessions')
                        ->whereRaw('clients.id = client_sessions.client_id')
                        ->where('client_sessions.followed_up_by', 'like', '%' . $followUp . '%');
                });
            }

        }
        if ($therapist) {
            $query = $query
                ->whereExists(function ($query) use ($therapist) {
                    $query->select(\DB::raw(1))
                        ->from('client_sessions')
                        ->whereRaw('clients.id = client_sessions.client_id')
                        ->where('client_sessions.psychologist_id', $therapist);
                });
        }
        if ($no_session > 0) {
            $query = DB::table('clients')
                ->selectRaw("clients.*,
                provinces.code as pCode,
                users.id as user_id,
                client_sessions.followed_up_by,
                provinces.name as province,
                 COUNT(client_sessions.client_id) as no_session")
                ->join('client_sessions', 'client_sessions.client_id', '=', 'clients.id')
                ->leftJoin('provinces', 'provinces.id', 'province_id')
                ->leftjoin('psychologists', 'psychologists.id', 'client_sessions.psychologist_id')
                ->leftjoin('users', 'users.id', 'psychologists.user_id')
                ->groupBy('clients.id')
                ->groupBy('client_sessions.client_id')
                ->orderBy('no_session', 'desc');
            $query = $query->having('no_session', $no_session);
        }
        if ($user) {
            $pQuery = $query
                ->whereExists(function ($query) use ($user) {
                    $query->select(\DB::raw(1))
                        ->from('client_sessions')
                        ->whereRaw('clients.id = client_sessions.client_id')
                        ->where('client_sessions.psychologist_id', $user->id);
                });
//            $query = $pQuery->where('user_id', 'like', '%' . $user . '%');
        }

        if ($name != '') {
            $query = $query->where('clients.name', 'like', '%' . $name . '%');
        }
        if ($age != '') {
            $query = $query->where('clients.age', 'like', '%' . $age . '%');
        }
        if ($gender) {
            $query = $query->where('clients.gender', $gender);
        }
        if ($adult == 'true') {
            $query = $query->where('clients.age', '>=', 18);
        }
        if ($ideal == 'true') {
            $query = $query->leftjoin('attempt_to_end_life', 'attempt_to_end_life.client_id', 'clients.id')->where('attempt_to_end_life.thoughts_to_end_your_life', '=', 1);
        }
        if ($child == 'true') {
            $query = $query->where('clients.age', '<=', 18);
        }
        if ($child == 'true' && $adult == 'true') {
            $query = $query->where('clients.age', '<=', 18)->orwhere('clients.age', '>=', 18);
        }
//        return ($code);
        if (count($code) >= 1) {
            for ($i = 0; $i < count($code); $i++) {
                if ($code[$i] != '' && $code[$i] != ' ') {
                    $query = $query->orwhere('clients.code', 'like', '%' . $code[$i] . '%');
                }
            }
        }
        if ($phone > 0) {
            $query = $query->where('clients.phone', 'like', '%' . $phone . '%');
        }
        if ($province_code != '') {
            $query = $query->where('provinces.code', 'like', '%' . $province_code . '%');
        }
        if ($household_status != '') {
            $query = $query->where('clients.household_status', $household_status);
        }
        if ($lang != '') {
//            return $lang;
            $query = $query->where('clients.native_language', 'like', '%' . $lang . '%');
        }
        if ($province != '') {
            $query = $query->where('provinces.name', $province);
        }
//        if(\Auth::check() && auth()->user()->psychologist)
//        {
////            return $query;
//            $query=$query->where('users.id',auth()->user()->psychologist->id);
//        }
        Paginator::currentPageResolver(function () use ($current_page) {
            return $current_page;
        });
        return $query->paginate($per_page);
    }

//    show function
    public function showClient($id, $psychology)
    {
        $query = $this->join('client_sessions', 'client_sessions.client_id', 'client_id')
            ->select('clients.*','clients.id as id')
            ->where('client_sessions.psychologist_id', $psychology)
            ->where('clients.id', $id)
            ->first();
        return $query;
        // $query = $this->leftjoin('client_sessions', 'client_sessions.client_id', 'client_id')
        // ->select('clients.*')
        // ->where('clients.id', $id)
        // ->whereExists(function ($query) use($psychology) {
        //     $query->select(\DB::raw(1))
        //         ->from('client_sessions')
        //         ->whereRaw('clients.id = client_sessions.client_id')
        //         ->where('client_sessions.psychologist_id', $psychology)
        //         ->first();
        // });
        // return $query;
    }

//    export to excel clients
    public function exportClientHotline($data)
    {
        $age = $data->age;
        $province = $data->province;
        $lang = $data->lang;
        $province_code = $data->province_code;
        $name = $data->name;
        $phone = $data->phone;
        $household_status = $data->household_status;
        $adult = $data->adult;
        $child = $data->child;
        $ideal = $data->ideal;
        $code = explode(',', $data->code[0]);
        $rows = explode(',', $data->rows[0]);
        $gender = $data->gender;
        $no_session = $data->no_session;
        $followUp = $data->followUp;
        $therapist = $data->therapist;
        $type = $data->type;
        $query = $this
            ->leftjoin('client_sessions', 'client_sessions.client_id', 'client_id')
            ->leftjoin('psychologists', 'psychologists.id', 'client_sessions.psychologist_id')
            ->leftjoin('users', 'users.id', 'psychologists.user_id')
            ->leftJoin('provinces', 'provinces.id', 'province_id')
            ->leftJoin('clinical_assessments', 'clinical_assessments.client_id', 'clients.id')
            ->leftJoin('attempt_to_end_life', 'attempt_to_end_life.client_id', 'clients.id')
            ->selectRaw('clients.*,provinces.name as province,
            users.name as focalPoint,
            clinical_assessments.main_problem as main_complaint,
            clinical_assessments.major_symptoms,
            clinical_assessments.previous_health_services,
            clinical_assessments.epilepsy,
            clients.id as client_id,
            clinical_assessments.distress_reasons,
            attempt_to_end_life.*,
            count(client_sessions.client_id) as noOfSession
            ')
            ->groupBY('clients.id');
        if ($name != '') {
            $query = $query->where('clients.name', 'like', '%' . $name . '%');
        }
        if ($gender) {
            $query = $query->where('clients.gender', $gender);
        }
        if (count($rows)>1) {
        $query = $query->whereIn('clients.id', $rows);
        }
        if ($adult == 'true') {
            $query = $query->where('clients.age', '>=', 18);
        }
        if ($ideal == 'true') {
            $query = $query->where('attempt_to_end_life.thoughts_to_end_your_life', '=', 1);
        }
        if ($child == 'true') {
            $query = $query->where('clients.age', '<=', 18);
        }
        if ($child == 'true' && $adult == 'true') {
            $query = $query->where('clients.age', '<=', 18)->orwhere('clients.age', '>=', 18);
        }
        if (count($code) >= 1) {
            for ($i = 0; $i < count($code); $i++) {
                if ($code[$i] != '' && $code[$i] != ' ') {
                    $query = $query->orwhere('clients.code', 'like', '%' . $code[$i] . '%');
                }
            }
        }
        if ($phone > 0) {
            $query = $query->where('clients.phone', 'like', '%' . $phone . '%');
        }
        if ($province_code != '') {
            $query = $query->where('provinces.code', 'like', '%' . $province_code . '%');
        }
        if ($household_status != '') {
            $query = $query->where('clients.household_status', $household_status);
        }
        if ($lang != '') {
//            return $lang;
            $query = $query->where('clients.native_language', 'like', '%' . $lang . '%');
        }
        if ($province != '') {
            $query = $query->where('provinces.name', $province);
        }
        if ($no_session > 0) {
            $x = $query->whereExists(function ($query) {
                $query->select(\DB::raw(1))
                    ->from('client_sessions')
                    ->whereRaw('clients.id = client_sessions.client_id');
            });
            $query = $x->having('noOfSession', $no_session);
        }
        if ($followUp) {
            $x = $query->whereExists(function ($query) {
                $query->select(\DB::raw(1))
                    ->from('client_sessions')
                    ->whereRaw('clients.id = client_sessions.client_id');
            });
            $query = $x->where('client_sessions.followed_up_by', 'like', '%' . $followUp . '%');
        }

        if ($therapist) {
            $x = $query->whereExists(function ($query) {
                $query->select(\DB::raw(1))
                    ->from('client_sessions')
                    ->whereRaw('clients.id = client_sessions.client_id');
            });
            $query = $x->where('users.name', 'like', '%' . $therapist . '%');
        }
        return $query->get();
    }

    //    export to excel client Referral
    public function exportClientReferral($data)
    {
        $age = $data->age;
        $province = $data->province;
        $lang = $data->lang;
        $province_code = $data->province_code;
        $name = $data->name;
        $code = explode(',', $data->code[0]);
        $phone = $data->phone;
        $household_status = $data->household_status;
        $adult = $data->adult;
        $child = $data->child;
        $rows = explode(',', $data->rows[0]);
        $ideal = $data->ideal;
        $gender = $data->gender;
        $no_session = $data->no_session;
        $followUp = $data->followUp;
        $therapist = $data->therapist;
        $type = $data->type;
        $query = $this
            ->leftjoin('client_sessions', 'client_sessions.client_id', 'client_id')
            ->leftjoin('psychologists', 'psychologists.id', 'client_sessions.psychologist_id')
            ->leftjoin('users', 'users.id', 'psychologists.user_id')
            ->leftJoin('provinces', 'provinces.id', 'province_id')
            ->leftJoin('emergency_contacts', 'emergency_contacts.client_id', 'clients.id')
            ->leftJoin('referrals', 'referrals.client_id', 'clients.id')
            ->leftJoin('attempt_to_end_life', 'attempt_to_end_life.client_id', 'clients.id')
            ->selectRaw('clients.*,provinces.name as province,
            users.name as focalPoint,
            referrals.*,
            clients.id as client_id,
            clients.code as client_code,
            referrals.code as referral_code,
            emergency_contacts.phone as emPhone,
            emergency_contacts.name as emName,
            count(client_sessions.client_id) as noOfSession
            ')
            ->groupBY('clients.id');
        if ($name != '') {
            $query = $query->where('clients.name', 'like', '%' . $name . '%');
        }
        if ($age != '') {
            $query = $query->where('clients.age', 'like', '%' . $age . '%');
        }
        if ($gender) {
            $query = $query->where('clients.gender', $gender);
        }
        if (count($rows)>1) {
            $query = $query->whereIn('clients.id', $rows);
        }
        if ($adult == 'true') {
            $query = $query->where('clients.age', '>=', 18);
        }
        if ($ideal == 'true') {
            $query = $query->where('attempt_to_end_life.thoughts_to_end_your_life', '=', 1);
        }
        if ($child == 'true') {
            $query = $query->where('clients.age', '<=', 18);
        }
        if ($child == 'true' && $adult == 'true') {
            $query = $query->where('clients.age', '<=', 18)->orwhere('clients.age', '>=', 18);
        }
//        return ($code);
        if (count($code) >= 1) {
            for ($i = 0; $i < count($code); $i++) {
                if ($code[$i] != '' && $code[$i] != ' ') {
                    $query = $query->orwhere('clients.code', 'like', '%' . $code[$i] . '%');
                }
            }
        }
        if ($phone > 0) {
            $query = $query->where('clients.phone', 'like', '%' . $phone . '%');
        }
        if ($province_code != '') {
            $query = $query->where('provinces.code', 'like', '%' . $province_code . '%');
        }
        if ($household_status != '') {
            $query = $query->where('clients.household_status', $household_status);
        }
        if ($lang != '') {
//            return $lang;
            $query = $query->where('clients.native_language', 'like', '%' . $lang . '%');
        }
        if ($province != '') {
            $query = $query->where('provinces.name', $province);
        }
        if ($no_session > 0) {
            $x = $query->whereExists(function ($query) {
                $query->select(\DB::raw(1))
                    ->from('client_sessions')
                    ->whereRaw('clients.id = client_sessions.client_id');
            });
            $query = $x->having('noOfSession', $no_session);
        }
        if ($followUp) {
            $x = $query->whereExists(function ($query) {
                $query->select(\DB::raw(1))
                    ->from('client_sessions')
                    ->whereRaw('clients.id = client_sessions.client_id');
            });
            $query = $x->where('client_sessions.followed_up_by', 'like', '%' . $followUp . '%');
        }
        if ($therapist) {
            $x = $query->whereExists(function ($query) {
                $query->select(\DB::raw(1))
                    ->from('client_sessions')
                    ->whereRaw('clients.id = client_sessions.client_id');
            });
            $query = $x->where('users.name', 'like', '%' . $therapist . '%');
        }
        return $query->get();
    }


//    export to pdf specific clients
    public function getClientPdf($id)
    {
        $query = $this
            ->leftjoin('client_sessions', 'client_sessions.client_id', 'client_id')
            ->leftjoin('psychologists', 'psychologists.id', 'client_sessions.psychologist_id')
            ->leftjoin('users', 'users.id', 'psychologists.user_id')
            ->leftJoin('provinces', 'provinces.id', 'province_id')
            ->leftJoin('clinical_assessments', 'clinical_assessments.client_id', 'clients.id')
            ->leftJoin('attempt_to_end_life', 'attempt_to_end_life.client_id', 'clients.id')
            ->selectRaw('clients.*,provinces.name as province,
            users.name as focalPoint,
            clinical_assessments.main_problem as main_complaint,
            clinical_assessments.major_symptoms,
            clinical_assessments.previous_health_services,
            clinical_assessments.epilepsy,
            clinical_assessments.distress_reasons,
            attempt_to_end_life.thoughts_to_end_your_life,
            count(client_sessions.client_id) as noOfSession
            ')
            ->groupBY('clients.id')
            ->where('clients.id', $id)
            ->first();
        return $query;
    }


    //refferal

    public function referral()
    {
        return $this->hasMany(Referral::class, 'client_id', 'id');
    }

//    export to excel clients
    public function getClientsSession()
    {
        $query = $this
            ->leftjoin('client_sessions', 'client_sessions.client_id', 'client_id')
            ->select('client_sessions.client_id as client_id', \DB::raw('count(client_sessions.client_id) as noOfSession'))
            ->groupBY('clients.id')
            ->groupBY('client_sessions.client_id')
            ->get();
        return $query;
    }


    // get Clients For Dashboard
    // get All province
    public function getAllProvince()
    {

        $data = \DB::table('provinces')
            ->select('*')
            ->get();

        return $data;
    }

    // get All Clients when proince select
    public function getClientsByProvince()
    {

        $data = \DB::table('clients')
            ->join('provinces', 'provinces.id', 'clients.province_id')
            ->selectRaw("provinces.dashboard_client_code as proCode,
             provinces.name as proName,
             COUNT(clients.id) as clientsTotal")
            ->groupBy(DB::raw('province_id'))
            ->get();

        return $data;
        //  print_r($data);
    }


    // count clients by type
    public function getClientsByType($proId)
    {
        $data = \DB::table('clients')
            ->selectRaw("COUNT(clients.id) AS clientTotalByProvince, clients.province_id as proId,
        (CASE
                WHEN clients.gender = 'male' AND clients.age >18  THEN 'men'
                WHEN clients.gender = 'female' AND clients.age >18 THEN 'women'
                WHEN clients.gender = 'male'  AND clients.age <= 18 THEN 'boys'
                WHEN clients.gender = 'female'  AND clients.age <= 18 THEN 'girls'
                ELSE 'not_specified'
                END) AS ageType")
            ->groupBy(DB::raw('ageType'))
            ->where('province_id', $proId)
            ->get();

        return $data;
    }

    // count clients of All province
    public function getClientsByTypeAllPro()
    {
        $data = \DB::table('clients')
            ->selectRaw("COUNT(clients.id) AS clientsTotalByAllPro,
        (CASE
                WHEN clients.gender = 'male' AND clients.age >18  THEN 'men'
                WHEN clients.gender = 'female' AND clients.age >18 THEN 'women'
                WHEN clients.gender = 'male'  AND clients.age <= 18 THEN 'boys'
                WHEN clients.gender = 'female'  AND clients.age <= 18 THEN 'girls'
                ELSE 'not_specified'
                END) AS ageType")
            ->groupBy(DB::raw('ageType'))
            ->get();

        return $data;
    }

    // count clients status is terminate on Discharge
    public function getClientTerminate()
    {
        $data = \DB::table('clients')
            ->selectRaw("COUNT(clients.id) AS clientsTerminate,
        (CASE
                WHEN clients.gender = 'male' AND clients.age >18  THEN 'men'
                WHEN clients.gender = 'female' AND clients.age >18 THEN 'women'
                WHEN clients.gender = 'male'  AND clients.age <= 18 THEN 'boys'
                WHEN clients.gender = 'female'  AND clients.age <= 18 THEN 'girls'
                ELSE 'not_specified'
                END) AS ageType")
            ->groupBy(DB::raw('ageType'))
            ->where('clients.status', 'terminate')
            ->get();

        return $data;
    }

    public function getCountClientTerminate()
    {
        $data = $this
            ->selectRaw("COUNT(clients.id) AS clientsTotalTerminate")
            ->where('clients.status', 'terminate')
            ->get();

        return $data;
    }


    // count of client in on Hold calls
    public function getClientOnHoldCalls()
    {
        $data = $this->selectRaw("COUNT(clients.id) AS totalClientsOnHold,
        (CASE
                WHEN clients.gender = 'male' AND clients.age >18  THEN 'men'
                WHEN clients.gender = 'female' AND clients.age >18 THEN 'women'
                WHEN clients.gender = 'male'  AND clients.age <= 18 THEN 'boys'
                WHEN clients.gender = 'female'  AND clients.age <= 18 THEN 'girls'
                ELSE 'not_specified'
                END) AS ageType")
            ->whereNotExists(function ($query) {
                $query->select(\DB::raw(1))
                    ->from('client_sessions')
                    ->whereRaw('clients.id = client_sessions.client_id');
            })
            ->groupBy(DB::raw('ageType'))
            ->get();
        return $data;
    }

    public function getTotalCountClientOnHoldCalls()
    {
        $data = $this
            ->selectRaw("COUNT(clients.id) AS TotalCountClientOnHoldCalls")
            ->whereNotExists(function ($query) {
                $query->select(\DB::raw(1))
                    ->from('client_sessions')
                    ->whereRaw('clients.id = client_sessions.client_id');
            })
            ->get();
        return $data;
    }

    // count of client in on going calls
    public function getClientOnGoingCalls()
    {
        $data = $this
            ->selectRaw("COUNT(clients.id) AS totalClientsOnGoing,
        (CASE
                WHEN clients.gender = 'male' AND clients.age >18  THEN 'men'
                WHEN clients.gender = 'female' AND clients.age >18 THEN 'women'
                WHEN clients.gender = 'male'  AND clients.age <= 18 THEN 'boys'
                WHEN clients.gender = 'female'  AND clients.age <= 18 THEN 'girls'
                ELSE 'not_specified'
                END) AS ageType ")
            ->whereExists(function ($query) {
                $query->select(\DB::raw(1))
                    ->from('client_sessions')
                    ->whereRaw('clients.id = client_sessions.client_id');
            })
            ->groupBy(DB::raw('ageType'))
            ->get();
        return $data;
    }

    public function getTotalCountOngoingStyle()
    {
        $data = $this
            ->selectRaw("COUNT(clients.id) AS totalCountOngoingStyle")
            ->whereExists(function ($query) {
                $query->select(\DB::raw(1))
                    ->from('client_sessions')
                    ->whereRaw('clients.id = client_sessions.client_id');
            })
            ->get();
        return $data;
    }


    // Monthly report of Bar chart
    public function getDefaultMonthlyReportChart()
    {
        $data = $this
            ->select(DB::raw('COUNT(*) as count'), DB::raw('MONTHNAME(created_at) as month_name'))
            ->whereYear('created_at', date('Y'))
            ->groupBy(\DB::raw("Month(created_at)"))
            ->pluck('count', 'month_name');
        return [
            $data->keys(),
            $data->values()
        ];
    }

    public function getYearForClientSelect()
    {


        $data = $this
            ->selectRaw("YEAR(created_at) as Year")
            ->distinct()
            ->get();
        return $data;
    }

    public function getYearForClientWhenSelect($date)
    {

        // $currentDate = date('Y');

        if ($date == 100) {
            $data = $this
                // ->selectRaw("COUNT(*) AS count")
                ->select(DB::raw('COUNT(*) as count'), DB::raw('MONTHNAME(created_at) as month_name'))
                ->whereYear('created_at', date('Y'))
                ->groupBy(\DB::raw("Month(created_at)"))
                ->pluck('count', 'month_name');
            return [
                $data->keys(),
                $data->values()
            ];

        } else {

            $data = $this
                // ->selectRaw("COUNT(*) AS count")
                ->select(DB::raw('COUNT(*) as count'), DB::raw('MONTHNAME(created_at) as month_name'))
                ->whereYear('created_at', $date)
                ->groupBy(\DB::raw("Month(created_at)"))
                ->pluck('count', 'month_name');

            return [
                $data->keys(),
                $data->values()
            ];

        }


    }


    // count wellbieng by type
    public function getClientWellbeing($request = null, $provinceId = null)
    {


        $endLineScore = \DB::table('client_wellbeings')
            ->selectRaw("SUM(IFNULL(client_wellbeings.score,0)) AS score,client_wellbeings.client_id")
            ->where('client_wellbeings.type', '=', 'endline')
            ->groupBy(\DB::raw('client_wellbeings.client_id'));


        $baseLineScore = \DB::table('client_wellbeings')
            ->selectRaw("SUM(IFNULL(client_wellbeings.score,0)) AS score,client_wellbeings.client_id")
            ->where('client_wellbeings.type', '=', 'baseline')
            ->groupBy(\DB::raw('client_wellbeings.client_id'));


        $data = $this
            ->selectRaw("
                SUM(IFNULL(baseLine.score,0))-IFNULL(endLine.score,0) AS score,
                clients.id AS client_id,clients.gender,clients.age,
                (CASE
                WHEN clients.gender = 'male' AND clients.age >18 AND (SUM(IFNULL(endLine.score,0))-IFNULL(baseLine.score,0))>0 THEN 'p_men'
                WHEN clients.gender = 'female' AND clients.age >18 AND (SUM(IFNULL(endLine.score,0))-IFNULL(baseLine.score,0))>0 THEN 'p_women'
                WHEN clients.gender = 'male'  AND clients.age <= 18 AND (SUM(IFNULL(endLine.score,0))-IFNULL(baseLine.score,0))>0 THEN 'p_boys'
                WHEN clients.gender = 'female'  AND clients.age <= 18 AND (SUM(IFNULL(endLine.score,0))-IFNULL(baseLine.score,0))>0 THEN 'p_girls'

                WHEN clients.gender = 'male' AND clients.age >18 AND (SUM(IFNULL(endLine.score,0))-IFNULL(baseLine.score,0))<=0 THEN 'men'
                WHEN clients.gender = 'female' AND clients.age >18 AND (SUM(IFNULL(endLine.score,0))-IFNULL(baseLine.score,0))<=0 THEN 'women'
                WHEN clients.gender = 'male'  AND clients.age <= 18 AND (SUM(IFNULL(endLine.score,0))-IFNULL(baseLine.score,0))<=0 THEN 'boys'
                WHEN clients.gender = 'female'  AND clients.age <= 18 AND (SUM(IFNULL(endLine.score,0))-IFNULL(baseLine.score,0))<=0 THEN 'girls'
                ELSE 'not_specified'
                END) AS ageType")
//
            ->leftjoinSub($endLineScore, 'endLine', function ($join) {
                $join->on('endLine.client_id', '=', 'clients.id');
            })
            ->leftjoinSub($baseLineScore, 'baseLine', function ($join) {
                $join->on('baseLine.client_id', '=', 'clients.id');

            })
            ->whereExists(function ($query) {
                $query->select(\DB::raw(1))
                    ->from('client_wellbeings')
                    ->whereRaw('clients.id = client_wellbeings.client_id');
            })
            ->groupBy(\DB::raw('clients.id', 'ageType'));

        $myQuery = $this
            ->selectRaw("wellbeing.ageType,
                count(wellbeing.score) AS total_score,
                    (CASE
                    WHEN wellbeing.score>0  THEN 'positive'
                   ELSE 'negative'
                    END) AS category")
            ->joinSub($data, 'wellbeing', function ($join) {
                $join->on('wellbeing.client_id', '=', 'clients.id');

            })
            ->groupBy('category', 'wellbeing.ageType');

        if ($provinceId) {
            $myQuery = $myQuery->where('clients.id');
        }

        return $myQuery->get();

    }


    // get new case client
    public function newCaseclients($request)
    {
        $search_keyword = $request->input('search_keyword');
        $per_page = $request->input('per_page');
        $per_page = $request->input('per_page');
        $current_page = $request->input('current_page');
        $column = ($request->input('column') ? $request->input('column') : 'receipts.created_at');
        $order = ($request->input('order') ? $request->input('order') : 'desc');
        $table = $request->input('table');
        $age = $request->input('age');
        $province = $request->input('province');
        $lang = $request->input('lang');
        $province_code = $request->input('province_code');
        $name = $request->get('name');
        $date = $request->input('date');
        $code = explode(',', $request->input('code'));
        $phone = $request->input('phone');
        $household_status = $request->input('household_status');
        $adult = $request->input('adult');
        $child = $request->input('child');
        $type = $request->input('type');
        $gender = $request->input('gender');
        $no_session = $request->input('no_session');
        $followUp = $request->input('followUp');
        $therapist = $request->input('therapist');
        $type = $request->input('type');
//        return $name;
        $order_by = $request->input('order_by');
        $order_direction = $request->input('order_direction');


        $query = \DB::table('clients')
            ->leftJoin('provinces', 'provinces.id', 'province_id')
            ->select(
                'clients.*',
                'provinces.code as pCode',
                'provinces.name as province'
            )
            ->orderBy('clients.code','ASC')
            ->whereNotExists(function ($query) {
                $query->select(\DB::raw(1))
                    ->from('client_sessions')
                    ->whereRaw('clients.id = client_sessions.client_id');
            });

        if ($search_keyword != '') {
            $query = $query->where('clients.name', 'like', '%' . $search_keyword . '%')->orwhere('provinces.code', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.last_name', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.marital_status', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.project_code', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.education', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.nic', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.job', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.district', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.address', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.phone', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.native_language', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.household_status', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.disabilities', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.referral_type', 'like', '%' . $search_keyword . '%')
                ->orwhere('clients.age', 'like', '%' . $search_keyword . '%');
        }
        if ($order_direction != '' || $order_by != '') {
            $query = $query->orderBy($order_by, $order_direction);
        } else {
            $query = $query->orderBy('clients.created_at', 'desc');
        }

        if ($name) {
            $query = $query->where('clients.name', 'like', '%' . $name . '%');
        }
        if ($followUp) {
            $query = $query->where('clients.follow_by', 'like', '%' . $followUp . '%');
        }
        if ($gender) {
            $query = $query->where('clients.gender', $gender);
        }
        if ($therapist) {
            $query = $query->where('users.name', 'like', '%' . $therapist . '%');
        }
//        if ($no_session>0) {
//            $query = $query->where('no_session',$no_session);
//        }
        if ($adult == 'true') {
            $query = $query->where('clients.age', '>=', 18);
        }
        if ($child == 'true') {
            $query = $query->where('clients.age', '<=', 18);
        }
        if ($child == 'true' && $adult == 'true') {
            $query = $query;
        }
//        return ($code);
        if (count($code) >= 1) {
//            return  count($code);
            for ($i = 0; $i < count($code); $i++) {
                if ($code[$i] != '' && $code[$i] != ' ') {
                    $query = $query->where('clients.code', 'like', '%' . $code[$i] . '%');
                }
            }
        }
        if ($phone != '') {
            $query = $query->where('clients.phone1', 'like', '%' . $phone . '%');
            $query = $query->where('clients.phone1', 'like', '%' . $phone . '%');
        }
        if ($province_code != '') {
            $query = $query->where('provinces.code', 'like', '%' . $province_code . '%');
        }
        if ($household_status != '') {
            $query = $query->where('clients.household_status', 'like', '%' . $household_status . '%');
        }
        if ($lang != '') {
//            return $lang;
            $query = $query->where('clients.native_language', 'like', '%' . $lang . '%');
        }
        if ($province != '') {
//            return gettype($province);
            $query = $query->where('provinces.id', $province);
        }
        Paginator::currentPageResolver(function () use ($current_page) {
            return $current_page;
        });
        return $query->paginate($per_page);
    }

    // get satisfaction survery
    public function SatisfactionSurvey($request = null, $provinceId = null)
    {
        $query = $this->selectRaw("
        count(clients.satisfaction_servey) AS participated_client_total,
        clients.satisfaction_servey AS survey_score
        ")
            ->Where(function ($query) {
                $query->where('clients.satisfaction_servey', '>', 0)
                    ->whereNotNull('clients.satisfaction_servey');
            })
            ->groupBy('clients.satisfaction_servey');

        if ($provinceId != '') {
//            return gettype($province);
            $query = $query->where('clients.province_id', $provinceId);
        }
        return $query->get();

    }

    // get satisfaction survery
    public function SatisfactionSurveyTotal($request = null, $provinceId = null)
    {
        $query = $this->selectRaw("
        count(clients.satisfaction_servey) AS total_survey
        ")
            ->Where(function ($query) {
                $query->where('clients.satisfaction_servey', '>', 0)
                    ->whereNotNull('clients.satisfaction_servey');
            });

        if ($provinceId != '') {
//            return gettype($province);
            $query = $query->where('clients.province_id', $provinceId);
        }

        return $query->first();

    }


    // get client disaggregation by data and
    // filter it by score it there is any
    public function genderDisaggregation($request = null, $score = null, $provinceId = null)
    {

        $data = $this
            ->selectRaw("count(clients.satisfaction_servey) AS total_survey,
                (CASE
                WHEN clients.gender = 'male' AND clients.age >18  THEN 'men'
                WHEN clients.gender = 'female' AND clients.age >18 THEN 'women'
                WHEN clients.gender = 'male'  AND clients.age <= 18 THEN 'boys'
                 WHEN clients.gender = 'female'  AND clients.age <= 18 THEN 'girls'
                ELSE 'not_specified'
                END) AS ageType")
            ->Where(function ($query) {
                $query->where('clients.satisfaction_servey', '>', 0)
                    ->whereNotNull('clients.satisfaction_servey');
            })
            ->groupBy(DB::raw('ageType', 'clients.satisfaction_servey'));

        if ($score) {
            $data = $data->where('clients.satisfaction_servey', $score);
        }
        if ($provinceId != '') {
//            return gettype($province);
            $data = $data->where('clients.province_id', $provinceId);
        }

        return $data->get();
    }

    //get client disaggregation by data and
    // filter it by score it there is any
    public function genderDisaggregationTotal($request = null, $score = null, $provinceId = null)
    {

        $data = $this
            ->selectRaw("count(clients.satisfaction_servey) AS total_survey")
            ->Where(function ($query) {
                $query->where('clients.satisfaction_servey', '>', 0)
                    ->whereNotNull('clients.satisfaction_servey');
            });

        if ($score) {
            $data = $data->where('clients.satisfaction_servey', $score);
        }
        if ($provinceId != '') {
//            return gettype($province);
            $data = $data->where('clients.province_id', $provinceId);
        }

        return $data->first();;
    }


}

