<?php

namespace App\Models\Client;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AttempToEndLife extends Model
{
    use HasFactory;
    protected $table = 'attempt_to_end_life';
    protected $guarded = [];
    
    public function client(){
        return $this->belongsTo(Client::class,'client_id','id');
    }
}