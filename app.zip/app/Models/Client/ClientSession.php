<?php

namespace App\Models\Client;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use function Symfony\Component\Mime\from;

class ClientSession extends Model
{
    use HasFactory;
    protected $guarded = [];

    public function getDateAttribute($value)
    {
        if($value)
        {
            return date("d-m-Y", strtotime($value));
//            return $value->format('U = Y-m-d');
        }
    }
    // get Psychologists appointments
    public function getPAppiontments($request)
    {
        $type       = $request->type;
        $from_date  = $request->from_date;
        $to_date    = $request->to_date;
        $id         = $request->id;
//        return $type;
        $query=$this
            ->join('schedules','schedules.id','client_sessions.schedule_id')
            ->join('timings','timings.id','client_sessions.timing_id')
            ->join('clients','clients.id','client_sessions.client_id')
            ->selectRaw("
        client_sessions.date,
        client_sessions.id,
        timings.start_time,
        timings.end_time,
        clients.name as client,
        clients.id as client_id
        ")
            ->orderBy('client_sessions.date','DESC')
            ->where('client_sessions.status',$type)
            ->where('client_sessions.psychologist_id',$id)
            ->limit(10);
        if($from_date !='')
        {
            $query=$query->whereDate('client_sessions.date','>=',$from_date);
        }

        if($to_date !=null)
        {
            $query=$query->whereDate('client_sessions.date','<=',$to_date);
        }

        return $query->get();
    }

    // get available Psychologist in specific date
    public function getDailySession($fromDay=null,$toDay=null,$fromDate=null,$toDate=null)
    {

        $query=$this
        ->join('psychologists','psychologists.id','client_sessions.psychologist_id')
        ->join('users','users.id','psychologists.user_id')
        ->join('clients','clients.id','client_sessions.client_id')
        ->join('schedules','schedules.id','client_sessions.schedule_id')
        ->join('timings','timings.id','client_sessions.timing_id')
        ->selectRaw("
        client_sessions.id,
        client_sessions.date,
        clients.name AS client_name,
        clients.last_name AS client_lastname,
        clients.code AS client_code,
        users.name AS psychologist_name,
        timings.start_time,
        timings.end_time,
        client_sessions.created_at AS start
        ")
        ->groupBY('timings.id','psychologists.id');

        if(\Auth::check() && auth()->user()->psychologist)
        {
            $query=$query->where('psychologists.id',auth()->user()->psychologist->id);
        }

        if($fromDay)
        {
           // $query=$query->where('schedules.day',$fromDay);
        }

        if($fromDate)
        {
            $query=$query->whereDate('client_sessions.date','>=',$fromDate);
        }

        if($toDate)
        {
            $query=$query->whereDate('client_sessions.date','<=',$toDate);
        }



        return $query->get();
    }

    // get available Psychologist in specific date
    public function getMonthlySession($fromDay=null,$toDay=null,$fromDate=null,$toDate=null)
    {

        $query=$this
        ->join('schedules','schedules.id','client_sessions.schedule_id')
        ->join('timings','timings.id','client_sessions.timing_id')
        ->join('psychologists','psychologists.id','client_sessions.psychologist_id')
        ->selectRaw("
        client_sessions.date,
        count(client_sessions.id) AS total_session
        ")
        ->groupBy('client_sessions.date');

        if(\Auth::check() && auth()->user()->psychologist)
        {

            $query=$query->where('psychologists.id',auth()->user()->psychologist->id);
        }

        if($fromDate)
        {
            $query=$query->whereDate('client_sessions.date','>=',$fromDate);
        }

        if($toDate)
        {
            $query=$query->whereDate('client_sessions.date','<=',$toDate);
        }

        return $query->get();
    }

    // get available Psychologist in specific date
    public function getWeeklySession($fromDay=null,$toDay=null,$fromDate=null,$toDate=null)
    {

        $query=$this
        ->join('schedules','schedules.id','client_sessions.schedule_id')
        ->join('timings','timings.id','client_sessions.timing_id')
        ->join('psychologists','psychologists.id','client_sessions.psychologist_id')
        ->selectRaw("
        client_sessions.date,
        timings.start_time,
        timings.end_time,
        count(client_sessions.id) AS total_session
        ")
        ->groupBy('client_sessions.date','timings.id');
        // ->groupBy(function($date) {
        //     return Carbon::parse($date->check_in)->format('W');
        // });

        if(\Auth::check() && auth()->user()->psychologist)
        {
            $query=$query->where('psychologists.id',auth()->user()->psychologist->id);
        }

        if($fromDate)
        {
            $query=$query->whereDate('client_sessions.date','>=',$fromDate);
        }

        if($toDate)
        {
            $query=$query->whereDate('client_sessions.date','<=',$toDate);
        }

        return $query->get();
    }
//    get total session of a client
    public function getClientSessions($id)
    {
        return $this->selectRaw('count(client_id) as noOfSession')
                   ->where('client_id',$id)
                   ->get();
    }

    // get client session detail
    public function clientSessionDetail($id)
    {
        return $this
        ->join('psychologists','psychologists.id','client_sessions.psychologist_id')
        ->join('users','users.id','psychologists.user_id')
        ->join('clients','clients.id','client_sessions.client_id')
        ->join('schedules','schedules.id','client_sessions.schedule_id')
        ->join('timings','timings.id','client_sessions.timing_id')
        ->selectRaw("
        client_sessions.*,
        clients.name AS client_name,
        clients.last_name AS client_lastname,
        clients.code AS client_code,
        users.name AS psychologist_name,
        timings.start_time,
        timings.end_time,
        client_sessions.created_at AS start
        ")
        ->where('client_sessions.id',$id)
        ->first();
    }


//    get specific client sessions
    public  function getClientsSessions($id,$status)
    {
        $query = $this
            ->leftjoin('clients', 'clients.id', 'client_sessions.client_id')
            ->join('psychologists','psychologists.id','client_sessions.psychologist_id')
            ->join('users','users.id','psychologists.user_id')
            ->selectRaw('client_sessions.*,users.name as doctor,client_sessions.id as session_id')
            ->where('client_sessions.client_id',$id)
            ->where('client_sessions.status',$status)
            ->get();
        return $query;
    }


}
