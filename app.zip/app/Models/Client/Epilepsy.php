<?php

namespace App\Models\Client;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Epilepsy extends Model
{
    use HasFactory;
    protected $table= "epilepsies";

    public function clinicalAS(){
        return $this->belongsTo(ClinicalAS::class,'clinical_assessment_id','id');
    }
    public function getLastEpisodeDateAttribute($value)
    {
        if($value)
        {
            return date("d-m-Y", strtotime($value));
        }
    }
    public function getClientEpilepsies($id)
    {
        return $this->leftjoin('clinical_assessments','clinical_assessments.id','clinical_assessment_id')
                    ->selectRaw('epilepsies.*')
                    ->where('clinical_assessments.client_id',$id)
                    ->first();
    }


}
