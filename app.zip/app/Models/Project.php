<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\Paginator;
use App\Traits\Uuids;

class Project extends Model
{
    use HasFactory, Uuids;

    protected $table = "projects";

    protected $fillable = [
        'code',
        'name',
        'start_date',
        'end_date',
        'province_id',
        'description',
        'budget',
        'currency',
        'total_beneficiary',
        'status',
        'attachments',
        'user_id',
        'company_id',
        'location_id'
    ];


    public function projectList($request)
    {

        $filter = $request->input('search_keyword');
        $per_page = $request->input('per_page') ? $request->input('per_page') : 10;
        $start_page = $request->input('current_page');
        $project_type = $request->input('project_type');
        $order_by = $request->input('order_by');
        $order_direction = $request->input('order_direction');
        $company_id = auth()->user()->current_company;
        $query = null;

        if(auth()->user()->type == 'province'){

            $query = DB::table('projects')
            ->leftjoin('provinces', 'provinces.id', 'projects.province_id')
            ->leftjoin('invoices', 'invoices.project_id', 'projects.id')
            ->selectRaw('
                projects.id,
                projects.code,
                projects.name,
                projects.start_date,
                projects.end_date,
                projects.description,
                projects.budget,
                projects.total_beneficiary,
                provinces.name as location,
                (CASE
                    WHEN invoices.project_id != "" THEN true
                    ELSE false
                END) AS invoice,
                projects.created_at')
            ->where(['projects.company_id'=> $company_id, 'projects.status'=> $project_type])
            ->whereIn('projects.location_id', json_decode(auth()->user()->location_id,true));
        } else {

            $query = DB::table('projects')
            ->leftjoin('provinces', 'provinces.id', 'projects.province_id')
            ->leftjoin('invoices', 'invoices.project_id', 'projects.id')
            ->selectRaw('
                projects.id,
                projects.code,
                projects.name,
                projects.start_date,
                projects.end_date,
                projects.description,
                projects.budget,
                projects.total_beneficiary,
                provinces.name as location,
                (CASE
                    WHEN invoices.project_id != "" THEN true
                    ELSE false
                END) AS invoice,
                projects.created_at')
            ->groupBy('projects.id')
            ->where(['projects.company_id'=> $company_id, 'projects.status'=> $project_type]);
        }

        if ($filter && $filter != '') {

            $query = $query->where(function ($where) use ($filter) {
                $where->where('projects.name', 'like', '%' . $filter . '%')
                    ->orWhere('projects.code', 'like', '%' . $filter . '%')
                    ->orWhere('provinces.name', 'like', '%' . $filter . '%');
            });
        }

        if ($order_direction != '' || $order_by != '') {
            $query = $query->orderBy($order_by, $order_direction);
        }else {
            $query = $query->orderBy('projects.updated_at', 'desc');
        }


        Paginator::currentPageResolver(function () use ($start_page) {
            return $start_page;
        });

        return $query->paginate($per_page);
    }

    public function getProjectByProvince()
    {

        $data = null;

        if(auth()->user()->type == 'province'){

            $data = \DB::table('projects')
            ->join('provinces', 'provinces.id', 'projects.province_id')
            ->selectRaw("provinces.dashboard_client_code as proCode,
               provinces.name as proName,
               COUNT(projects.id) as clientsTotal")
            ->whereIn('projects.location_id', json_decode(auth()->user()->location_id,true))
            ->groupBy(DB::raw('province_id'))
            ->get();
        } else{

            $data = \DB::table('projects')
            ->join('provinces', 'provinces.id', 'projects.province_id')
            ->selectRaw("provinces.dashboard_client_code as proCode,
               provinces.name as proName,
               COUNT(projects.id) as clientsTotal")
            ->groupBy(DB::raw('province_id'))
            ->get();
        }

        return $data;
    }

    public function paidBinificiaries($id)
    {
        $query = DB::table('payments')
            ->leftJoin('payment_details','payment_details.payment_id','payments.id')
            ->where('payments.project_id',$id)
            ->sum('quantity');
        return $query;
    }

    public function paidBinificiariesInvoice($id)
    {
        $query = DB::table('payments')
            ->leftJoin('payment_details','payment_details.payment_id','payments.id')
            ->selectRaw('COALESCE(sum(payment_details.quantity), 0) as quantity, COALESCE(sum(payment_details.quantity * payment_details.amount), 0) as amount')
            ->where('payments.project_id',$id)
            ->first();
        return $query;
    }

    public function paidAmount($id)
    {
        $query = DB::table('payments')
                             ->leftJoin('transactions','transactions.id','payments.transaction_id')
                             ->where('payments.project_id',$id)
                             ->sum('transactions.amount');
        return $query;
    }

    public function getProjectByType($proId)
    {
        $data = \DB::table('projects')
            ->selectRaw("COUNT(projects.id) AS projectTotalByProvince, projects.province_id as proId")
            ->where('projects.province_id', $proId)
            ->get();

        return $data;
    }
//    final report for project

    public function finalReport($project_id) {
        return $this->leftjoin('provinces', 'projects.province_id','provinces.id')
                    ->selectRaw('projects.*,provinces.name as province')
                    ->where('projects.id', $project_id)
                    ->first();
    }
}
