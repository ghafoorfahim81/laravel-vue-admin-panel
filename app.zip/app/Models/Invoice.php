<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;
use App\Traits\Uuids;

class Invoice extends Model
{
    use HasFactory, Uuids;

    protected $table = "invoices";

    protected $fillable = [
        'organization_id',
        'project_id',
        'invoice_no',
        'date',
        'currency',
        'exchange_rate',
        'exchange_currency',
        'exchange_rate_second',
        'vol_rep',
        'status',
        'description',
        'purpose',
        'transaction_id',
        'attachment',
        'parent_id',
        'company_id',
        'location_id',
        'type',
        'is_show'
    ];


    public function invoices($request)
    {
        $filter = $request->input('search_keyword');
        $per_page = $request->input('per_page');
        $current_page = $request->input('current_page');
        $order_by = $request->input('order_by') ;
        $order_direction = $request->input('order_direction');
        $status = ($request->input('invoice_type') == 'paid') ? 1 : 0;
        $query = null;
        
        if(auth()->user()->type == 'province'){

            $query = DB::table('invoices')->leftJoin('invoice_details', 'invoice_details.invoice_id', 'invoices.id')
                ->leftJoin('companies', 'companies.id', 'invoices.organization_id')
                ->leftJoin('projects', 'projects.id', 'invoices.project_id')
                ->leftJoin('provinces', 'provinces.id', 'invoices.location_id')
                ->leftjoin('transactions', 'transactions.id', 'invoices.transaction_id')
                ->selectRaw('invoices.id,
                invoices.invoice_no,
                provinces.name as province,
                (transactions.amount) as amount,
                projects.name as project,
                companies.name as company,
                invoices.currency,
                invoices.created_at')
                ->where('invoices.company_id', auth()->user()->current_company)
                ->whereIn('invoices.location_id',  json_decode(auth()->user()->location_id,true))
                ->where('invoices.status', $status)
                ->groupBy('invoices.id', 'invoices.invoice_no', 'projects.name', 'companies.name', 'invoices.created_at');
        } else {

            $query = DB::table('invoices')->leftJoin('invoice_details', 'invoice_details.invoice_id', 'invoices.id')
            ->leftJoin('companies', 'companies.id', 'invoices.organization_id')
            ->leftJoin('projects', 'projects.id', 'invoices.project_id')
             ->leftJoin('provinces', 'provinces.id', 'invoices.location_id')
            ->leftjoin('transactions', 'transactions.id', 'invoices.transaction_id')
            ->selectRaw('invoices.id,
            invoices.invoice_no,
            (transactions.amount) as amount,
            projects.name as project,
             provinces.name as province,
            companies.name as company,
            invoices.currency,
            invoices.created_at')
            ->where('invoices.company_id', auth()->user()->current_company)
            ->where('invoices.status', $status)
            ->groupBy('invoices.id', 'invoices.invoice_no', 'projects.name', 'companies.name', 'invoices.created_at');
        }

        if ($filter != '') {
            $query = $query->where('invoices.invoice_no', 'like', '%' . $filter . '%');
        }

        if ($order_direction != '' || $order_by != '') {
            $query = $query->orderBy($order_by, $order_direction);
        } else {
            $query = $query->orderBy('invoices.created_at', 'desc');
        }
        Paginator::currentPageResolver(function () use ($current_page) {
            return $current_page;
        });
        return $query->paginate($per_page);
    }

    public function invoiceDetails()
    {
        return $this->hasMany('App\Models\InvoiceDetails', 'invoice_id');
    }

    public function print($id = null)
    {
            return DB::table('invoices')
            ->leftJoin('invoice_details', 'invoice_details.invoice_id', 'invoices.id')
            ->leftJoin('companies', 'companies.id', 'invoices.organization_id')
            ->leftJoin('projects', 'projects.id', 'invoices.project_id')
            ->leftJoin('provinces', 'provinces.id', 'invoice_details.location')
            ->leftJoin('currencies', 'currencies.code', 'invoices.currency')
            ->leftJoin('currencies as exchange_currencies', 'exchange_currencies.code', 'invoices.exchange_currency')
            ->selectRaw('companies.name as organization,companies.desc as company_datials, invoices.description as details, invoices.invoice_no,DATE_FORMAT(invoices.date, "%d/%M/%Y") as date,invoices.type as type, invoices.vol_rep,invoice_details.purchase_order,invoice_details.total_amount,(invoice_details.total_amount * COALESCE(invoices.exchange_rate,1)) as amount,invoice_details.total_amount, provinces.name as location,invoice_details.date as invoice_date,invoices.currency , invoices.purpose,invoices.parent_id,invoice_details.service_fee_percent,invoice_details.service_fee_amount,invoice_details.household,invoices.exchange_rate_second,invoices.exchange_currency, invoice_details.amount as house_amount,invoice_details.total, (invoice_details.total_amount * invoices.exchange_rate_second) as extra_amount,DATE_FORMAT(projects.created_at, "%Y") as project_date,projects.name as project_name, projects.code as project_code, currencies.symbol,exchange_currencies.symbol as exchange_symbol, IF(invoices.is_show =0, "false", "true") as show_project_name')
            ->where('invoices.id', $id)->get();
    }


    // function for getting invoices

    public function getInvoicesByStatus($status)
    {
        if(auth()->user()->type == 'province'){

            return $this->leftjoin('transactions', 'transactions.id', 'invoices.transaction_id')
                ->leftjoin('projects', 'projects.id', 'invoices.project_id')
                ->selectRaw('invoices.*,
                    invoices.id as id,
                    projects.name as project,
                    projects.province_id,
                    ((transactions.amount)) as amount,
                    transactions.currency')
                ->where('invoices.status', $status)
                ->whereIn('invoices.location_id',  json_decode(auth()->user()->location_id,true))
                ->orderBY('invoices.date')
                ->get();
        }
        else {
            return $this->leftjoin('transactions', 'transactions.id', 'invoices.transaction_id')
                ->leftjoin('projects', 'projects.id', 'invoices.project_id')
                ->selectRaw('invoices.*,
                    invoices.id as id,
                    projects.name as project,
                    projects.province_id,
                    ((transactions.amount)) as amount,
                    transactions.currency')
                ->where('invoices.status', $status)
                ->where('invoices.company_id', auth()->user()->current_company)
                ->orderBY('invoices.date')
                ->get();
        }
    }
    
    public function companyInvoices($request)
    {
        $filter = $request->input('search_keyword');
        $per_page = $request->input('per_page');
        $current_page = $request->input('current_page');
        $order_by = $request->input('order_by') ;
        $order_direction = $request->input('order_direction');
        $company_id = $request->input('company_id');
        $query = null;
        
        if(auth()->user()->type == 'province'){

            $query = DB::table('invoices')
                ->leftJoin('companies', 'companies.id', 'invoices.organization_id')
                ->leftJoin('projects', 'projects.id', 'invoices.project_id')
                ->leftJoin('provinces', 'provinces.id', 'invoices.location_id')
                ->leftjoin('transactions', 'transactions.id', 'invoices.transaction_id')
                ->leftjoin(DB::raw("(SELECT COALESCE(SUM(receipt_details.amount), 0) as paid_amount, receipt_details.invoice_id FROM receipt_details GROUP BY receipt_details.invoice_id) receipt_invoice"), function ($join) {
                    $join->on('invoices.id', '=', 'receipt_invoice.invoice_id');
                })
                ->selectRaw('invoices.id,
                invoices.invoice_no,
                provinces.name as province,
                (transactions.amount - receipt_invoice.paid_amount) as amount,
                projects.name as project,
                companies.name as company,
                invoices.currency,
                invoices.created_at')
                ->where('invoices.company_id', $company_id)
                ->whereIn('invoices.location_id',  json_decode(auth()->user()->location_id,true))
                ->where('invoices.status', false)
                ->groupBy('invoices.id', 'invoices.invoice_no', 'projects.name', 'companies.name', 'invoices.created_at');
        } else {

            $query = DB::table('invoices')
            ->leftJoin('companies', 'companies.id', 'invoices.organization_id')
            ->leftJoin('projects', 'projects.id', 'invoices.project_id')
            ->leftJoin('cash_drops', 'cash_drops.id', 'invoices.project_id')
            ->leftJoin('provinces as pro_location', 'pro_location.id', 'projects.province_id')
            ->leftJoin('provinces', 'provinces.id', 'cash_drops.province_id')
            ->leftjoin('transactions', 'transactions.id', 'invoices.transaction_id')
            ->leftjoin(DB::raw("(SELECT SUM(receipt_details.amount) as paid_amount, receipt_details.invoice_id 
            FROM receipt_details WHERE receipt_details.amount IS NOT NULL GROUP BY receipt_details.invoice_id) receipt_invoice"), function ($join) {
                $join->on('invoices.id', '=', 'receipt_invoice.invoice_id');
            })
            ->selectRaw('invoices.id,
            invoices.invoice_no,
            receipt_invoice.paid_amount,
            transactions.amount as tran_amount,
            (transactions.amount - receipt_invoice.paid_amount) as amount,
            projects.name as project,
            pro_location.name as province,
            provinces.name as cash_province,
            companies.name as company,
            invoices.currency,
            invoices.created_at')
            ->where('invoices.company_id', $company_id)
            ->where('invoices.status', false)
            ->groupBy('invoices.id', 'invoices.invoice_no', 'projects.name', 'companies.name', 'invoices.created_at');
        }

        if ($filter != '') {
            $query = $query->where('invoices.invoice_no', 'like', '%' . $filter . '%');
        }

        if ($order_direction != '' || $order_by != '') {
            $query = $query->orderBy($order_by, $order_direction);
        } else {
            $query = $query->orderBy('invoices.created_at', 'desc');
        }
        Paginator::currentPageResolver(function () use ($current_page) {
            return $current_page;
        });
        return $query->paginate($per_page);
    }


    public function invoiceNoParents()
    {

        if(auth()->user()->type == 'province'){

            return $this->leftjoin('projects', 'projects.id', 'invoices.project_id')
                ->selectRaw('invoices.id, IF(IFNULL(projects.name, "no") = "no", invoices.invoice_no, CONCAT(invoices.invoice_no, "-", projects.name)) as invoice')
                ->whereNull('invoices.parent_id')
                ->where('invoices.company_id', auth()->user()->current_company)
                ->whereIn('invoices.location_id',  json_decode(auth()->user()->location_id,true))
                ->get();
        } else {

            return $this->leftjoin('projects', 'projects.id', 'invoices.project_id')
                ->selectRaw('invoices.id,
                                IF(IFNULL(projects.name, "no") = "no", invoices.invoice_no, CONCAT(invoices.invoice_no, "-", projects.name)) as invoice')
                ->whereNull('invoices.parent_id')
                ->where('invoices.company_id', auth()->user()->current_company)
                ->get();
        }
    }

    public function invoiceReport($id)
    {
        $query = DB::table('invoices')->leftJoin('companies', 'companies.id', 'invoices.organization_id')
                ->leftJoin('projects', 'projects.id', 'invoices.project_id')
                ->leftJoin('provinces', 'provinces.id', 'projects.location_id')
                ->leftjoin('transactions', 'transactions.id', 'invoices.transaction_id')
                ->selectRaw('invoices.id,
                invoices.*,
                (transactions.amount)/transactions.rate as amount,
                projects.name as project,
                projects.code as project_code,
                companies.name as company,
                invoices.currency,
                provinces.name as province,
                (CASE
                    WHEN invoices.parent_id != "" THEN "comission"
                    ELSE "principle"
                END) AS type,
                DATE_FORMAT(invoices.date, "%Y-%m-%d") as date,
                invoices.created_at')
                ->where('invoices.id',$id);
                return $query->first();
    }


}
