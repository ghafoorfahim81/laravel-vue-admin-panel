<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\Uuids;

class ReceiptDetails extends Model
{
    use HasFactory,Uuids;

    protected $fillable = [
           'receipt_id',
           'type',
           'invoice_no',
           'pay_date',
           'transaction_id',
           'invoice_id',
           'currency',
           'amount',
    ];

    public function getDetails($id){
        return $this->leftjoin('invoices','invoices.id','receipt_details.invoice_id')
                    ->leftjoin('projects','projects.id','invoices.project_id')
                    ->leftjoin('transactions','transactions.id','receipt_details.transaction_id')
                    ->selectRaw('invoices.invoice_no as invoice_no,projects.name as project,
                    transactions.currency,
                    transactions.amount,
                    receipt_details.*')
                    ->where('receipt_details.receipt_id',$id)
                    ->get();
    }
}
