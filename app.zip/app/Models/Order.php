<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;
use App\Traits\Uuids;

class Order extends Model
{
    use HasFactory, Uuids;

    protected $table = "orders";

    protected $fillable = [
        'number',
        'organization_id',
        'project_id',
        'from_date',
        'to_date',
        'currency',
        'exchange_rate',
        'ref_no',
        'description',
        'status',
        'user_id',
        'company_id',
        'location_id'
    ];

    public function orders($request){
        $filter = $request->input('filter');
        $per_page = $request->input('per_page');
        $current_page = $request->input('current_page');
        $order_by = $request->input('order_by');
        $order_direction = $request->input('order_direction');
        $query = null;

        if(auth()->user()->type == 'province'){

            $query = DB::table('orders')->leftJoin('order_details','order_details.order_id','orders.id')
                      ->leftJoin('companies','companies.id','orders.organization_id')
                      ->leftJoin('projects','projects.id','orders.project_id')
                      ->selectRaw('orders.id, 
                            orders.number,
                            sum((order_details.quantity*order_details.price) * orders.exchange_rate ) as amount,
                            projects.name as project,
                            companies.name as company, 
                            orders.currency,
                            orders.created_at')
                      ->where('orders.company_id', auth()->user()->current_company)
                      ->whereIn('orders.location_id', json_decode(auth()->user()->location_id,true))
                      ->groupBy('orders.id', 'orders.number', 'projects.name', 'companies.name', 'orders.created_at');
        } else {

            $query = DB::table('orders')->leftJoin('order_details','order_details.order_id','orders.id')
                      ->leftJoin('companies','companies.id','orders.organization_id')
                      ->leftJoin('projects','projects.id','orders.project_id')
                      ->selectRaw('orders.id, 
                            orders.number,
                            sum((order_details.quantity*order_details.price) * orders.exchange_rate ) as amount,
                            projects.name as project,
                            companies.name as company, 
                            orders.currency,
                            orders.created_at')
                      ->where(['orders.company_id'=> auth()->user()->current_company])
                      ->groupBy('orders.id', 'orders.number', 'projects.name', 'companies.name', 'orders.created_at');
        }
        
        if ($filter != '') {
            $query = $query->where('orders.currency', 'like', '%' . $filter . '%')
                ->orwhere('companies.name', 'like', '%' . $filter . '%')
                ->orwhere('projects.name', 'like', '%' . $filter . '%');
        }

        if ($order_direction != '' || $order_by != '') {
            $query = $query->orderBy($order_by, $order_direction);
        }
      Paginator::currentPageResolver(function () use ($current_page) {
        return $current_page;
        });
        return $query->paginate($per_page);
    }

    public function orderDetails()
    {
        return $this->hasMany('App\Models\OrderDetails', 'order_id'); 
    }
}

