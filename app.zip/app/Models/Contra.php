<?php

namespace App\Models;

use App\Traits\Uuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;

class Contra extends Model
{
    use HasFactory, Uuids;

    protected $fillable = [
        'company_id',
        'transaction_id',
        'request_id',
        'receipt_no',
        'purpose',
        'location_id'
    ];
    public function contras($request){
        $filter = $request->input('search_keyword');
        $per_page = $request->input('per_page') ? $request->input('per_page') : 10;
        $start_page = $request->input('current_page');
        $order_by = $request->input('order_by');
        $order_direction = $request->input('order_direction');
        $query = $this->leftJoin('transactions','transactions.id','cash_drops.transaction_id')
                      ->selectRaw('transactions.amount,transactions.currency,cash_drops.*')
                      ->where('cash_drops.company_id', auth()->user()->current_company);
        if ($order_direction != '' || $order_by != '') {
            $query = $query->orderBy($order_by, $order_direction);
        }
        if ($filter != '') {
            $query = $query->where('cash_drops.request_id', 'like', '%' . $filter . '%')
             ->orwhere('cash_drops.receipt_no', 'like', '%' . $filter . '%')
             ->orwhere('accounts.purpose', 'like', '%' . $filter . '%')
             ->orwhere('transactions.currency', 'like', '%' . $filter . '%');
        }
        Paginator::currentPageResolver(function () use ($start_page) {
            return $start_page;
        });

        return $query->paginate($per_page);
    }

    public function getContra($id){
        return $this->leftjoin('transactions','transactions.id','cash_drops.transaction_id')
                    ->selectRaw('transactions.amount,transactions.currency,transactions.rate,cash_drops.*')
                    ->where('cash_drops.id',$id)
                    ->first();
    }
}
