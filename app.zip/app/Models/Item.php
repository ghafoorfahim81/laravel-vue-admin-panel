<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;
use App\Traits\Uuids;

class Item extends Model
{
    use HasFactory, Uuids;

    protected $connection = 'mysql';
    protected $table = "items";

    protected $fillable = [
        'name',
        'description',
        'user_id'
    ];

    public function itemList($request)
    {
        $filter = $request->input('search_keyword');
        $per_page = $request->input('per_page') ? $request->input('per_page') : 10;
        $start_page = $request->input('current_page');
        $order_by = $request->input('order_by');
        $order_direction = $request->input('order_direction');

        $query = $this->selectRaw('items.id, items.name, items.description, items.created_at');
        if ($filter && $filter != '') {

            $query = $query->where(function ($where) use ($filter) {
                $where->where('items.name', 'like', '%' . $filter . '%')
                    ->orWhere('items.description', 'like', '%' . $filter . '%');
            });
        }

        if ($order_direction != '' || $order_by != '') {
            $query = $query->orderBy($order_by, $order_direction);
        }


        Paginator::currentPageResolver(function () use ($start_page) {
            return $start_page;
        });

        return $query->paginate($per_page);
    }
}
 