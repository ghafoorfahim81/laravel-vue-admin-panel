<?php

namespace App\Models;

use App\Traits\Uuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;

class Account extends Model
{
    use HasFactory, Uuids;

    protected $fillable = [
        'id',
        'name',
        'station',
        'account_no',
        'address',
        'contact_person',
        'phone_no',
        'email',
        'currency',
        'swift',
        'user_id',
        'company_id',
        'location_id'
    ];

    public function accountList($request)
    {
        $filter = $request->input('search_keyword');
        $per_page = $request->input('per_page') ? $request->input('per_page') : 10;
        $start_page = $request->input('current_page');
        $order_by = $request->input('order_by');
        $order_direction = $request->input('order_direction');
        $query = DB::table('accounts')->selectRaw('*')
            ->where('company_id', auth()->user()->current_company);
        // ->groupBy('id');
        if ($order_direction != '' || $order_by != '') {
            $query = $query->orderBy($order_by, $order_direction);
        }
        if ($filter != '') {
            $query = $query->where('accounts.name', 'like', '%' . $filter . '%');
                // ->orwhere('accounts.code', 'like', '%' . $filter . '%')
                // ->orwhere('accounts.symbol', 'like', '%' . $filter . '%')
                // ->orwhere('accounts.format', 'like', '%' . $filter . '%')
                // ->orwhere('accounts.exchange_rate', 'like', '%' . $filter . '%');
        }
        Paginator::currentPageResolver(function () use ($start_page) {
            return $start_page;
        });

        return $query->paginate($per_page);
    }

    public function getAccountByName($name)
    {
        return $this->select('name','id')->where('name',$name)->first();
    }
}
