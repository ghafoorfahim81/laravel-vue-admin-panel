<?php

    return[
        
        'updated_success'=>'Updated Successfully',
        'warning'=>'Something wen wrong please try again',
        'created_success'=>'Created Successfully',
        'exists'=>'Record already exists',
        'has_data'=>'Sorry this record has releted data you can not delete or update this',
        'error'=>'Something went wrong please try again',
        'success'=>'Successfully done',
        'no_contract_msg'=>'Sorry no contract found',
        "401_msg"=>"Sorry you are not authorized",
       
        ''=>'',
        
    ];
?>