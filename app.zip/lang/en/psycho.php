<?php

    return[

        'psychologist'=>'Psychologist',
        'information'=>'Information',
        'saturday'=>'Saturday',
        'sunday'=>'Sunday',
        'monday'=>'Monday',
        'tuesday'=>'Tuesday',
        'wednesday'=>'Wednesday',
        'thursday'=>'Thursday',
        'friday'=>'Friday',
        ''=>'',
        ''=>'',
        ''=>'',
        ''=>'',
        ''=>'',
        ''=>'',
        ''=>'',
        ''=>'',
        ''=>'',

    ];
?>
