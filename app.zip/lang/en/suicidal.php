<?php

    return[
        'suicidal_ideation_initial_assessment'=>'Suicidal ideation initial assessment',
        'in_the_past_month_have_you_had_serious_thoughts_or_a_plan_to_end_your_life?'=>'In the past month, have you had serious thoughts or a plan to end your life?',
        'what_actions_have_you_taken_to_end_life?'=>'What actions have you taken to end life?',
        'do_you_plan_to_end_your_life_to_end_your_life_in_next_two_week'=>'Do you plan to end your life to end your life in next two week',
        'unsure'=>'Unsure',
        ''=>'',
        ''=>'',
        ''=>'',
        ''=>'',

    ];
?>
