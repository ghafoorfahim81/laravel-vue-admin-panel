<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Client\ClientController;
use App\Http\Controllers\DashboardController;
// use App\Http\Controllers\Client\PriorityController;
// use App\Http\Controllers\Client\WellbeingController;
use App\Http\Controllers\Client\ClinicalASController;
use App\Http\Controllers\Client\ReferralController;
use App\Http\Controllers\Partial\DisabilityController;
use App\Http\Controllers\Partial\SymptomController;
use App\Http\Controllers\Partial\MajorSymptomController;
// use App\Http\Controllers\Psycho\AppointmentController;
use App\Http\Controllers\TimingController;
use App\Http\Controllers\PsychologistController;
use App\Http\Controllers\CompanyController;
use App\Http\Controllers\CurrencyController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\ItemController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\Order\OrderController;

use App\Events\Appointment;
use App\Events\Test;
use App\Http\Controllers\TransactionsController;
use App\Http\Middleware\DBConfigMiddleware;

use App\Http\Controllers\Reports;
// Route::get('/broadcast',function(){
//     // broadcast(new Appointment());
//     broadcast(new Test());
// });
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//Route::middleware(['auth:sanctum', 'verified'])->get('/', function () {
//    return view('dashboard');
//})->name('dashboard');

//begin auth middelware and route group
// Route::get('/company/create', [CompanyController::class, 'create'])->middleware('permission:company_create')->name('company.create');
// Route::post('/company/store', [CompanyController::class, 'store'])->middleware('permission:company_create')->name('company.store');

Route::get('/testPdf', ['uses' => 'Report\ReportController@index',  'as' => 'tests.index']);

Route::get('/dbFresh', function () {
    Artisan::call('migrate:fresh --seed');
});

Route::get('/company/create', ['uses' => 'CompanyController@create', 'middleware' => [ 'permission:company_create'], 'as' => 'company.create']);
Route::post('/company/store', ['uses' => 'CompanyController@store', 'middleware' => [ 'permission:company_create'], 'as' => 'company.store']);
Route::get('/mail/send', ['uses' => 'ItemController@sendMail', 'as' => 'item.mail']);

Route::middleware(['auth', 'checkcompany'])->group(function () {
    //--------------------------------------------------company routes
    // Route::get('/company', [CompanyController::class, 'index'])->middleware('permission:company_list')->name('company.index');
    // Route::get('company/edit/{id}', [CompanyController::class, 'edit'])->middleware('permission:company_create')->name('company.edit');
    // Route::patch('company/{id}', [CompanyController::class, 'update'])->middleware('permission:company_edit')->name('company.update');
    // Route::get('/company/select/{id}', [CompanyController::class, 'switchCompany'])->middleware('permission:company_view')->name('company.select');

    Route::get('/company', ['uses' => 'CompanyController@index', 'middleware' => [ 'permission:company_list'], 'as' => 'company.index']);
    Route::get('/company/{id}', ['uses' => 'CompanyController@show', 'middleware' => [ 'permission:company_list'], 'as' => 'company.show']);
    Route::get('/company/edit/{id}', ['uses' => 'CompanyController@edit', 'middleware' => [ 'permission:company_create'], 'as' => 'company.edit']);
    Route::patch('/company/{id}', ['uses' => 'CompanyController@update', 'middleware' => [ 'permission:company_edit'], 'as' => 'company.update']);
    Route::get('/company/select/{id}', ['uses' => 'CompanyController@switchCompany', 'middleware' => [ 'permission:company_view'], 'as' => 'company.view']);
    Route::get('company_profile', ['uses' => 'CompanyController@profile','middleware' => [ 'permission:company_list'], 'as' => 'company_profile.index']);

    //--------------------------------------------------currency routes
    // Route::get('/currency', [CurrencyController::class, 'index', 'middleware' => ['permission:currency_list']])->name('currency.index');
    // Route::post('/currency/store', [CurrencyController::class, 'store', 'middleware' => ['permission:currency_create']])->name('currency.store');
    // Route::get('/getCurrencies', [CurrencyController::class, 'getCurrencies', 'middleware' => ['permission:currency_list']])->name('currency.all');
    // Route::get('/defaultCurrenies', [CurrencyController::class, 'defaultCurrenies', 'middleware' => ['permission:currency_list']])->name('currency.default');
    // Route::get('/currency/rate', [CurrencyController::class, 'rateIndex', 'middleware' => ['permission:rate_list']])->name('rate.view');
    // Route::get('/rate/index', [CurrencyController::class, 'editRate', 'middleware' => ['permission:rate_list']])->name('rate.index');
    // Route::get('/rate/default', [CurrencyController::class, 'getOpeningCurrency', 'middleware' => ['permission:rate_list']])->name('rate.default');
    // Route::get('/getRate/{id}', [CurrencyController::class, 'getRate', 'middleware' => ['permission:rate_list']])->name('currency_get_rate');
    // Route::patch('/rate', [CurrencyController::class, 'update_rate', 'middleware' => ['permission:rate_edit']])->name('rate.update');
    // Route::delete('currency/{id}', ['uses' => 'CurrencyController@destroy', 'middleware' => ['permission:currency_delete'], 'as' => 'currency.delete']);

    // Route::get('/transactions', [TransactionsController::class, 'index'])->name('transactions.index');
    // Route::get('/transactions/create', [TransactionsController::class, 'create'])->name('transactions.create');

    // new currency and rate route
    Route::get('/currency', ['uses' => 'CurrencyController@index', 'middleware' => [ 'permission:currency_list'], 'as' => 'currency.index']);
    Route::post('/currency/store', ['uses' => 'CurrencyController@store', 'middleware' => [ 'permission:currency_create'], 'as' => 'currency.store']);
    Route::get('/getCurrencies', ['uses' => 'CurrencyController@getCurrencies', 'middleware' => [ 'permission:currency_list'], 'as' => 'currency.all']);
    Route::get('/defaultCurrenies', ['uses' => 'CurrencyController@defaultCurrenies', 'middleware' => [ 'permission:currency_list'], 'as' => 'currency.default']);
    Route::get('/currency/rate', ['uses' => 'CurrencyController@rateIndex', 'middleware' => [ 'permission:rate_list'], 'as' => 'rate.view']);
    Route::post('currency/{id}', ['uses' => 'CurrencyController@destroy', 'middleware' => [ 'permission:currency_delete'], 'as' => 'currency.delete']);
    //rate
    Route::get('/rate/index', ['uses' => 'CurrencyController@editRate', 'middleware' => [ 'permission:rate_list'], 'as' => 'rate.index']);
    Route::get('/rate/default', ['uses' => 'CurrencyController@getOpeningCurrency', 'middleware' => [ 'permission:rate_list'], 'as' => 'rate.default']);
    Route::get('/getRate/{id}', ['uses' => 'CurrencyController@getRate', 'middleware' => [ 'permission:rate_list'], 'as' => 'currency_get_rate']);
    Route::post('/rate', ['uses' => 'CurrencyController@update_rate', 'middleware' => [ 'permission:rate_edit'], 'as' => 'rate.update']);

    //end currency andn rate route
    //start transaction route
    Route::get('/transactions', ['uses' => 'TransactionsController@update_rate',  'as' => 'transactions.index']);
    Route::get('/final_report/{project_id}', ['uses' => 'Report\ReportController@finalReport',  'as' => 'final.report']);
    Route::get('/export/to/excel/invoice/{invoice_id}', ['uses' => 'Excel\ExcelController@exportInvoice',  'as' => 'invoice.excel']);
    Route::get('/export/to/pdf/invoice/{invoice_id}', ['uses' => 'PDF\PDFController@invoicesPDF',  'as' => 'invoice.pdf']);

    Route::get('/transactions/create', ['uses' => 'TransactionsController@create',  'as' => 'transactions.create']);

    //end transaction
    //=----------------------------------------------------------- Account
    Route::get('account', ['uses' => 'AccountController@index', 'middleware' => ['permission:account_list'], 'as' => 'account.index']);
    Route::get('account/create', ['uses' => 'AccountController@create', 'middleware' => ['permission:account_create'], 'as' => 'account.create']);
    Route::post('account/store', ['uses' => 'AccountController@store', 'middleware' => ['permission:account_create'], 'as' => 'account.store']);
    Route::get('account/edit/{id}', ['uses' => 'AccountController@edit', 'middleware' => ['permission:account_edit'], 'as' => 'account.edit']);
    Route::patch('account/{id}', ['uses' => 'AccountController@update', 'middleware' => ['permission:account_edit'], 'as' => 'account.update']);
    Route::post('account/{id}', ['uses' => 'AccountController@destroy', 'middleware' => ['permission:account_delete'], 'as' => 'account.destroy']);
    //=----------------------------------------------------------- Account
    Route::get('expense', ['uses' => 'ExpenseController@index', 'middleware' => ['permission:expense_list'], 'as' => 'expense.index']);
    Route::get('expense/create', ['uses' => 'ExpenseController@create', 'middleware' => ['permission:expense_create'], 'as' => 'expense.create']);
    Route::post('expense/store', ['uses' => 'ExpenseController@store', 'middleware' => ['permission:expense_create'], 'as' => 'expense.store']);
    Route::get('expense/edit/{id}', ['uses' => 'ExpenseController@edit', 'middleware' => ['permission:expense_edit'], 'as' => 'expense.edit']);
    Route::patch('expense/{id}', ['uses' => 'ExpenseController@update', 'middleware' => ['permission:expense_edit'], 'as' => 'expense.update']);
    Route::post('expense/{id}', ['uses' => 'ExpenseController@destroy', 'middleware' => ['permission:expense_delete'], 'as' => 'expense.destroy']);
    //=----------------------------------------------------------- Account
    Route::get('expenseCategory', ['uses' => 'ExpenseCategoryController@index', 'middleware' => ['permission:category_list'], 'as' => 'expense_category.index']);
    Route::get('expenseCategoryAll', ['uses' => 'ExpenseCategoryController@categories', 'middleware' => ['permission:category_list'], 'as' => 'categories']);
    Route::get('expenseCategory/create', ['uses' => 'ExpenseCategoryController@create', 'middleware' => ['permission:category_create'], 'as' => 'expense_category.create']);
    Route::post('expenseCategory/store', ['uses' => 'ExpenseCategoryController@store', 'middleware' => ['permission:category_create'], 'as' => 'expense_category.store']);
        Route::get('expense/{id}', ['uses' => 'ExpenseController@show', 'middleware' => ['permission:expense_view'], 'as' => 'expense.show']);
    Route::get('expenseCategory/edit/{id}', ['uses' => 'ExpenseCategoryController@edit', 'middleware' => ['permission:category_edit'], 'as' => 'expense_category.edit']);
    Route::patch('expenseCategory/{id}', ['uses' => 'ExpenseCategoryController@update', 'middleware' => ['permission:category_edit'], 'as' => 'expense_category.update']);
    Route::post('expenseCategory/{id}', ['uses' => 'ExpenseCategoryController@destroy', 'middleware' => ['permission:category_delete'], 'as' => 'expense_category.destroy']);

    //--------------------------------------------------project routes
    // Route::get('/project', [ProjectController::class, 'index','middleware' => ['permission:project_list']])->name('project.index');
    // Route::get('/project/all', [ProjectController::class, 'all', 'middleware' => ['permission:project_list']])->name('project.all');
    // Route::get('/project/create', [ProjectController::class, 'create', 'middleware' => ['permission:project_create']])->name('project.create');
    // Route::post('/project/store', [ProjectController::class, 'store', 'middleware' => ['permission:project_create']])->name('project.store');
    // Route::get('project/download/{name}/{id}', [ProjectController::class, 'downloadFile'])->name('project.download');
    // Route::get('/project/{id}', [ProjectController::class, 'show', 'middleware' => ['permission:project_edit']])->name('project.show');
    // Route::get('/project/edit/{id}', [ProjectController::class, 'edit', 'middleware' => ['permission:project_edit']])->name('project.edit');
    // Route::patch('/project/update/{id}', [ProjectController::class, 'update', 'middleware' => ['permission:project_edit']])->name('project.update');
    // Route::delete('project/{id}', [ProjectController::class, 'destroy', 'middleware' => ['permission:project_edit']])->name('project.delete');

    Route::get('/checkProject', ['uses' => 'ProjectController@checkNameAndCode', 'as' => 'project.check']);

    Route::get('/project', ['uses' => 'ProjectController@index', 'middleware' => [ 'permission:project_list'], 'as' => 'project.index']);
    Route::get('/project/all', ['uses' => 'ProjectController@all', 'middleware' => [ 'permission:project_list'], 'as' => 'project.all']);
    Route::get('/project/create', ['uses' => 'ProjectController@create', 'middleware' => [ 'permission:project_create'], 'as' => 'project.create']);
    Route::post('/project/files', ['uses' => 'ProjectController@newFiles', 'middleware' => [ 'permission:project_create'], 'as' => 'project.files']);
    Route::post('/project/store', ['uses' => 'ProjectController@store', 'middleware' => [ 'permission:project_create'], 'as' => 'project.store']);
    Route::get('project/download/{name}/{id}', ['uses' => 'ProjectController@downloadFile', 'middleware' => [ 'permission:project_view'], 'as' => 'project.download']);
    Route::get('/project/{id}', ['uses' => 'ProjectController@show', 'middleware' => [ 'permission:project_view'], 'as' => 'project.show']);
    Route::get('/project/close/{id}', ['uses' => 'ProjectController@closeProject', 'middleware' => [ 'permission:project_view'], 'as' => 'project.close']);
    Route::get('/project/edit/{id}', ['uses' => 'ProjectController@edit', 'middleware' => [ 'permission:project_edit'], 'as' => 'project.edit']);
    Route::patch('/project/update/{id}', ['uses' => 'ProjectController@update', 'middleware' => [ 'permission:project_edit'], 'as' => 'project.update']);
    Route::post('/project/{id}', ['uses' => 'ProjectController@destroy', 'middleware' => [ 'permission:project_delete'], 'as' => 'project.delete']);
    //--------------------------------------------------item routes
    // Route::middleware([DBConfigMiddleware::class])->group(function(){

    // });
    Route::get('/item', ['uses'=>'ItemController@index','middleware' => [ 'permission:beneficialy_list'],'as'=>'item.index']);
    Route::get('/item/create', ['uses'=>'ItemController@create', 'middleware' => [ 'permission:beneficialy_create'],'as'=>'item.create']);
    Route::post('/item/store', ['uses'=>'ItemController@store', 'middleware' => [ 'permission:beneficialy_create'],'as'=>'item.store']);
    Route::post('/item/edit', ['uses'=>'ItemController@edit', 'middleware' => [ 'permission:beneficialy_edit'],'as'=>'item.edit']);
    Route::post('/item/update', ['uses'=>'ItemController@update', 'middleware' => [ 'permission:beneficialy_edit'],'as'=>'item.update']);
    Route::get('/item/all', ['uses'=>'ItemController@getItems', 'middleware' => [ 'permission:beneficialy_list'],'as'=>'item.all']);

    // Order
    Route::get('order', ['uses'=>'Order\OrderController@index', 'middleware' => ['permission:order_list'],'as'=>'order.index']);
    Route::get('order/create', ['uses'=>'Order\OrderController@create', 'middleware' => [ 'permission:order_create'],'as'=>'order.create']);
    Route::post('order/store', ['uses'=>'Order\OrderController@store', 'middleware' => [ 'permission:order_create'],'as'=>'order.store']);
    Route::get('order/edit/{id}', ['uses'=>'Order\OrderController@edit', 'middleware' => [ 'permission:order_edit'],'as'=>'order.edit']);
    Route::get('order/{id}', ['uses'=>'Order\OrderController@show', 'middleware' => [ 'permission:order_view'],'as'=>'order.show']);
    Route::patch('order/{id}', ['uses'=>'Order\OrderController@update', 'middleware' => [ 'permission:order_edit'],'as'=>'order.update']);
    Route::post('order/{id}', ['uses'=>'Order\OrderController@destroy', 'middleware' => [ 'permission:order_delete'],'as'=>'order.delete']);

// invoice
    Route::get('invoice', ['uses'=>'InvoiceController@index', 'middleware' => ['permission:invoice_list'],'as'=>'invoice.index']);
    Route::get('invoice/numberCheck', ['uses'=>'InvoiceController@checkInvoiceNumber', 'middleware' => ['permission:invoice_create'],'as'=>'invoice.checkInvoiceNumber']);
    Route::get('invoice/create', ['uses'=>'InvoiceController@create', 'middleware' => ['permission:invoice_create'],'as'=>'invoice.create']);
    Route::post('invoice/store', ['uses'=>'InvoiceController@store', 'middleware' => ['permission:invoice_create'],'as'=>'invoice.store']);
    Route::get('invoice/download/{name}/{id}', ['uses'=>'InvoiceController@downloadFile','as'=>'invoice.download']);
    Route::get('invoice/edit/{id}', ['uses'=>'InvoiceController@edit', 'middleware' => ['permission:invoice_edit'],'as'=>'invoice.edit']);
    Route::get('invoice/commission/{id}', ['uses'=>'InvoiceController@getInvoiceCommission', 'middleware' => ['permission:invoice_create'],'as'=>'invoice.commission']);
    Route::get('invoice/{id}', ['uses'=>'InvoiceController@show', 'middleware' => ['permission:invoice_view'],'as'=>'invoice.show']);
    Route::patch('invoice/{id}', ['uses'=>'InvoiceController@update', 'middleware' => ['permission:invoice_edit'],'as'=>'invoice.update']);
    Route::get('invoice/print/{id}', ['uses'=>'InvoiceController@print', 'middleware' => ['permission:invoice_view'],'as'=>'invoice.print']);
    Route::get('householde/{id}', ['uses'=>'InvoiceController@paidBinificiariesFunc', 'middleware' => ['permission:invoice_create'],'as'=>'invoice.householde']);
    Route::post('invoice/{id}', ['uses'=>'InvoiceController@destroy','middleware' => ['permission:invoice_delete'],'as'=>'invoice.dalete']);




    Route::get('/item', ['uses'=>'ItemController@index', 'as'=>'item.index']);

    Route::get('/', ['uses'=>'AdminController@index','as'=>'admin']);
    Route::post('/checkpassword', ['uses'=>'AdminController@checkpassword', 'as'=>'checkpassword']);
    Route::get('/setting', ['uses'=>'AdminController@setting','middleware'=>['permission:setting'],'as'=>'setting']);
    Route::post('/change-referral-export-password', ['uses'=>'AdminController@changeReferralExportPassword', 'as'=>'changeReferralExportPassword']);
    Route::get('/', ['uses'=>'DashboardController@index','as'=>'dashboard']);
    Route::get('/dashboardData', ['uses'=>'DashboardController@dashboardData', 'middleware' => ['permission:dashboard_show'],'as'=>'dashboardData']);

    Route::get('/clientsDashboard', ['uses'=>'DashboardController@index','middleware'=>['permission:dashboard_show'],'as'=>'getClientDashboard']);

    Route::get('export_pdf/{id}', ['uses'=>'ReferralController@show', 'as'=>'export-pdf']);
    Route::post('excel', ['uses' => 'Excel\ExcelController@export']);
    Route::post('pdf', ['uses' => 'PDF\PDFController@pdf']);


    Route::group(['namespace' => 'UserManagement'], function () {
        // user
        Route::get('user', ['uses' => 'UserController@index', 'middleware' => [ 'permission:user_list'], 'as' => 'user.index']);
        Route::get('user/create', ['uses' => 'UserController@create', 'middleware' => [ 'permission:user_create'], 'as' => 'user.create']);
        Route::post('user/store', ['uses' => 'UserController@store', 'middleware' => [ 'permission:user_create'], 'as' => 'user.store']);
        Route::get('user/setting', ['uses' => 'UserController@getCurrentUserSetting', 'middleware' => [ 'permission:user_view'], 'as' => 'user.setting']);
        Route::post('user/setting', ['uses' => 'UserController@setting', 'middleware' => [ 'permission:user_view'], 'as' => 'user.update_setting']);
        Route::get('user/edit/{id}', ['uses' => 'UserController@edit', 'middleware' => [ 'permission:user_edit'], 'as' => 'user.edit']);
        Route::get('user/{id}', ['uses' => 'UserController@show', 'middleware' => [ 'permission:user_view'], 'as' => 'user.show']);
        Route::get('profile/{id}', ['uses' => 'UserController@profile', 'as' => 'user.profile']);
        Route::patch('user/{id}', ['uses' => 'UserController@update', 'middleware' => [ 'permission:user_edit'], 'as' => 'user.update']);
        Route::post('user/updateProfile', ['uses' => 'UserController@updateProfile', 'middleware' => [ 'permission:user_edit'], 'as' => 'user.updateProfile']);
        Route::post('user/{id}', ['uses' => 'UserController@destroy', 'middleware' => [ 'permission:user_delete'], 'as' => 'user']);
        Route::get('check_password', 'UserController@checkPassword')->name('users.password');
        Route::get('checkEmail',  ['uses'=> 'UserController@checkEmail', 'middleware' => [ 'permission:user_list']])->name('users.check');



        // role
        Route::get('role', ['uses' => 'RoleController@index', 'middleware' => [ 'permission:role_list'], 'as' => 'role.index']);
        Route::get('role/create', ['uses' => 'RoleController@create', 'middleware' => [ 'permission:role_create'], 'as' => 'role.create']);
        Route::post('role/store', ['uses' => 'RoleController@store', 'middleware' => [ 'permission:role_create'], 'as' => 'role.store']);
        Route::get('role/edit/{id}', ['uses' => 'RoleController@edit', 'middleware' => [ 'permission:role_edit'], 'as' => 'role.edit']);
        Route::get('role/{id}', ['uses' => 'RoleController@show', 'middleware' => [ 'permission:role_view'], 'as' => 'role.show']);
        Route::patch('role/{id}', ['uses' => 'RoleController@update', 'middleware' => [ 'permission:role_edit'], 'as' => 'role.update']);
        Route::post('role/{id}', ['uses' => 'RoleController@destroy', 'middleware' => [ 'permission:role_delete'], 'as' => 'role']);
    });

    Route::get('searchItem', ['uses' => 'Fund\FundController@search','as' => 'search.item']);

    Route::get('cash_drop', ['uses' => 'CashDrop\CashDropController@index', 'middleware' => [ 'permission:cash_drop_list'], 'as' => 'cash_drop.index']);
    Route::get('cash_drop/create', ['uses' => 'CashDrop\CashDropController@create', 'middleware' => [ 'permission:cash_drop_create'], 'as' => 'cash_drop.create']);
    Route::post('cash_drop/store', ['uses' => 'CashDrop\CashDropController@store', 'middleware' => [ 'permission:cash_drop_create'], 'as' => 'cash_drop.store']);
    Route::get('cash_drop/download/{name}/{id}', ['uses' => 'CashDrop\CashDropController@downloadFile', 'middleware' => [ 'permission:project_view'], 'as' => 'project.download']);
    Route::post('/cash_drop/files', ['uses' => 'CashDrop\CashDropController@newFiles', 'middleware' => [ 'permission:cash_drop_create'], 'as' => 'cash_drop.files']);
    Route::get('cash_drop/edit/{id}', ['uses' => 'CashDrop\CashDropController@edit', 'middleware' => [ 'permission:cash_drop_edit'], 'as' => 'cash_drop.edit']);
    Route::get('cash_drop/{id}', ['uses' => 'CashDrop\CashDropController@show', 'middleware' => [ 'permission:cash_drop_view'], 'as' => 'cash_drop.show']);
    Route::patch('cash_drop/{id}', ['uses' => 'CashDrop\CashDropController@update', 'middleware' => [ 'permission:cash_drop_edit'], 'as' => 'cash_drop.update']);
    Route::post('cash_drop/{id}', ['uses' => 'CashDrop\CashDropController@destroy', 'middleware' => [ 'permission:cash_drop_delete'], 'as' => 'cash_drop']);


    Route::get('receipt', ['uses' => 'Receipt\ReceiptController@index', 'middleware' => [ 'permission:receipt_list'], 'as' => 'receipt.index']);
    Route::get('receipt/create', ['uses' => 'Receipt\ReceiptController@create', 'middleware' => [ 'permission:receipt_create'], 'as' => 'receipt.create']);
    Route::post('receipt/store', ['uses' => 'Receipt\ReceiptController@store', 'middleware' => [ 'permission:receipt_create'], 'as' => 'receipt.store']);
    Route::get('receipt/edit/{id}', ['uses' => 'Receipt\ReceiptController@edit', 'middleware' => [ 'permission:receipt_edit'], 'as' => 'receipt.edit']);
    Route::get('receipt/{id}', ['uses' => 'Receipt\ReceiptController@show', 'middleware' => [ 'permission:receipt_view'], 'as' => 'receipt.show']);
    Route::patch('receipt/{id}', ['uses' => 'Receipt\ReceiptController@update', 'middleware' => [ 'permission:receipt_edit'], 'as' => 'receipt.update']);
    Route::post('receipt/{id}', ['uses' => 'Receipt\ReceiptController@destroy', 'middleware' => [ 'permission:receipt_delete'], 'as' => 'receipt']);

    Route::get('provinces', ['uses' => 'Location\LocationController@index', 'as' => 'provinces.index']);
    Route::get('location/create', ['uses' => 'Location\LocationController@create', 'middleware' => [ 'permission:receipt_create'], 'as' => 'location.create']);
    Route::post('location/store', ['uses' => 'Location\LocationController@store', 'middleware' => [ 'permission:receipt_create'], 'as' => 'location.store']);
    Route::get('location/edit/{id}', ['uses' => 'Location\LocationController@edit', 'middleware' => [ 'permission:receipt_edit'], 'as' => 'location.edit']);
    Route::get('location/{id}', ['uses' => 'Location\LocationController@show', 'middleware' => [ 'permission:receipt_view'], 'as' => 'location.show']);
    Route::patch('location/{id}', ['uses' => 'Location\LocationController@update', 'middleware' => [ 'permission:receipt_edit'], 'as' => 'location.update']);
    Route::post('location/{id}', ['uses' => 'Location\LocationController@destroy', 'middleware' => [ 'permission:receipt_delete'], 'as' => 'location']);


    Route::get('payment', ['uses' => 'Payment\PaymentController@index', 'middleware' => [ 'permission:payment_list'], 'as' => 'payment.index']);
    Route::get('payment/create', ['uses' => 'Payment\PaymentController@create', 'middleware' => [ 'permission:payment_create'], 'as' => 'payment.create']);
    Route::post('payment/store', ['uses' => 'Payment\PaymentController@store', 'middleware' => [ 'permission:payment_create'], 'as' => 'payment.store']);
    Route::get('payment/edit/{id}', ['uses' => 'Payment\PaymentController@edit', 'middleware' => [ 'permission:payment_edit'], 'as' => 'payment.edit']);
    Route::get('payment/{id}', ['uses' => 'Payment\PaymentController@show', 'middleware' => [ 'permission:payment_view'], 'as' => 'payment.show']);
    Route::patch('payment/{id}', ['uses' => 'Payment\PaymentController@update', 'middleware' => [ 'permission:payment_edit'], 'as' => 'payment.update']);
    Route::post('payment/{id}', ['uses' => 'Payment\PaymentController@destroy', 'as' => 'payment']);

    Route::get('reports', ['uses' => 'Report\ReportController@index','middleware' => [ 'permission:report_list'], 'as' => 'reports.index']);
    Route::get('reports/company', ['uses' => 'Report\ReportController@reportInvoices','middleware' => [ 'permission:report_list'], 'as' => 'reports.invoices']);
    Route::get('getReportPermission', ['uses' => 'Report\ReportController@getReportPermission','middleware' => [ 'permission:report_list'], 'as' => 'getReportPermission']);
    Route::get('all_report', ['uses' => 'Report\ReportController@allReport','middleware' => [ 'permission:report_list'], 'as' => 'all_report']);
    Route::get('location', ['uses' => 'Report\ReportController@location','middleware' => [ 'permission:report_list'], 'as' => 'location']);
    Route::get('zone', ['uses' => 'Report\ReportController@zone','middleware' => [ 'permission:report_list'], 'as' => 'zone']);

});
