@extends('layouts.master')
@section('title', __('lang.reports'))
@section('css')
<link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css" />
<link href="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}" rel="stylesheet" type="text/css" />
<style type="text/css">
    h4 {
        text-align: center;

    }

    td {
        text-align: center;
        font-size: 15px;
    }
</style>
@endsection
@section('content')

<div class="page-content-wrapper" id="app">
    <div class="container-fluid" v-cloak>

        <div class="card">
            <div class="card-body">
                <!-- Nav tabs -->
                <div class="d-flex">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item" v-for="(t,index) in tabs">
                            <a class="nav-link " :class="t.is_active?'active':''" @click="setActive(index)" data-toggle="tab" :href="'#'+t.tab" role="tab">
                                <i :class="'fas '+t.css_class+' mr-1'"></i> <span class="d-md-inline-block">@{{t.value}}</span>
                            </a>
                        </li>
                        <!-- <li class="nav-item">
                            <a class="nav-link" @click="filterCard = true" data-toggle="tab" href="#profile" role="tab">
                                <i class="fas fa-user mr-1"></i> <span class="d-md-inline-block">Reciepts</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" @click="filterCard = true" data-toggle="tab" href="#messages" role="tab">
                                <i class="far fa-envelope mr-1"></i> <span class="d-md-inline-block">Payments</span>
                            </a>
                        </li> 
                        <li class="nav-item">
                            <a class="nav-link" @click="filterCard = true" data-toggle="tab" href="#settings" role="tab">
                                <i class="fas fa-cog mr-1"></i> <span class="d-md-inline-block">Expenses</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" @click="filterCard = true" data-toggle="tab" href="#settings" role="tab">
                                <i class="fas fa-cog mr-1"></i> <span class="d-md-inline-block">Order</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" @click="filterCard = true" data-toggle="tab" href="#settings" role="tab">
                                <i class="fas fa-cog mr-1"></i> <span class="d-md-inline-block">Invoices</span>
                            </a>
                        </li> -->
                    </ul>

                </div>

                <div v-show="filterCard" class="card p-2 mt-3">
                    <div div class="d-flex ">
                        <div class="col">
                            <span class="ml-0 pl-0 col-4">From Date</span>
                            <input class="form-control col" v-model="from" type="date" />
                        </div>

                        <div class="col">
                            <span class="ml-0 pl-0 col-4">To Date</span>
                            <input class="form-control col" v-model="to" type="date" />
                        </div>

                        <div class="col" v-show="!tabs[1].is_active">
                            <span class="ml-0 pl-0 col-4">@{{type_name}}</span>
                            <v-select :select-on-tab="true" v-model="selected_type" label="name" :options="types" placeholder="@lang('lang.search')">
                                <template v-slot:no-options="{ search, searching }">
                                    <template v-if="searching">
                                        @lang('lang.no_record_found_for') @{{search}}
                                    </template>
                                    <em class="v-select-search-hint" v-else>@lang('lang.type_to_search')</em>
                                </template>
                            </v-select>
                            <input type="hidden" name="selected_type" :value="(selected_type == null) ? null : selected_type.name">
                        </div>

                        <div class="col-1 d-flex justify-content-center ">
                            <button type="button" @click="getRecord()" class="btn btn-primary btn-lg btn-floating align-self-end">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Tab panes -->
                <div class="tab-content p-3">
                    <div :class="'tab-pane'+tabs[0].is_active?'active':''" v-show="tabs[0].is_active" id="general" role="tabpanel">
                        <div class="row">
                            <div class="col-xl-4">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between p-md-1">
                                            <div class="d-flex flex-row">
                                                <div class="align-self-center">
                                                    <i class="fas fa-file-invoice text-success fa-2x me-4"></i>
                                                </div>
                                                <div>
                                                    <h6>All </h6>
                                                    <p class="mb-0">Monthly Income</p>
                                                </div>
                                            </div>
                                            <div class="align-self-center">
                                                <h6 class="h6 mb-0">{{$totalIncomes>0?$totalIncomes:0}}{{homeCurrency()['symbol']}}</h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-4">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between p-md-1">
                                            <div class="d-flex flex-row">
                                                <div class="align-self-center">
                                                    <i class="fas fa-file-invoice text-info fa-2x me-4"></i>
                                                </div>
                                                <div>
                                                    <h6>All Expenses</h6>
                                                    <p class="mb-0">Monthly Expenses</p>
                                                </div>
                                            </div>
                                            <div class="align-self-center">
                                                <h6 class="h6 mb-0">{{$totalExpenses>0?$totalExpenses:0}}{{homeCurrency()['symbol']}}</h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-4">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between p-md-1">
                                            <div class="d-flex flex-row">
                                                <div class="align-self-center">
                                                    <i class="fas fa-file-invoice text-info fa-2x me-4"></i>
                                                </div>
                                                <div>
                                                    <h6>All Receipts</h6>
                                                    <p class="mb-0">Monthly Receipts</p>
                                                </div>
                                            </div>
                                            <div class="align-self-center">
                                                <h6 class="h6 mb-0">{{$totalReceipts>0?$totalReceipts:0}}{{homeCurrency()['symbol']}}</h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-4">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between p-md-1">
                                            <div class="d-flex flex-row">
                                                <div class="align-self-center">
                                                    <i class="fas fa-file-invoice text-info fa-2x me-4"></i>
                                                </div>
                                                <div>
                                                    <h6>All Payments</h6>
                                                    <p class="mb-0">Monthly Payments</p>
                                                </div>
                                            </div>
                                            <div class="align-self-center">
                                                <h6 class="h6 mb-0">{{$totalPayments>0?$totalPayments:0}}{{homeCurrency()['symbol']}}</h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-4">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between p-md-1">
                                            <div class="d-flex flex-row">
                                                <div class="align-self-center">
                                                    <i class="fas fa-file-invoice text-info fa-2x me-4"></i>
                                                </div>
                                                <div>
                                                    <h6>All Invoices</h6>
                                                    <p class="mb-0">Monthly Invoice</p>
                                                </div>
                                            </div>
                                            <div class="align-self-center">
                                                <h6 class="h6 mb-0">{{$totalInvoices>0?$totalInvoices:0}}{{homeCurrency()['symbol']}}</h6>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-4">
                                <div class="card">
                                    <div class="d-flex justify-content-between p-md-1">
                                        <div class="d-flex flex-row">
                                            <div class="align-self-center">
                                                <i class="fas fa-file-invoice text-info fa-2x me-4"></i>
                                            </div>
                                            <div>
                                                <h6>All Orders</h6>
                                                <p class="mb-0">Monthly Orders</p>
                                            </div>
                                        </div>
                                        <div class="align-self-center">
                                            <h6 class="h6 mb-0">{{$totalOrder>0?$totalOrder:0}}{{homeCurrency()['symbol']}}</h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div :class="'tab-pane'+tabs[3].is_active?'active':''" v-show="tabs[3].is_active" id="expenses" role="tabpanel">
                        <div class=" ">
                            <datatable ref="child" :per-page="{{perPage()}}" :no-record-found-text="'@lang('lang.no_record_found')'" :per-page-text="'@lang('lang.show')'" :showing-text="'@lang('lang.showing')'" :from-text="'@lang('lang.from')'" :to-text="'@lang('lang.to')'" :record-text="'@lang('lang.record')'" :app-per-page="{!! perPage(1) !!}" :columns="columns" :data="apiData" @pagination-change-page="getRecord" :limit="1" :filterRecord="getRecord">
                                <template slot="tbody">
                                    <tbody v-show="!apiData.data">
                                        <tr v-for="skeleton in 4">


                                            <td>
                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                            </td>

                                            <td>
                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                            </td>

                                            <td>
                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                            </td>

                                            <td>
                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                            </td>

                                            <td>
                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                            </td>

                                            <td>
                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                            </td>

                                            <td>
                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                            </td>
                                            <td>
                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                            </td>

                                        </tr>
                                    </tbody>
                                    <tbody v-show="apiData.data">
                                        <tr v-for="(record,index) in apiData.data" :key="record.id">
                                            <td>
                                                <input type="checkbox" class="" v-model="selectedRows" :value="record.id" :id="`checked-${record.id}}`">

                                            </td>
                                            <td> @{{++index}}</td>
                                            <td> @{{record.category}}</td>
                                            <td> @{{record.amount}}</td>
                                            <td> @{{record.date}}</td>
                                            <td> @{{record.description}}</td>
                                        </tr>

                                    </tbody>

                                </template>
                            </datatable>
                            <!-- <Pagination align="center" :limit="1" :data="records" @pagination-change-page="getRecord"></Pagination> -->
                        </div>
                    </div>
                    <div :class="'tab-pane'+tabs[4].is_active?'active':''" v-show="tabs[4].is_active" id="orders" role="tabpanel">
                        <div>
                            <datatable ref="child" :per-page="{{perPage()}}" :no-record-found-text="'@lang('lang.no_record_found')'" :per-page-text="'@lang('lang.show')'" :showing-text="'@lang('lang.showing')'" :from-text="'@lang('lang.from')'" :to-text="'@lang('lang.to')'" :record-text="'@lang('lang.record')'" :app-per-page="{!! perPage(1) !!}" :columns="columns" :data="apiData" @pagination-change-page="getRecord" :limit="1" :filterRecord="getRecord">
                                <template slot="tbody">
                                    <tbody>
                                        <tr v-for="(record,index) in apiData.data" :key="record.id">
                                            <td>
                                                <input type="checkbox" class="" v-model="selectedRows" :value="record.id" :id="`checked-${record.id}}`">

                                            </td>
                                            <td> @{{++index}}</td>
                                            <td> @{{record.number}}</td>
                                            <td> @{{record.company}}</td>
                                            <td> @{{record.project}}</td>
                                            <td> @{{record.amount}}</td>
                                            <td> @{{record.currency}}</td>
                                        </tr>

                                    </tbody>

                                </template>
                            </datatable>
                            <Pagination align="center" :limit="1" :data="apiData" @pagination-change-page="getRecord"></Pagination>
                        </div>
                    </div>
                    <div :class="'tab-pane'+tabs[5].is_active?'active':''" v-show="tabs[5].is_active" id="invoices" role="tabpanel">
                        <div>
                            <datatable ref="child" :per-page="{{perPage()}}" :no-record-found-text="'@lang('lang.no_record_found')'" :per-page-text="'@lang('lang.show')'" :showing-text="'@lang('lang.showing')'" :from-text="'@lang('lang.from')'" :to-text="'@lang('lang.to')'" :record-text="'@lang('lang.record')'" :app-per-page="{!! perPage(1) !!}" :columns="columns" :data="apiData" @pagination-change-page="getRecord" :limit="1" :filterRecord="getRecord">
                                <template slot="tbody">
                                    <tbody>
                                        <tr v-for="(record,index) in apiData.data" :key="record.id">
                                            <td>
                                                <input type="checkbox" class="" v-model="selectedRows" :value="record.id" :id="`checked-${record.id}}`">

                                            </td>
                                            <td> @{{++index}}</td>
                                            <td> @{{record.number}}</td>
                                            <td> @{{record.company}}</td>
                                            <td> @{{record.project}}</td>
                                            <td> @{{record.amount}}</td>
                                            <td> @{{record.currency}}</td>
                                        </tr>

                                    </tbody>

                                </template>
                            </datatable>
                            {{-- <Pagination align="center" :limit="1" :data="apiData" @pagination-change-page="getRecord"></Pagination>--}}
                        </div>
                    </div>
                    <div :class="'tab-pane'+tabs[2].is_active?'active':''" v-show="tabs[2].is_active" id="payments" role="tabpanel">
                        <datatable ref="child" :per-page="{{perPage()}}" :no-record-found-text="'@lang('lang.no_record_found')'" :per-page-text="'@lang('lang.show')'" :showing-text="'@lang('lang.showing')'" :from-text="'@lang('lang.from')'" :to-text="'@lang('lang.to')'" :record-text="'@lang('lang.record')'" :app-per-page="{!! perPage(1) !!}" :columns="columns" :data="apiData" @pagination-change-page="getRecord" :limit="1" :filterRecord="getRecord">
                            <template slot="tbody">
                                <tbody v-show="!apiData.data">
                                    <tr v-for="skeleton in 4">


                                        <td>
                                            <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                        </td>

                                        <td>
                                            <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                        </td>

                                        <td>
                                            <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                        </td>

                                        <td>
                                            <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                        </td>

                                        <td>
                                            <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                        </td>

                                        <td>
                                            <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                        </td>

                                        <td>
                                            <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                        </td>
                                        <td>
                                            <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                        </td>
                                        <td>
                                            <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                        </td>
                                    </tr>
                                </tbody>
                                <tbody v-show="apiData.data">
                                    <tr v-for="(record,index) in apiData.data" :key="record.id">
                                        <td>
                                            <input type="checkbox" class="" v-model="selectedRows" :value="record.id" :id="`checked-${record.id}}`">

                                        </td>
                                        <td> @{{++index}}</td>
                                        <td> @{{record.date}}</td>
                                        <td> @{{record.amount}}</td>
                                        <td> @{{record.project}}</td>
                                        <td> @{{record.location}}</td>
                                        <td> @{{record.description}}</td>
                                    </tr>

                                </tbody>

                            </template>
                        </datatable>
                        {{-- <Pagination align="center" :limit="1" :data="records" @pagination-change-page="getRecord"></Pagination>--}}
                    </div>
                    <div :class="'tab-pane'+tabs[1].is_active?'active':''" v-show="tabs[1].is_active" id="receipts" role="tabpanel">
                        <datatable ref="child" :per-page="{{perPage()}}" :no-record-found-text="'@lang('lang.no_record_found')'" :per-page-text="'@lang('lang.show')'" :showing-text="'@lang('lang.showing')'" :from-text="'@lang('lang.from')'" :to-text="'@lang('lang.to')'" :record-text="'@lang('lang.record')'" :app-per-page="{!! perPage(1) !!}" :columns="columns" :data="apiData" @pagination-change-page="getRecord" :limit="1" :filterRecord="getRecord">
                            <template slot="tbody">
                                <tbody v-show="!apiData.data">
                                    <tr v-for="skeleton in 4">


                                        <td>
                                            <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                        </td>

                                        <td>
                                            <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                        </td>

                                        <td>
                                            <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                        </td>

                                        <td>
                                            <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                        </td>

                                        <td>
                                            <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                        </td>

                                        <td>
                                            <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                        </td>

                                        <td>
                                            <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                        </td>
                                        <td>
                                            <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                        </td>
                                        <td>
                                            <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                        </td>
                                    </tr>
                                </tbody>
                                <tbody v-show="apiData.data">
                                    <tr v-for="(record,index) in apiData.data" :key="record.id">
                                        <td>
                                            <input type="checkbox" class="" v-model="selectedRows" :value="record.id" :id="`checked-${record.id}}`">

                                        </td>
                                        <td> @{{++index}}</td>
                                        <td> @{{record.date}}</td>
                                        <td> @{{record.amount}}</td>
                                        <td> @{{record.description}}</td>
                                    </tr>

                                </tbody>

                            </template>
                        </datatable>
                        {{-- <Pagination align="center" :limit="1" :data="records" @pagination-change-page="getRecord"></Pagination>--}}
                    </div>
                    <div :class="'tab-pane'+tabs[6].is_active?'active':''" v-show="tabs[6].is_active" id="all_report" role="tabpanel">
                        <div class="container center mt-3">
                            <h4 class="p-3">Weekly Report Of Institue</h4>
                            <table class="table table-bordered table-responsive-sm">

                                <tbody>
                                    <tr>
                                        <td colspan="2"><strong>Credit+</strong></td>
                                        <td colspan="2"><strong>Debit-</strong></td>
                                        <td rowspan="2" style="vertical-align: middle;"><strong>Institue Name</strong></td>
                                        <td rowspan="2" style="vertical-align: middle;"><strong>No</strong></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Afghani +</strong></td>
                                        <td><strong>Dollar +</strong></td>
                                        <td><strong>Afghani -</strong></td>
                                        <td><strong>Dollar -</td>
                                        </tr>
                                        <tr v-for="(rep, index) in all_report">
                                            <td>@{{rep.afnCr}}</td>
                                            <td>@{{rep.usdCr}}</td>
                                            <td>@{{rep.afnDR}}</td>
                                            <td>@{{rep.usdDR}}</td>
                                            <td>@{{rep.name}}</td>
                                            <td>@{{index+1}}</td>
                                        </tr>
                                    <!-- <tr v-for="(rep, index) in reports">
                                        <td>@{{rep.credit}}</td>
                                        <td>@{{rep.debit}}</td>
                                        <td>@{{rep.name}}</td>
                                        <td>@{{index+1}}</td>
                                    </tr> -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<!-- end page-content-wrapper -->

@endsection
@section('js')
<script>
    //Vue.component('pagination', require('laravel-vue-pagination'));
    var vm = new Vue({
        el: '#app',
        components: {
            'skeleton-loader-vue': window.VueSkeletonLoader,
        },
        data() {
            return {
                all_report:{!!$all_reports!!},
                tabs: [{
                    tab: 'general',
                    css_class: 'fa-home',
                    value: 'General',
                    is_active: true
                },
                {
                    tab: 'receipts',
                    css_class: 'fa-user',
                    value: 'Receipts',
                    is_active: false
                },
                {
                    tab: 'payments',
                    css_class: 'fa-envelope',
                    value: 'Payments',
                    is_active: false
                },
                {
                    tab: 'expenses',
                    css_class: 'fa-cog',
                    value: 'Expenses',
                    is_active: false
                },
                {
                    tab: 'orders',
                    css_class: 'fa-cog',
                    value: 'Orders',
                    is_active: false
                },
                {
                    tab: 'invoices',
                    css_class: 'fa-cog',
                    value: 'Invoices',
                    is_active: false
                },
                {
                    tab: 'َall_report',
                    css_class: 'fa-cog',
                    value: 'all_report',
                    is_active: false
                }
                ],
                url: '{{route("reports.index")}}?type=',
                columns: [],
                all_columns: [
                    // Receipts
                    [{
                        label: "#",
                        name: '#',
                        sort: false,
                    },
                    {
                        label: "@lang('lang.date')",
                        name: 'receipts.date',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    },
                    {
                        label: "@lang('lang.amount')",
                        name: 'receipts.amount',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    },
                    {
                        label: "@lang('lang.description')",
                        name: 'amount.name',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    }
                    ],
                    // Payments
                    [{
                        label: "#",
                        name: '#',
                        sort: false,
                    },
                    {
                        label: "@lang('lang.date')",
                        name: 'payments.date',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    },
                    {
                        label: "@lang('lang.amount')",
                        name: 'payments.amount',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    },
                    {
                        label: "@lang('lang.project')",
                        name: 'payments.project',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    },
                    {
                        label: "@lang('lang.location')",
                        name: 'payments.location',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    },
                    {
                        label: "@lang('lang.description')",
                        name: 'payments.description',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    }
                    ],
                    // Expenses
                    [{
                        label: "#",
                        name: '#',
                        sort: false,
                    },
                    {
                        label: "@lang('lang.category')",
                        name: 'category',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    },
                    {
                        label: "@lang('lang.amount')",
                        name: 'expense_details.amount',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    },
                    {
                        label: "@lang('lang.date')",
                        name: 'expenses.date',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    },
                    {
                        label: "@lang('lang.description')",
                        name: 'expenses.description',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    },
                        // {
                        //     label: "@lang('lang.currency')",
                        //     name: 'currency',
                        //     sort: true,
                        //     activeSort: true,
                        //     order_direction: 'desc',
                        // },
                        ],
                    // Orders
                    [{
                        label: "#",
                        name: '#',
                        sort: false,
                    },
                    {
                        label: "@lang('lang.number')",
                        name: 'orders.number',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    },
                    {
                        label: "@lang('lang.organization')",
                        name: 'companies.name',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    },
                    {
                        label: "@lang('lang.project')",
                        name: 'projects.name',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    },
                    {
                        label: "@lang('lang.amount')",
                        name: 'orders.amount',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    },
                    {
                        label: "@lang('lang.currency')",
                        name: 'order.currency',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    }
                    ],
                    // Invoices
                    [{
                        label: "#",
                        name: '#',
                        sort: false,
                    },
                    {
                        label: "@lang('lang.number')",
                        name: 'orders.number',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    },
                    {
                        label: "@lang('lang.organization')",
                        name: 'companies.name',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    },
                    {
                        label: "@lang('lang.project')",
                        name: 'projects.name',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    },
                    {
                        label: "@lang('lang.amount')",
                        name: 'orders.amount',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    },
                    {
                        label: "@lang('lang.currency')",
                        name: 'order.currency',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    }
                    ],

                    ],
                    apiData: {},
                    appPerPage: {!!perPage(1) !!},
                    perPage: "{{perPage()}}",
                    page: 1,
                    selectedRows: [],
                    from: null,
                    to: null,
                    categories: [],
                    selected_category: null,
                    projects: [],
                    selected_project: null,
                    reports: [],
                    selected_report: null,
                    types: [],
                    selected_type: null,
                    type_name: 'Select Project',
                    companies:[]
                }

            },
            computed: {
                filterCard() {
                    if (this.tabs[0].is_active || this.tabs[this.tabs.length - 1].is_active)
                        return false
                    else
                        return true;
                }
            },
            mounted() {
                this.getProject();
                console.log('this is all ',this.all_report)
                this.getCategories();
            },
            methods: {
                setActive(index = 0) {
                    console.log('test');
                    this.tabs.forEach(e => {
                        e.is_active = false;
                    });
                    this.tabs[index].is_active = true;
                    if (this.tabs[index].tab == 'expenses') {
                        this.selected_project = null;
                        this.types = JSON.parse(JSON.stringify(this.categories));
                        this.type_name = 'Select Category';
                    } else {
                        this.selected_category = null;
                        this.types = JSON.parse(JSON.stringify(this.projects));
                        this.type_name = 'Select Project';
                    }
                    this.selected_type = null;
                    this.from = null;
                    this.to = null;

                    // if (index > 0) {
                    //     this.columns = this.all_columns[index - 1];
                    //     if (this.tabs[index].tab != 'general' || this.tabs[index].tab != 'all_report')
                    //         this.getRecord();
                    //     if (this.tabs[index].tab != 'all_report')
                    //         this.getAllReports();
                    // }
                },
                getProject() {
                    axios.get("{{route('project.all')}}")
                    .then(data => {
                        this.projects = data.data
                    })
                },
                getAllReports() {
                    axios.get("{{route('all_report')}}")
                    .then(data => {
                        let d = data.data;
                        let form = [];
                        let company = {name: null, usd: null, afg: null};
                        // let companies_data={}
                        // let companies = [];
                        d.forEach(e=>{
                            let n = this.companies.find(x=>x.name==e.name);
                            if(!n?.name)
                                this.companies.push({name: e.name, usd: null, afn: null,usd_cr: null, afn_cr: null});
                        });
                        // console.log(this.companies);
                        for(let x=0; x<this.companies.length; x++){
                            let vh = d.filter(o=>o.name==this.companies[x].name);
                            console.log(vh);
                            vh.forEach((e,i)=>{
                                if(e.currency == e.currency_cr && e.currency == 'USD'){
                                    this.companies[x].usd += Math.abs(e.amount - e.amount_cr);
                                    this.companies[x].usd_cr +=  e.amount_cr;
                                } else if(e.currency == 'USD' || e.currency_cr == 'USD') {
                                    this.companies[x].usd += (e.amount != null) ? e.amount : 0;
                                    this.companies[x].usd_cr += (e.amount_cr != null) ? e.amount_cr : 0;
                                }

                                if(e.currency == e.currency_cr && e.currency == 'AFN'){
                                    this.companies[x].afn += Math.abs(e.amount - e.amount_cr);
                                    this.companies[x].afn_cr +=  e.amount_cr;
                                } else if(e.currency == 'AFN' || e.currency_cr == 'AFN') {
                                    this.companies[x].afn += (e.amount != null) ? e.amount : 0;
                                    this.companies[x].afn_cr += (e.amount_cr != null) ? e.amount_cr : 0;
                                }
                                    // if(e.currency == e.currency_cr && e.currency == 'USD'){
                                    //     this.companies[x].usd_cr =  e.amount_cr;
                                    // } else if(e.currency == 'USD') {
                                    //     this.companies[x].usd_cr = (e.amount_cr != null) ? e.amount_cr : 0;
                                    // }

                                    // if(e.currency == e.currency_cr && e.currency == 'AFN'){
                                    //     this.companies[x].afn_cr =  e.amount_cr;
                                    // } else if(e.currency == 'AFN') {
                                    //     this.companies[x].afn_cr = (e.amount_cr != null) ? e.amount_cr : 0;
                                    // }
                                });
                            // let foundDuplicateName = d.filter((nnn, index) =>{
                            //     let da= d.filter((x, ind)=> x.name === nnn.name && index !== ind );
                            //     da.forEach((e,i)=>{

                            //         if(e.currency == e.currency_cr && e.currency == 'USD'){
                            //             this.companies[x].usd = e.amount - e.amount_cr;
                            //         } else if(e.currency == 'USD') {
                            //             this.companies[x].usd = (e.amount != null) ? e.amount : 0;
                            //         }

                            //         if(e.currency == e.currency_cr && e.currency == 'AFN'){
                            //             this.companies[x].afg = e.amount - e.amount_cr;
                            //         } else if(e.currency == 'AFN') {
                            //             this.companies[x].afg = (e.amount != null) ? e.amount : 0;
                            //         }
                            //         // if()
                            //         form[index] =e
                            //     })
                            // });
                        }
                        console.log('foundDuplicateName',this.companies);

                    //   let check=  d.some((element, index) => {
                    //     console.log('index', index);
                    //     console.log('element.company', element.name);
                    //     console.log('d.indexOf(element.name)', d.indexOf(element));
                    //         return d.indexOf(element.name) !== index
                    //     });
                    //     console.log("data.data",check);

                        // this.reports = data.data
                    })
            },
            getCategories() {
                axios.get("{{route('categories')}}")
                .then(data => {
                    this.categories = data.data
                })
            },
            /**
             * get record from api
             */
             showFilterModal() {
                $('#filterModal').modal('show');
                this.getProvinces();
            },
            getRecord: _.debounce((page = vm.page) => {
                let selected_type = vm.selected_type?.id
                let tab = vm.tabs.find(e => e.is_active == true).tab;
                if (tab != 'general' || tab != 'all_report') {
                    let url = '{{route("reports.index")}}?type=' + tab + '&from=' + vm.from + "&to=" + vm.to + "&selected_type=" + selected_type;
                    axios.get(url +
                        '&current_page=' +
                        page + '&per_page=' + vm.perPage)
                    .then((response) => {
                        if (response.data) {
                            vm.page = response.data.current_page;
                        }
                        vm.apiData = response.data;
                    })
                    .catch((error) => {
                        console.log(error);
                    });
                }
            }, 200),

        }
    });
</script>
@endsection