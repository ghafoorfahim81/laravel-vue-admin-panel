<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="style.css"> -->
    <title>HTML & CSS Table</title>
    <style>

*{
    box-sizing: border-box;
    padding: 0;
    margin: 0;
}

body{
    font-family: sans-serif;
    position: relative;
}

.container{
    width: 90%;
    margin: auto;
    margin-top: 50px;
    display: flex;
    flex-direction: column;
}

.txt-section{
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: center;
    padding: 10px;
    row-gap: 15px;
}
.txt-section .title{
    font-weight: 900;
    text-align: center;
    text-transform: capitalize;
}
 .txt-section .info{
    text-align: center;
    text-transform: capitalize;
    line-height: 30px;
 }

.tbl{
    overflow-x: auto;
}


table {
    width: 100%;
    border-collapse: collapse;
    text-align: center;
}

table, td, th {
        border: 1px solid;
}

th{
border: 1px;
font-weight: 900;
height: 50px;
color: #fff;
background-color: rgb(0, 162, 255);
}

td{
padding: 20px;
font-weight: bold;
}


@media only screen and (max-width: 600px) {
.container{
width: 98%;
margin: auto;
margin-top: 50px;
display: flex;
flex-direction: column;
}

.txt-section h2{
    font-size: 23px;
}

}
    </style>
</head>
<body>

    <main class="container">
        <section class="txt-section">
            <h1 class="title">afghan sharq money services</h1>
            <div class="info">
                <h2>office, 42 sari-shahzade, kabul, afghanistan</h2>
                <h3>0777816565, info@afghansharq.com</h3>
            </div>
            <h4 class="date" style="text-align:center;">{{$type}} Export on Date:<span class="date">13-09-2022</span></h4>
        </section>

        <section class="tbl">
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Date</th>
                        <th>Amount</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    @for ($i = 0; $i < count($data); $i++)
                        <tr>
            
                            <td> {{$data[$i]['code']}}</td>
                            <td> {{$data[$i]['date']}}</td>
                            <td> {{$data[$i]['amount']}}</td>
                            <td> {{$data[$i]['description']}}</td>
                        </tr>
                    @endfor
                </tbody>
            </table>
        </section>
    </main>
    
</body>
</html>