<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- <link href="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}" rel="stylesheet" type="text/css" /> -->
</head>

<body>
    <div class="container center mt-3">
        <h4 class="p-3">Weekly Report Of Institue</h4>
        <table class="table table-bordered table-responsive-sm">

            <tbody>
                <tr>
                    <td rowspan="2" style="vertical-align: middle;"><strong>No</strong></td>
                    <td rowspan="2" style="vertical-align: middle;"><strong>Institue Name</strong></td>
                    <td colspan="2"><strong>Credit+</strong></td>
                    <td colspan="2"><strong>Debit-</strong></td>
                </tr>
                <tr>
                    <td><strong>Afghani +</strong></td>
                    <td><strong>Dollar +</strong></td>
                    <td><strong>Afghani -</strong></td>
                    <td><strong>Dollar -</td>
                </tr>
                @for ($i = 0; $i < count($data); $i++)
                <tr>
                    <td>{{$data[$i]['code']}}</td>
                    <td>{{$data[$i]['name']}}</td>
                    <td>{{$data[$i]['afnDR']}}</td>
                    <td>{{$data[$i]['usdDR']}}</td>
                    <td>{{$data[$i]['afnCr']}}</td>
                    <td>{{$data[$i]['usdCr']}}</td>
                </tr>
                @endfor
                <!-- <tr v-for="(rep, index) in reports">
                                        <td>@{{rep.credit}}</td>
                                        <td>@{{rep.debit}}</td>
                                        <td>@{{rep.name}}</td>
                                        <td>@{{index+1}}</td>
                                    </tr> -->
            </tbody>
        </table>
    </div>
</body>

</html>