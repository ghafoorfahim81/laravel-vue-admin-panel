<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table</title>
    <style>
        body{
            font-family: sans-serif;
        }
        .container {
            width: 90%;
            margin: auto;
            text-align: center;
        }
        .container h1{
            text-transform: capitalize;
            font-size: 36px;
            font-weight: 100;
        }
        .container .tbl{
            overflow-x: auto;
        }

        table,th,td{
            border: 1px;
            border-collapse: collapse;
            text-align: center;
            border-style: ridge ;
            
        }        
        th,td{
            padding: 10px;
        }

        @media  screen and (max-width:500px) {
            .container{
                width: 98%;
            }
            th,td{
            padding: 7px;
            font-size: 15px;
            }

        }
    </style>
</head>
<body>
    <main class="container">
        <h1>weekly report of institue</h1>
        <div class="tbl">
            <table style="width:100%" >
                <thead>
                    <tr>
                        <th rowspan="2" style="width:5% ;">No</th>
                        <th rowspan="2">Institue Name</th>
                        <th colspan="2">Credit+</th>
                        <th colspan="2">Debit-</th>
                    </tr>
                    <tr>
                        <th>Afghani +</th>
                        <th>Dollar +</th>
                        <th>Afghani -</th>
                        <th>Dollar -</th>
                    </tr>
                </thead>
                <tbody>
                    @for ($i = 0; $i < count($data); $i++)
                    <tr>
                        <td>{{$data[$i]['code']}}</td>
                        <td>{{$data[$i]['name']}}</td>
                        <td>{{$data[$i]['afnDR']}}</td>
                        <td>{{$data[$i]['usdDR']}}</td>
                        <td>{{$data[$i]['afnCr']}}</td>
                        <td>{{$data[$i]['usdCr']}}</td>
                    </tr>
                    @endfor
                </tbody>
            </table>    
        </div>
    </main>
</body>
</html>