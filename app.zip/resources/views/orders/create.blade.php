@extends('layouts.master')
@section('title', __('lang.add').' '.__('lang.order'))
@section('css')
<link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css" />
<link href="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}" rel="stylesheet" type="text/css" />
<link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
 
<style>
    .right-drawer {
        position: absolute;
        top: 0;
        right: 0;
        width: 0;
        /* initially */
        overflow: hidden;
        height: 100vh;
        padding-left: 0;
        /* initially */
        border-left: 1px solid whitesmoke;
        background: white;
        z-index: 200;
        transition: all 0.2s;
        /* for the animation */
    }

    .drawer-mask {
        position: absolute;
        left: 0;
        top: 0;
        width: 0;
        /* initially */
        height: 100vh;
        background: #000;
        opacity: 0.3;
        z-index: 199;
    }
</style>

@endsection
@section('content')
<div class="page-content-wrapper" id="myapp" v-cloak>
    <div class="container-fluid">

     


    <div class="row ">
        <div class="col-xl-12">
            <div class="card">
                <form action="{{route('order.store')}}" @submit="handleSubmit($event)" method="post" id="userForm" enctype="multipart/form-data">
                    @csrf

                    <div class="card-body" style="padding-bottom: 0px">
                        <div class="">
                            <!-- <h4 class="header-title">@lang('lang.add') @lang('lang.order')</h4> -->
                            <div class="row justify-content-center">
                                <div class="row">
                                    <div class="col-xl-4" v-show="showFields('organization')">
                                        <div class="form-group">
                                            <label for="">@lang('lang.organization')
                                            </label>
                                            <input type="text" value="{{$company->name}}" class="form-control"
                                                   autocomplete="new-password"
                                                   disabled
                                                   placeholder="@lang('lang.invoice_number')">
                                            <input type="hidden" name="company"
                                                   value="{{$company->id}}">
                                        </div>
                                    </div>
                                    <div class="col-xl-4" v-show="showFields('from_date')">
                                        <div class="form-group">
                                            <label for="">@lang('lang.fro_date')
                                            </label>
                                            <input type="date" name="from_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" id="email" data-vv-as="@lang('lang.from_date')" placeholder="@lang('lang.from_date')" autocomplete="new-email">
                                            <span class="help-block rq-hint">
                                                @{{errors.first('from_date')}}</span>
                                        </div>
                                    </div>
                                    <div class="col-xl-4" v-show="showFields('to_date')">
                                        <div class="form-group">
                                            <label for="">@lang('lang.to_date')
                                            </label>
                                            <input type="date" name="to_date" class="form-control" id="email" data-vv-as="@lang('lang.to_date')" placeholder="@lang('lang.to_date')" autocomplete="new-email">

                                        </div>
                                    </div>
                                    <div class="col-xl-4" v-show="showFields('project')">
                                        <div class="form-group">
                                            <label for="">@lang('lang.project')
                                            </label>
                                            <v-select :select-on-tab="true" v-model="selected_project" label="name" :options="projects" placeholder="@lang('lang.selectProject')">
                                                <template v-slot:no-options="{ search, searching }">
                                                    <template v-if="searching">
                                                        @lang('lang.no_record_found_for') @{{search}}
                                                    </template>
                                                    <em class="v-select-search-hint" v-else>@lang('lang.type_to_search')</em>
                                                </template>
                                            </v-select>
                                            <input type="hidden" name="project" :value="(selected_project == null) ? null : selected_project.id">
                                            <input type="hidden" name="location_id" :value="(selected_project == null) ? null : selected_project.location_id"> 

                                        </div>
                                    </div>
                                    <div class="col-xl-2" v-show="showFields('currency')">
                                        <div class="form-group">
                                            <label for="">@lang('lang.currency')
                                            </label>
                                            <v-select :select-on-tab="true" v-model="selected_currency" label="code" :options="currencies" placeholder="@lang('lang.select_currency')">
                                                <template v-slot:no-options="{ search, searching }">
                                                    <template v-if="searching">
                                                        @lang('lang.no_record_found_for') @{{search}}
                                                    </template>
                                                    <em class="v-select-search-hint" v-else>@lang('lang.type_to_search')</em>
                                                </template>
                                            </v-select>
                                            <input type="hidden" name="currency" :value="(selected_currency == null) ? null : selected_currency.code">
                                        </div>
                                    </div>
                                    <div class="col-xl-2" v-show="showFields('exchange_rate')">
                                        <div class="form-group">
                                            <label for="">@lang('lang.exchange_rate')
                                            </label>
                                            <input type="text" name="exchange_rate" class="form-control" v-model="!selected_currency ? 1 : selected_currency.rate" autocomplete="new-password" data-vv-as="@lang('lang.password')" placeholder="@lang('lang.exchange_rate')">
                                            <span class="help-block rq-hint">
                                                @{{errors.first('exchange_rate')}}</span>
                                        </div>
                                    </div>
                                    <div class="col-xl-4" v-show="showFields('reference_number')">
                                        <div class="form-group">
                                            <label for="">@lang('lang.ref_no')
                                            </label>
                                            <input type="text" name="ref_no" class="form-control" autocomplete="new-password" data-vv-as="@lang('lang.password')" placeholder="@lang('lang.ref_no')">
                                            <span class="help-block rq-hint">
                                                @{{errors.first('ref_no')}}</span>
                                        </div>
                                    </div>
                                    <div class="col-xl-6" v-show="showFields('description')">
                                        <div class="form-group">
                                            <label for="">@lang('lang.description')
                                            </label>
                                            <textarea class="form-control" id="exampleFormControlTextarea1" name="desc" rows="2">
                                                    </textarea>
                                            <span class="help-block rq-hint">
                                                @{{errors.first('ref_no')}}</span>
                                        </div>
                                    </div>
                                    <div class="col-xl-6 align-self-end p-0" v-show="showFields('grant_total')">
                                        <div class="d-flex flex-row-reverse mb-2">
                                            <div class="col-xl-8 col-md-8 p-0">
                                                <div class="w-full shadow-4 rounded-sm p-3 border">
                                                    <div class="row justify-around">
                                                        <span class="font-weight-bold text-xl col-7">Grand Total</span>
                                                        <span class="font-weight-bold text-xl col text-end">@{{total_grant.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}} @{{ (selected_currency != null) ? selected_currency.symbol : null }}</span>
                                                    </div>

                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="table-responsive rounded-sm shadow-4 ">

                                <table class="table mb-0 ">
                                    <thead class="bg-light-blue-7 text-white">
                                        <tr>
                                            <th v-show="showTable('no')" class="text-center p-2">#</th>
                                            <th v-show="showTable('item')" class="p-2" style="width:300px">@lang('lang.beneficiary')</th>
                                            <th v-show="showTable('quantity')" class="p-2">Quantity</th>
                                            <th v-show="showTable('price')" class="p-2">Price</th>
                                            <th v-show="showTable('total')" class="text-center p-2">Total</th>
                                            <th v-show="showTable('action')" class="text-center p-2">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-for="(item, index) in items">
                                            <th v-show="showTable('no')" class="p-0 text-center border-right align-middle" scope="row">@{{++index}}</th>
                                            <td v-show="showTable('item')" class=" p-0 vue_dropdown border-right align-middle">
                                                <!-- <v-select :select-on-tab="true" v-model="item.item.selected_item" @click.native="addRow(index)" label="name" class="border border-white w-full" :options="itemData" placeholder="@lang('lang.searchItem')">
                                                    <template v-slot:no-options="{ search, searching }">
                                                        <template v-if="searching">
                                                            @lang('lang.no_record_found_for') @{{search}}
                                                        </template>
                                                        <em class="v-select-search-hint" v-else>@lang('lang.type_to_search')</em>
                                                    </template>
                                                </v-select> -->
                                                <input type="text" @click="addRow(index)" placeholder="@lang('lang.beneficiary')" class="form-control border border-white" value="beneficiary" name="party[]">
                                                <!-- <input type="hidden" name="item_ids[]" :value="(item.item.selected_item == null) ? null : item.item.selected_item.id"> -->
                                            </td>
                                            <td v-show="showTable('quantity')" class="p-0 border-right align-middle">
                                                <input type="number" placeholder="Your quantity" class="form-control border border-white" v-model="item.item.quantity" name="quantity[]">
                                            </td>
                                            <td v-show="showTable('price')" class="p-0 border-right align-middle">
                                                <input type="number" placeholder="Your price" class="form-control border border-white" v-model="item.item.price" name="price[]">
                                            </td>
                                            <td v-show="showTable('total')" class="p-0 border-right  text-center align-middle">
                                                @{{ isNaN(Number.parseFloat(item.item.price) * Number.parseFloat(item.item.quantity) * Number.parseFloat(selected_currency?.rate)) ? '0' : (Number.parseFloat(item.item.price) * Number.parseFloat(item.item.quantity) * Number.parseFloat(selected_currency?.rate)).toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") }}
                                            </td>
                                            <td v-show="showTable('action')" class="p-0 text-center align-middle"><i class="far fa-trash-alt" style="color:red" v-on:click="deleteItem(index)"></i></td>
                                        </tr>
 
                                    </tbody>
                                    <!-- <tfoot class="bg-light-blue-7 text-white">
                                                        <tr>
                                                            <th class="text-center p-0"></th>
                                                            <th class="p-0" style="width:300px"></th>
                                                            <th class="p-0"></th>
                                                            <th class="p-0"></th>
                                                            <th class="text-center p-0">@{{total_grant}} @{{ (selected_currency != null) ? selected_currency.symbol : null }}</th>
                                                            <th class="text-center p-0"></th>
                                                        </tr>
                                                    </tfoot> -->
                                </table>
                            </div>
                        </div>

                        <div class="card-footer text-right pr-0 bg-white">
                            <button class="btn btn-info" type="submit">

                                <!-- <span :class="spinner" class="  spinner-border-sm" role="status" aria-hidden="true"></span> -->
                                <span class="ml-2">Save Order</span>
                            </button>
                        </div>
                    </div>

                </form>
            </div>

        </div>

    </div>
    <!-- end row -->
</div> 
<!-- end container-fluid -->
<!-- </div> -->
<!-- end page-content-wrapper -->




@endsection
@section('js')


<script>
    var vm = new Vue({
        el: '#myapp',
        data: {
            drawerVisible: false,
            spinner: 'spinner-border',
            disabled: true,
            projects: {!!$projects!!},
            currencies: {!!$currencies!!},
            selected_project: null,
            selected_company: null,
            selected_currency: null,
            items: [{
                    item: {
                        selected_item: null,
                        quantity: null,
                        price: null
                    }
                },
                {
                    item: {
                        selected_item: null,
                        quantity: null,
                        price: null
                    }
                },
                {
                    item: {
                        selected_item: null,
                        quantity: null,
                        price: null
                    }
                },
            ],
            itemData: [],
            form: {

            },
            control_room: {
                fields: null,
                table: null
            }
        }, 
        components: {
            'skeleton-loader-vue': window.VueSkeletonLoader,
        },
        mounted: function() {
            // this.getItems();
            let currency = {!! $home_currency !!};
            console.log('check home_currency', currency);
            this.selected_currency = this.currencies.find(cur => cur.code == currency.code);
            console.log('check selected currency', this.selected_currency);
            this.selected_currency.rate = (this.selected_currency.rate == 0) ? 1: this.selected_currency.rate;
            console.log('chkec', this.currencies);
            this.selected_project = (this.projects.length > 0) ? this.projects[0] : null;


            this.setControlRoom();
            // this.getHomeCurrency();
            // this.selectedCompany();
        },
        computed: {
            total_grant() {
                let total = 0;
                for (let x = 0; x < this.items.length; x++) {

                    total += (this.items[x].item.price * this.items[x].item.quantity) || 0;
                }

                return total;
            }
        },
        methods: {
            showFields(name) {
                if (
                    this.control_room.fields?.find((e) => e.name == name && e.value == true)
                )
                    return true;
                else return false;
            },
            showTable(name) {
                if (
                    this.control_room.table?.find((e) => e.name == name && e.value == true)
                )
                    return true;
                else return false;
            },
            setControlRoom() {
                if (!localStorage.getItem("setting")) {
                    axios.get('/user/setting').then(res => {
                        console.log(res.data);
                        let setting = res.data.find(
                            (e) => e.name == 'Order'
                        ).data;
                        // checkData(setting, this)
                        this.control_room.fields = setting?. [0]?.values;
                        this.control_room.table = setting?. [1]?.values
                        localStorage.setItem('setting', JSON.stringify(res.data));


                    })
                } else {
                    let setting = JSON.parse(localStorage.getItem("setting")).find(
                        (e) => e.name == 'Order'
                    ).data;
                    // checkData(setting, this);
                    this.control_room.fields = setting?. [0]?.values;
                    this.control_room.table = setting?. [1]?.values
                }
            },
            saveSetting() {
                let setting = JSON.parse(localStorage.getItem("setting"));
                let index = setting.findIndex((e) => e.name == "Order");
                setting[index].data[0].values = this.control_room.fields;
                setting[index].data[1].values = this.control_room.table;
                axios
                    .post("/user/setting", {
                        form: JSON.stringify(setting)
                    })
                    .then((res) => {
                        localStorage.setItem("setting", JSON.stringify(setting));
                    });
            },
            searchItems: _.debounce((e) => {
                axios.get("{{route('item.all') }}?" +
                        "type=" + 'item'
                    )
                    .then((res) => {
                        this.itemData = res.data;
                    });
            }, 200),
            getItems() {
                axios.get("{{route('item.all') }}")
                    .then((res) => {
                        this.itemData = res.data;
                    });
            },
            addRow(index) {
                if (this.items[index + 1] == undefined) {
                    this.items.push({
                        item: {
                            selected_item: null,
                            quantity: null,
                            price: null
                        }
                    });
                }
            },
            deleteItem(index) {
                if (this.items.length - 1 > 0) this.items.splice(index, 1);
            },
            getItemTotal(item = null, exchanged_rate = 1) {
                let result = 0;
                if (item != null && item.quantity > 0) {
                    let price = item.price;
                    let quantity = item.quantity;
                    let total = price * quantity * 1;
                    result = Number.parseFloat(total).toFixed(2);
                }
                return result;
            },
            /**
             * handleSubmit
             */
            handleSubmit(e, type = 'save') {
                this.$validator.validate().then(valid => {

                    if (valid) {

                        let ids = [];
                        for (let i = 0; i < this.selected_role.length; i++) {
                            ids.push(this.selected_role[i].id)
                        }

                        $('#role_ids').val(ids);
                        document.getElementById('permission_id').value = selected_p;
                        e.preventDefault();
                        let url = (e.target.form == undefined) ? e.target.action : e.target.form.action;
                        let data = (e.target.form == undefined) ? $(e.target).serialize() : $(e.target.form).serialize();
                        data = new FormData(e.target.form);
                        toggleBlock(1);
                        axios.post(url, data)
                            .then(function(response) {
                                toggleBlock(0);
                                let message = "{{__('message.success')}}";
                                if (response.data) {
                                    message = response.data.message;
                                }
                                alertify.success(message);
                                if (type != 'save') {
                                    vm.defaultValue(e);
                                } else {
                                    window.location.href = "{{route('user.index')}}";
                                }
                            })
                            .catch(function(error) {
                                toggleBlock(0);
                                let warning = "{{__('message.error')}}";
                                if (error.response.data) {
                                    if (error.response.data.message) {
                                        warning = error.response.data.message;
                                    }
                                    if ((error.response.status == 422) == true) {
                                        let my_error = error.response.data.errors;

                                        for (index in my_error) {

                                            alertify.error(my_error[index][0]);
                                        }

                                    }
                                }

                                alertify.error(warning);
                            })
                    }
                });
            }
        }
    });
</script>

<style>
    .vue_dropdown .vs__dropdown-toggle {
        border: none !important;
    }
</style>

@endsection

