@extends('layouts.master')
@section('title', __('lang.edit').' '.__('lang.order'))
@section('css')
    <link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css"/>
    <link href="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}" rel="stylesheet" type="text/css"/>


@endsection
@section('content')
    <div class="page-content-wrapper" id="myapp" v-cloak>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <form action="{{route('order.update', $order->id)}}" @submit="handleSubmit($event)" method="post" id="userForm" enctype="multipart/form-data">
                            @csrf
                            @method('patch')
                            <div class="card-body" style="padding-bottom: 0px">
                                <div class="card-body client-nav">
                                        <!-- <h4 class="header-title">@lang('lang.add') @lang('lang.order')</h4> -->
                                    <div class="row">
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.organization')
                                                </label>
                                                    <v-select :select-on-tab="true"
                                                              v-model="selected_company" 
                                                              label="name" 
                                                              :options="companies" placeholder="@lang('lang.selectCompany')"
                                                                >
                                                                <template v-slot:no-options="{ search, searching }">
                                                                    <template v-if="searching">
                                                                        @lang('lang.no_record_found_for') @{{search}}
                                                                    </template>
                                                                    <em class="v-select-search-hint"
                                                                        v-else>@lang('lang.type_to_search')</em>
                                                                </template>
                                                            </v-select>
                                                    <input type="hidden" name="company" :value="(selected_company == null) ? null : selected_company.id">
                                                </div>
                                            </div>
                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="">@lang('lang.fro_date')
                                                    </label>
                                                   <input type="date" name="from_date" class="form-control" id="email" data-vv-as="@lang('lang.from_date')"
                                                           placeholder="@lang('lang.from_date')" autocomplete="new-email" value="{{$order->from_date}}">
                                                    <span class="help-block rq-hint">
                                                    @{{errors.first('from_date')}}</span>
                                                </div>
                                            </div>
                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="">@lang('lang.to_date')
                                                    </label>
                                                    <input type="date" name="to_date" class="form-control" id="email"data-vv-as="@lang('lang.to_date')"
                                                           placeholder="@lang('lang.to_date')" autocomplete="new-email" value="{{$order->to_date}}">
                                                    
                                                </div>
                                            </div>
                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="">@lang('lang.project')
                                                    </label>
                                                    <v-select :select-on-tab="true"
                                                      v-model="selected_project" 
                                                      label="name" 
                                                      :options="projects" placeholder="@lang('lang.selectProject')"
                                                        >
                                                        <template v-slot:no-options="{ search, searching }">
                                                            <template v-if="searching">
                                                                @lang('lang.no_record_found_for') @{{search}}
                                                            </template>
                                                            <em class="v-select-search-hint"
                                                                v-else>@lang('lang.type_to_search')</em>
                                                        </template>
                                                    </v-select>
                                                    <input type="hidden" name="project" :value="(selected_project == null) ? null : selected_project.id">

                                                </div>
                                            </div>
                                            <div class="col-xl-2">
                                                 <div class="form-group">
                                                    <label for="">@lang('lang.currency')
                                                    </label>
                                                    <v-select :select-on-tab="true"
                                                      v-model="selected_currency" 
                                                      label="code" 
                                                      :options="currencies" placeholder="@lang('lang.select_currency')"
                                                        >
                                                        <template v-slot:no-options="{ search, searching }">
                                                            <template v-if="searching">
                                                                @lang('lang.no_record_found_for') @{{search}}
                                                            </template>
                                                            <em class="v-select-search-hint"
                                                                v-else>@lang('lang.type_to_search')</em>
                                                        </template>
                                                    </v-select>
                                                    <input type="hidden" name="currency" :value="(selected_currency == null) ? null : selected_currency.code">
                                                </div>
                                            </div>
                                            <div class="col-xl-2">
                                                 <div class="form-group">
                                                    <label for="">@lang('lang.exchange_rate') 
                                                    </label>
                                                    <input type="text" name="exchange_rate" class="form-control"
                                                        v-model="!selected_currency ? 1 : selected_currency.rate"
                                                          autocomplete="new-password" 
                                                           data-vv-as="@lang('lang.password')"
                                                           placeholder="@lang('lang.exchange_rate')">
                                                    <span class="help-block rq-hint">
                                                    @{{errors.first('exchange_rate')}}</span>
                                                </div>
                                            </div>
                                            <div class="col-xl-4">
                                                 <div class="form-group">
                                                    <label for="">@lang('lang.ref_no') 
                                                    </label>
                                                    <input type="text" value="{{$order->ref_no}}" name="ref_no" class="form-control"
                                                          autocomplete="new-password" 
                                                           data-vv-as="@lang('lang.password')"
                                                           placeholder="@lang('lang.ref_no')">
                                                    <span class="help-block rq-hint">
                                                    @{{errors.first('ref_no')}}</span>
                                                </div>
                                            </div>
                                            <div class="col-xl-6">
                                                 <div class="form-group">
                                                    <label for="">@lang('lang.description') 
                                                    </label>
                                                    <textarea class="form-control" id="exampleFormControlTextarea1" name="desc" rows="2">{{$order->description}}
                                                    </textarea>
                                                    <span class="help-block rq-hint">
                                                    @{{errors.first('ref_no')}}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- end of permission -->
                                    </div>
                                     <div class="table-responsive">
                                                <table class="table mb-0">
                                                    <thead>
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Item</th>
                                                            <th>Quantity</th>
                                                            <th>Price</th>
                                                            <th>Total</th>
                                                            <th><i class="far fa-trash-alt" style="color:red"></i></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr v-for="(item, index) in items">
                                                            <th scope="row">@{{++index}}</th>
                                                            <td> 
                                                                <v-select :select-on-tab="true"
                                                              v-model="item.item.selected_item"
                                                              @click.native="addRow(index)"
                                                              label="name"
                                                              style="width:180px "
                                                              :options="itemData" placeholder="@lang('lang.searchItem')"
                                                                >
                                                                <template v-slot:no-options="{ search, searching }">
                                                                    <template v-if="searching">
                                                                        @lang('lang.no_record_found_for') @{{search}}
                                                                    </template>
                                                                    <em class="v-select-search-hint"
                                                                        v-else>@lang('lang.type_to_search')</em>
                                                                </template>
                                                            </v-select>
                                                            <input type="hidden" name="item_ids[]" :value="(item.item.selected_item == null) ? null : item.item.selected_item.id">
                                                            </td>
                                                            <td>
                                                                <input type="number" class="form-control" v-model="item.item.quantity" name="quantity[]">
                                                            </td>
                                                            <td>
                                                                <input type="number" class="form-control" v-model="item.item.price" name="price[]">
                                                            </td>
                                                            <td>
                                                                @{{ Number.parseFloat(item.item.price) * Number.parseFloat(item.item.quantity) || '0'}} 
                                                            </td>
                                                            <td><i class="far fa-trash-alt" style="color:red"  v-on:click="deleteItem(index)"></i></td>
                                                        </tr>
                                                         
                                                    </tbody>
                                                </table>
                                            </div>
                                </div>

                                <div class="card-footer ">
                                    <button class="btn btn-md btn-primary" type="submit">
                                        <span hidden id="btn-loading" class="spinner-border spinner-border-sm"
                                              user="status" aria-hidden="true"></span> @lang('lang.save')</button>
                                    <button class="btn btn-md btn-danger" type="reset">@lang('lang.reset')</button>
                                    <button class="btn btn-md btn-danger" type="button"
                                            onclick="location.href='{{route('user.index')}}'">@lang('lang.cancel')</button>

                                </div>
                        </form>
                    </div>

                </div>
                </div>
                <!-- end row -->
            </div>
            <!-- end container-fluid -->
    </div>
        <!-- end page-content-wrapper -->


@endsection
@section('js')
    

    <script>
      
        var vm = new Vue({
            el: '#myapp',
            data: {
                order : {!! $order !!},
                order_details: {!! $order_details !!},
                projects:{!!$projects!!},
                companies:{!!$companies!!},
                currencies:{!!$currencies!!},
                selected_project:null,
                selected_company:null, 
                selected_currency:null, 
                items: [],
                itemData: [],
                form: {
        
                }
            },
            mounted: function () {
                this.getItems();
                let order = {!! $order !!};
                this.selected_currency = this.currencies.find( cur => cur.code == order.currency);
                this.selected_company = this.companies.find( comp => comp.id == order.organization_id);
                this.selected_project = this.projects.find( proj => proj.id == order.project_id);
                let order_details = {!! $order_details !!};

                for(let x=0; x< order_details.length; x++){
                    let item = this.itemData.find(it => it.id == order_details[x].item_id);
                    console.log('check item', item);
                    this.items.push({ item: {selected_item: item, quantity: order_details[x].quantity, price: order_details[x].price} });
                }
                // console.log('chkec', this.currencies);
                // this.getHomeCurrency();
                // this.selectedCompany();
            },
            methods: {
                searchItems: _.debounce(function (e) {
                    axios.get("{{route('item.all') }}?" +
                        "type="+'item'
                    )
                    .then((res) => {
                        this.itemData = res.data;
                    });
                }, 200),
                getItems(){
                    axios.get("{{route('item.all') }}")
                        .then((res) => {
                            this.itemData = res.data;
                        });
                },
                addRow(index){  
                  if (this.items[index + 1] == undefined) { 
                    this.items.push({ item: {selected_item: null, quantity: null, price: null} });
                  }
                },
                deleteItem(index) {
                  if (this.items.length - 1 > 0) this.items.splice(index, 1);
                },
                getItemTotal(item = null, exchanged_rate = 1) {
                      let result = 0;
                      if (item != null && item.quantity > 0) {
                        let price    = item.price;
                        let quantity = item.quantity;
                        let total = price * quantity * 1; 
                        result = Number.parseFloat(total).toFixed(2);
                      }
                      return result;
                    },
                /**
                 * handleSubmit
                 */
                handleSubmit(e, type = 'save') {
                    this.$validator.validate().then(valid => {

                        if (valid) {

                            let ids = [];
                            for (let i = 0; i < this.selected_role.length; i++) {
                                ids.push(this.selected_role[i].id)
                            }

                            $('#role_ids').val(ids);
                            document.getElementById('permission_id').value = selected_p;
                            e.preventDefault();
                            let url = (e.target.form == undefined) ? e.target.action : e.target.form.action;
                            let data = (e.target.form == undefined) ? $(e.target).serialize() : $(e.target.form).serialize();
                            data = new FormData(e.target.form);
                            toggleBlock(1);
                            axios.post(url, data)
                                .then(function (response) {
                                    toggleBlock(0);
                                    let message = "{{__('message.success')}}";
                                    if (response.data) {
                                        message = response.data.message;
                                    }
                                    alertify.success(message);
                                    if (type != 'save') {
                                        vm.defaultValue(e);
                                    } else {
                                        window.location.href = "{{route('user.index')}}";
                                    }
                                })
                                .catch(function (error) {
                                    toggleBlock(0);
                                    let warning = "{{__('message.error')}}";
                                    if (error.response.data) {
                                        if (error.response.data.message) {
                                            warning = error.response.data.message;
                                        }
                                        if ((error.response.status == 422) == true) {
                                            let my_error = error.response.data.errors;

                                            for (index in my_error) {

                                                alertify.error(my_error[index][0]);
                                            }

                                        }
                                    }

                                    alertify.error(warning);
                                })
                        }
                    });
                },
                /**
                 * this is used to set default value
                 */
            

           


            }
        });

    </script>

@endsection
