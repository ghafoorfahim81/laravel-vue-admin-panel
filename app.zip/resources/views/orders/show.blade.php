@extends('layouts.master')
@section('title', __('lang.show').' '.__('lang.order'))
@section('css')

@endsection
@section('content')
    <div class="page-content-wrapper" id="myapp" v-cloak>
    <div class="card mx-3">
  <div class="card-body">
    <div class="container mb-5 mt-3">
      <div class="row d-flex align-items-baseline">
        <div class="col-xl-9">
          <p style="color: #7e8d9f;font-size: 20px;">Order <strong>ID: #{{$order->ref_no}}</strong></p>
        </div>
        <div class="col-xl-3 float-end">
          <a class="btn btn-light text-capitalize border-0" data-mdb-ripple-color="dark"><i
              class="fas fa-print text-primary"></i> Print</a>
          <a class="btn btn-light text-capitalize" data-mdb-ripple-color="dark"><i
              class="far fa-file-pdf text-danger"></i> Export</a>
        </div>
        <hr>
      </div>

      <div class="container">
        <div class="col-md-12">
          <div class="text-center">
          <img
             src="https://apyouths.org/wp-content/uploads/2022/03/PSP-UNHCR-INDONESIA-JOB.png"
             height="49"
             alt=""
             
             loading="lazy"
             />
            
          </div>

        </div>


        <div class="row">
          <div class="col-xl-8">
            <ul class="list-unstyled">
              <li class="text-muted">Organization: <span style="color:#5d9fc5 ;">{{$company->name}}</span></li>
              <li class="text-muted">Project Name: <span style="color:#5d9fc5 ;">{{$project->name}}</span></li>
              <li class="text-muted">Currency: <span style="color:#5d9fc5 ;">{{$order->currency}}</span></li>
              <li class="text-muted">Exchange Rate: <span style="color:#5d9fc5 ;">{{$order->exchange_rate}}</span></li>
            </ul>
          </div>
          <div class="col-xl-4">
            <ul class="list-unstyled">
              <li class="text-muted"><i class="fas fa-circle" style="color:#84B0CA ;"></i> <span
                  class="fw-bold">Reference Number:</span>#{{$order->ref_no}}</li>
              <li class="text-muted"><i class="fas fa-circle" style="color:#84B0CA ;"></i> <span
                  class="fw-bold">From Date: </span>{{substr($order->from_date, 0, 10)}}</li>
              <li class="text-muted"><i class="fas fa-circle" style="color:#84B0CA ;"></i> <span
                  class="fw-bold">To Date: </span>{{substr($order->to_date, 0, 10)}}</li>
            </ul>
          </div>
        </div>

        <div class="row my-2 mx-1 justify-content-center">
        <table class="table align-middle mb-8 bg-white">
            <thead class="bg-light">
                <tr>
                <th>#</th>
                <th>Party Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total</th>
                </tr>
            </thead>
            <tbody>
                
                <tr v-for="(detail, index) in order_details">
                  <td>@{{++index}}</td>
                  <td>
                  <p class="fw-bold mb-1">@{{detail.party}}</p>
                  </td>
                  <td>@{{detail.quantity}}</td>
                  <td>@{{detail.price}}</td>
                  <td>@{{ detail.quantity * detail.price}}</td>
                </tr>
            </tbody>
            </table>
        </div>
        <div class="row">
          <div class="col-xl-8">
            <!-- <p class="ms-3">Add additional notes and payment information</p> -->

          </div>
          <div class="col-xl-3">
            <!-- <ul class="list-unstyled">
              <li class="text-muted ms-3"><span class="text-black me-4">SubTotal</span>$1110</li>
              <li class="text-muted ms-3 mt-2"><span class="text-black me-4">Tax(15%)</span>$111</li>
            </ul> -->
            <p class="text-black float-start"><span class="text-black me-3"> Total Amount</span><span
                style="font-size: 25px;">{{$currency->symbol}} @{{total_amount}}</span></p>
          </div>
        </div>
        <hr>
        <div class="row">
          <div class="col-xl-10">
            <p>Order description goes here.</p>
          </div>
          <div class="col-xl-2">
            <!-- <button type="button" class="btn btn-primary text-capitalize"
              style="background-color:#60bdf3 ;">Pay Now</button> -->
          </div>
        </div>

      </div>
    </div>
  </div>
</div>
    </div>
  
<!-- Tabs content -->
            
            <!-- end container-fluid -->
    </div>
        <!-- end page-content-wrapper -->


@endsection
@section('js')
    

    <script>
      
        var vm = new Vue({
            el: '#myapp',
            data: {
                tabs:[
                        {tab:'general', css_class:'fa-home',value:'General', is_active:true},
                        {tab:'receipts', css_class:'fa-user',value:'Attachments', is_active:false},
                    ],

               order_details: {!! $order_details !!},
               total_amount: 0,
            },
            created(){

              let order_details = {!! $order_details !!};
              for(let x=0; x<order_details.length; x++){
                this.total_amount += ( order_details[x].price * order_details[x].quantity);
              }
            },
           
        });

    </script>

    <style>
        .vue_dropdown .vs__dropdown-toggle {
            border: none !important;
        }
    </style>

@endsection
