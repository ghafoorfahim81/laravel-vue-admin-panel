@extends('layouts.master')
@section('title', __('lang.edit').' '.__('lang.order'))
@section('css')
    <link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css"/>
    <link href="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}" rel="stylesheet" type="text/css"/>


@endsection
@section('content')
    <div class="page-content-wrapper" id="myapp" v-cloak>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <form action="{{route('order.update', $order->id)}}" @submit="handleSubmit($event)" method="post" id="userForm" enctype="multipart/form-data">
                            @csrf
                            @method('patch')
                            <div class="card-body" style="padding-bottom: 0px">
                                <div class="">
                                        <!-- <h4 class="header-title">@lang('lang.add') @lang('lang.order')</h4> -->

                                    <div class="row justify-content-center">
                                        <div class="row">
                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="">@lang('lang.organization')
                                                    </label>
                                                    <input type="text" value="{{$company->name}}" class="form-control"
                                                   autocomplete="new-password"
                                                   disabled
                                                   placeholder="@lang('lang.invoice_number')">
                                                    <input type="hidden" name="company"
                                                       value="{{$company->id}}">
                                                </div>
                                            </div>
                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="">@lang('lang.fro_date')
                                                    </label>
                                                    <input type="date" name="from_date" class="form-control" id="email" data-vv-as="@lang('lang.from_date')" placeholder="@lang('lang.from_date')" autocomplete="new-email" v-model="from_date">
                                                    <span class="help-block rq-hint">
                                                        @{{errors.first('from_date')}}</span>
                                                </div>
                                            </div>
                                            <div class="col-xl-4" >
                                                <div class="form-group">
                                                    <label for="">@lang('lang.to_date')
                                                    </label>
                                                    <input type="date" v-model="to_date" name="to_date" class="form-control" id="email" data-vv-as="@lang('lang.to_date')" placeholder="@lang('lang.to_date')" autocomplete="new-email">

                                                </div>
                                            </div>
                                            <div class="col-xl-4" >
                                                <div class="form-group">
                                                    <label for="">@lang('lang.project')
                                                    </label>
                                                    <v-select :select-on-tab="true" v-model="selected_project" label="name" :options="projects" placeholder="@lang('lang.selectProject')">
                                                        <template v-slot:no-options="{ search, searching }">
                                                            <template v-if="searching">
                                                                @lang('lang.no_record_found_for') @{{search}}
                                                            </template>
                                                            <em class="v-select-search-hint" v-else>@lang('lang.type_to_search')</em>
                                                        </template>
                                                    </v-select>
                                                    <input type="hidden" name="project" :value="(selected_project == null) ? null : selected_project.id">
                                                    <input type="hidden" name="location_id" :value="(selected_project == null) ? null : selected_project.location_id">

                                                </div>
                                            </div>
                                            <div class="col-xl-2" >
                                                <div class="form-group">
                                                    <label for="">@lang('lang.currency')
                                                    </label>
                                                    <v-select :select-on-tab="true" v-model="selected_currency" label="code" :options="currencies" placeholder="@lang('lang.select_currency')">
                                                        <template v-slot:no-options="{ search, searching }">
                                                            <template v-if="searching">
                                                                @lang('lang.no_record_found_for') @{{search}}
                                                            </template>
                                                            <em class="v-select-search-hint" v-else>@lang('lang.type_to_search')</em>
                                                        </template>
                                                    </v-select>
                                                    <input type="hidden" name="currency" :value="(selected_currency == null) ? null : selected_currency.code">
                                                </div>
                                            </div>
                                            <div class="col-xl-2" >
                                                <div class="form-group">
                                                    <label for="">@lang('lang.exchange_rate')
                                                    </label>
                                                    <input type="text" name="exchange_rate" class="form-control" v-model="exchange_rate" autocomplete="new-password" data-vv-as="@lang('lang.password')" placeholder="@lang('lang.rate')">
                                                    <span class="help-block rq-hint">
                                                        @{{errors.first('exchange_rate')}}</span>
                                                </div>
                                            </div>
                                            <div class="col-xl-4" >
                                                <div class="form-group">
                                                    <label for="">@lang('lang.ref_no')
                                                    </label>
                                                    <input type="text" value="{{$order->ref_no}}" name="ref_no" class="form-control" autocomplete="new-password" data-vv-as="@lang('lang.password')" placeholder="@lang('lang.ref_no')">
                                                    <span class="help-block rq-hint">
                                                        @{{errors.first('ref_no')}}</span>
                                                </div>
                                            </div>
                                            <div class="col-xl-6" >
                                                <div class="form-group">
                                                    <label for="">@lang('lang.description')
                                                    </label>
                                                    <textarea class="form-control" id="exampleFormControlTextarea1" name="desc" rows="2">{{$order->description}}
                                                            </textarea>
                                                    <span class="help-block rq-hint">
                                                        @{{errors.first('ref_no')}}</span>
                                                </div>
                                            </div>
                                            <div class="col-xl-6 align-self-end p-0">
                                                <div class="d-flex flex-row-reverse mb-2">
                                                    <div class="col-xl-8 col-md-8 p-0">
                                                        <div class="w-full shadow-4 rounded-sm p-3 border">
                                                            <div class="row justify-around">
                                                                <span class="font-weight-bold text-xl col-7">Grand Total</span>
                                                                <span class="font-weight-bold text-xl col text-end">@{{total_grant.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}} @{{ (selected_currency != null) ? selected_currency.symbol : null }}</span>
                                                            </div>

                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    
                                     <div class="table-responsive shadow-4 rounded-sm">
                                                <table class="table mb-0 ">
                                                    <thead class="bg-light-blue-7 text-white">
                                                        <tr>
                                                            <th class="text-center p-2">#</th>
                                                            <th class="p-2" style="width:300px">@lang('lang.beneficiary')</th>
                                                            <th class="p-2">@lang('lang.quantity')</th>
                                                            <th class="p-2">@lang('lang.price')</th>
                                                            <th class="text-center p-2">@lang('lang.total')</th>
                                                            <th class="text-center p-2">@lang('lang.action')</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr v-for="(item, index) in items">
                                                            <th class="p-0 text-center border-right align-middle" scope="row">@{{++index}}</th>
                                                            <td class=" p-0 vue_dropdown border-right align-middle" > 
                                                                <!-- <v-select :select-on-tab="true"
                                                              v-model="item.item.selected_item"
                                                              @click.native="addRow(index)"
                                                              label="name"
                                                              
                                                              class="border border-white w-full"
                                                              :options="itemData" placeholder="@lang('lang.searchbeneficiary')"
                                                                >
                                                                <template v-slot:no-options="{ search, searching }">
                                                                    <template v-if="searching">
                                                                        @lang('lang.no_record_found_for') @{{search}}
                                                                    </template>
                                                                    <em class="v-select-search-hint"
                                                                        v-else>@lang('lang.type_to_search')</em>
                                                                </template>
                                                            </v-select>
                                                            <input type="hidden" name="item_ids[]" :value="(item.item.selected_item == null) ? null : item.item.selected_item.id"> -->
                                                            <input type="text" placeholder="@lang('lang.beneficiary')" class="form-control border border-white" value="beneficiary" name="party[]" v-model="item.item.party">
                                                            </td>
                                                            <td class="p-0 border-right align-middle">
                                                                <input type="number" placeholder="Your quantity" class="form-control border border-white" v-model="item.item.quantity" name="quantity[]">
                                                            </td>
                                                            <td class="p-0 border-right align-middle">
                                                                <input type="number" placeholder="Your price"  class="form-control border border-white" v-model="item.item.price" name="price[]">
                                                            </td>
                                                            <td class="p-0 text-center align-middle"> 

                                                                @{{ isNaN(Number.parseFloat(item.item.price) * Number.parseFloat(item.item.quantity) * Number.parseFloat(exchange_rate)) ? '0' : (Number.parseFloat(item.item.price) * Number.parseFloat(item.item.quantity) * Number.parseFloat(exchange_rate)).toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") }}
                                                            </td>
                                                            <td class="p-0 text-center align-middle"><i class="far fa-trash-alt" style="color:red"  v-on:click="deleteItem(index)"></i></td>
                                                        </tr>
                                                         
                                                    </tbody>
                                                </table>
                                            </div>
                                </div>

                                <div class="card-footer text-right pr-0">
                                    <!-- <button class="btn btn-md btn-primary" type="submit">
                                        <span hidden id="btn-loading" class="spinner-border spinner-border-sm"
                                              user="status" aria-hidden="true"></span> @lang('lang.save')</button>
                                    <button class="btn btn-md btn-danger" type="reset">@lang('lang.reset')</button>
                                    <button class="btn btn-md btn-danger" type="button"
                                            onclick="location.href='{{route('user.index')}}'">@lang('lang.cancel')</button> -->
                                            
                                            <!-- <button type="submit" class="btn btn-info mr-0">
                                            Save Changes
                                            </button> -->

                                            <button class="btn btn-info" type="submit" >
                                                
                                            <!-- <span :class="spinner" class="  spinner-border-sm" role="status" aria-hidden="true"></span> -->
                                                <span class="ml-2">Save Order</span>
                                            </button>

                                </div>


                                <!-- Save-Banner Start -->
                                <nav class="navbar navbar-expand-lg py-0 navbar-light bg-dark fixed-top ">
                                <div>
                                            <a class="navbar-brand me-2" href="https://mdbgo.com/">
                                            <img
                                                src="https://mdbcdn.b-cdn.net/img/logo/mdb-transaprent-noshadows.webp"
                                                
                                                alt="MDB Logo"
                                                loading="lazy"
                                                style="margin-top: -1px;"
                                            />
                                            </a>

                                            </div>
                                    <!-- Container wrapper -->
                                    <div class="container">
                                        
                                        <!-- Navbar brand -->
                                           

                                        <!-- Toggle button -->
                                        <button
                                        class="navbar-toggler"
                                        type="button"
                                        data-mdb-toggle="collapse"
                                        data-mdb-target="#navbarButtonsExample"
                                        aria-controls="navbarButtonsExample"
                                        aria-expanded="false"
                                        aria-label="Toggle navigation"
                                        >
                                        <i class="fas fa-bars"></i>
                                        </button>

                                        <!-- Collapsible wrapper -->
                                        <div class="collapse navbar-collapse" id="navbarButtonsExample">
                                        <!-- Left links -->
                                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                                            <li class="nav-item">
                                            <a class="nav-link text-white text-xl" href="#">Unsaved Changes</a>
                                            </li>
                                        </ul>
                                        <!-- Left links -->

                                        <div class="d-flex align-items-center">
                                            <button type="button" onclick="location.href='{{route('user.index')}}'" class="btn btn-dark px-3 me-2">
                                            Cancel
                                            </button>
                                            
                                            <button type="reset" class="btn btn-dark px-3 me-2">
                                            Reset
                                            </button>
                                            <button class="btn btn-info" type="button" :disabled="disabled">
                                                
                                            <span :class="spinner" class="spinner-border-sm" role="status" aria-hidden="true"></span>
                                                <span class="ml-2">Save Changes</span>
                                            </button>
                                        </div>
                                        </div>
                                        <!-- Collapsible wrapper -->
                                    </div>
                                    <!-- Container wrapper -->
                                    </nav>
                                <!-- Save-Banner End -->
                        </form>
                    </div>

                </div>
                    
                </div>
                <!-- end row -->
            </div>
            <!-- end container-fluid -->
    </div>
        <!-- end page-content-wrapper -->


@endsection
@section('js')
    

    <script> 
      
        var vm = new Vue({
            el: '#myapp',
            data: {
                order : {!! $order !!},
                from_date: null,
                to_date: null,
                order_details: {!! $order_details !!},
                spinner: 'spinner-border',
                disabled: true,
                projects:{!!$projects!!},
                currencies:{!!$currencies!!},
                selected_project:null, 
                selected_currency:null, 
                exchange_rate: {!! $order->exchange_rate !!},
                items: [],
                itemData: [],
                form: {
        
                }
            },
            mounted: function () {
                // this.getItems();
                let order = {!! $order !!};
                this.selected_currency = this.currencies.find( cur => cur.code == order.currency);
                this.selected_project = this.projects.find( proj => proj.id == order.project_id);

                this.from_date = (order?.from_date).split(' ')[0];
                this.to_date = (order?.to_date).split(' ')[0];
                let order_details = {!! $order_details !!};

                for(let x=0; x< order_details.length; x++){
                    
                    this.items.push({ item: {party: order_details[x].party, quantity: order_details[x].quantity, price: order_details[x].price} });
                }

                this.items.push({ item: {party: null, quantity: null, price: null} });
                
            },
            computed:{
                total_grant(){
                    let total = 0;
                    for(let x=0; x<this.items.length; x++){
                        
                        total += (this.items[x].item.price * this.items[x].item.quantity) || 0;
                    }

                    total = total * Number.parseFloat(this.exchange_rate) || 0;
                    return total;
                }
            },
            methods: {
                searchItems: _.debounce(function (e) {
                    axios.get("{{route('item.all') }}?" +
                        "type="+'item'
                    )
                    .then((res) => {
                        this.itemData = res.data;
                    });
                }, 200),
                getItems(){
                    axios.get("{{route('item.all') }}")
                        .then((res) => {
                            this.itemData = res.data;
                            let order_details = {!! $order_details !!};

                            for(let x=0; x< order_details.length; x++){
                                let item = this.itemData.find(it => it.id == order_details[x].item_id);
                                console.log('check item', item);
                                this.items.push({ party: {selected_item: item, quantity: order_details[x].quantity, price: order_details[x].price} });
                            }

                            this.items.push({ item: {selected_item: null, quantity: null, price: null} });
                        });
                },
                addRow(index){  
                    if (this.items[index + 1] == undefined) { 
                        this.items.push({ item: {selected_item: null, quantity: null, price: null} });
                    }

                },
                deleteItem(index) {
                  if (this.items.length - 1 > 0) this.items.splice(index, 1);
                },
                getItemTotal(item = null, exchanged_rate = 1) {
                      let result = 0;
                      if (item != null && item.quantity > 0) {
                        let price    = item.price;
                        let quantity = item.quantity;
                        let total = price * quantity * 1; 
                        result = Number.parseFloat(total).toFixed(2);
                      }
                      return result;
                    },
                /**
                 * handleSubmit
                 */
                handleSubmit(e, type = 'save') {
                    this.$validator.validate().then(valid => {

                        if (valid) {

                            let ids = [];
                            for (let i = 0; i < this.selected_role.length; i++) {
                                ids.push(this.selected_role[i].id)
                            }

                            $('#role_ids').val(ids);
                            document.getElementById('permission_id').value = selected_p;
                            e.preventDefault();
                            let url = (e.target.form == undefined) ? e.target.action : e.target.form.action;
                            let data = (e.target.form == undefined) ? $(e.target).serialize() : $(e.target.form).serialize();
                            data = new FormData(e.target.form);
                            toggleBlock(1);
                            axios.post(url, data)
                                .then(function (response) {
                                    toggleBlock(0);
                                    let message = "{{__('message.success')}}";
                                    if (response.data) {
                                        message = response.data.message;
                                    }
                                    alertify.success(message);
                                    if (type != 'save') {
                                        vm.defaultValue(e);
                                    } else {
                                        window.location.href = "{{route('user.index')}}";
                                    }
                                })
                                .catch(function (error) {
                                    toggleBlock(0);
                                    let warning = "{{__('message.error')}}";
                                    if (error.response.data) {
                                        if (error.response.data.message) {
                                            warning = error.response.data.message;
                                        }
                                        if ((error.response.status == 422) == true) {
                                            let my_error = error.response.data.errors;

                                            for (index in my_error) {

                                                alertify.error(my_error[index][0]);
                                            }

                                        }
                                    }

                                    alertify.error(warning);
                                })
                        }
                    });
                }
                /**
                 * this is used to set default value
                 */
            

           


            }
        });

    </script>

    <style>
        .vue_dropdown .vs__dropdown-toggle {
            border: none !important;
        }
    </style>

@endsection
