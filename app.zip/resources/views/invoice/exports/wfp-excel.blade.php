<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
    </style>
</head>

<body>

<!-- </div> -->

<table>

    <?php
    $showCommission = false;
    $grandTotal = 0;
    $totalComissions = 0;
    $showAmount = false;
    $showHouseHold = true;
    $colSpan = 0;
    $rowSpan = 0;
    if (strlen($invoice->description) > 100) {
        $rowSpan = 7;
    } else {
        $rowSpan = 2;
    }
    foreach ($invoice_details as $d) {
        $grandTotal += $d->total>0?$d->total:$d->total_amount;

        if ($d->service_fee_amount > 0) {
            $colSpan = 6;
            $showCommission = true;
            $totalComissions += (($d->total>0?$d->total:$d->total_amount) * $d->service_fee_percent) / 100;
        } else {
            $colSpan = 5;
            $showCommission = false;
        }
        if ($d->amount > 0) {
            $showAmount = true;
        }
        if ($showCommission && $d->amount > 0) {
            $showAmount = true;
            $colSpan += 1;
        }
        if ($showCommission == false && $d->amount <= 0) {
            $showAmount = false;
            $colSpan = 4;
        }
        if ($d->household == 0) {
            $showHouseHold = false;
            $colSpan = $colSpan-1;
        }
    }
    $headerHeight = '180px';
    $footerHeight = '150px';
    if ($colSpan == 4) {
        $headerHeight = '150px';
        $footerHeight = '120px';
    } elseif ($colSpan > 5) {
        $headerHeight = '180px';
        $footerHeight = '150px';
    }
    elseif ($colSpan > 6) {
        $headerHeight = '240px';
        $footerHeight = '210px';
    }
    elseif ($colSpan ==3) {
        $headerHeight = '110px';
        $footerHeight = '80px';
    }
    ?>
    <tr>
        <td colspan="{{$colSpan}}">
            <img src="{{ public_path('header.PNG') }}" height="{{$headerHeight}}" alt="" srcset="">
        </td>

    </tr>
</table>

<table>
    <tr>
        <th style="text-align:center; align-self:center;" colspan="{{$colSpan}}">
            <b>Invoice  </b>
        </th>
    </tr>
    <tr>
        <td style="text-align: left; padding: 4px;" colspan="1"><b>Invoice No</b>: {{$invoice->invoice_no}}</td>
        <td style="text-align: right; padding: 4px;" colspan="{{$colSpan-2}}"><b>Invoice Date</b>: {{$invoice->date}}
        </td>
    </tr>
    <tr>
        <td style=" text-align: left; padding: 4px;" colspan="6">&nbsp;</td>
    </tr>

    <tr>
        <td style="text-align: left; padding: 4px;" colspan="{{$colSpan}}"><b>Organization:</b> WFP</td>
    </tr>
    @if($invoice->is_show)
        <tr>
            <th style="text-align:left; align-self:center;" colspan="{{$colSpan}}">
                <b>Cash Plan ID:</b> {{$invoice->project_code}}
            </th>
        </tr>
    @endif
</table>

<table>
    <thead>
    <tr bgcolor="#000000">
        <th bgcolor="black" width="100px"
            style="border: 2px solid #000000; padding: 2px; text-align: center; font-weight: bold;color: white">#
        </th>
        <th bgcolor="black" width="200px"
            style="border: 2px solid #000000; padding: 8px; text-align: center; font-weight: bold; color: white">
            Location
        </th>
        @if($showHouseHold)
            <th bgcolor="black" width="100px"
                style="border: 2px solid #000000; padding: 8px; text-align: center; font-weight: bold; color: white">House
                Hold
            </th>
        @endif
        @if($showAmount)
            <th bgcolor="black" width="150px"
                style="border: 2px solid #000000; padding: 8px; text-align: center; font-weight: bold; color: white">
                Amount ({{$invoice->currency}})
            </th>
        @endif
        <th bgcolor="black" width="300px"
            style="border: 2px solid #000000; padding: 8px; text-align: center; font-weight: bold; color: white">Grand
            Total ({{$invoice->currency}})
        </th>
        @if($showCommission)
            <th bgcolor="black" width="50px"
                style="border: 2px solid #000000; padding: 8px; text-align: center; font-weight: bold; color: white"> %
            </th>
            <th bgcolor="black" width="200px"
                style="border: 2px solid #000000; padding: 8px; text-align: center; font-weight: bold; color: white">
                Commission ({{$invoice->currency}})
            </th>
        @endif
    </tr>
    </thead>
    @foreach($invoice_details as $detail)
        <tr style="background-color: #dddddd;">
            <td width="100px"
                style="border: 2px solid #000000; text-align: center; ">{{$loop->iteration}}</td>
            <th width="200px"
                style="border: 2px solid #000000; text-align: center; padding: 4px;">{{$detail->province}}</th>
            @if($showHouseHold)
                <th width="100px"
                    style="border: 2px solid #000000; text-align: center; padding: 4px;">{{$detail->household}}</th>
            @endif
            @if($showAmount)
                <th width="150px"
                    style="border: 2px solid #000000; text-align: center; padding: 4px;">{{$detail->amount}}</th>
            @endif
            <th width="300px"
                style="border: 2px solid #000000; text-align: center; padding: 4px;">{{$detail->total>0?$detail->total:$detail->total_amount}}</th>
            @if($showCommission)
                <th width="50px"
                    style="border: 2px solid #000000; text-align: center; padding: 4px;">{{$detail->service_fee_percent}}</th>
                <th width="200px"
                    style="border: 2px solid #000000; text-align: center; padding: 4px;">{{(($detail->total>0?$detail->total:$detail->total_amount)*$detail->service_fee_percent)/100}}</th>
            @endif
        </tr>
        @if($loop->last)
            <!-- Check if it's the last iteration -->
            @for($i = 1; $i <= 3; $i++)
                <tr style="background-color: #dddddd;">
                    <td width="100px"
                        style="border: 2px solid #000000; text-align: center;">{{$loop->iteration+$i}}</td>
                    <th width="200px"
                        style="border: 2px solid #000000; text-align: center; padding: 4px;"></th>
                    @if($showHouseHold)
                        <th width="100px"
                            style="border: 2px solid #000000; text-align: center; padding: 4px;"></th>
                    @endif
                    @if($showAmount)
                        <th width="150px"
                            style="border: 2px solid #000000; text-align: center; padding: 4px;"></th>
                    @endif
                    <th width="300px"
                        style="border: 2px solid #000000; text-align: center; padding: 4px;"></th>
                    @if($showCommission)
                        <th width="50px"
                            style="border: 2px solid #000000; text-align: center; padding: 4px;"></th>
                        <th width="200px"
                            style="border: 2px solid #000000; text-align: center; padding: 4px;"></th>
                    @endif
                </tr>
            @endfor
        @endif
    @endforeach

    <tfoot>
    <tr style="background-color: #dddddd;">
        <th width="20px" style="font-weight: bold; border: 2px solid #000000; padding: 8px; text-align: center;"></th>
        <th width="200px" style="font-weight: bold; border: 2px solid #000000; padding: 8px; text-align: center;">Total
            ({{$invoice->currency}})
        </th>
        @if($showAmount)
            <th width="100px"
                style="font-weight: bold; border: 2px solid #000000; padding: 8px; text-align: right;"></th>
        @endif
        @if($showHouseHold)
            <th width="150px" style="font-weight: bold; border: 2px solid #000000; padding: 8px; text-align: right;"></th>
        @endif
        @if($showCommission)
            <th width="300px"
                style="font-weight: bold; border: 2px solid #000000; padding: 8px; text-align: center;">{{$grandTotal}}</th>
            <th width="50px"
                style="font-weight: bold; border: 2px solid #000000; padding: 8px; text-align: center;"></th>
        @endif
        <th width="200px" style="font-weight: bold; border: 2px solid #000000; padding: 8px; text-align: center;">
            {{$showCommission?$totalComissions:$grandTotal}}</th>
    </tr>

    @for($i = 1; $i <= 10; $i++)
        <tr>

        </tr>
    @endfor

    <tr>
        <td width="200px"
            colspan="{{$colSpan}}">
            <img height="{{$footerHeight}}" src="{{ public_path('footer.PNG') }}" alt="" srcset="">
        </td>
    </tr>
    </tfoot>
</table>
</body>

</html>
