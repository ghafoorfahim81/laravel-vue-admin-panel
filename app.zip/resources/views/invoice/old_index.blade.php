@extends('layouts.master')
@section('title', __('lang.invoice_list'))
@section('css')
    <link rel="stylesheet" href="{{asset('assets/css/print.css')}}">

@endsection
@section('content')

    <div class="page-content-wrapper" id="app"  v-cloak>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">

                        <div style="display: flex;">
                            <div class="row m-4">
                                <div class="col-sm-12 col-md-2 form-inline">
                                    <div class="form-group">
                                        @if(hasPermission(['invoice_create']))
                                            <button onclick="location.href='{{route('invoice.create')}}'"
                                                    class="btn btn-info btn-sm waves-effect waves-light"
                                                    type="button">@lang('lang.add') @lang('lang.invoice')
                                                <i class="mdi mdi-plus-thick"></i></button>&nbsp
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <ul class="nav nav-tabs mt-2" role="tablist">

                                <li class="nav-item">
                                    <a class="nav-link active" style="font-size: 15px;" data-toggle="tab"
                                       href="#profile" role="tab">
                                        <i class="fas fa-exclamation-circle"></i>
                                        <span class="d-md-inline-block" @click="getRecord">UnPaid Invoices</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" style="font-size: 15px;" data-toggle="tab" href="#home"
                                       role="tab">
                                        <i class="fas fa-hands-helping"></i>
                                        <span class="d-md-inline-block"
                                              @click="getRecordPaid">Paid Invoices</span>
                                    </a>
                                </li>

                            </ul> 
                        </div>

                        <!-- Tab panes -->
                        <div class="tab-content p-3">

                            <!-- Tab 1 Content Start -->
                            <div class="tab-pane" id="home" role="tabpanel">

                                    <div  class="shadow-4 col-xl-3 rounded-sm p-3 border total__card mr-4">
                                        <div class="row justify-around">
                                            <div class="pl-8" v-show="!apiDataPaid.data" >
                                                <skeleton-loader-vue  type="rect" :height="20" :width="200" animation="fade"/>
                                            </div>
                                            <span v-show="apiDataPaid.data" class="font-weight-bold text-2xl col-7">Total: @{{total_paid.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</span>
                                        </div>
                                    </div>
                                    <div class="col text-right pr-4">
                                <button type="button" @click="exortToExcelSingle('paid_invoice')" class="btn btn-success btn-sm">
                                    <i class="fas fa-file-excel"></i>
                                    <span class="ml-1">Excel</span>
                                    </button>
                                    <button type="button" @click="exortToPDF('paid_invoice')" class="btn btn-danger btn-sm ml-1">
                                    <i class="fas fa-file-pdf"></i>
                                    <span class="ml-1">PDF</span>
                                    </button>
                                </div>
                                <input type="hidden" name="permission_id" id="permission_id">

                                <div style="padding-bottom: 0px">
                                    <div class="card-body client-nav">
                                        <div class=" ">
                                            <datatable ref="child" :per-page="{{perPage()}}"
                                                       :no-record-found-text="'@lang('lang.no_record_found')'"
                                                       :per-page-text="'@lang('lang.show')'"
                                                       :showing-text="'@lang('lang.showing')'"
                                                       :from-text="'@lang('lang.from')'" :to-text="'@lang('lang.to')'"
                                                       :record-text="'@lang('lang.record')'"
                                                       :app-per-page="{!! perPage(1) !!}" :columns="columns"
                                                       :data="apiDataPaid" @pagination-change-page="getRecordPaid"
                                                       :limit="1" :filterRecord="getRecordPaid" :multiple-select="true"
                                                       :selected-rows="selectedRows"
                                                       @delete-method-action="deleteRecordPaid">
                                                <template slot="tbody">
                                                    <tbody v-show="!apiDataPaid.data">
                                                    <tr v-for="skeleton in 4">


                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15" :width="50"
                                                                                 class="m-3" animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15" :width="50"
                                                                                 class="m-3" animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15" :width="50"
                                                                                 class="m-3" animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15" :width="50"
                                                                                 class="m-3" animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15" :width="50"
                                                                                 class="m-3" animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15" :width="50"
                                                                                 class="m-3" animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15" :width="50"
                                                                                 class="m-3" animation="fade"/>
                                                        </td>
                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15" :width="50"
                                                                                 class="m-3" animation="fade"/>
                                                        </td>

                                                    </tr>
                                                    </tbody>
                                                    <tbody v-show="apiDataPaid.data">
                                                    <tr v-for="(record,index) in apiDataPaid.data" :key="record.id">
                                                        <td>
                                                            <input type="checkbox" class="" v-model="selectedRows"
                                                                   :value="record.id" :id="`checked-${record.id}}`">

                                                        </td>
                                                        <td> @{{++index}}</td>
                                                        <td> @{{record.invoice_no}}</td>
                                                        <td> @{{record.company}}</td>
                                                        <td> @{{record.project}}</td>
                                                        <td> @{{record.amount}}</td>
                                                        <td> @{{record.currency}}</td>
                                                        <td class="">
                                                            <div class="p-1" role="group" style="width: 230px; text-align: center;">
                                                                @if(hasPermission(['invoice_view']))
                                                                    <a class="btn btn-info btn-sm"
                                                                       @click="printInvoice(record.id)"
                                                                       data-toggle="tooltip" data-placement="top"
                                                                       title="Print">
                                                                        <i class="mdi mdi-printer"></i>
                                                                    </a>&nbsp;
                                                                @endif
                                                                @if(hasPermission(['invoice_edit']))
                                                                    <a class="btn btn-primary btn-sm"
                                                                       :href="`{{url('invoice/edit')}}/${record.id}`"
                                                                       data-toggle="tooltip" data-placement="top"
                                                                       title="Edit">
                                                                        <i class="dripicons-document-edit"></i>
                                                                    </a>&nbsp;
                                                                @endif
                                                                @if(hasPermission(['invoice_view']))
                                                                    <a class="btn btn-info btn-sm"
                                                                       :href="`{{url('invoice')}}/${record.id}`"
                                                                       data-toggle="tooltip" data-placement="top"
                                                                       title="View">
                                                                        <i style="color: white" class="mdi mdi-eye"></i>
                                                                    </a>
                                                                @endif
                                                                @if(hasPermission(['invoice_delete']))
                                                                    <a class="btn btn-danger btn-sm"
                                                                       @click="deleteRecordPaid(record.id)"
                                                                       data-toggle="tooltip" data-placement="top"
                                                                       title="Delete">
                                                                        <i style="color: white"
                                                                           class="mdi mdi-delete"></i>
                                                                    </a>
                                                                @endif
                                                            </div>
                                                        </td>
                                                    </tr>

                                                    </tbody>

                                                </template>
                                            </datatable>
                                            {{-- <Pagination align="center" :limit="1" :data="records" @pagination-change-page="getRecords"></Pagination>--}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Tab 1 Content End -->


                            <!-- Tab 2 Content Start -->
                            <div class="tab-pane active" id="profile" role="tabpanel">
                                    <div  class="shadow-4 col-xl-3 rounded-sm p-3 border total__card mr-4">
                                        <div class="row justify-around">
                                            <div class="pl-8" v-show="!apiDataPaid.data">
                                                <skeleton-loader-vue  type="rect" :height="20" :width="200" animation="fade"/>
                                            </div>
                                            <span v-show="apiDataPaid.data" class="font-weight-bold text-2xl col-7">Total: @{{total_unpaid.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</span>
                                        </div>
                                    </div>
                                    <div class="col text-right pr-4">
                                <button type="button" @click="exortToExcelSingle('unpaid_invoice')" class="btn btn-success btn-sm">
                                    <i class="fas fa-file-excel"></i>
                                    <span class="ml-1">Excel</span>
                                    </button>
                                    <button type="button" @click="exortToPDF('unpaid_invoice')" class="btn btn-danger btn-sm ml-1">
                                    <i class="fas fa-file-pdf"></i>
                                    <span class="ml-1">PDF</span>
                                    </button>
                                </div>
                                <input type="hidden" name="permission_id" id="permission_id">
                                <div style="padding-bottom: 0px">
                                    <div class="card-body client-nav">
                                        <div class=" ">
                                            <datatable ref="child" :per-page="{{perPage()}}"
                                                       :no-record-found-text="'@lang('lang.no_record_found')'"
                                                       :per-page-text="'@lang('lang.show')'"
                                                       :showing-text="'@lang('lang.showing')'"
                                                       :from-text="'@lang('lang.from')'" :to-text="'@lang('lang.to')'"
                                                       :record-text="'@lang('lang.record')'"
                                                       :app-per-page="{!! perPage(1) !!}" :columns="columns"
                                                       :data="apiData" @pagination-change-page="getRecord" :limit="1"
                                                       :filterRecord="getRecord" :multiple-select="true"
                                                       :selected-rows="selectedRows"
                                                       @delete-method-action="deleteRecord">
                                                <template slot="tbody">
                                                    <tbody v-show="!apiData.data">
                                                    <tr v-for="skeleton in 4">


                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15" :width="50"
                                                                                 class="m-3" animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15" :width="50"
                                                                                 class="m-3" animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15" :width="50"
                                                                                 class="m-3" animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15" :width="50"
                                                                                 class="m-3" animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15" :width="50"
                                                                                 class="m-3" animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15" :width="50"
                                                                                 class="m-3" animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15" :width="50"
                                                                                 class="m-3" animation="fade"/>
                                                        </td>
                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15" :width="50"
                                                                                 class="m-3" animation="fade"/>
                                                        </td>

                                                    </tr>
                                                    </tbody>
                                                    <tbody v-show="apiData.data">
                                                    <tr v-for="(record,index) in apiData.data" :key="record.id">
                                                        <td>
                                                            <input type="checkbox" class="" v-model="selectedRows"
                                                                   :value="record.id" :id="`checked-${record.id}}`">

                                                        </td>
                                                        <td> @{{++index}}</td>
                                                        <td> @{{record.invoice_no}}</td>
                                                        <td> @{{record.company}}</td>
                                                        <td> @{{record.project}}</td>
                                                        <td> @{{record.amount}}</td>
                                                        <td> @{{record.currency}}</td>
                                                        <td class="">
                                                            <div class="p-1" role="group" style="width: 180px; text-align: center;">
                                                                @if(hasPermission(['invoice_view']))
                                                                    <a class="btn btn-info btn-sm"
                                                                       @click="printInvoice(record.id)"
                                                                       data-toggle="tooltip" data-placement="top"
                                                                       title="Print">
                                                                        <i class="mdi mdi-printer"></i>
                                                                    </a>&nbsp;
                                                                @endif
                                                                @if(hasPermission(['invoice_edit']))
                                                                    <a class="btn btn-primary btn-sm"
                                                                       :href="`{{url('invoice/edit')}}/${record.id}`"
                                                                       data-toggle="tooltip" data-placement="top"
                                                                       title="Edit">
                                                                        <i class="dripicons-document-edit"></i>
                                                                    </a>&nbsp;
                                                                @endif
                                                                @if(hasPermission(['invoice_view']))
                                                                    <a class="btn btn-info btn-sm"
                                                                       :href="`{{url('invoice')}}/${record.id}`"
                                                                       data-toggle="tooltip" data-placement="top"
                                                                       title="View">
                                                                        <i style="color: white" class="mdi mdi-eye"></i>
                                                                    </a>
                                                                @endif
                                                                @if(hasPermission(['invoice_delete']))
                                                                    <a class="btn btn-danger btn-sm"
                                                                       @click="deleteRecord(record.id)"
                                                                       data-toggle="tooltip" data-placement="top"
                                                                       title="Delete">
                                                                        <i style="color: white"
                                                                           class="mdi mdi-delete"></i>
                                                                    </a>
                                                                @endif
                                                            </div>
                                                        </td>
                                                    </tr>

                                                    </tbody>

                                                </template>
                                            </datatable>
                                            {{-- <Pagination align="center" :limit="1" :data="records" @pagination-change-page="getRecords"></Pagination>--}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Tab 2 Content End -->

                        </div>

                    </div>

                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- <div class="tbl-container" id="content_print_reports" style="visibility: hidden;"> -->
        <div id="content_print_report" style="visibility: hidden;">
        <!-- <div id="back"></div> -->
            <div id="title">
                <img src="{{asset('header.PNG')}}" class="img_header" alt="" srcset="">
            </div>
            <table class="tbl-container" id="table-container">

                <tr>
                    <th colspan="5" id="invoice">invoice</th>
                </tr>
                <tr>
                    <td  colspan="3" v-if="showFields('invoice_number')">Inoice No: @{{print_data.invoice_no}}</td>
                    <td colspan="3" v-else></td>
                    <td colspan="2" id="invoice-date" v-if="showFields('date')">Invoice Date: @{{print_data.date}}</td>
                    <td colspan="2" v-else></td>
                </tr>
                <br/>
                <tr>
                    <th colspan="3" id="organization" v-if="showFields('organization')">Organization: @{{print_data.organization}}</th>
                    <th colspan="3" v-else></th>
                    <td colspan="2"></td>
                </tr>
                <tr id="table-grant">
                    <td  colspan="3" v-if="showFields('vol_rep')">VolRep @{{print_data.vol_rep}}</td>
                    <td colspan="3" v-else></td>
                    <td colspan="2"></td>
                </tr>
                <tr id="table-grant">
                    <td  colspan="3" v-if="showFields('purpose')">Purpose @{{print_data.purpose}}</td>
                    <td colspan="3" v-else></td>
                    <td colspan="2"></td>
                </tr>

                <tr class="table-header"  v-if="print_data.parent_id">
                    <th rowspan="2">#</th>
                    <th rowspan="2" v-if="showTable('location')">Location</th>
                    <th rowspan="2" v-if="showTable('date')">Date</th>
                    <th rowspan="2">Amount in (USD)</th>
                    <th rowspan="2">Grand total</th>
                    <th colspan="2"  v-if="print_data.parent_id">Commision</th>
                </tr>
                <tr class="table-header" v-else>
                    <th>#</th>
                    <th v-if="showTable('location')">Location</th>
                    <th v-if="showTable('date')">Date</th>
                    <th>Amount in (USD)</th>
                    <th>Grand total</th>
                </tr>
                <tr class="table-header" v-if="print_data.parent_id">
                    <th>%</th>
                    <th>Total</th>
                </tr>
                <tr class="table-data" v-for="(invo, index) in invoice_details">
                    <td class="no" style="width: 5% !important;">@{{index+1}}</td>
                    <td v-if="showTable('location')">@{{invo?.location}}</td>
                    <td v-if="showTable('date')">@{{invo?.invoice_date}} </td>
                    <!-- <td>@{{invo?.start_date}} / @{{invo?.end_date }}</td> -->
                    <td>@{{invo?.amount?.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</td>
                    <td>@{{invo?.amount?.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</td>
                    <td v-if="print_data.parent_id"> @{{invo?.service_fee_percent}}%</td>
                    <td v-if="print_data.parent_id"> @{{invo?.service_fee_amount}}</td>
                </tr>
                <tr class="table-data">
                    <td colspan="3">Total</td>
                    <td></td>
                    <td>@{{total.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</td>
                    <td colspan="2" v-if="print_data.parent_id">@{{total_commision.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</td>
                </tr>
                <tr id="table-description">
                    <td colspan="5">
                        <div  v-html="print_data.details"></div>
                    </td>
                </tr>
                <!-- <tr class="thanks">
                        <td colspan="4">Thanks and Regards</td>
                    </tr>
                    <tr class="thanks" id="auth">
                        <td colspan="4">Authorized signature</td>
                    </tr>
                     -->
            </table>
            <div id="table-footer">
            <img src="{{asset('footer.PNG')}}" class="img_header" alt="" srcset="">
            <!-- <span>
                Address: Sara I Shazada, Ground Floor,
                Shop# 42, Kabul-Afghanistan- , Phone# (0) 202100960 / Mobile# 0093(0) 777 55 31 55 &nabla;&nabla;&nabla;&nabla; &nbsp;ادرس: سرای شهزاده منزل اول دوکان نمبر 42، کابل- افغانستان

            </span> -->
            </div>
        </div>
    </div>
    <!-- end page-content-wrapper -->

@endsection
@section('js')
    <script src="{{asset('assets/js/print.js')}}"></script>
    <script>
        //Vue.component('pagination', require('laravel-vue-pagination'));
        var vm = new Vue({
            el: '#app',
            components: {
                'skeleton-loader-vue': window.VueSkeletonLoader,
            },
            data() {
                return {
                    url: "{{route('invoice.index')}}?",
                    columns: [{
                        label: "#",
                        name: '#',
                        sort: false,
                    },
                        {
                            label: "@lang('lang.number')",
                            name: 'invoices.invoice_no',
                            sort: true,
                            activeSort: true,
                            order_direction: 'desc',
                        },
                        {
                            label: "@lang('lang.organization')",
                            name: 'companies.name',
                            sort: true,
                            activeSort: true,
                            order_direction: 'desc',
                        },
                        {
                            label: "@lang('lang.project')",
                            name: 'projects.name',
                            sort: true,
                            activeSort: true,
                            order_direction: 'desc',
                        },
                        {
                            label: "@lang('lang.amount')",
                            name: 'invoices.amount',
                            sort: true,
                            activeSort: true,
                            order_direction: 'desc',
                        },
                        {
                            label: "@lang('lang.currency')",
                            name: 'invoices.currency',
                            sort: true,
                            activeSort: true,
                            order_direction: 'desc',
                        },
                        {
                            label: "@lang('lang.actions')",
                            name: 'action',
                            sort: false
                        }
                    ],

                    apiData: {},
                    apiDataPaid: {},
                    appPerPage: '{!! perPage(1) !!}',
                    perPage: "{{perPage()}}",
                    page: 1,
                    selectedRows: [],
                    invoice_details: [],
                    print_data: {},
                    total: 0,
                    total_commision: 0,
                    total_unpaid: 0,
                    total_paid: 0,
                    control_room: {
                        fields: null,
                        table: null
                    }
                }

            },
            mounted() {
                this.getRecordPaid();
                this.setControlRoom();
            },
            methods: {

                /**
                 * get record from api
                 */
                showFilterModal() {
                    $('#filterModal').modal('show');
                    this.getProvinces();
                },
                showFields(name) {
                    if (
                        this.control_room.fields?.find((e) => e.name == name && e.value == true)
                    )
                        return true;
                    else return false;
                },
                showTable(name) {
                    if (
                        this.control_room.table?.find((e) => e.name == name && e.value == true)
                    )
                        return true;
                    else return false;
                },
                exortToExcelSingle(type,id=null){
                    new Promise((resolve, reject)=>{
                        let data =[];
                        const formData = new FormData();
                        if(type =='unpaid_invoice'){
                            data = vm.apiData.data;
                        } else {
                            data = vm.apiDataPaid.data;
                        }
                         formData.append("data", JSON.stringify(data));
                            axios({
                                method: "post",
                                url: "excel?type=" + type,
                                responseType: "blob",
                                data: formData
                            }).then(response=>{
                                console.log('for test:',response.data);
                                resolve('response');

                                let Fformat= ".xlsx";
                                var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                                var fileLink = document.createElement("a");
                                fileLink.href = fileURL;
                                fileLink.setAttribute("download", type+".xlsx");
                                document.body.appendChild(fileLink);
                                fileLink.click();
                             })
                             .catch((error) => {
                                reject(error);
                                console.log(error);
                            });
                    }).then(()=>resolve('data')).catch(e=>reject(e));
                },
                exortToPDF(type,id=null){
                    new Promise((resolve, reject)=>{
                        let data =[];
                        const formData = new FormData();
                        if(type =='unpaid_invoice'){
                            data = vm.apiData.data;
                        } else {
                            data = vm.apiDataPaid.data;
                        }
                         formData.append("data", JSON.stringify(data));
                            axios({
                                method: "post",
                                url: "pdf?type=" + type,
                                responseType: "blob",
                                data: formData
                            }).then(response=>{
                                console.log('for test:',response.data);
                                resolve('response');

                                let Fformat= ".xlsx";
                                var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                                var fileLink = document.createElement("a");
                                fileLink.href = fileURL;
                                fileLink.setAttribute("download", type+".pdf");
                                document.body.appendChild(fileLink);
                                fileLink.click();
                             })
                             .catch((error) => {
                                reject(error);
                                console.log(error);
                            });
                    });
                },
                setControlRoom() {
                    if (!localStorage.getItem("setting")) {
                        axios.get('/user/setting').then(res => {
                            console.log(res.data);
                            let setting = res.data.find(
                                (e) => e.name == 'Invoice'
                            ).data;
                            // checkData(setting, this)
                            this.control_room.fields = setting?. [0]?.values;
                            this.control_room.table = setting?. [1]?.values
                            localStorage.setItem('setting', JSON.stringify(res.data));


                        })
                    } else {
                        let setting = JSON.parse(localStorage.getItem("setting")).find(
                            (e) => e.name == 'Invoice'
                        ).data;
                        // checkData(setting, this);
                        this.control_room.fields = setting?. [0]?.values;
                        this.control_room.table = setting?. [1]?.values
                    }
                },
                getRecord: _.debounce((page = vm.page) => {

                    let type = 'unpaid';
                    axios.get(vm.url +
                        '&current_page=' +
                        page + '&per_page=' + vm.perPage + '&invoice_type=' + type)
                        .then((response) => {
                            if (response.data) {
                                vm.page = response.data.current_page;
                            }
                            vm.apiData = response.data;
                            vm.total_unpaid = 0;
                            for(let x=0; x<response.data.data.length; x++){
                                vm.total_unpaid += Number.parseFloat(response.data.data[x].amount);
                            }
                        })
                        .catch((error) => {
                            console.log(error);
                        });
                }, 200),
                getRecordPaid: _.debounce((page = vm.page) => {
                    let type = 'paid';
                    axios.get(vm.url +
                        '&current_page=' +
                        page + '&per_page=' + vm.perPage + '&invoice_type=' + type)
                        .then((response) => {

                            if (response.data) {
                                vm.page = response.data.current_page;
                            }
                            vm.apiDataPaid = response.data;
                            vm.total_paid = 0;
                            for(let x=0; x<response.data.data.length; x++){
                                vm.total_paid += Number.parseFloat(response.data.data[x].amount);

                            }

                        })
                        .catch((error) => {
                            console.log(error);
                        });


                }, 200),

                // delete record
                deleteRecord(id = null) {
                    if (id && id != null) {
                        deleteItem(`invoice/${id}`);
                        this.selectedRows = [];
                    } else {
                        deleteItem(`invoice/multiple`, this.selectedRows);
                        this.selectedRows = [];
                    }
                },
                deleteRecordPaid(id = null) {
                    if (id && id != null) {
                        deleteItem(`invoice/${id}`);
                        this.selectedRows = [];
                    } else {
                        deleteItem(`invoice/multiple`, this.selectedRows);
                        this.selectedRows = [];
                    }
                },
                async printInvoice(id = null) {

                    await axios.get("{{route('invoice.print','')}}/" + id)
                        .then(data => {
                            console.log(data);
                            this.invoice_details = data.data;
                            this.print_data = this.invoice_details[0]
                            let total = 0;
                            let total_commision = 0;
                            this.invoice_details.forEach(e => total += e.amount);
                            this.invoice_details.forEach(e => total_commision += e.service_fee_amount);
                            this.total = total;
                            this.total_commision = total_commision;
                            // console.log(this.invoice_details.reduce((pre,curr)=>pre.amount+curr.amount));
                            // this.total = this.invoice_details.reduce((pre,curr)=>pre.amount+curr.amount);
                            console.log(total);

                        }).then(() => {
                            printJS({
                                printable: 'content_print_report',
                                type: 'html',
                                style: `
                            @media print {
                                @page {
                                margin: 20px;
                                size: auto;
                                }
                                #content_print_report:before{
                                    content: ' ';
                                    display: block;
                                    position: absolute;
                                    left: 0;
                                    top: 0;
                                    width: 100%;
                                    height: 100%;
                                    opacity: 0.2;
                                    background-image: url("{{asset('mark.jpg')}}");
                                    background-repeat: no-repeat;
                                    // background-position: 50% 0;
                                    // background-size: cover;
                                    // background-image: url("{{asset('mark.jpg')}}") !important;
                                    // height:98% !important;
                                    background-size: 500px 500px;
                                    background-position: center;
                                    // background-repeat: no-repeat;
                                    // position: absolute;
                                    // z-index: -1;
                                    justify-content: center;
                                    align-content: center;
                                    // opacity: 0.2;
                                }
                                table#table-container {
                                    border-radius: 5px;
                                    width: 100% !important;
                                    margin: 0 auto;
                                    height: 100% !important;
                                    font-family: sans-serif;
                                    border-collapse:collapse;
                                    border: 1px solid black;
                                    border:none;
                                }
                                table tr th {
                                    border-collapse:collapse;
                                }
                                // #title th{
                                //     border: 1px solid black;
                                //     // height:5px !important;
                                //     font-size: large !important;
                                //     background-color: lightgray;
                                // }
                                #invoice{
                                    height: 70px !important;
                                    text-align: center;
                                    padding-top:20px;
                                }
                                #organization{
                                    text-align: left;
                                }
                                #invoice-date{
                                    height: 70px !important;
                                    text-align: right;
                                }
                                #main-table {
                                    border: 1px solid black;
                                    // bordNer-collapse:collapse;
                                }
                                #table-grant{
                                    padding-bottom:10px !important;
                                }
                                .table-header th{
                                    border: 1px solid black;
                                    background-color: lightgray;
                                }
                                .table-data td{
                                    border: 1px solid black;
                                    text-align: center;
                                }
                                .no {
                                    width:10% !important;
                                }
                                #table-terms th {
                                    text-align: left;
                                    padding-top: 40px !important;
                                }
                                #table-description td {
                                    text-align: left;
                                    padding-top: 50px !important;
                                    padding-bottom: 100px !important;

                                }
                                #auth td{
                                    // padding-bottom: 35% !important;
                                }
                                #table-footer  {
                                    // border-top:1px solid black;
                                    position: fixed;
                                    bottom: 0;
                                    right: 0;
                                    padding-top:10px;
                                }
                                .img_header{
                                    width:90%;
                                    // position:static;
                                    height:100% !important;
                                }
                                #title{
                                    position: fixed;
                                    top: 0;
                                    left: 0;
                                    height:12% !important;
                                    // padding-bottom:30px;
                                }

                            }`
                            });
                        })
                },
            }
        });
    </script>
    <style>
        .total__card {
            position: absolute;
            top:15px;
            right: 15px;
        }


        @media screen and (max-width: 992px) {
            .total__card {
                    position: absolute;
                    top:5px;
                    right: 0;
                }
            }

            /* On screens that are 600px wide or less, make the columns stack on top of each other instead of next to each other */
            @media screen and (max-width: 600px) {
                .total__card {
                    position: relative;
                    top:-30px;
                    right: 0;
                }
            }
    </style>
@endsection
