@extends('layouts.master')
@section('title', __('lang.add').' '.__('lang.invoice'))
@section('css')
    <link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css"/>
    <link href="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}" rel="stylesheet" type="text/css"/>
    <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css"/> 
 
    <style>
        .right-drawer {
            position: absolute;
            top: 0;
            right: 0;
            width: 0;
            /* initially */
            overflow: hidden;
            height: 100vh;
            padding-left: 0;
            /* initially */
            border-left: 1px solid whitesmoke;
            background: white;
            z-index: 200;
            transition: all 0.2s;
            /* for the animation */
        }

        .drawer-mask {
            position: absolute;
            left: 0;
            top: 0;
            width: 0;
            /* initially */
            height: 100vh;
            background: #000;
            opacity: 0.3;
            z-index: 199;
        }
    </style>

@endsection
@section('content')
    <div class="page-content-wrapper" id="myapp" v-cloak>
        <div class="container-fluid">


            <div
                class="right-drawer"
                style="z-index: 1032;"
                :style="{
                    width: drawerVisible ? '20vw' : '0',
                    paddingLeft: drawerVisible ? '10px' : '0' }">


                <div class="modal-header">

                    <button type="button" class="btn btn-info w-100 d-flex justify-content-between">
    <span><i class="fas fa-cog me-2 text-white"></i>
        General Settings</span>
                        <i class="fas fa-times me-2 text-white align-self-center" @click="drawerVisible = false"></i>
                    </button>
                    <!-- <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close" ></button> -->

                </div>
                <div class="modal-body" style="max-height: 90vh; overflow-y:auto">
                    <!-- <div class=" px-4 " v-for="(c,i) in control_room.fields">
                        <h6 class="fw-bold">@{{c.name}}</h6>
                        <div class="form-check form-switch ml-3">
                            <input class="form-check-input" @change="saveSetting" v-model="c.value" type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                        </div>
                    </div> -->

                    <p class="text-left card-header bg-transparent">General</p>

                    <div v-for="(c,i) in control_room.fields">
                        <div class=" px-4 py-2 mb-2"
                             style="border-radius: 5px; box-shadow: rgba(17, 17, 26, 0.05) 0px 4px 16px, rgba(17, 17, 26, 0.05) 0px 8px 32px;">
                            <div class="form-check form-switch ml-3 row">
                                <input class="form-check-input" @change="saveSetting" v-model="c.value" type="checkbox"
                                       role="switch" id="flexSwitchCheckDefault"/>
                                <h6 class="fw-bold ml-2">@{{c.name}}</h6>
                            </div>
                        </div>
                    </div>


                    <p class="text-left card-header bg-transparent">Table</p>
                    <!-- <div class=" px-4 " v-for="(c,i) in control_room.table">
                        <h6 class="fw-bold">@{{c.name}}</h6>
                        <div class="form-check form-switch ml-3">
                            <input class="form-check-input" @change="saveSetting" v-model="c.value" type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                        </div>
                    </div> -->

                    <div v-for="(c,i) in control_room.table" class="w-100">
                        <div class=" px-4 py-2 mb-2"
                             style="border-radius: 5px; box-shadow: rgba(17, 17, 26, 0.05) 0px 4px 16px, rgba(17, 17, 26, 0.05) 0px 8px 32px;">
                            <div class="form-check form-switch ml-3 row">
                                <input class="form-check-input" @change="saveSetting" v-model="c.value" type="checkbox"
                                       role="switch" id="flexSwitchCheckDefault"/>
                                <h6 class="fw-bold ml-2">@{{c.name}}</h6>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
            <!-- We will make the mask fill the screen while the menu is visible. Because its z-index is 1 less than that of the menu, the menu will still be displayed on top of it -->
            <div class="drawer-mask" style="z-index: 1031;" :style="{
            width: drawerVisible ? '100vw' : '0',
            opacity: drawerVisible ? '0.6' : '0',
        }" @click="drawerVisible = false"></div>
        </div>
        <!-- Tabs navs -->
        <div class="row justify-between  px-4">
            <ul class="nav nav-tabs mb-3 shadow-xl w-auto col-md-6 col-xl-6" id="ex1" role="tablist">
                <li class="nav-item" role="presentation">
                    <a
                        class="nav-link active"
                        id="ex1-tab-1"
                        data-mdb-toggle="tab"
                        href="#ex1-tabs-1"
                        role="tab"
                        aria-controls="ex1-tabs-1"
                        aria-selected="true"
                    >Home</a
                    >
                </li>
                <li class="nav-item" role="presentation">
                    <a
                        class="nav-link"
                        id="ex1-tab-2"
                        data-mdb-toggle="tab"
                        href="#ex1-tabs-2"
                        role="tab"
                        aria-controls="ex1-tabs-2"
                        aria-selected="false"
                    >Attachments</a
                    >
                </li>

            </ul>
            <div class="col-md-6 col-xl-6" style="text-align: -webkit-right; align-self: center;">

                <button @click="drawerVisible = true" type="button" class="btn btn-info" style="border-radius: 100px;">
                    <i class="fas fa-cog"></i>
                </button>
            </div>

        </div>
        <!-- Tabs navs -->

        <!-- Tabs content -->
        <form action="{{route('invoice.store')}}" method="post" id="userForm" enctype="multipart/form-data">
            <div class="tab-content" id="ex1-content">
                <div
                    class="tab-pane fade show active"
                    id="ex1-tabs-1"
                    role="tabpanel"
                    aria-labelledby="ex1-tab-1"
                >
                    @csrf
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="card">

                                <div class="card-body" style="padding-bottom: 0px">
                                    <div class="">
                                        <!-- <h4 class="header-title">@lang('lang.add') @lang('lang.order')</h4> -->
                                        <div class="row justify-content-center">
                                            <div class="col-xl-9 col-md-9 row">
                                                <div class="col-xl-4" v-show="showFields('invoice_number')">
                                                    <div class="form-group">
                                                        <label for="">@lang('lang.invoice_number')
                                                        </label>
                                                        <input type="number" name="invoice_number" class="form-control"
                                                               autocomplete="new-password"
                                                               data-vv-as="@lang('lang.password')"
                                                               placeholder="@lang('lang.invoice_number')">
                                                        <span class="help-block rq-hint">
                                                            @{{errors.first('invoice_number')}}
                                                        </span>
                                                        <input type="hidden" name="is_cashe" :value="type">
                                                        <input type="hidden" name="cash_id" :value="cash_id">
                                                    </div>
                                                </div>
                                                <div class="col-xl-4" v-show="showFields('organization')">
                                                    <div class="form-group">
                                                        <label for="">@lang('lang.organization')
                                                        </label>
                                                        <input type="text" value="{{$company->name}}" class="form-control"
                                                               autocomplete="new-password"
                                                               disabled
                                                               placeholder="@lang('lang.invoice_number')">
                                                        <input type="hidden" name="company"
                                                               value="{{$company->id}}">
                                                    </div>
                                                </div>
                                                <div class="col-xl-4" v-show="showFields('date')">
                                                    <div class="form-group">
                                                        <label for="">@lang('lang.date')
                                                        </label>
                                                        <input type="date" name="date" value="<?php echo date('Y-m-d'); ?>" class="form-control" id="email"
                                                               data-vv-as="@lang('lang.date')"
                                                               placeholder="@lang('lang.date')"
                                                               autocomplete="new-email">
                                                        <span class="help-block rq-hint">
                                                            @{{errors.first('date')}}
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-xl-4" v-show="showFields('project')">
                                                    <div class="form-group">
                                                        <label for="">@lang('lang.project')
                                                        </label>
                                                        <v-select :select-on-tab="true"
                                                                  v-model="selected_project"
                                                                  label="name"
                                                                  :options="projects"
                                                                  @input="setProvince()"
                                                                  placeholder="@lang('lang.selectProject')"
                                                        >
                                                            <template v-slot:no-options="{ search, searching }">
                                                                <template v-if="searching">
                                                                    @lang('lang.no_record_found_for') @{{search}}
                                                                </template>
                                                                <em class="v-select-search-hint"
                                                                    v-else>@lang('lang.type_to_search')</em>
                                                            </template>
                                                        </v-select>
                                                        <input type="hidden" name="project"
                                                               :value="(selected_project == null) ? null : selected_project.id">
                                                        <input type="hidden" name="location_id"
                                                               :value="(selected_project == null) ? null : selected_project.location_id">

                                                    </div>
                                                </div>
                                                <div class="col-xl-2" v-show="showFields('currency')">
                                                    <div class="form-group">
                                                        <label for="">@lang('lang.currency')
                                                        </label>
                                                        <v-select :select-on-tab="true"
                                                                  v-model="selected_currency"
                                                                  label="code"
                                                                  :options="currencies"
                                                                  placeholder="@lang('lang.select_currency')"
                                                        >
                                                            <template v-slot:no-options="{ search, searching }">
                                                                <template v-if="searching">
                                                                    @lang('lang.no_record_found_for') @{{search}}
                                                                </template>
                                                                <em class="v-select-search-hint"
                                                                    v-else>@lang('lang.type_to_search')</em>
                                                            </template>
                                                        </v-select>
                                                        <input type="hidden" name="currency"
                                                               :value="(selected_currency == null) ? null : selected_currency.code">
                                                    </div>
                                                </div>
                                                <div class="col-xl-2" v-show="showFields('exchange_rate')">
                                                    <div class="form-group">
                                                        <label for="">@lang('lang.rate')
                                                        </label>
                                                        <input type="number" name="exchange_rate" class="form-control"
                                                               v-model="!selected_currency ? 1 : selected_currency.rate"
                                                               placeholder="@lang('lang.rate')" @input="rateChanged">
                                                        <span class="help-block rq-hint">
                                        @{{errors.first('exchange_rate')}}</span>
                                                    </div>
                                                </div>
                                                <div class="col-xl-4" v-show="showFields('vol_rep')">
                                                    <div class="form-group">
                                                        <label for="">@lang('lang.vol_rep')
                                                        </label>
                                                        <input type="text" name="vol_rep" class="form-control"
                                                               autocomplete="new-password"
                                                               data-vv-as="@lang('lang.password')"
                                                               placeholder="@lang('lang.vol_rep')">
                                                        <span class="help-block rq-hint">
                                        @{{errors.first('vol_rep')}}</span>
                                                    </div>
                                                </div>
                                                 
                                            </div>
                                            <!-- end of permission -->

                                            <div class="col-xl-3 col-md-3" v-show="showFields('sub_total')">
                                                <div class="w-full shadow-4 rounded-sm p-3 border">
                                                    <div class="row justify-around">
                                                        <span class="text-xl col-7">Sub Total</span>
                                                        <span class="text-xl col text-end">@{{sub_total.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}} @{{ (selected_currency != null) ? selected_currency.symbol : null }}</span>
                                                    </div>
                                                    <div class="row justify-around">
                                                        <span class="text-xl col-7">Service Total</span>
                                                        <span class="text-xl col text-end">@{{total_service.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}} @{{ (selected_currency != null) ? selected_currency.symbol : null }}</span>
                                                    </div>
                                                    <br/>
                                                    <hr class="p-0 m-0"/>

                                                    <div class="row justify-around">
                                                        <span class="font-weight-bold text-xl col-7">Grand Total</span>
                                                        <span class="font-weight-bold text-xl col text-end">@{{total_grant.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}} @{{ (selected_currency != null) ? selected_currency.symbol : null }}</span>
                                                    </div>
                                                    <hr class="p-0 m-0"/>

                                                </div>
                                                <br/>
                                                <div class="col-xl-12" v-show="showFields('description')">
                                                    <div class="form-group"> 

                                                        <label for="">@lang('lang.commision')
                                                        </label>
                                                        <input type="checkbox" v-model="is_comission" @click="changeValue"  id="check-commision">
                                                    </div>
                                                </div>
                                                <div class="col-xl-12" v-show="showFields('description')">
                                                    <div class="form-group" v-show="is_comission">
                                                        <label for="">@lang('lang.invoice')
                                                        </label>
                                                        <v-select :select-on-tab="true"
                                                                  v-model="selected_invoice"
                                                                  label="invoice"
                                                                  :options="invoices"
                                                                  placeholder="@lang('lang.invoice')"
                                                        >
                                                            <template v-slot:no-options="{ search, searching }">
                                                                <template v-if="searching">
                                                                    @lang('lang.no_record_found_for') @{{search}}
                                                                </template>
                                                                <em class="v-select-search-hint"
                                                                    v-else>@lang('lang.type_to_search')</em>
                                                            </template>
                                                        </v-select>
                                                    </div>
                                                </div>
                                                <input type="hidden" name="parent_id"
                                                       :value="(selected_invoice == null) ? null : selected_invoice.id">
                                            </div>
                                        </div>
                                        <div class="row justify-content-center">
                                            <div class="col-xl-6" v-show="showFields('description')">
                                                <div class="form-group">
                                                    <label for="">@lang('lang.description')
                                                    </label>

                                                    <textarea id="elm1" name="desc">{{$invoice_desc}}
                                                    </textarea>
                                                    <span class="help-block rq-hint">
                                                        @{{errors.first('desc')}}
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="col-xl-6" v-show="showFields('purpose')">
                                                <div class="form-group">
                                                    <label for="">@lang('lang.purpose')
                                                    </label>

                                                    <textarea class="form-control" name="purpose" rows="4">{{$invoice_propuse}}
                                                    </textarea>
                                                    <span class="help-block rq-hint">
                                                        @{{errors.first('purpose')}}
                                                    </span>
                                                </div>
                                            </div> 
                                        </div>
                                        <div class="table-responsive shadow-4 rounded-sm">
                                            <table class="table mb-0 ">
                                                <thead class="bg-light-blue-7 text-white">
                                                <tr>
                                                    <th v-show="showTable('no')" class="text-center p-2">#</th>
                                                    <th v-show="showTable('location')" style="width:200px"
                                                        class="p-2">@lang('lang.location')</th>
                                                    <th v-show="showTable('date')" class="p-2">@lang('lang.date')</th>
                                                    <th v-show="showTable('houseHold')" class="p-2">@lang('lang.house')</th>
                                                    <th v-show="showTable('amount')"
                                                        class="p-2">@lang('lang.amount')</th>
                                                    <th v-show="show_subtotal"
                                                        class="p-2">@lang('lang.total')</th>
                                                    <th v-show="showTable('service_fee_percent')"
                                                        class="p-2">@lang('lang.service_fee_percent')</th>
                                                    <th v-show="showTable('service_fee_amount-not')"
                                                        class="p-2">@lang('lang.service_fee_amount') @{{
                                                        (selected_currency != null) ? selected_currency.symbol : null }}
                                                    </th>
                                                    <th v-show="showTable('total')" class="text-center p-2">Total</th>
                                                    <th v-show="showTable('action')" class="text-center p-2">Action</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr v-for="(item, index) in items">
                                                    <th v-show="showTable('no')"
                                                        class="p-0 text-center border-right align-middle" scope="row">
                                                        @{{++index}}
                                                    </th>
                                                    <td v-show="showTable('location')"
                                                        class="p-0 vue_dropdown border-right align-middle">
                                                        <v-select :select-on-tab="true"
                                                                  v-model="item.item.selected_province"
                                                                  @input="addRow(index)"
                                                                  label="name"

                                                                  class="border border-white w-full"
                                                                  :options="provinces"
                                                                  placeholder="@lang('lang.searchLoaction')"
                                                        >
                                                            <template v-slot:no-options="{ search, searching }">
                                                                <template v-if="searching">
                                                                    @lang('lang.no_record_found_for') @{{search}}
                                                                </template>
                                                                <em class="v-select-search-hint"
                                                                    v-else>@lang('lang.type_to_search')</em>
                                                            </template>
                                                        </v-select>
                                                        <input type="hidden" name="location[]"
                                                               :value="(item.item.selected_province == null) ? null : item.item.selected_province.id">
                                                    </td>
                                                    <td v-show="showTable('date')"
                                                        class="p-0 border-right align-middle">
                                                        <input type="text" placeholder="@lang('lang.date')"
                                                               class="form-control border border-white"
                                                               name="date_d[]"
                                                               v-model="item.item.date">
                                                    </td>
                                                    <td v-show="showTable('houseHold')"
                                                        class="p-0 border-right align-middle">
                                                        <input type="number" placeholder="@lang('lang.house')"
                                                               class="form-control border border-white"
                                                               name="household[]"
                                                               @input="setHousehold(index, item.item.household)"
                                                               v-model="item.item.household">
                                                    </td>
                                                    <td v-show="showTable('amount')"
                                                        class="p-0 border-right align-middle">
                                                        <input type="number" placeholder="amount"
                                                               class="form-control border border-white" name="amount[]"
                                                               v-model="item.item.amount"
                                                               @input="setAmount(index, item.item.amount)">
                                                    </td>
                                                    <td v-show="show_subtotal"
                                                        class="p-0 border-right align-middle">
                                                        @{{item.item.amount * item.item.household}}
                                                    </td>
                                                    <td v-show="showTable('service_fee_percent')"
                                                        class="p-0 border-right align-middle">
                                                        <input type="number" class="form-control border border-white"
                                                               name="service_fee_percent[]"
                                                               @input="setServiceFee(index, item.item.percent)"
                                                               v-model="item.item.percent">
                                                    </td>
                                                    <td v-show="showTable('service_fee_amount-not')"
                                                        class="p-0 border-right align-middle">

                                                        <input type="number" class="form-control border border-white"
                                                               @input="setservice(index, item.item.service_amount)"
                                                               v-model="item.item.service_amount"
                                                               name="service_amount[]">
                                                    </td> 
                                                    <td v-show="showTable('total')"
                                                        class="p-0 text-center align-middle">

                                                        <input type="number" class="form-control border border-white"
                                                               v-model="item.item.row_total" name="total[]">
                                                    </td>
                                                    <td v-show="showTable('action')"
                                                        class="p-0 text-center align-middle"><i class="far fa-trash-alt"
                                                                                                style="color:red"
                                                                                                v-on:click="deleteItem(index)"></i>
                                                    </td>
                                                </tr>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>


                                </div>

                            </div>

                        </div>
                        <!-- end row -->
                    </div>
                </div>
                <div class="tab-pane fade" id="ex1-tabs-2" role="tabpanel" aria-labelledby="ex1-tab-2">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="card">

                                <div class="card-body" style="padding-bottom: 0px">
                                    <div class="">
                                        <!-- <h4 class="header-title">@lang('lang.add') @lang('lang.order')</h4> -->

                                        <div class="table-responsive shadow-4 rounded-sm">
                                            <table class="table mb-0 ">
                                                <thead class="bg-light-blue-7 text-white">
                                                <tr>
                                                    <th class="text-center p-2">#</th>

                                                    <th class="p-2">Title</th>
                                                    <th class="text-center p-2">Attachment</th>
                                                    <th class="text-center p-2">Action</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr v-for="(item, index) in attachments">
                                                    <th class="p-0 text-center border-right align-middle" scope="row">
                                                        @{{++index}}
                                                    </th>


                                                    <td class="p-0 border-right align-middle">
                                                        <input @click="addAttachment(index)" type="text"
                                                               placeholder="Title"
                                                               class="form-control border border-white" name="title[]">
                                                    </td>
                                                    <td class="p-0 border-right align-middle">
                                                        <input type="file" class="form-control-sm" name="attach_file[]"
                                                               id="customFile"/>
                                                    </td>

                                                    <td v-show="showTable('action')"
                                                        class="p-0 text-center align-middle"><i class="far fa-trash-alt"
                                                                                                style="color:red"
                                                                                                v-on:click="deleteAttachment(index)"></i>
                                                    </td>
                                                </tr>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                </div>
                <!-- Tabs content -->

                <div class="card-footer text-right">
                    <button class="btn btn-info" type="submit" @click="sendForm">
                        <span class="ml-2">Save Invoice</span>
                    </button>
                </div>
        </form>
    </div>
    <!-- end page-content-wrapper -->

@endsection
@section('js')
    <!--tinymce js-->
        <script src="{{ asset('assets/libs/tinymce/tinymce.min.js') }}"></script>

        <!--ck editor js-->
        <script src="{{ asset('assets/libs/ckeditor4/ckeditor.js') }}"></script>

        <!-- init js -->
        <script src="{{ asset('assets/js/pages/form-editor.init.js') }}"></script>
    <script>

        var vm = new Vue({
            el: '#myapp',
            data: {
                show_subtotal: false,
                invoices: {!! $invoices !!},
                selected_invoice: null,
                is_comission: false,
                drawerVisible: false,
                spinner: 'spinner-border',
                disabled: true,
                projects: {!!$projects!!},
                currencies: {!!$currencies!!},
                provinces: {!!$provinces!!},
                selected_province: null,
                selected_project: null,
                selected_company: null,
                selected_currency: null,
                attachments: [
                    {item: {title: null}},
                    {item: {title: null}},
                    {item: {title: null}},
                ],
                items: [
                    {
                        item: {
                            selected_item: null,
                            selected_province: null,
                            amount: null,
                            percent: null,
                            household: null,
                            date: null,
                            service_amount: null,
                            row_total: 0
                        }
                    },
                    {
                        item: {
                            selected_item: null,
                            selected_province: null,
                            amount: null,
                            percent: null,
                            household: null,
                            date: null,
                            service_amount: null,
                            row_total: 0
                        }
                    },
                    {
                        item: {
                            selected_item: null,
                            selected_province: null,
                            amount: null,
                            percent: null,
                            household: null,
                            date: null,
                            service_amount: null,
                            row_total: 0
                        }
                    },
                ],
                itemData: [],
                form: {},
                control_room: {
                    fields: null,
                    table: null
                },
                type: 'no-cashe',
                cash_id: "",
            },
            mounted: function () { 
                // this.getItems();
                let currency = {!! $home_currency !!}; 
                this.selected_currency = this.currencies.find(cur => cur.code == currency.code);
                console.log("this.selected_currency", this.selected_currency);
                if (this.selected_currency) {

                    this.selected_currency.rate = currency?.exchange_rate;
                }

                if("{!! $is_cash_drop !!}" == 'yes'){

                    this.selected_project = null;
                    this.items[0].item.selected_province = this.provinces.find(e=>e.id=="{!! $location_id !!}");
                    this.items[0].item.household = 0;
                    this.items[0].item.amount    = {!! $cash_drop_amount?$cash_drop_amount:0 !!};
                    this.items[0].item.row_total = {!! $cash_drop_amount?$cash_drop_amount:0 !!};
                    this.type = 'cache';
                    this.cash_id = "{!! $cashe_id !!}";

                } else {

                    // console.log('currency', currency);
                     this.selected_project = this.projects.find(e=>e.id=="{!!$selected_project!!}") || null; 
                    // this.selected_project = (this.projects.length > 0) ? this.projects[0] : null;
                     
                    this.items[0].item.selected_province = this.provinces.find(e=>e.id==this.selected_project?.location_id);
                    this.items[0].item.household = '{!!$paid_binificiaries!!}';
                    this.items[0].item.amount =  (this.selected_project.budget/ this.selected_project.total_beneficiary).toFixed(2);

                    this.items[0].item.row_total = (this.items[0].item.amount * this.items[0].item.household).toFixed(2) || 0;
                }

                
                // console.log("paid_binificiaries",'{!!$paid_binificiaries!!}');
                this.setControlRoom();
                // this.getHomeCurrency(); 
                // this.selectedCompany();
            },
            computed: {
                total_grant() {
                    
                    let total = 0;
                    for (let x = 0; x < this.items.length; x++) {

                        if(this.is_comission){

                            total += Number.parseFloat(this.items[x].item.row_total) || 0;

                        } else {
                            
                            total += Number.parseFloat(this.items[x].item.service_amount) || 0;
                            total += Number.parseFloat(this.items[x].item.row_total) || 0;
                        
                        }
                        
                    }

                    return total;
                },
                sub_total() {
                    let total = 0;
                    if(!this.is_comission){
                        for (let x = 0; x < this.items.length; x++) {

                            total += Number.parseFloat(this.items[x].item.row_total) || 0;

                        }
                    } 

                    return total;
                },
                total_service() {

                    let total = 0;
                    
                    if(this.is_comission){

                        for (let x = 0; x < this.items.length; x++) {

                            total += Number.parseFloat(this.items[x].item.row_total) || 0;
                            
                        }
                    } else {
                        for (let x = 0; x < this.items.length; x++) {

                            total += Number.parseFloat(this.items[x].item.service_amount) || 0;
                            
                        }
                    }
                    return total;
                },
            },
            methods: { 
                setProvince(){
                    if(this.selected_project?.id) {
                        this.items[0].item.selected_province = this.provinces.find(e=>e.id==this.selected_project?.location_id);
                        this.items[0].item.amount =  (this.selected_project.budget/ this.selected_project.total_beneficiary).toFixed(2);
                        this.getHousehold(this.selected_project.id);
                         
                    }
                    else {
                        this.items[0].item.selected_province = null;
                        this.items[0].item.household    = null;
                        this.items[0].item.amount       = null;
                        this.items[0].item.row_total    = null;
                    }
                },
                getHousehold(id){

                    if(this.type == 'cache'){

                        this.items[0].item.row_total = (this.items[0].item.amount).toFixed(2) || 0;

                    } else {

                        if(this.showTable('houseHold')){

                            axios.get('{{url("householde")}}/'+id).then(e=>{
                                this.items[0].item.household = e.data;
                                this.items[0].item.row_total = (this.items[0].item.amount * this.items[0].item.household).toFixed(2) || 0;
                            });
                        } else {
                            this.items[0].item.row_total = (this.items[0].item.amount).toFixed(2) || 0;
                        }
                    }
                },
                changeValue(){
                    this.is_comission = !this.is_comission;
                    if(this.is_comission){
                        this.show_subtotal = true;
                        // this.control_room.table.service_fee_percent = true;
                        // this.control_room.table['service_fee_percent']= true
                        let index =this.control_room.table.findIndex(e=>e.name=='service_fee_percent')
                        this.control_room.table[index].value= true
                        let index2 =this.control_room.table.findIndex(e=>e.name=='service_fee_amount')
                        this.control_room.table[index2].value= true
                        // "service_fee_percent"
                        // console.log('sss', this.control_room.table[index].value);
                        this.saveSetting()
                    }
                    console.log('check is_comission', this.is_comission);

                    if(this.is_comission){

                        for (let x = 0; x < this.items.length; x++) {

                            let service_amount = ((Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(this.items[x].item.percent) /100)) || 0;

                            if(service_amount > 0){

                                this.items[x].item.service_amount = service_amount;

                                if(this.type == 'cache'){

                                    this.items[x].item.row_total = ((Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(this.items[x].item.percent) /100)) || 0;

                                } else {

                                    if(this.showTable('houseHold')){

                                        this.items[x].item.row_total = ((Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(this.items[x].item.percent) /100) * Number.parseFloat(this.items[x].item.household)) || 0;
                                    } else {

                                        this.items[x].item.row_total = ((Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(this.items[x].item.percent) /100)) || 0;
                                    }
                                }


                                

                            } else {

                                this.items[x].item.service_amount = 0;

                                if(this.type == 'cache'){

                                    this.items[x].item.row_total = Number.parseFloat(this.items[x].item.amount) || 0;

                                } else {

                                    if(this.showTable('houseHold')){

                                        this.items[x].item.row_total = (Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(this.items[x].item.household)) || 0;
                                    } else {
                                        
                                        this.items[x].item.row_total = Number.parseFloat(this.items[x].item.amount) || 0;
                                    }
                                }


                            }
                        }

                    } else {
                        this.show_subtotal = false;

                        for (let x = 0; x < this.items.length; x++) {

                            if(this.type == 'cache'){

                                this.items[x].item.row_total = Number.parseFloat(this.items[x].item.amount) || 0;

                                // this.items[x].item.service_amount = (Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(this.items[x].item.percent) /100) || 0;
                                this.items[x].item.service_amount = 0;

                            } else {

                                if(this.showTable('houseHold')){

                                    this.items[x].item.row_total = ((Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(this.items[x].item.household))) || 0;

                                    // this.items[x].item.service_amount = ((Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(this.items[x].item.percent) /100) * Number.parseFloat(this.items[x].item.household)) || 0;
                                    this.items[x].item.service_amount = 0;
                                } else {

                                    this.items[x].item.row_total = Number.parseFloat(this.items[x].item.amount) || 0;

                                    // this.items[x].item.service_amount = (Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(this.items[x].item.percent) /100) || 0;
                                    this.items[x].item.service_amount = 0;
                                }
                            }

                            
                        }

                    }

                    
                },
                rateChanged() {

                    // for (let x = 0; x < this.items.length; x++) {

                    //     if (this.items[x].item.amount != null) {


                    //         this.items[x].item.row_total = ((Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(this.items[x].item.household))) || 0;
                    //     } else if (this.items[x].item.amount == null || this.items[x].item.amount <= 0) {

                    //         this.items[x].item.row_total = ((Number.parseFloat(this.items[x].item.service_amount) * Number.parseFloat(this.items[x].item.household))) || 0;
                    //     }
                    // }
                },
                sendForm() {
                    document.getElementById("userForm").submit();
                },
                setHousehold(index, value) {

                    this.items[index - 1].item.household = value;

                    if(this.is_comission){

                        let service_amount = ((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent) /100)) || 0;

                        if(service_amount > 0){

                            this.items[index - 1].item.service_amount = service_amount;
                            this.items[index - 1].item.row_total = ((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent) /100) * Number.parseFloat(this.items[index - 1].item.household)) || 0;

                        } else {

                            this.items[index - 1].item.service_amount = 0;
                            this.items[index - 1].item.row_total = (Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.household)) || 0;

                        }

                    } else {

                        this.items[index - 1].item.row_total = ((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.household))) || 0;

                        // this.items[index - 1].item.service_amount = ((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent) /100) * Number.parseFloat(this.items[index - 1].item.household)) || 0;
                        this.items[index - 1].item.service_amount = 0;
                    }

                },
                setAmount(index, value) {

                    this.items[index - 1].item.amount = value;

                    if(this.is_comission){

                        let service_amount = ((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent) /100)) || 0;

                        if(service_amount > 0){

                            this.items[index - 1].item.service_amount = service_amount;

                            if(this.showTable('houseHold')){

                                this.items[index - 1].item.row_total = ((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent) /100) * Number.parseFloat(this.items[index - 1].item.household)) || 0;
                            } else {

                                this.items[index - 1].item.row_total = ((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent) /100)) || 0;
                            }

                        } else {

                            this.items[index - 1].item.service_amount = 0;

                            if(this.showTable('houseHold')){

                                this.items[index - 1].item.row_total = (Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.household)) || 0;
                            } else {

                                this.items[index - 1].item.row_total = Number.parseFloat(this.items[index - 1].item.amount) || 0;
                            }

                        }

                        
                    } else {

                        if(this.showTable('houseHold')){

                            this.items[index - 1].item.service_amount = ((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent) /100) * Number.parseFloat(this.items[index - 1].item.household)) || 0;
                            this.items[index - 1].item.row_total = (Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.household)) || 0;
                        } else {

                            this.items[index - 1].item.service_amount = ((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent) /100)) || 0;
                            this.items[index - 1].item.row_total = Number.parseFloat(this.items[index - 1].item.amount) || 0;

                        }
                    } 


                },
                setServiceFee(index, value) {

                    this.items[index - 1].item.percent = value;
                    let household = (Number.parseFloat(this.items[index - 1].item.household) > 0) ? this.items[index - 1].item.household : 1;

                    if(this.is_comission){

                        this.items[index - 1].item.service_amount = (((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent)) / 100))  || 0;

                        if(this.showTable('houseHold')){

                            this.items[index - 1].item.row_total = (Number.parseFloat(this.items[index - 1].item.service_amount) * Number.parseFloat(this.items[index - 1].item.household)) || 0;
                        } else {
                            this.items[index - 1].item.row_total = Number.parseFloat(this.items[index - 1].item.service_amount) || 0;
                        }

                    } else {

                        if(this.showTable('houseHold')){

                            this.items[index - 1].item.service_amount = (((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent)) / 100) * Number.parseFloat(this.items[index - 1].item.household))  || 0;

                            this.items[index - 1].item.row_total = (Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.household)) || 0;

                        } else {

                            this.items[index - 1].item.service_amount = (((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent)) / 100))  || 0;

                            this.items[index - 1].item.row_total = Number.parseFloat(this.items[index - 1].item.amount) || 0;
                        }

                            

                    }
                },
                setservice(index, value) {


                    if(this.is_comission){
                        
                        this.items[index - 1].item.service_amount = value;
                        this.items[index - 1].item.amount = 0;

                        if(this.showTable('houseHold')){

                            this.items[index - 1].item.row_total = (Number.parseFloat(this.items[index - 1].item.service_amount) * Number.parseFloat(this.items[index - 1].item.household)) || 0;
                        } else {

                            this.items[index - 1].item.row_total = Number.parseFloat(this.items[index - 1].item.service_amount) || 0;
                        }

                    } else {
                        this.items[index - 1].item.service_amount = value;

                        if(this.showTable('houseHold')){

                        } else {

                            this.items[index - 1].item.row_total = Number.parseFloat(this.items[index - 1].item.amount) || 0;
                        }

                    }

                    

                },
                setTotalAmount(index, value) {

                    this.items[index - 1].item.row_total = value;

                },
                showFields(name) {
                    if (
                        this.control_room.fields?.find((e) => e.name == name && e.value == true)
                    )
                        return true;
                    else return false;
                },
                showTable(name) {
                    if (
                        this.control_room.table?.find((e) => e.name == name && e.value == true)
                    )
                        return true;
                    else return false;
                },
                setControlRoom() { 
                    if (!localStorage.getItem("setting")) {
                        axios.get("{{url('/user/setting')}}").then(res => {
                            console.log(res.data);
                            let setting = res.data.find(
                                (e) => e.name == 'Invoice'
                            ).data;
                            // checkData(setting, this)
                            this.control_room.fields = setting?. [0]?.values;
                            this.control_room.table = setting?. [1]?.values
                            localStorage.setItem('setting', JSON.stringify(res.data));


                        })
                    } else {
                        let setting = JSON.parse(localStorage.getItem("setting")).find(
                            (e) => e.name == 'Invoice'
                        ).data;
                        // checkData(setting, this);
                        this.control_room.fields = setting?. [0]?.values;
                        this.control_room.table = setting?. [1]?.values
                    }
                },
                saveSetting() {
                    let setting = JSON.parse(localStorage.getItem("setting"));
                    let index = setting.findIndex((e) => e.name == "Invoice");
                    setting[index].data[0].values = this.control_room.fields;
                    console.log("this.control_room.table",this.control_room.table);
                    setting[index].data[1].values = this.control_room.table;
                    axios
                        .post("/user/setting", {
                            form: JSON.stringify(setting)
                        })
                        .then((res) => {
                            localStorage.setItem("setting", JSON.stringify(setting));
                        });
                },
                searchItems: _.debounce(function (e) {
                    axios.get("{{route('item.all') }}?" +
                        "type=" + 'item'
                    )
                        .then((res) => {
                            this.itemData = res.data;
                        });
                }, 200),
                getItems() {
                    axios.get("{{route('item.all') }}")
                        .then((res) => {
                            this.itemData = res.data;
                        });
                },
                addRow(index) {
                    if ((index - 1) == this.items.length - 1) {
                        console.log('inside');
                        let amount = null;
                        if(this.items[index-1].item.selected_province != null){

                            amount = (this.selected_project != null) ? (this.selected_project.budget/ this.selected_project.total_beneficiary).toFixed(2) : null;
                            // this.items[index].item.household = this.household(this.items[index].item.selected_province.id);
                        }

                        this.items.push({
                            item: {
                                selected_item: null,
                                selected_province: null,
                                amount: amount,
                                percent: null,
                                household: null,
                                date: null,
                                service_amount: null,
                                row_total: 0
                            }
                        });
                    } else {
                        
                        let amount = null;
                        if(this.items[index-1].item.selected_province != null){

                            amount = (this.selected_project != null) ? (this.selected_project.budget/ this.selected_project.total_beneficiary).toFixed(2) : null;
                            // this.items[index].item.household = this.household(this.items[index].item.selected_province.id);
                        }
                        this.items[index-1].item.amount = amount;
                    }
                }, 
                addAttachment(index) {
                    if ((index - 1) == this.attachments.length - 1) {
                        this.attachments.push({item: {title: null}});
                    }
                },
                deleteAttachment(index) {
                    if (this.attachments.length - 1 > 0) this.attachments.splice(index - 1, 1);
                },
                deleteItem(index) {
                    if (this.items.length - 1 > 0) this.items.splice(index - 1, 1);
                },
                getItemTotal(item = null, exchanged_rate = 1) {
                    let result = 0;
                    if (item != null && item.quantity > 0) {
                        let price = item.price;
                        let quantity = item.quantity;
                        let total = price * quantity * 1;
                        result = Number.parseFloat(total).toFixed(2);
                    }
                    return result;
                },
                /**
                 * handleSubmit
                 */
                handleSubmit(e, type = 'save') {
                    this.$validator.validate().then(valid => {

                        if (valid) {

                            let ids = [];
                            for (let i = 0; i < this.selected_role.length; i++) {
                                ids.push(this.selected_role[i].id)
                            }

                            $('#role_ids').val(ids);
                            document.getElementById('permission_id').value = selected_p;
                            e.preventDefault();
                            let url = (e.target.form == undefined) ? e.target.action : e.target.form.action;
                            let data = (e.target.form == undefined) ? $(e.target).serialize() : $(e.target.form).serialize();
                            data = new FormData(e.target.form);
                            toggleBlock(1);
                            axios.post(url, data)
                                .then(function (response) {
                                    toggleBlock(0);
                                    let message = "{{__('message.success')}}";
                                    if (response.data) {
                                        message = response.data.message;
                                    }
                                    alertify.success(message);
                                    if (type != 'save') {
                                        vm.defaultValue(e);
                                    } else {
                                        window.location.href = "{{route('user.index')}}";
                                    }
                                })
                                .catch(function (error) {
                                    toggleBlock(0);
                                    let warning = "{{__('message.error')}}";
                                    if (error.response.data) {
                                        if (error.response.data.message) {
                                            warning = error.response.data.message;
                                        }
                                        if ((error.response.status == 422) == true) {
                                            let my_error = error.response.data.errors;

                                            for (index in my_error) {

                                                alertify.error(my_error[index][0]);
                                            }

                                        }
                                    }

                                    alertify.error(warning);
                                })
                        }
                    });
                }
                /**
                 * this is used to set default value
                 */


            }
        });

    </script>

    <style>
        .vue_dropdown .vs__dropdown-toggle {
            border: none !important;
        }
    </style>

@endsection
