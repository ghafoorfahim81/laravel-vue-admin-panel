@extends('layouts.master')
@section('title', __('lang.invoice_list'))
@section('css')
    <link rel="stylesheet" href="{{ asset('assets/css/print.css') }}">

@endsection
@section('content')

    <div class="page-content-wrapper" id="app" v-cloak>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">

                        <div style="display: flex;">
                            <div class="row m-4">
                                <div class="col-sm-12 col-md-2 form-inline">
                                    <div class="form-group">
                                        @if (hasPermission(['invoice_create']))
                                            <button onclick="location.href='{{ route('invoice.create') }}'"
                                                    class="btn btn-info btn-sm waves-effect waves-light"
                                                    type="button">@lang('lang.add') @lang('lang.invoice')
                                                <i class="mdi mdi-plus-thick"></i></button>&nbsp
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <ul class="nav nav-tabs mt-2" role="tablist">

                                <li class="nav-item">
                                    <a class="nav-link active" style="font-size: 15px;" data-toggle="tab"
                                       href="#profile"
                                       role="tab">
                                        <i class="fas fa-exclamation-circle"></i>
                                        <span class="d-md-inline-block" @click="getRecord">UnPaid Invoices</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" style="font-size: 15px;" data-toggle="tab" href="#home"
                                       role="tab">
                                        <i class="fas fa-hands-helping"></i>
                                        <span class="d-md-inline-block"
                                              @click="getRecordPaid">Paid Invoices</span>
                                    </a>
                                </li>

                            </ul>
                        </div>

                        <!-- Tab panes -->
                        <div class="tab-content p-3">

                            <!-- Tab 1 Content Start -->
                            <div class="tab-pane" id="home" role="tabpanel">

                                <div class="shadow-4 col-xl-3 rounded-sm p-3 border total__card mr-4">
                                    <div class="row justify-around">
                                        <div class="pl-8" v-show="!apiDataPaid.data">
                                            <skeleton-loader-vue type="rect" :height="20"
                                                                 :width="200" animation="fade"/>
                                        </div>
                                        <span v-show="apiDataPaid.data" class="font-weight-bold text-2xl col-7">Total:
                                            @{{ total_paid.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") }}</span>
                                    </div>
                                </div>
                                <div class="col text-right pr-4">
                                    <button type="button" @click="exortToExcelSingle('paid_invoice')"
                                            class="btn btn-success btn-sm">
                                        <i class="fas fa-file-excel"></i>
                                        <span class="ml-1">Excel</span>
                                    </button>
                                    <button type="button" @click="exortToPDF('paid_invoice')"
                                            class="btn btn-danger btn-sm ml-1">
                                        <i class="fas fa-file-pdf"></i>
                                        <span class="ml-1">PDF</span>
                                    </button>
                                </div>
                                <input type="hidden" name="permission_id" id="permission_id">

                                <div style="padding-bottom: 0px">
                                    <div class="card-body client-nav">
                                        <div class=" ">
                                            <datatable ref="child1" :per-page="{{ perPage() }}"
                                                       :no-record-found-text="'@lang('lang.no_record_found')'"
                                                       :per-page-text="'@lang('lang.show')'"
                                                       :showing-text="'@lang('lang.showing')'"
                                                       :from-text="'@lang('lang.from')'" :to-text="'@lang('lang.to')'"
                                                       :record-text="'@lang('lang.record')'"
                                                       :app-per-page="{!! perPage(1) !!}"
                                                       :columns="columns" :data="apiDataPaid"
                                                       @pagination-change-page="getRecordPaid" :limit="1"
                                                       :filterRecord="getRecordPaid" :multiple-select="true"
                                                       :selected-rows="selectedRows"
                                                       @delete-method-action="deleteRecordPaid">
                                                <template slot="tbody">
                                                    <tbody v-show="!apiDataPaid.data">
                                                    <tr v-for="skeleton in 4">


                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15"
                                                                                 :width="50" class="m-3"
                                                                                 animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15"
                                                                                 :width="50" class="m-3"
                                                                                 animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15"
                                                                                 :width="50" class="m-3"
                                                                                 animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15"
                                                                                 :width="50" class="m-3"
                                                                                 animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15"
                                                                                 :width="50" class="m-3"
                                                                                 animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15"
                                                                                 :width="50" class="m-3"
                                                                                 animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15"
                                                                                 :width="50" class="m-3"
                                                                                 animation="fade"/>
                                                        </td>
                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15"
                                                                                 :width="50" class="m-3"
                                                                                 animation="fade"/>
                                                        </td>

                                                    </tr>
                                                    </tbody>
                                                    <tbody v-show="apiDataPaid.data">
                                                    <tr v-for="(record,index) in apiDataPaid.data"
                                                        :key="record.id">
                                                        <td>
                                                            <input type="checkbox" class="" v-model="selectedRows"
                                                                   :value="record.id" :id="`checked-${record.id}}`">

                                                        </td>
                                                        <td> @{{ ++index }}</td>
                                                        <td> @{{ record.invoice_no }}</td>
                                                        <td> @{{ record.company }}</td>
                                                        <td> @{{ record.project }}</td>
                                                        <td> @{{ record.amount }}</td>
                                                        <td> @{{ record.currency }}</td>
                                                        <td class="">
                                                            <div class="p-1" role="group" style="width: 230px; text-align:center">
                                                                @if (hasPermission(['invoice_view']))
                                                                    <a class="btn btn-info btn-sm"
                                                                       style="padding: 0.375rem 0.6rem"
                                                                       @click="printInvoice(record.id)"
                                                                       data-toggle="tooltip" data-placement="top"
                                                                       title="Print">
                                                                        <i class="mdi mdi-printer"></i>
                                                                    </a>&nbsp;
                                                                @endif
                                                                @if (hasPermission(['invoice_view']))
                                                                    <a class="btn btn-success btn-sm"
                                                                       style="padding: 0.375rem 0.6rem"
                                                                       :href="`{{ url('export/to/excel/invoice') }}/${record.id}`"
                                                                       data-toggle="tooltip" data-placement="top"
                                                                       title="Print">
                                                                        <i class="fas fa-file-excel"></i>
                                                                    </a>&nbsp;
                                                                @endif
                                                                    @if (hasPermission(['invoice_view']))
                                                                    <a class="btn btn-danger btn-sm"
                                                                       style="padding: 0.375rem 0.6rem"
                                                                       :href="`{{ url('export/to/pdf/invoice') }}/${record.id}`"
                                                                       data-toggle="tooltip" data-placement="top"
                                                                       title="Print">
                                                                        <i class="fas fa-file-pdf"></i>
                                                                    </a>&nbsp;
                                                                @endif
                                                                @if (hasPermission(['invoice_edit']))
                                                                    <a class="btn btn-primary btn-sm"
                                                                       style="padding: 0.375rem 0.6rem"
                                                                       :href="`{{ url('invoice/edit') }}/${record.id}`"
                                                                       data-toggle="tooltip" data-placement="top"
                                                                       title="Edit">
                                                                        <i class="dripicons-document-edit"></i>
                                                                    </a>&nbsp;
                                                                @endif
                                                                @if (hasPermission(['invoice_view']))
                                                                    <a class="btn btn-info btn-sm"
                                                                       style="padding: 0.375rem 0.6rem"
                                                                       :href="`{{ url('invoice') }}/${record.id}`"
                                                                       data-toggle="tooltip" data-placement="top"
                                                                       title="View">
                                                                        <i style="color: white"
                                                                           class="mdi mdi-eye"></i>
                                                                    </a>
                                                                @endif
                                                                @if (hasPermission(['invoice_delete']))
                                                                    <a class="btn btn-danger btn-sm"
                                                                       style="padding: 0.375rem 0.6rem"
                                                                       @click="deleteRecordPaid(record.id)"
                                                                       data-toggle="tooltip" data-placement="top"
                                                                       title="Delete">
                                                                        <i style="color: white"
                                                                           class="mdi mdi-delete"></i>
                                                                    </a>
                                                                @endif
                                                            </div>
                                                        </td>
                                                    </tr>

                                                    </tbody>

                                                </template>
                                            </datatable>
                                            {{-- <Pagination align="center" :limit="1" :data="records" @pagination-change-page="getRecords"></Pagination> --}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Tab 1 Content End -->


                            <!-- Tab 2 Content Start -->
                            <div class="tab-pane active" id="profile" role="tabpanel">
                                <div class="shadow-4 col-xl-3 rounded-sm p-3 border total__card mr-4">
                                    <div class="row justify-around">
                                        <div class="pl-8" v-show="!apiDataPaid.data">
                                            <skeleton-loader-vue type="rect" :height="20"
                                                                 :width="200" animation="fade"/>
                                        </div>
                                        <span v-show="apiDataPaid.data" class="font-weight-bold text-2xl col-7">Total:
                                            @{{ total_unpaid.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") }}</span>
                                    </div>
                                </div>
                                <div class="col text-right pr-4">
                                    <button type="button" @click="exortToExcelSingle('unpaid_invoice')"
                                            class="btn btn-success btn-sm">
                                        <i class="fas fa-file-excel"></i>
                                        <span class="ml-1">Excel</span>
                                    </button>
                                    <button type="button" @click="exortToPDF('unpaid_invoice')"
                                            class="btn btn-danger btn-sm ml-1">
                                        <i class="fas fa-file-pdf"></i>
                                        <span class="ml-1">PDF</span>
                                    </button>
                                </div>
                                <input type="hidden" name="permission_id" id="permission_id">
                                <div style="padding-bottom: 0px">
                                    <div class="card-body client-nav">
                                        <div class=" ">
                                            <datatable ref="child" :per-page="{{perPage()}}"
                                                       :no-record-found-text="'@lang('lang.no_record_found')'"
                                                       :per-page-text="'@lang('lang.show')'"
                                                       :showing-text="'@lang('lang.showing')'"
                                                       :from-text="'@lang('lang.from')'" :to-text="'@lang('lang.to')'"
                                                       :record-text="'@lang('lang.record')'"
                                                       :app-per-page="{!! perPage(1) !!}" :columns="columns"
                                                       :data="apiData" @pagination-change-page="getRecord" :limit="1"
                                                       :filterRecord="getRecord" :multiple-select="true"
                                                       :selected-rows="selectedRows"
                                                       @delete-method-action="deleteRecord">

                                                <template slot="tbody">
                                                    <tbody v-show="!apiData.data">
                                                    <tr v-for="skeleton in 4">


                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15"
                                                                                 :width="50" class="m-3"
                                                                                 animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15"
                                                                                 :width="50" class="m-3"
                                                                                 animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15"
                                                                                 :width="50" class="m-3"
                                                                                 animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15"
                                                                                 :width="50" class="m-3"
                                                                                 animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15"
                                                                                 :width="50" class="m-3"
                                                                                 animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15"
                                                                                 :width="50" class="m-3"
                                                                                 animation="fade"/>
                                                        </td>

                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15"
                                                                                 :width="50" class="m-3"
                                                                                 animation="fade"/>
                                                        </td>
                                                        <td>
                                                            <skeleton-loader-vue type="rect" :height="15"
                                                                                 :width="50" class="m-3"
                                                                                 animation="fade"/>
                                                        </td>

                                                    </tr>
                                                    </tbody>
                                                    <tbody v-show="apiData.data">
                                                    <tr v-for="(record,index) in apiData.data" :key="record.id">
                                                        <td>
                                                            <input type="checkbox" class=""
                                                                   v-model="selectedRows" :value="record.id"
                                                                   :id="`checked-${record.id}}`">

                                                        </td>
                                                        <td> @{{ ++index }}</td>
                                                        <td> @{{ record.invoice_no }}</td>
                                                        <td> @{{ record.company }}</td>
                                                        <td> @{{ record.project }}</td>
                                                        <td> @{{ record.amount }}</td>
                                                        <td> @{{ record.currency }}</td>
                                                        <td class="">
                                                            <div class="p-1" role="group" style="width: 230px; text-align:center">
                                                                @if (hasPermission(['invoice_view']))
                                                                    <a class="btn btn-info btn-sm"
                                                                       style="padding: 0.375rem 0.6rem"
                                                                       @click="printInvoice(record.id)"
                                                                       data-toggle="tooltip" data-placement="top"
                                                                       title="Print">
                                                                        <i class="mdi mdi-printer"></i>
                                                                    </a>&nbsp;
                                                                @endif
                                                                @if (hasPermission(['invoice_view']))
                                                                    <a class="btn btn-success btn-sm"
                                                                       style="padding: 0.375rem 0.6rem"
                                                                       :href="`{{ url('export/to/excel/invoice') }}/${record.id}`"
                                                                       data-toggle="tooltip" data-placement="top"
                                                                       title="Print">
                                                                        <i class="fas fa-file-excel"></i>
                                                                    </a>&nbsp;
                                                                @endif
                                                                    @if (hasPermission(['invoice_view']))
                                                                    <a class="btn btn-danger btn-sm"
                                                                       style="padding: 0.375rem 0.6rem"
                                                                       :href="`{{ url('export/to/pdf/invoice') }}/${record.id}`"
                                                                       data-toggle="tooltip" data-placement="top"
                                                                       title="Print">
                                                                        <i class="fas fa-file-pdf"></i>
                                                                    </a>&nbsp;
                                                                @endif
                                                                @if (hasPermission(['invoice_edit']))
                                                                    <a class="btn btn-primary btn-sm"
                                                                       style="padding: 0.375rem 0.6rem"
                                                                       :href="`{{ url('invoice/edit') }}/${record.id}`"
                                                                       data-toggle="tooltip" data-placement="top"
                                                                       title="Edit">
                                                                        <i class="dripicons-document-edit"></i>
                                                                    </a>&nbsp;
                                                                @endif
                                                                @if (hasPermission(['invoice_view']))
                                                                    <a class="btn btn-info btn-sm"
                                                                       style="padding: 0.375rem 0.6rem"
                                                                       :href="`{{ url('invoice') }}/${record.id}`"
                                                                       data-toggle="tooltip" data-placement="top"
                                                                       title="View">
                                                                        <i style="color: white"
                                                                           class="mdi mdi-eye"></i>
                                                                    </a>
                                                                @endif
                                                                @if (hasPermission(['invoice_delete']))
                                                                    <a class="btn btn-danger btn-sm"
                                                                       style="padding: 0.375rem 0.6rem"
                                                                       @click="deleteRecord(record.id)"
                                                                       data-toggle="tooltip" data-placement="top"
                                                                       title="Delete">
                                                                        <i style="color: white"
                                                                           class="mdi mdi-delete"></i>
                                                                    </a>
                                                                @endif
                                                            </div>
                                                        </td>
                                                    </tr>

                                                    </tbody>

                                                </template>
                                            </datatable>
                                            {{-- <Pagination align="center" :limit="1" :data="records" @pagination-change-page="getRecords">
                    </Pagination> --}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Tab 2 Content End -->

                        </div>

                    </div>

                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- <div class="tbl-container" id="content_print_reports" style="visibility: hidden;"> -->
        <div id="content_print_report" style="visibility: hidden;">
            <div id="title">
                <img src="{{ asset('header.PNG') }}" class="img_header1" alt="" srcset="">
            </div>
            <!-- <div id="main-content"> -->
            <!-- <div id="date-no">
                                                    <h1 id="in-date">Invoice Date: @{{ print_data.date }}</h1>
                                                    <h1 id="in-no">Inoice No: @{{ print_data.invoice_no }}</h1>
                                                </div> -->
            <div id="main-tbl">

            </div>
            <!-- </div> -->
            <div id="table-footer">
                <img src="{{ asset('footer.PNG') }}" class="img_header" alt="" srcset="">
            </div>
            <!-- <span>
                                                    Address: Sara I Shazada, Ground Floor,
                                                    Shop# 42, Kabul-Afghanistan- , Phone# (0) 202100960 / Mobile# 0093(0) 777 55 31 55 &nabla;&nabla;&nabla;&nabla; &nbsp;ادرس: سرای شهزاده منزل اول دوکان نمبر 42، کابل- افغانستان

                                                </span> -->
        </div>
        <!-- </div> -->
    </div>
    <!-- end page-content-wrapper -->

@endsection
@section('js')
    <script src="{{ asset('assets/js/print.js') }}"></script>
    <script>
        //Vue.component('pagination', require('laravel-vue-pagination'));
        var vm = new Vue({
            el: '#app',
            components: {
                'skeleton-loader-vue': window.VueSkeletonLoader,
            },
            data() {
                return {
                    url: "{{ route('invoice.index') }}?",
                    columns: [{
                        label: "#",
                        name: '#',
                        sort: false,
                    },
                        {
                            label: "@lang('lang.number')",
                            name: 'invoices.invoice_no',
                            sort: true,
                            activeSort: true,
                            order_direction: 'desc',
                        },
                        {
                            label: "@lang('lang.organization')",
                            name: 'companies.name',
                            sort: true,
                            // activeSort: true,
                            order_direction: 'desc',
                        },
                        {
                            label: "@lang('lang.project')",
                            name: 'projects.name',
                            sort: true,
                            // activeSort: true,
                            order_direction: 'desc',
                        },
                        {
                            label: "@lang('lang.amount')",
                            name: 'invoices.amount',
                            sort: true,
                            // activeSort: true,
                            order_direction: 'desc',
                        },
                        {
                            label: "@lang('lang.currency')",
                            name: 'invoices.currency',
                            sort: true,
                            // activeSort: true,
                            order_direction: 'desc',
                        },
                        {
                            label: "@lang('lang.actions')",
                            name: 'action',
                            sort: false
                        }
                    ],

                    apiData: {},
                    apiDataPaid: {},
                    appPerPage: '{!! perPage(1) !!}',
                    perPage: "{{ perPage() }}",
                    page: 1,
                    selectedRows: [],
                    invoice_details: [],
                    print_data: {},
                    total: 0,
                    total_service_fee_amount: 0,
                    all_total: 0,
                    extra_amount: 0,
                    total_commision: 0,
                    total_unpaid: 0,
                    total_paid: 0,
                    control_room: {
                        fields: null,
                        table: null
                    }
                }

            },
            mounted() {
                this.getRecordPaid();
                this.setControlRoom();
            },
            methods: {

                /**
                 * get record from api
                 */
                showFilterModal() {
                    $('#filterModal').modal('show');
                    this.getProvinces();
                },
                showFields(name) {
                    if (
                        this.control_room.fields?.find((e) => e.name == name && e.value == true)
                    )
                        return true;
                    else return false;
                },
                showTable(name) {
                    if (
                        this.control_room.table?.find((e) => e.name == name && e.value == true)
                    )
                        return true;
                    else return false;
                },
                exortToExcelSingle(type, id = null) {
                    new Promise((resolve, reject) => {
                        let data = [];
                        const formData = new FormData();
                        if (type == 'unpaid_invoice') {
                            data = vm.apiData.data;
                        } else {
                            data = vm.apiDataPaid.data;
                        }
                        formData.append("data", JSON.stringify(data));
                        axios({
                            method: "post",
                            url: "excel?type=" + type,
                            responseType: "blob",
                            data: formData
                        }).then(response => {
                            console.log('for test:', response.data);
                            resolve('response');

                            let Fformat = ".xlsx";
                            var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                            var fileLink = document.createElement("a");
                            fileLink.href = fileURL;
                            fileLink.setAttribute("download", type + ".xlsx");
                            document.body.appendChild(fileLink);
                            fileLink.click();
                        })
                            .catch((error) => {
                                reject(error);
                                console.log(error);
                            });
                    }).then(() => resolve('data')).catch(e => reject(e));
                },
                exortToPDF(type, id = null) {
                    new Promise((resolve, reject) => {
                        let data = [];
                        const formData = new FormData();
                        if (type == 'unpaid_invoice') {
                            data = vm.apiData.data;
                        } else {
                            data = vm.apiDataPaid.data;
                        }
                        formData.append("data", JSON.stringify(data));
                        axios({
                            method: "post",
                            url: "pdf?type=" + type,
                            responseType: "blob",
                            data: formData
                        }).then(response => {
                            console.log('for test:', response.data);
                            resolve('response');

                            let Fformat = ".xlsx";
                            var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                            var fileLink = document.createElement("a");
                            fileLink.href = fileURL;
                            fileLink.setAttribute("download", type + ".pdf");
                            document.body.appendChild(fileLink);
                            fileLink.click();
                        })
                            .catch((error) => {
                                reject(error);
                                console.log(error);
                            });
                    });
                },
                setControlRoom() {
                    if (!localStorage.getItem("setting")) {
                        axios.get('public/user/setting').then(res => {
                            console.log(res.data);
                            let setting = res.data.find(
                                (e) => e.name == 'Invoice'
                            ).data;
                            // checkData(setting, this)
                            this.control_room.fields = setting?.[0]?.values;
                            this.control_room.table = setting?.[1]?.values
                            localStorage.setItem('setting', JSON.stringify(res.data));


                        })
                    } else {
                        let setting = JSON.parse(localStorage.getItem("setting")).find(
                            (e) => e.name == 'Invoice'
                        ).data;
                        // checkData(setting, this);
                        this.control_room.fields = setting?.[0]?.values;
                        this.control_room.table = setting?.[1]?.values
                    }
                },
                getRecord: _.debounce((page = vm.page) => {
                    console.log('test paid', vm.$refs.child.$refs.filter)
                    let type = 'unpaid';
                    axios.get(vm.url +
                        '&current_page=' +
                        page + '&per_page=' + vm.perPage + '&invoice_type=' + type)
                        .then((response) => {
                            if (response.data) {
                                vm.page = response.data.current_page;
                            }
                            vm.apiData = response.data;
                            vm.total_unpaid = 0;
                            for (let x = 0; x < response.data.data.length; x++) {
                                vm.total_unpaid += Number.parseFloat(response.data.data[x].amount);
                            }
                        })
                        .catch((error) => {
                            console.log(error);
                        });
                }, 200),
                getRecordPaid: _.debounce((page = vm.page) => {
                    let type = 'paid';
                    axios.get(vm.url +
                        '&current_page=' +
                        page + '&per_page=' + vm.perPage + '&invoice_type=' + type)
                        .then((response) => {

                            if (response.data) {
                                vm.page = response.data.current_page;
                            }
                            vm.apiDataPaid = response.data;
                            vm.total_paid = 0;
                            for (let x = 0; x < response.data.data.length; x++) {
                                vm.total_paid += Number.parseFloat(response.data.data[x].amount);

                            }

                        })
                        .catch((error) => {
                            console.log(error);
                        });


                }, 200),

                // delete record
                deleteRecord(id = null) {
                    if (id && id != null) {
                        deleteItem(`invoice/${id}`);
                        this.selectedRows = [];
                    } else {
                        deleteItem(`invoice/multiple`, this.selectedRows);
                        this.selectedRows = [];
                    }
                },
                deleteRecordPaid(id = null) {
                    if (id && id != null) {
                        deleteItem(`invoice/${id}`);
                        this.selectedRows = [];
                    } else {
                        deleteItem(`invoice/multiple`, this.selectedRows);
                        this.selectedRows = [];
                    }
                },
                printInvoice(id = null) {

                    axios.get("invoice/print/" + id)
                        .then(data => {
                            console.log(data);
                            this.invoice_details = data.data;
                            this.print_data = this.invoice_details[0]
                            let total = 0;
                            let total_service_fee_amount = 0;
                            let all_total = 0;
                            let extra_amount = 0;
                            let total_commision = 0;
                            this.invoice_details.forEach(e => total += Number.parseFloat(e.amount) ?? '');
                            this.invoice_details.forEach(e => total_service_fee_amount += Number.parseFloat(e
                                .amount * e.service_fee_percent) / 100);
                            this.invoice_details.forEach(e => all_total += Number.parseFloat(((e.amount * e
                                .service_fee_percent) / 100) + e.amount));
                            this.invoice_details.forEach(e => extra_amount += Number.parseFloat(e
                                .extra_amount));
                            if (this.print_data?.household)
                                this.invoice_details.forEach(e => total_commision += Number.parseFloat(((e
                                        .amount *
                                    e.service_fee_percent) / 100)));
                            else
                                this.invoice_details.forEach(e => total_commision += Number.parseFloat(((e
                                        .house_amount *
                                    e.service_fee_percent) / 100)));
                            if (this.invoice_details.length <= 3) {
                                let len = 3 - this.invoice_details.length;
                                for (let i = 0; i < len; i++) {
                                    this.invoice_details.push({
                                        amount: 0,
                                        company_datials: null,
                                        currency: null,
                                        date: null,
                                        details: null,
                                        exchange_currency: null,
                                        exchange_rate_second: 0,
                                        exchange_symbol: null,
                                        extra_amount: 0,
                                        house_amount: 0,
                                        household: 0,
                                        invoice_date: null,
                                        invoice_no: null,
                                        location: null,
                                        organization: null,
                                        parent_id: null,
                                        project_code: null,
                                        project_date: null,
                                        project_name: null,
                                        purpose: null,
                                        service_fee_amount: 0,
                                        service_fee_percent: 0,
                                        show_project_name: null,
                                        symbol: null,
                                        total: 0,
                                        total_amount: 0,
                                        type: null,
                                        vol_rep: null,
                                    })

                                }
                            }
                            // this.invoice_details.forEach(e => total_commision += Number.parseFloat(e.service_fee_amount));
                            this.total = total;
                            this.total_service_fee_amount = total_service_fee_amount;
                            this.all_total = all_total;
                            this.extra_amount = extra_amount;
                            this.total_commision = total_commision ? total_commision : 0;
                            // console.log(this.invoice_details.reduce((pre,curr)=>pre.amount+curr.amount));
                            // this.total = this.invoice_details.reduce((pre,curr)=>pre.amount+curr.amount);
                            // console.log(total);
                            // this.print_data.house_amount = 0;
                            // this.print_data.household = 0;
                            // this.print_data.service_fee_percent = 0;
                            // this.print_data.parent_id = 0;
                            // (this.print_data.location|| this.print_data.purchase_order) = '';
                            // this.print_data.date = '';
                            let main_tbl = document.getElementById('main-tbl');
                            // this.print_data.purpose = this.print_data.organization.toLowerCase()?.includes(
                            //     'wfp') ? '' : this.print_data.purpose;
                            let first_tbl = `
                            <table class="tbl-container" id="table-container2">
                                    <tr>
                                        <th colspan="${(this.print_data.parent_id || this.print_data?.service_fee_percent) ? '8' : '6'}" id="invoice">Invoice</th>
                                    </tr>
                                    <tr>`;
                            if (this.print_data.invoice_no) {

                                first_tbl +=
                                    `<td colspan="${(this.print_data.parent_id || this.print_data?.service_fee_percent) ? '4' : '3'}">Inoice No:
                                        ${(this.print_data.project_date || new Date().getFullYear()) + '/' + this.print_data.invoice_no}</td>`
                            } else {
                                first_tbl +=
                                    `<td colspan="${(this.print_data.parent_id || this.print_data?.service_fee_percent) ? '4' : '3'}"></td>`
                            }
                            if (this.print_data.date) {

                                first_tbl += `<td colspan="${(this.print_data.parent_id || this.print_data?.service_fee_percent) ? '4' : '3'}" id="invoice-date" >
                                        Invoice Date: ${this.print_data.date}</td>`
                            } else {
                                first_tbl +=
                                    `<td colspan="${(this.print_data.parent_id || this.print_data?.service_fee_percent) ? '4' : '3'}"></td>`
                            }

                            first_tbl += `</tr> <br /> <tr>`;
                            if (this.print_data.organization) {
                                if (this.print_data.organization.toLowerCase()?.includes('unhcr'))
                                    this.print_data.organization = 'UNHCR'
                                if (this.print_data.organization.toLowerCase()?.includes('wfp'))
                                    this.print_data.organization = 'WFP'

                                console.log('test --', this.print_data.organization?.startsWith('UNHCR'));
                                first_tbl += `<th colspan="3" id="organization" >Organization:
                                    ${this.print_data.organization}</th>`
                            } else {
                                first_tbl += `<th colspan="3"></th>`
                            }

                            first_tbl += `<th colspan="2"></th></tr>
                                <tr id="table-grant">
                                    `;
                            if (this.print_data.vol_rep) {

                                first_tbl += `<td colspan="3" >VolRep ${this.print_data.vol_rep}</td>`
                            } else {
                                first_tbl += `<td colspan="3" ></td>`
                            }
                            if (this.print_data.show_project_name == 'true') {
                                if (this.print_data.project_name && !this.print_data.organization.toLowerCase()?.includes(
                                    'wfp'))
                                    first_tbl +=
                                        ` <tr id="table-grant"><td colspan="3" > Cash for ${this.print_data.project_name}</td><td colspan="2"></td><tr>`
                                if (this.print_data.organization?.startsWith('WFP'))
                                    first_tbl +=
                                        `<tr id="table-grant"><td colspan="3" > Project (${this.print_data.project_code})</td><td colspan="2"></td><tr>`
                                else if(this.print_data.project_code)
                                    first_tbl +=
                                        `<tr id="table-grant"><td colspan="3" > Cash Plan ID (${this.print_data.project_code})</td><td colspan="2"></td><tr>`
                            }
                            first_tbl += `<td colspan="2"></td></tr>
                                <tr id="table-grant">
                                    `;
                            // if(this.print_data.organization?.startsWith('UNHCR')) {

                            //     first_tbl += `<td colspan="3" >Purpose ${ this.print_data.purpose }</td>`
                            // }

                            if (this.print_data.purpose) {

                                first_tbl += `<td colspan="3" >Purpose ${this.print_data.purpose}</td>`
                            } else {
                                first_tbl += `<td colspan="3" ></td>`
                            }
                            first_tbl += `<td colspan="2"></td></tr>`;

                            first_tbl += `</table>`;
                            first_tbl +=
                                `<table class="tbl-container tbl-container-content" id="table-container">`;
                            if (this.print_data.parent_id || this.print_data?.service_fee_percent) {

                                first_tbl += `<tr class="table-header" ><th>#</th>`;
                                if (this.print_data.location || this.print_data.purchase_order) {
                                    first_tbl += `<th >Location</th>`
                                }
                                if (this.print_data.invoice_date) {
                                    first_tbl += `<th >Date</th>`
                                }
                                if (this.print_data.household) {
                                    first_tbl += `<th >House Holde</th>`
                                }
                                if (this.print_data.house_amount > 0)
                                    first_tbl += `<th>Amount in (${this.print_data.currency})</th>`;
                                if (this.print_data.type != "commission_principle")
                                    first_tbl += `<th>Grand total (${this.print_data.currency})</th>`;
                                first_tbl += `<th >%</th>
                                <th >Commission (${this.print_data.currency})</th>`;
                                if (this.print_data.type == "commission_principle")
                                    first_tbl += `<th>Balance (${this.print_data.currency})</th>`;
                                first_tbl += `</tr>`;
                            } else {
                                first_tbl += `<tr class="table-header"><th>#</th>`;
                                if (this.print_data.location || this.print_data.purchase_order) {
                                    first_tbl += `<th  >Location</th>`
                                }
                                if (this.print_data.invoice_date) {
                                    first_tbl += `<th  >Date</th>`
                                }
                                if (this.print_data.household) {
                                    first_tbl += `<th  >House Holde</th>`
                                }
                                if (this.print_data.house_amount > 0)
                                    first_tbl += `<th>Amount in (${this.print_data.currency})</th>`;
                                // first_tbl += `<th>Grand total (${ this.print_data.currency })</th></tr>`;
                                if (this.print_data.type != "commission_principle")
                                    first_tbl += `<th>Grand total (${this.print_data.currency})</th></tr>`;
                                if (this.print_data.type == "commission_principle")
                                    first_tbl += `<th>Balance (${this.print_data.currency})</th></tr>`;
                            }

                            // if(this.print_data.parent_id || this.print_data?.service_fee_percent) {
                            //     first_tbl += `<tr class="table-header"><th>%</th><th>Total</th></tr>`;
                            // }
                            this.invoice_details.forEach((e, index) => {
                                first_tbl += `<tr class="table-data">
                                    <td class="no" style="width: 5% !important;">${index + 1}</td>`;
                                if (this.print_data.location || this.print_data.purchase_order) {
                                    first_tbl += `<td >${e.purchase_order ? (e?.location + ' (' + e.purchase_order + ")") : e?.location ?? ''}</td>`;
                                }
                                if (this.print_data.invoice_date) {
                                    first_tbl += `<td>${e?.invoice_date ?? ''} </td>`;
                                }
                                if (this.print_data.household) {
                                    first_tbl += `<td>${e?.household > 0 ? e?.household : ''}</td>`;
                                }
                                if (this.print_data.house_amount > 0)
                                    first_tbl +=
                                        `<td>${e?.house_amount > 0 ? e?.house_amount?.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : ''}</td>`
                                // else
                                //     first_tbl += `<td></td>`

                                if (this.print_data.type != "commission_principle")
                                    first_tbl +=
                                        `<td>${e?.amount > 0 ? e?.amount?.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : ''}</td>`;
                                if (this.print_data.parent_id || this.print_data?.service_fee_percent) {
                                    first_tbl += `<td > ${e?.service_fee_percent > 0 ? (e?.service_fee_percent + '%') : ''}</td><td>`;
                                    if (e?.household)
                                        first_tbl +=
                                            ` ${e?.amount > 0 ? ((e?.amount * e?.service_fee_percent) / 100)?.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : ''}</td>`;
                                    else
                                        first_tbl +=
                                            ` ${e?.house_amount > 0 ? ((e?.house_amount * e?.service_fee_percent) / 100)?.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : ''}</td>`;
                                }
                                if (this.print_data.type == "commission_principle")
                                    first_tbl +=
                                        `<td>${e?.amount > 0 ? (parseFloat(e?.amount) + parseFloat(e.total_amount))?.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : ''}</td>`;
                                first_tbl += `</tr>`;
                            });
                            first_tbl +=
                                `<tr class="table-data">
                                            <td colspan="${(this.print_data.household && this.print_data.invoice_date && (this.print_data.location || this.print_data.purchase_order)) ? 4 : ((!this.print_data.household && this.print_data.invoice_date && (this.print_data.location || this.print_data.purchase_order)) || (this.print_data.household && !this.print_data.invoice_date && (this.print_data.location || this.print_data.purchase_order)) || (this.print_data.household && this.print_data.invoice_date && !(this.print_data.location || this.print_data.purchase_order)) ? 3 : 2)}">Total (${this.print_data.currency})</td>`;
                            // if (this.print_data.household || this.print_data.invoice_date || this.print_data
                            //     .location) {
                            //     first_tbl += `<td></td>`;
                            // }
                            if (this.print_data.house_amount > 0)
                                first_tbl += `<td></td>`;

                            if (this.print_data.type != "commission_principle")
                                first_tbl +=
                                    ` <td>${this.total > 0 ? (this.total)?.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : 0}</td>`;

                            if (this.print_data.parent_id || this.print_data?.service_fee_percent) {
                                first_tbl +=
                                    `<td colspan="2" >
                                    ${this.total_commision > 0 ? (this.total_commision?.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")) : 0}</td>`;
                            }
                            if (this.print_data.type == "commission_principle")
                                first_tbl +=
                                    ` <td>${this.total > 0 ? ((parseFloat(this.total) + parseFloat(this.total_commision)))?.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : 0}</td>`;

                            first_tbl += `</tr>`;

                            if (this.extra_amount > 0) {
                                first_tbl +=
                                    `<tr class="table-data">
                                            <td colspan="${(this.print_data.household && this.print_data.invoice_date && (this.print_data.location || this.print_data.purchase_order)) ? 4 : ((!this.print_data.household && this.print_data.invoice_date && (this.print_data.location || this.print_data.purchase_order)) || (this.print_data.household && !this.print_data.invoice_date && (this.print_data.location || this.print_data.purchase_order)) || (this.print_data.household && this.print_data.invoice_date && !(this.print_data.location || this.print_data.purchase_order)) ? 3 : 2)}">Exchange Currency (${this.print_data.exchange_currency})</td>`;

                                // if(this.print_data.house_amount>0)
                                //     first_tbl += `<td></td>`;
                                if (this.print_data.house_amount > 0) {
                                    if (!(this.print_data.parent_id || this.print_data?.service_fee_percent))
                                        first_tbl += `<td>${this.print_data?.exchange_rate_second > 0 ? this.print_data?.exchange_rate_second : ''}</td>`;
                                    else
                                        first_tbl += `<td></td>`;
                                }
                                if (this.print_data.parent_id || this.print_data?.service_fee_percent) {
                                    first_tbl +=
                                        `<td colspan="2" >${this.print_data?.exchange_rate_second ? this.print_data?.exchange_rate_second : ''}</td>`;
                                }
                                first_tbl += `<td>${this.total > 0 ? ((this.total + (this.total_commision ?? 0)) / (this.print_data.exchange_rate_second))?.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : ''}</td>
                                            `;
                            }
                            // if(this.print_data.type=="commission_principle")
                            //     first_tbl +=` <td>${ (parseFloat(this.total)+parseFloat(this.total_commision))?.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") }</td>`;
                            first_tbl += `</tr>`;
                            first_tbl += `<tr id="table-description"><td colspan="5"><div id="detial_para">`;
                            first_tbl += (this.print_data.details == null) ? '' : this.print_data.details.trim();
                            first_tbl += `</div></td></tr></table>`;

                            main_tbl.innerHTML = first_tbl;

                        }).then(() => {
                        printJS({
                            printable: 'content_print_report',
                            type: 'html',
                            style: `
                            @media print {
                                @page {
                                    margin: 5px auto !important;
                                    left:0 !important;
                                size: auto;
                                }
                                #content_print_report {
                                    height:100% !important;
                                    position: relative;



                                }
                                p {
                                    line-height: 0.3 !important;
                                }
                                #detial_para, #detial_para * {
                                margin: 0; /* Remove margin for parent and sub child elements */
                                padding: 0; /* Remove padding for parent and sub child elements */
                                }
                            /* // #main-content:before{
                            //     // content: ' ';
                            //     display: block;
                            //     position: static;
                            //     left: 0;
                            //     top: 0;
                            //     width: 100%;
                            //     height: 100%;
                            //     opacity: 0.2;
                            //     background-image: url("{{ asset('mark.jpg') }}");
                            //     background-repeat: no-repeat;
                            //     // background-position: 50% 0;
                            //     // background-size: cover;
                            //     // background-image: url("{{ asset('mark.jpg') }}") !important;
                            //     // height:98% !important;
                            //     background-size: 500px 500px;
                            //     background-position: center;
                            //     // background-repeat: no-repeat;
                            //     // position: static;
                            //     // z-index: -1;
                            //     justify-content: center;
                            //     align-content: center;
                            //     // opacity: 0.2;
                            // } */
                            #content_print_report:after {
                                position: relative;
                                width: 95% !important;
                                height: 95% !important;
                                left: 0;
                                top: 0;
                                opacity: 1;
                                margin: 5px auto !important;

                            }

                            #main-content:before {
                                background-image: url("{{ asset('mark.jpg') }}");
                                background-repeat: no-repeat;
                                opacity: 0.2;
                                background-size: 500px 500px;
                                background-position: center !important;
                                align-content: center;
                                text-align: center;
                                content: ' ';
                                display: block;
                                position: static;
                                left: 0 !important;
                                top: 300px !important;
                                width: 100%;
                                height: 100%;
                                /* // opacity: 0.6; */

                            }

                            #mark {
                                top: 60% !important;
                                left:600px;
                                width: 100%;
                                height: auto;
                                opacity: 0.3;
                                lign-content: center;
                            }

                            #main-tbl {
                                /* // margin: 0 auto; */
                                width: 100% important;
                                position: relative;
                                /* // border: 1px solid red !important; */

                            }

                            table#table-container {
                                overflow: hidden;
                                position: absolute;
                                /* // border-radius: 5px !important; */
                                width: 95% !important;
                                /* // margin: 10 auto !impotant; */
                                height: 100% !important;
                                font-family: sans-serif;
                                border-collapse: collapse;
                                border: 1px solid black;
                                border: none;
                                /* // top:30% !important; */
                                /* // padding-top: 100px; */

                            }

                            table tr th {
                                border-collapse: collapse;
                            }

                            /* // #title th{
                            //     border: 1px solid black;
                            //     // height:5px !important;
                            //     font-size: large !important;
                            //     background-color: lightgray;
                            // } */
                            #invoice {
                                /* // height: 70px !important; */
                                text-align: center;
                                /* // padding-top:20px; */
                            }

                            #organization {
                                text-align: left;
                            }

                            #invoice-date {
                                height: 70px !important;
                                text-align: right;
                            }

                            #main-table {
                                border: 1px solid black;
                                /* // bordNer-collapse:collapse; */
                            }

                            #table-grant {
                                padding-bottom: 10px !important;
                            }

                            .table-header th {
                                border: 1px solid black;
                                background-color: lightgray;
                            }

                            .td {
                                border: 1px solid black;
                                text-align: center;
                            }

                            .no {
                                width: 10% !important;
                            }

                            #table-container td,
                            #table-container th {
                                border: 1px solid #ddd;
                                padding: 4px;
                                text-align: center;

                            }

                            #table-container tr:nth-child(even) {
                                background-color: #f2f2f2;
                            }

                            #table-container th {
                                /* // padding-top: 12px !important;
                                // padding-bottom: 12px !important;*/
                                color: white !important;
                                background-color: #000000 !important;
                                text-align: center !important;
                            }

                            #table-container2 {
                                width: 98% !important;
                            }

                            #table-header {
                                padding-top: 12px !important;
                                padding-bottom: 12px !important;
                                background-color: #000000 !important;
                                color: white !important;
                                text-align: center !important;
                            }

                            #table-description td {
                                text-align: left;
                                padding-top: 50px !important;
                                // padding-bottom: 100px !important;
                                border: none !important;
                                background-color: #fff !important;

                            }

                            #auth td {
                                /* // padding-bottom: 35% !important; */
                            }

                            #table-footer {
                                /* // border-top:1px solid black; */
                                position: fixed;
                                bottom: 0;
                                /* // right: 0 !important;
                                // left: 0; */
                                margin: auto !important;
                                width: 100% !important;
                                /* // border: 1px solid red !important; */
                                text-align: center !important;
                                padding-top: 10px;
                            }

                            .img_header {
                                width: 100% !important;
                                /* // left:0 !important;
                                // position:static; */
                                height: 100% !important;
                                position: relative;
                            }

                            .img_header1 {
                                position: relative;
                                width: 100% !important;
                                top: 0;
                                left: 0 !important;
                                right: 0 !important;
                                height: 100%;
                                /* // padding-bottom: 100px !important; */
                            }

                            #title {
                                position: relative;
                                top: 0;
                                left: 0 !important;
                                right: 0 !important;
                                width: 100% !important;
                                height: 12% !important;
                                /* // padding-bottom:30px; */
                            }
                            body{
                            -webkit-print-color-adjust:exact !important;
                            print-color-adjust:exact !important;
                            }
                            #date-no {
                                position: relative;
                                margin: 0;
                                display: inlie-block;
                                padding-bottom: 0 !important;
                            }

                            #in-date {
                                position: static;
                                top: 11.5% !important;
                                left: 22px;
                                /* // width: 5%; */
                                text-align: left;
                                font-size: 18px;
                            }

                            #in-no {
                                position: static;
                                top: 11.5% !important;
                                right: 10px;
                                /* // width: 5%; */
                                text-align: right;
                                font-size: 18px;
                            }

                            }`
                        });
                    })
                },
            }
        });
    </script>
    <style>
        .total__card {
            position: static;
            top: 15px;
            right: 15px;
        }


        @media screen and (max-width: 992px) {
            .total__card {
                position: static;
                top: 5px;
                right: 0;
            }
        }

        /* On screens that are 600px wide or less, make the columns stack on top of each other instead of next to each other */
        @media screen and (max-width: 600px) {
            .total__card {
                position: relative;
                top: -30px;
                right: 0;
            }
        }
    </style>
@endsection
