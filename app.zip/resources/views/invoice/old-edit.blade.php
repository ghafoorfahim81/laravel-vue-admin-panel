@extends('layouts.master')
@section('title', __('lang.edit').' '.__('lang.invoice'))
@section('css')
    <link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css"/>
    <link href="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}" rel="stylesheet" type="text/css"/>


@endsection
@section('content')
    <div class="page-content-wrapper" id="myapp" v-cloak>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <form action="{{route('invoice.update', $invoice->id)}}" @submit="handleSubmit($event)" method="post" id="userForm" enctype="multipart/form-data">
                            @csrf
                            @method('patch')
                            <div class="card-body" style="padding-bottom: 0px">
                                <div class="">
                                        <!-- <h4 class="header-title">@lang('lang.add') @lang('lang.order')</h4> -->
                                    <div class="row justify-content-center">
                                    <div class="col-xl-9 col-md-9 row">
                                        <div class="col-xl-4">
                                             <div class="form-group">
                                                <label for="">@lang('lang.invoice_number') 
                                                </label>
                                                <input type="number" name="invoice_number" class="form-control"
                                                       placeholder="@lang('lang.invoice_number')" value="{{$invoice->invoice_no}}">
                                                <span class="help-block rq-hint" >
                                                @{{errors.first('invoice_number')}}</span>
                                            </div>
                                        </div>
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.organization')
                                                </label>
                                                    <v-select :select-on-tab="true"
                                                              v-model="selected_company" 
                                                              label="name" 
                                                              :options="companies" placeholder="@lang('lang.selectCompany')"
                                                                >
                                                                <template v-slot:no-options="{ search, searching }">
                                                                    <template v-if="searching">
                                                                        @lang('lang.no_record_found_for') @{{search}}
                                                                    </template>
                                                                    <em class="v-select-search-hint"
                                                                        v-else>@lang('lang.type_to_search')</em>
                                                                </template>
                                                            </v-select>
                                                    <input type="hidden" name="company" :value="(selected_company == null) ? null : selected_company.id">
                                                </div>
                                            </div>
                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="">@lang('lang.date')
                                                    </label> 
                                                   <input type="date" name="date" class="form-control" id="email" data-vv-as="@lang('lang.date')"
                                                           placeholder="@lang('lang.date')" autocomplete="new-email" v-model="date">
                                                    <span class="help-block rq-hint">
                                                    @{{errors.first('date')}}</span>
                                                </div>
                                            </div>
                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="">@lang('lang.project')
                                                    </label>
                                                    <v-select :select-on-tab="true"
                                                      v-model="selected_project" 
                                                      label="name" 
                                                      :options="projects" placeholder="@lang('lang.selectProject')"
                                                        >
                                                        <template v-slot:no-options="{ search, searching }">
                                                            <template v-if="searching">
                                                                @lang('lang.no_record_found_for') @{{search}}
                                                            </template>
                                                            <em class="v-select-search-hint"
                                                                v-else>@lang('lang.type_to_search')</em>
                                                        </template>
                                                    </v-select>
                                                    <input type="hidden" name="project" :value="(selected_project == null) ? null : selected_project.id">

                                                </div>
                                            </div>
                                            <div class="col-xl-2">
                                                 <div class="form-group">
                                                    <label for="">@lang('lang.currency')
                                                    </label>
                                                    <v-select :select-on-tab="true"
                                                      v-model="selected_currency" 
                                                      label="code" 
                                                      :options="currencies" placeholder="@lang('lang.select_currency')"
                                                        >
                                                        <template v-slot:no-options="{ search, searching }">
                                                            <template v-if="searching">
                                                                @lang('lang.no_record_found_for') @{{search}}
                                                            </template>
                                                            <em class="v-select-search-hint"
                                                                v-else>@lang('lang.type_to_search')</em>
                                                        </template>
                                                    </v-select>
                                                    <input type="hidden" name="currency" :value="(selected_currency == null) ? null : selected_currency.code">
                                                </div>
                                            </div>
                                            <div class="col-xl-2">
                                                 <div class="form-group">
                                                    <label for="">@lang('lang.rate') 
                                                    </label>
                                                    <input type="text" name="exchange_rate" class="form-control"
                                                        v-model="exchange_rate"
                                                          autocomplete="new-password" 
                                                           data-vv-as="@lang('lang.password')"
                                                           placeholder="@lang('lang.rate')">
                                                    <span class="help-block rq-hint">
                                                    @{{errors.first('exchange_rate')}}</span>
                                                </div>
                                            </div>
                                            <div class="col-xl-4">
                                                 <div class="form-group">
                                                    <label for="">@lang('lang.vol_rep') 
                                                    </label>
                                                    <input type="text" name="vol_rep" class="form-control" 
                                                           placeholder="@lang('lang.vol_rep')" value="{{$invoice->vol_rep}}">
                                                    <span class="help-block rq-hint">
                                                    @{{errors.first('vol_rep')}}</span>
                                                </div>
                                            </div>
                                            <div class="col-xl-6">
                                                 <div class="form-group">
                                                    <label for="">@lang('lang.description') 
                                                    </label>
                                                    <textarea class="form-control" id="exampleFormControlTextarea1" name="desc" rows="2">{{$invoice->description}}</textarea>
                                                    <span class="help-block rq-hint">
                                                    @{{errors.first('ref_no')}}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- end of permission -->
                                   
                                    <div class="col-xl-3 col-md-3">
                                        <div class="w-full shadow-4 rounded-sm p-3 border">
                                                <div class="row justify-around">
                                                    <span class="text-xl col-7">Sub Total</span>
                                                    <span class="text-xl col text-end">@{{sub_total}} @{{ (selected_currency != null) ? selected_currency.symbol : null }}</span>
                                                </div>
                                                <div class="row justify-around">
                                                    <span class="text-xl col-7">Service Total</span>
                                                    <span class="text-xl col text-end">@{{total_service}} @{{ (selected_currency != null) ? selected_currency.symbol : null }}</span>
                                                </div>
                                                <br/>
                                                <hr class="p-0 m-0" />

                                                <div class="row justify-around">
                                                    <span class="font-weight-bold text-xl col-7">Grand Total</span>
                                                    <span class="font-weight-bold text-xl col text-end">@{{total_grant}} @{{ (selected_currency != null) ? selected_currency.symbol : null }}</span>
                                                </div>
                                                <hr class="p-0 m-0" />
                                                
                                            </div>
                                    </div>
                                    </div>
                                    <div class="table-responsive shadow-4 rounded-sm">
                                        <table class="table mb-0 ">
                                            <thead class="bg-light-blue-7 text-white">
                                                <tr>
                                                    <th class="text-center p-2">#</th>
                                                    <th class="p-2" style="width:300px">Item</th>
                                                    <th class="p-2">@lang('lang.location')</th>
                                                    <th class="p-2">@lang('lang.quantity')</th>
                                                    <th class="p-2">@lang('lang.house')</th>
                                                    <th class="p-2">@lang('lang.amount')</th>
                                                    <th class="p-2">@lang('lang.commission')</th>
                                                    <th class="p-2">@lang('lang.service_fee_percent')</th>
                                                    <th class="p-2">@lang('lang.service_fee_amount') @{{ (selected_currency != null) ? selected_currency.symbol : null }}</th>
                                                    <th class="text-center p-2">Total</th>
                                                    <th class="text-center p-2">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr v-for="(item, index) in items">
                                                    <th class="p-0 text-center border-right align-middle" scope="row">@{{++index}}</th>
                                                    <td class=" p-0 vue_dropdown border-right align-middle" > 
                                                        <v-select :select-on-tab="true"
                                                      v-model="item.item.selected_item"
                                                      @click.native="addRow(index)"
                                                      label="name"
                                                      
                                                      class="border border-white w-full"
                                                      :options="itemData" placeholder="@lang('lang.searchItem')"
                                                        >
                                                        <template v-slot:no-options="{ search, searching }">
                                                            <template v-if="searching">
                                                                @lang('lang.no_record_found_for') @{{search}}
                                                            </template>
                                                            <em class="v-select-search-hint"
                                                                v-else>@lang('lang.type_to_search')</em>
                                                        </template>
                                                    </v-select>
                                                    <input type="hidden" name="item_ids[]" :value="(item.item.selected_item == null) ? null : item.item.selected_item.id">
                                                    </td>
                                                    <td class="p-0 vue_dropdown border-right align-middle">
                                                        <v-select :select-on-tab="true"
                                                      v-model="item.item.selected_province"
                                                      @click.native="addRow(index)"
                                                      label="name"
                                                      
                                                      class="border border-white w-full"
                                                      :options="provinces" placeholder="@lang('lang.searchItem')"
                                                        >
                                                        <template v-slot:no-options="{ search, searching }">
                                                            <template v-if="searching">
                                                                @lang('lang.no_record_found_for') @{{search}}
                                                            </template>
                                                            <em class="v-select-search-hint"
                                                                v-else>@lang('lang.type_to_search')</em>
                                                        </template>
                                                    </v-select>
                                                    <input type="hidden" name="location[]" :value="(item.item.selected_province == null) ? null : item.item.selected_province.id">
                                                    </td>
                                                    <td class="p-0 border-right align-middle">
                                                        <input type="number" placeholder="quantity"  class="form-control border border-white" name="quantity[]" v-model="item.item.quantity">
                                                    </td>
                                                    <td class="p-0 border-right align-middle">
                                                        <input type="number" placeholder="household"  class="form-control border border-white" name="household[]" v-model="item.item.household">
                                                    </td>
                                                    <td class="p-0 border-right align-middle">
                                                        <input type="number" placeholder="amount"  class="form-control border border-white" name="amount[]" v-model="item.item.amount">
                                                    </td>
                                                    <td class="p-0 border-right align-middle">
                                                        <input type="number" placeholder="commission"  class="form-control border border-white" name="commission[]" v-model="item.item.commission">
                                                    </td>
                                                    <td class="p-0 border-right align-middle">
                                                        <input type="number"  class="form-control border border-white" name="service_fee_percent[]" v-model="item.item.percent">
                                                    </td>
                                                    <td class="p-0 border-right align-middle">
                                                        @{{ (((Number.parseFloat(item.item.amount) * Number.parseFloat(item.item.percent)) / 100) * Number.parseFloat(exchange_rate) ) || 0 }}
                                                    </td>
                                                    <td class="p-0 text-center align-middle">
                                                        @{{ (((Number.parseFloat(item.item.amount) * Number.parseFloat(item.item.percent)) / 100 ) + (Number.parseFloat(item.item.amount) * Number.parseFloat(item.item.household)) * exchange_rate ) || 0 }}
                                                    </td>
                                                    <td class="p-0 text-center align-middle"><i class="far fa-trash-alt" style="color:red"  v-on:click="deleteItem(index)"></i></td>
                                                </tr>
                                                 
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div class="card-footer text-right pr-0">
                                    <!-- <button class="btn btn-md btn-primary" type="submit">
                                        <span hidden id="btn-loading" class="spinner-border spinner-border-sm"
                                              user="status" aria-hidden="true"></span> @lang('lang.save')</button>
                                    <button class="btn btn-md btn-danger" type="reset">@lang('lang.reset')</button>
                                    <button class="btn btn-md btn-danger" type="button"
                                            onclick="location.href='{{route('user.index')}}'">@lang('lang.cancel')</button> -->
                                            
                                            <!-- <button type="submit" class="btn btn-info mr-0">
                                            Save Changes
                                            </button> -->

                                            <button class="btn btn-info" type="submit" >
                                                
                                            <!-- <span :class="spinner" class="  spinner-border-sm" role="status" aria-hidden="true"></span> -->
                                                <span class="ml-2">Save Invoice</span>
                                            </button>

                                </div>


                                <!-- Save-Banner Start -->
                                <nav class="navbar navbar-expand-lg py-0 navbar-light bg-dark fixed-top ">
                                <div>
                                            <a class="navbar-brand me-2" href="https://mdbgo.com/">
                                            <img
                                                src="https://mdbcdn.b-cdn.net/img/logo/mdb-transaprent-noshadows.webp"
                                                
                                                alt="MDB Logo"
                                                loading="lazy"
                                                style="margin-top: -1px;"
                                            />
                                            </a>

                                            </div>
                                    <!-- Container wrapper -->
                                    <div class="container">
                                        
                                        <!-- Navbar brand -->
                                           

                                        <!-- Toggle button -->
                                        <button
                                        class="navbar-toggler"
                                        type="button"
                                        data-mdb-toggle="collapse"
                                        data-mdb-target="#navbarButtonsExample"
                                        aria-controls="navbarButtonsExample"
                                        aria-expanded="false"
                                        aria-label="Toggle navigation"
                                        >
                                        <i class="fas fa-bars"></i>
                                        </button>

                                        <!-- Collapsible wrapper -->
                                        <div class="collapse navbar-collapse" id="navbarButtonsExample">
                                        <!-- Left links -->
                                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                                            <li class="nav-item">
                                            <a class="nav-link text-white text-xl" href="#">Unsaved Changes</a>
                                            </li>
                                        </ul>
                                        <!-- Left links -->

                                        <div class="d-flex align-items-center">
                                            <button type="button" onclick="location.href='{{route('user.index')}}'" class="btn btn-dark px-3 me-2">
                                            Cancel
                                            </button>
                                            
                                            <button type="reset" class="btn btn-dark px-3 me-2">
                                            Reset
                                            </button>
                                            <button class="btn btn-info" type="button" :disabled="disabled">
                                                
                                            <span :class="spinner" class="spinner-border-sm" role="status" aria-hidden="true"></span>
                                                <span class="ml-2">Save Changes</span>
                                            </button>
                                        </div>
                                        </div>
                                        <!-- Collapsible wrapper -->
                                    </div>
                                    <!-- Container wrapper -->
                                    </nav>
                                <!-- Save-Banner End -->
                        </form>
                    </div>

                </div>
                    
                </div>
                <!-- end row -->
            </div>
            <!-- end container-fluid -->
    </div>
        <!-- end page-content-wrapper -->


@endsection
@section('js')
    

    <script>
      
        var vm = new Vue({
            el: '#myapp',
            data: {
                spinner: 'spinner-border',
                disabled: true,
                projects:{!!$projects!!},
                companies:{!!$companies!!},
                currencies:{!!$currencies!!},
                provinces:{!!$provinces!!},
                selected_project:null,
                selected_company:null, 
                selected_currency:null, 
                items: [],
                itemData: [],
                exchange_rate: {!! $invoice->exchange_rate !!},
                form: {
        
                },
                date: "{{ $invoice->date}}"
            },
            mounted: function () {
                this.getItems();
                let invoice = {!! $invoice !!};
                this.selected_currency = this.currencies.find( cur => cur.code == invoice.currency);
                this.selected_company = this.companies.find( comp => comp.id == invoice.organization_id);
                this.selected_project = this.projects.find( proj => proj.id == invoice.project_id);
                // this.getHomeCurrency();
                // this.selectedCompany();
            },
            computed:{
                total_grant(){
                    let total = 0;
                    for(let x=0; x<this.items.length; x++){
                        
                        total += (((Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(this.items[x].item.percent)) / 100 ) +  Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(this.items[x].item.household)) || 0;
                    }

                    total = total * Number.parseFloat(this.exchange_rate) || 0;
                    return total;
                },
                 sub_total(){
                    let total = 0;
                    for(let x=0; x<this.items.length; x++){
                        
                        total += (Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(this.items[x].item.household)) || 0;
                    }

                    total = total * Number.parseFloat(this.exchange_rate) || 0;
                    return total;
                 },
                 total_service(){
                    let total = 0;
                    for(let x=0; x<this.items.length; x++){
                        
                        total += ((Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(this.items[x].item.percent)) / 100 ) || 0;
                    }

                    total = total * Number.parseFloat(this.exchange_rate) || 0;
                    return total;
                },
            },
            methods: {
                searchItems: _.debounce(function (e) {
                    axios.get("{{route('item.all') }}?" +
                        "type="+'item'
                    )
                    .then((res) => {
                        this.itemData = res.data;
                    });
                }, 200),
                getItems(){
                    axios.get("{{route('item.all') }}")
                        .then((res) => {
                            this.itemData = res.data;
                            let invoice_details = {!! $invoice_details !!};
                            let provinces = {!! $provinces !!};

                            for(let x=0; x< invoice_details.length; x++){
                                let item = this.itemData.find(it => it.id == invoice_details[x].item_id);
                                let province = provinces.find(it => it.id == invoice_details[x].location);
                                console.log('check item', item);
                                this.items.push({ item: {
                                        selected_item: item, 
                                        selected_province: province,
                                        quantity: invoice_details[x].quantity,
                                        household: invoice_details[x].household,
                                        amount: invoice_details[x].amount,
                                        commission: invoice_details[x].commission,
                                        percent: invoice_details[x].service_fee_percent
                                    } 
                                });
                            }

                            this.items.push({ item: {selected_item: null, selected_province: null, quantity: null, household: null ,amount: null, commission: null, percent: null} });
                        });
                },
                addRow(index){  
                  if (this.items[index + 1] == undefined) { 
                    this.items.push({ item: {selected_item: null, selected_province: null, quantity: null, household: null ,amount: null, commission: null, percent: null} });
                  }
                },
                deleteItem(index) {
                  if (this.items.length - 1 > 0) this.items.splice(index, 1);
                },
                /**
                 * handleSubmit
                 */
                handleSubmit(e, type = 'save') {
                    this.$validator.validate().then(valid => {

                        if (valid) {

                            let ids = [];
                            for (let i = 0; i < this.selected_role.length; i++) {
                                ids.push(this.selected_role[i].id)
                            }

                            $('#role_ids').val(ids);
                            document.getElementById('permission_id').value = selected_p;
                            e.preventDefault();
                            let url = (e.target.form == undefined) ? e.target.action : e.target.form.action;
                            let data = (e.target.form == undefined) ? $(e.target).serialize() : $(e.target.form).serialize();
                            data = new FormData(e.target.form);
                            toggleBlock(1);
                            axios.post(url, data)
                                .then(function (response) {
                                    toggleBlock(0);
                                    let message = "{{__('message.success')}}";
                                    if (response.data) {
                                        message = response.data.message;
                                    }
                                    alertify.success(message);
                                    if (type != 'save') {
                                        vm.defaultValue(e);
                                    } else {
                                        window.location.href = "{{route('user.index')}}";
                                    }
                                })
                                .catch(function (error) {
                                    toggleBlock(0);
                                    let warning = "{{__('message.error')}}";
                                    if (error.response.data) {
                                        if (error.response.data.message) {
                                            warning = error.response.data.message;
                                        }
                                        if ((error.response.status == 422) == true) {
                                            let my_error = error.response.data.errors;

                                            for (index in my_error) {

                                                alertify.error(my_error[index][0]);
                                            }

                                        }
                                    }

                                    alertify.error(warning);
                                })
                        }
                    });
                }
                /**
                 * this is used to set default value
                 */
            

           


            }
        });

    </script>

    <style>
        .vue_dropdown .vs__dropdown-toggle {
            border: none !important;
        }
    </style>

@endsection
