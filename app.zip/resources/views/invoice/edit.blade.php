@extends('layouts.master')
@section('title', __('lang.edit').' '.__('lang.invoice'))
@section('css')
    <link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css"/>
    <link href="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}" rel="stylesheet" type="text/css"/>
    <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css"/>
 
    <style>
        .right-drawer {
            position: absolute;
            top: 0;
            right: 0;
            width: 0;
            height: 110%;
            border-left: 1px solid whitesmoke;
            background: white;
            z-index: 200;
            transition: all 0.2s;
        }

        .drawer-mask {
            position: absolute;
            left: 0;
            top: 0;
            width: 0;
            height: 110%;
            background: #000;
            opacity: 0.3;
            z-index: 199;
        }
    </style>

@endsection
@section('content')
    <div class="page-content-wrapper" id="myapp" v-cloak>
        <div class="container-fluid">
            <div
                class="right-drawer"
                style="z-index: 1032; height:110%"
                :style="{
                    width: drawerVisible ? '20vw' : '0',
                    paddingLeft: drawerVisible ? '10px' : '0' }">
                <div class="modal-header">

                    <button type="button" class="btn btn-info w-100 d-flex justify-content-between">
                        <span><i class="fas fa-cog me-2 text-white"></i>General Settings</span>
                        <i class="fas fa-times me-2 text-white align-self-center" @click="drawerVisible = false"></i>
                    </button>

                </div>
                <div class="modal-body" style="overflow-y:auto">

                    <p class="text-left card-header bg-transparent">General</p>

                    <div v-for="(c,i) in control_room.fields">
                        <div class=" px-4 py-2 mb-2"
                             style="border-radius: 5px; box-shadow: rgba(17, 17, 26, 0.05) 0px 4px 16px, rgba(17, 17, 26, 0.05) 0px 8px 32px;">
                            <div class="form-check form-switch ml-3 row">
                                <input class="form-check-input" @change="saveSetting" v-model="c.value" type="checkbox"
                                       role="switch" id="flexSwitchCheckDefault"/>
                                <h6 class="fw-bold ml-2">@{{c.name}}</h6>
                            </div>
                        </div>
                    </div>

                    <p class="text-left card-header bg-transparent">Table</p>

                    <div v-for="(c,i) in control_room.table" class="w-100">
                        <div class=" px-4 py-2 mb-2"
                             style="border-radius: 5px; box-shadow: rgba(17, 17, 26, 0.05) 0px 4px 16px, rgba(17, 17, 26, 0.05) 0px 8px 32px;">
                            <div class="form-check form-switch ml-3 row">
                                <input class="form-check-input" @change="saveSetting" v-model="c.value" type="checkbox"
                                       role="switch" id="flexSwitchCheckDefault"/>
                                <h6 class="fw-bold ml-2">@{{c.name}}</h6>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
            <!-- We will make the mask fill the screen while the menu is visible. Because its z-index is 1 less than that of the menu, the menu will still be displayed on top of it -->
            <div class="drawer-mask" style="z-index: 1031;" :style="{
            width: drawerVisible ? '100vw' : '0',
            opacity: drawerVisible ? '0.6' : '0',
        }" @click="drawerVisible = false"></div>
        </div>
        <!-- Tabs navs -->
        <div class="row justify-between  px-4">
            <ul class="nav nav-tabs mb-3 shadow-xl w-auto col-md-6 col-xl-6" id="ex1" role="tablist">
                <li class="nav-item" role="presentation">
                    <a
                        class="nav-link active"
                        id="ex1-tab-1"
                        data-mdb-toggle="tab"
                        href="#ex1-tabs-1"
                        role="tab"
                        aria-controls="ex1-tabs-1"
                        aria-selected="true"
                    >Home</a
                    >
                </li>
                <li class="nav-item" role="presentation">
                    <a
                        class="nav-link"
                        id="ex1-tab-2"
                        data-mdb-toggle="tab"
                        href="#ex1-tabs-2"
                        role="tab"
                        aria-controls="ex1-tabs-2"
                        aria-selected="false"
                    >Attachments</a
                    >
                </li>

            </ul>
            <div class="col-md-6 col-xl-6" style="text-align: -webkit-right; align-self: center;">

                <button @click="drawerVisible = true" type="button" class="btn btn-info" style="border-radius: 100px;">
                    <i class="fas fa-cog"></i>
                </button>
            </div>

        </div>
        <!-- Tabs navs -->

        <!-- Tabs content -->
        <form action="{{route('invoice.update', $invoice->id)}}" method="post" id="userForm"
              enctype="multipart/form-data">
            <div class="tab-content" id="ex1-content">
                <div
                    class="tab-pane fade show active"
                    id="ex1-tabs-1"
                    role="tabpanel"
                    aria-labelledby="ex1-tab-1"
                >
                    @csrf
                    @method('patch')
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="card">

                                <div class="card-body" style="padding-bottom: 0px">
                                    <div class="">
                                        <div class="row justify-content-center">
                                            <div class="col-xl-9 col-md-9 row">
                                                <div class="col-xl-4" v-show="showFields('invoice_number')">
                                                    <div class="form-group">
                                                        <label for="">@lang('lang.invoice_number')
                                                        </label>
                                                        <input type="number" name="invoice_number" class="form-control"
                                                               v-model="invoice_data.invoice_number"
                                                               autocomplete="new-password"
                                                               data-vv-as="@lang('lang.password')"
                                                               placeholder="@lang('lang.invoice_number')"
                                                               value="{{$invoice->invoice_no}}">
                                                        <span class="help-block rq-hint">
                                                            @{{errors.first('invoice_number')}}
                                                        </span>
                                                        <input type="hidden" name="is_cashe" :value="type">
                                                        <input type="hidden" name="cash_id" :value="cash_id">
                                                    </div>
                                                </div>
                                                <div class="col-xl-4" v-show="showFields('organization')">
                                                    <div class="form-group">
                                                        <label for="">@lang('lang.organization')
                                                        </label>
                                                        <input type="text" value="{{$company->name}}" class="form-control"
                                                               autocomplete="new-password"
                                                               disabled
                                                               placeholder="@lang('lang.invoice_number')">
                                                        <input type="hidden" name="company"
                                                               value="{{$company->id}}">
                                                    </div>
                                                </div>
                                                <div class="col-xl-4" v-show="showFields('date')">
                                                    <div class="form-group">
                                                        <label for="">@lang('lang.date')
                                                        </label>
                                                        <input type="date" name="date" class="form-control" id="email"
                                                               data-vv-as="@lang('lang.date')"
                                                               placeholder="@lang('lang.date')" autocomplete="new-email"
                                                               v-model="invoice_data.date">
                                                        <span class="help-block rq-hint">
                                                            @{{errors.first('date')}}
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-xl-4" v-show="showFields('project')">
                                                    <div class="form-group">
                                                        <label for="">@lang('lang.project')
                                                        </label>
                                                        <v-select :select-on-tab="true"
                                                                  v-model="selected_project"
                                                                  label="name"
                                                                  :options="projects"
                                                                  @input="setProvince()"
                                                                  placeholder="@lang('lang.selectProject')"
                                                        >
                                                            <template v-slot:no-options="{ search, searching }">
                                                                <template v-if="searching">
                                                                    @lang('lang.no_record_found_for') @{{search}}
                                                                </template>
                                                                <em class="v-select-search-hint"
                                                                    v-else>@lang('lang.type_to_search')</em>
                                                            </template>
                                                        </v-select>
                                                        <input type="hidden" name="project"
                                                               :value="(selected_project == null) ? null : selected_project.id">
                                                        <input type="hidden" name="location_id"
                                                               :value="(selected_project == null) ? null : selected_project.location_id">

                                                    </div>
                                                </div>
                                                <div class="col-xl-4" v-show="showFields('currency')">
                                                    <div class="form-group">
                                                        <label for="">@lang('lang.currency')
                                                        </label>
                                                        <v-select :select-on-tab="true"
                                                                  v-model="selected_currency"
                                                                  label="code"
                                                                  :options="currencies"
                                                                  placeholder="@lang('lang.select_currency')"
                                                        >
                                                            <template v-slot:no-options="{ search, searching }">
                                                                <template v-if="searching">
                                                                    @lang('lang.no_record_found_for') @{{search}}
                                                                </template>
                                                                <em class="v-select-search-hint"
                                                                    v-else>@lang('lang.type_to_search')</em>
                                                            </template>
                                                        </v-select>
                                                        <input type="hidden" name="currency"
                                                               :value="(selected_currency == null) ? null : selected_currency.code">
                                                    </div>
                                                </div>
                                                <div class="col-xl-4" v-show="showFields('exchange_rate')">
                                                    <div class="form-group">
                                                        <label for="">@lang('lang.rate')
                                                        </label>
                                                        <input type="number" name="exchange_rate" class="form-control"
                                                               v-model="exchange_rate"
                                                               autocomplete="new-password"
                                                               data-vv-as="@lang('lang.password')"
                                                               placeholder="@lang('lang.rate')"
                                                               @input="rateChanged">
                                                        <span class="help-block rq-hint">
                                        @{{errors.first('exchange_rate')}}</span>
                                                    </div>
                                                </div>
                                                <div class="col-xl-4" v-show="showFields('currency')">
                                                    <div class="form-group">
                                                        <label for="">@lang('lang.exchange_currency')
                                                        </label>
                                                        <v-select :select-on-tab="true"
                                                                  v-model="exchange_currency"
                                                                  label="code"
                                                                  :options="currencies"
                                                                  placeholder="@lang('lang.select_currency')"
                                                        >
                                                            <template v-slot:no-options="{ search, searching }">
                                                                <template v-if="searching">
                                                                    @lang('lang.no_record_found_for') @{{search}}
                                                                </template>
                                                                <em class="v-select-search-hint"
                                                                    v-else>@lang('lang.type_to_search')</em>
                                                            </template>
                                                        </v-select>
                                                        <input type="hidden" name="exchange_currency"
                                                               :value="(exchange_currency == null) ? null : exchange_currency.code">
                                                    </div>
                                                </div>
                                                <div class="col-xl-4" v-show="showFields('exchange_rate')">
                                                    <div class="form-group">
                                                        <label for="">@lang('lang.exchange_rate')
                                                        </label>
                                                        <input type="number" name="exchange_rate_second" class="form-control"
                                                               v-model="!exchange_currency ? null : exchange_currency.rate"
                                                               placeholder="@lang('lang.rate')">
                                                        <span class="help-block rq-hint">
                                        @{{errors.first('exchange_rate')}}</span>
                                                    </div>
                                                </div>
                                                <div class="col-xl-4" v-show="showFields('vol_rep')">
                                                    <div class="form-group">
                                                        <label for="">@lang('lang.vol_rep')
                                                        </label>
                                                        <input type="text" name="vol_rep" class="form-control"
                                                               v-model="invoice_data.vol_rep"
                                                               autocomplete="new-password"
                                                               data-vv-as="@lang('lang.password')"
                                                               placeholder="@lang('lang.vol_rep')">
                                                        <span class="help-block rq-hint">
                                        @{{errors.first('vol_rep')}}</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- end of permission -->

                                            <div class="col-xl-3 col-md-3" v-show="showFields('sub_total')">
                                                <div class="w-full shadow-4 rounded-sm p-3 border">
                                                    <div class="row justify-around">
                                                        <span class="text-xl col-7">Sub Total</span>
                                                        <span class="text-xl col text-end">@{{sub_total.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}} @{{ (selected_currency != null) ? selected_currency.symbol : null }}</span>
                                                    </div>
                                                    <div class="row justify-around">
                                                        <span class="text-xl col-7">Service Total</span>
                                                        <span class="text-xl col text-end">@{{total_service.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}} @{{ (selected_currency != null) ? selected_currency.symbol : null }}</span>
                                                    </div>
                                                    <br/>
                                                    <hr class="p-0 m-0"/>

                                                    <div class="row justify-around">
                                                        <span class="font-weight-bold text-xl col-7">Grand Total</span>
                                                        <span class="font-weight-bold text-xl col text-end">@{{total_grant.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}} @{{ (selected_currency != null) ? selected_currency.symbol : null }}</span>
                                                    </div>
                                                    <hr class="p-0 m-0"/>

                                                </div>
                                                <div class="col-xl-12">
                                                    <div class="form-group"> 
                                                        <label for="">Show project in print</label>
                                                        <input type="checkbox" name="is_show" v-model="is_show">
                                                    </div>
                                                </div>
                                                <div class="col-xl-12">
                                                    <div class="form-group"> 
                                                        <label for="">Principle and commission</label>
                                                        <input type="checkbox" name="p_c" @click="principleCommission" v-model="principle_commission">
                                                    </div>
                                                </div>
                                                <div class="col-xl-12">
                                                    <div class="form-group">
                                                        <label for="">@lang('lang.Commision')</label><br/>
                                                        <input type="checkbox" v-model="is_comission" @click="changeValue" id="check-commision">
                                                    </div>
                                                </div>
                                                <div class="col-xl-12" v-show="showFields('description')">
                                                    <div class="form-group" v-show="is_comission">
                                                        <label for="">@lang('lang.invoice')
                                                        </label>
                                                        <v-select :select-on-tab="true"
                                                                  @input="setInvoice()"
                                                                  v-model="selected_invoice"
                                                                  label="invoice"
                                                                  :options="invoices"
                                                                  placeholder="@lang('lang.invoice')"
                                                        >
                                                            <template v-slot:no-options="{ search, searching }">
                                                                <template v-if="searching">
                                                                    @lang('lang.no_record_found_for') @{{search}}
                                                                </template>
                                                                <em class="v-select-search-hint"
                                                                    v-else>@lang('lang.type_to_search')</em>
                                                            </template>
                                                        </v-select>
                                                    </div>
                                                </div>
                                                <input type="hidden" name="parent_id"
                                                       :value="(selected_invoice == null) ? null : selected_invoice.id">
                                            </div>
                                        </div>
                                        <div class="row justify-content-center">
                                            <div class="col-xl-6" v-show="showFields('description')">
                                                <div class="form-group">
                                                    <label for="">@lang('lang.description')</label>
                                                    <textarea id="elm1" name="desc">@{{invoice_data.description}}
                                                    </textarea>
                                                    <span class="help-block rq-hint">
                                                        @{{errors.first('desc')}}
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="col-xl-6" v-show="showFields('purpose')">
                                                <div class="form-group">
                                                    <label for="">@lang('lang.purpose')
                                                    </label>

                                                    <textarea class="form-control" name="purpose" rows="4">@{{invoice_data.purpose}}
                                                    </textarea>
                                                    <span class="help-block rq-hint">
                                                        @{{errors.first('purpose')}}
                                                    </span>
                                                </div>
                                            </div> 
                                        </div>
                                        <input type="hidden" name="has_location" :value="showTable('location')">
                                        <input type="hidden" name="has_amount" :value="showTable('amount')">
                                        <input type="hidden" name="check_principle" :value="principle_commission">
                                        <input type="hidden" v-model="is_comission" name="is_comission">
                                        <div class="table-responsive shadow-4 rounded-sm">
                                            <table class="table mb-0 ">
                                                <thead class="bg-light-blue-7 text-white">
                                                <tr>
                                                    <th v-show="showTable('no')" class="text-center p-2">#</th>
                                                    <th v-show="showTable('location')" style="width:200px"
                                                        class="p-2">@lang('lang.location')</th>
                                                    <th v-show="showTable('description') && showTable('location')" class="p-2">@lang('lang.description')</th>
                                                    <th v-show="showTable('date')" class="p-2">@lang('lang.date')</th>
                                                    <th v-show="showTable('household')" class="p-2">@lang('lang.house')</th>
                                                    <th v-show="showTable('amount')"
                                                        class="p-2">@lang('lang.amount') @{{
                                                        (selected_currency != null) ? selected_currency.symbol : null }}</th>
                                                    <th v-show="show_subtotal"
                                                        class="p-2">@lang('lang.total') @{{
                                                        (selected_currency != null) ? selected_currency.symbol : null }}</th>
                                                    <th v-show="showTable('service_fee_percent')"
                                                        class="p-2">@lang('lang.service_fee_percent')</th>
                                                    <th v-show="showTable('service_fee_amount-not')"
                                                        class="p-2">@lang('lang.service_fee_amount') @{{
                                                        (selected_currency != null) ? selected_currency.symbol : null }}
                                                    </th>
                                                    <th v-show="showTable('total')" class="text-center p-2">@{{ (is_comission || principle_commission) ? 'Commission' : 'Total' }} @{{
                                                        (selected_currency != null) ? selected_currency.symbol : null }}</th>
                                                    <th v-if="principle_commission" class="text-center p-2">Grand Total</th>
                                                    <th v-show="showTable('action')" class="text-center p-2">Action</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr v-for="(item, index) in items">
                                                    <th v-show="showTable('no')"
                                                        class="p-0 text-center border-right align-middle" scope="row">
                                                        @{{++index}}
                                                    </th>
                                                    <td v-show="showTable('location')"
                                                        class="p-0 vue_dropdown border-right align-middle">
                                                        <v-select :select-on-tab="true"
                                                                  v-model="item.item.selected_province"
                                                                  @click.native="addRow(index)"
                                                                  label="name"

                                                                  class="border border-white w-full"
                                                                  :options="provinces"
                                                                  placeholder="@lang('lang.searchLoaction')"
                                                        >
                                                            <template v-slot:no-options="{ search, searching }">
                                                                <template v-if="searching">
                                                                    @lang('lang.no_record_found_for') @{{search}}
                                                                </template>
                                                                <em class="v-select-search-hint"
                                                                    v-else>@lang('lang.type_to_search')</em>
                                                            </template>
                                                        </v-select>
                                                        <input type="hidden" name="location[]"
                                                               :value="(item.item.selected_province == null) ? null : item.item.selected_province.id">
                                                    </td>
                                                    <td v-show="showTable('description') && showTable('location')"
                                                                    class="p-0 border-right align-middle">
                                                                    <input @input="addRow(index)" type="text" placeholder="@lang('lang.description')"
                                                                           class="form-control border border-white"
                                                                           name="purchase_order[]"
                                                                           v-model="item.item.purchase_order">
                                                                </td>
                                                    <td v-show="showTable('date')"
                                                        class="p-0 border-right align-middle">
                                                        <input type="text" placeholder="@lang('lang.date')"
                                                               class="form-control border border-white"
                                                               name="date_d[]"
                                                               v-model="item.item.date">
                                                    </td>
                                                    <td v-show="showTable('household')"
                                                        class="p-0 border-right align-middle">
                                                        <input type="number" placeholder="@lang('lang.house')"
                                                               class="form-control border border-white"
                                                               name="household[]"
                                                               @input="setHousehold(index, item.item.household)"
                                                               v-model="item.item.household">
                                                    </td>
                                                    <td v-show="showTable('amount')"
                                                        class="p-0 border-right align-middle">
                                                        <input type="number" placeholder="amount"
                                                               class="form-control border border-white"
                                                               v-model="item.item.show_amount"
                                                               @input="setAmount(index, item.item.show_amount)">
                                                        <input type="hidden" name="amount[]" :value="item.item.amount" />
                                                    </td>
                                                    <td v-show="show_subtotal"
                                                        class="p-0 border-right align-middle" v-if="principle_commission">
                                                        <input type="number" placeholder="total"
                                                               class="form-control border border-white" name="total_priciple[]"
                                                               v-model="item.item.principle_commision"
                                                               @input="principleCommissionTotal(index, item.item.principle_commision)">
                                                    </td>
                                                    <td v-show="show_subtotal"
                                                        class="p-0 border-right align-middle" v-else>
                                                        @{{(type == 'cache') ? item.item.amount : ((item.item.amount > 0) ? item.item.amount * item.item.household : item.item.row_total)}}
                                                    </td>
                                                    <td v-show="showTable('service_fee_percent')"
                                                        class="p-0 border-right align-middle">
                                                        <input type="number" class="form-control border border-white"
                                                               name="service_fee_percent[]"
                                                               @input="setServiceFee(index, item.item.percent)"
                                                               v-model="item.item.percent">
                                                        <input type="hidden" name="service_amount[]" v-model="item.item.service_amount" />
                                                    </td>
                                                    <td v-show="showTable('service_fee_amount-not')"
                                                        class="p-0 border-right align-middle">

                                                        <input type="number" class="form-control border border-white"
                                                               v-model="item.item.service_amount"
                                                                disabled>
                                                    </td>
                                                    <td v-show="showTable('total')"
                                                        class="p-0 text-center align-middle">

                                                        <input type="number" class="form-control border border-white"
                                                               @input="setTotalAmount(index, item.item.row_total)"
                                                               v-model="item.item.row_total" name="total[]">
                                                    </td>
                                                    <td v-if="principle_commission" class="p-0 text-center align-middle"> @{{parseFloat(item.item.row_total) + parseFloat(item.item.principle_commision)}}</td>
                                                    <td v-show="showTable('action')"
                                                        class="p-0 text-center align-middle"><i class="far fa-trash-alt" v-on:click="deleteItem(index)"></i>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="10" style="text-align:right;padding: 10px;font-size: 17px;"> 
                                                        <strong>Total: @{{exchange_total.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}} @{{ (exchange_currency != null) ? exchange_currency.symbol : null }}</strong>
                                                    </td>
                                                </tr>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->
                    </div>
                </div>
                <div class="tab-pane fade" id="ex1-tabs-2" role="tabpanel" aria-labelledby="ex1-tab-2">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="card">
                                <div class="card-body" style="padding-bottom: 0px">
                                    <div class="">

                                        <div class="table-responsive shadow-4 rounded-sm">
                                            <table class="table mb-0 ">
                                                <thead class="bg-light-blue-7 text-white">
                                                <tr>
                                                    <th class="text-center p-2">#</th>

                                                    <th class="p-2">Title</th>
                                                    <th class="text-center p-2">File</th>
                                                    <th class="text-center p-2">Attachment</th>
                                                    <th class="text-center p-2">Action</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr v-for="(item, index) in attachments">
                                                    <th class="p-0 text-center border-right align-middle" scope="row">
                                                        @{{++index}}
                                                    </th>


                                                    <td class="p-0 border-right align-middle">
                                                        <input type="text" @click="addAttachment(index)"
                                                               placeholder="Title" v-model="item.title"
                                                               class="form-control border border-white" name="title[]">
                                                    </td>
                                                    <td>
                                                        @{{item.file}}
                                                        <input type="hidden" name="old_file[]" :value="item.main_name">
                                                    </td>
                                                    <td class="p-0 border-right align-middle">
                                                        <input type="file" class="form-control-sm" name="attach_file[]"
                                                               id="customFile"/>
                                                    </td>

                                                    <td v-show="showTable('action')"
                                                        class="p-0 text-center align-middle"><i class="far fa-trash-alt"
                                                                                                style="color:red"
                                                                                                v-on:click="deleteAttachment(index)"></i>
                                                    </td>
                                                </tr>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card-footer bg-white text-right pr-0">
                            <button class="btn btn-info" type="submit" @click="sendForm">
                                <span class="ml-2">Save Invoice</span>
                            </button>
                        </div>
                        <!-- end row -->
                    </div>
                </div>
        </form>
    </div>
    <!-- Tabs content -->

    <!-- end container-fluid -->
    </div>
    <!-- end page-content-wrapper -->

@endsection
@section('js')
    <!--tinymce js-->
        <script src="{{ asset('assets/libs/tinymce/tinymce.min.js') }}"></script>

        <!--ck editor js-->
        <script src="{{ asset('assets/libs/ckeditor4/ckeditor.js') }}"></script>

        <!-- init js -->
        <script src="{{ asset('assets/js/pages/form-editor.init.js') }}"></script>
    <script> 

        var vm = new Vue({
            el: '#myapp',
            data: {
                invoice_data:{
                    invoice_number: null,
                    date: "<?php echo date('Y-m-d'); ?>",
                    vol_rep: null,
                    description: `{!! $invoice_desc !!}`,
                    purpose: `{!! $invoice_propuse !!}`
                },
                check_commission: true,
                principle_commission: false,
                is_show: false,
                show_subtotal: false,
                invoices: {!! $invoices !!},
                selected_invoice: null,
                is_comission: false,
                drawerVisible: false,
                spinner: 'spinner-border',
                disabled: true,
                projects: {!!$projects!!},
                currencies: {!!$currencies!!},
                provinces: {!!$provinces!!},
                selected_province: null,
                selected_project: null,
                selected_currency: null,
                exchange_rate: {!! $invoice->exchange_rate !!},
                exchange_currency: null,
                date: null,
                attachments: [],
                items: [],
                itemData: [],
                form: {},
                control_room: {
                    fields: null,
                    table: null
                },
                type: 'no-cashe',
                cash_id: "",
                disable_amount:false,
                is_default_service_fee: false,
                check_amount: 0,
                check_house_hold: true,
            }, 
            mounted: function () {
                
                let invoice = {!! $invoice !!};
                let paid_amount = {!! $paid_amount !!};
                this.invoice_data.invoice_number = invoice.invoice_no;
                this.invoice_data.date = (invoice?.date).split(' ')[0];
                this.invoice_data.vol_rep = invoice.vol_rep;
                this.invoice_data.description = invoice.description;
                this.invoice_data.purpose = invoice.purpose;
                this.is_show = invoice.is_show;
                this.attachments = {!! $attachments !!};
                this.attachments.push({title: null, file: null, main_name: null});
                this.selected_currency = this.currencies.find(cur => cur.code == invoice.currency);
                this.exchange_currency = this.currencies.find(cur => cur.code == invoice.exchange_currency);

                if(this.exchange_currency){
                    this.exchange_currency.rate = invoice.exchange_rate_second;
                }
                
                let invoice_details = {!! $invoice_details !!};
                let provinces = {!! $provinces !!};
                
                if(invoice.type == 'commission_principle'){
                    this.principle_commission = true;
                    this.show_subtotal = true;
                    this.selected_project = this.projects.find(e=>e.id==invoice.project_id) || null; 
                } else {
                    
                    this.selected_invoice = this.invoices.find(inv => inv.id == invoice.parent_id);
                    if (this.selected_invoice) {
                        this.is_comission = true;
                        this.check_commission = false;
                    }
    
                    if(invoice.type == 'cashe'){
    
                        this.type = 'cache';
                        this.selected_project = null;
                        this.cash_id = invoice.project_id;
                        this.is_default_service_fee = true;
    
                    } else {
    
                        this.selected_project = this.projects.find(e=>e.id==invoice.project_id) || null;
                    }
                    
                    if(invoice.type == 'commission'){
                        this.show_subtotal = true; 
                        this.is_comission = true;
                    }
                }

                
                for (let x = 0; x < invoice_details.length; x++) {
                    
                    let province = provinces.find(it => it.id == invoice_details[x].location);
                    if(this.principle_commission){
                        let household = (invoice_details[x].household > 0) ? invoice_details[x].household : 1;
                        
                        if(invoice_details[x].household != 0 && this.check_house_hold){
                            this.check_house_hold = false;
                        }
                        
                        this.items.push({
                            item: {
                                selected_province: province,
                                purchase_order: invoice_details[x].purchase_order,
                                household: invoice_details[x].household,
                                date: invoice_details[x].date,
                                amount: (invoice_details[x].amount > 0) ? invoice_details[x].amount : (invoice_details[x].total/household),
                                show_amount: (invoice_details[x].amount > 0) ? invoice_details[x].amount : (invoice_details[x].total/household).toFixed(2),
                                percent: invoice_details[x].service_fee_percent,
                                service_amount: invoice_details[x].service_fee_amount,
                                row_total: invoice_details[x].total_amount,
                                principle_commision: invoice_details[x].total
                            }
                        });
                    } else {
                        
                        if(invoice_details[x].amount > this.check_amount){
                            this.check_amount = invoice_details[x].amount;
                        }
                        
                        if(invoice_details[x].household != 0 && this.check_house_hold){
                            this.check_house_hold = false;
                        }
                        
                        this.items.push({
                            item: {
                                selected_province: province,
                                purchase_order: invoice_details[x].purchase_order,
                                household: invoice_details[x].household,
                                date: invoice_details[x].date,
                                amount: (invoice_details[x].amount > 0) ? invoice_details[x].amount : (invoice_details[x].total/invoice_details[x].household),
                                show_amount: (invoice_details[x].amount > 0) ? invoice_details[x].amount : (invoice_details[x].total/invoice_details[x].household).toFixed(2),
                                percent: invoice_details[x].service_fee_percent,
                                service_amount: invoice_details[x].service_fee_amount,
                                row_total: invoice_details[x].total_amount,
                                principle_commision: 0
                            }
                        });
                    }
                }

                console.log('check all items:',this.items);
                this.items.push({
                    item: {
                        selected_province: null,
                        household: null,
                        date: null,
                        purchase_order: null,
                        amount: null,
                        show_amount: null,
                        percent: null,
                        service_amount: null,
                        row_total: 0,
                        principle_commision: 0
                    }
                });

                this.setControlRoom();
            },
            computed: {
                exchange_total(){
                    let total = 0;
                    let exchange_rate = (this.exchange_currency?.rate) ? this.exchange_currency?.rate : 1;
                    if(this.exchange_currency){

                         if(this.principle_commission){
                            
                            for(let x=0; x<this.items.length; x++){
                                let household = (Number.parseFloat(this.items[x].item.household) > 0) ? this.items[x].item.household : 1; 
                                total += (Number.parseFloat(this.items[x].item.row_total)/Number.parseFloat(exchange_rate)) || 0;
                                total += ((Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(household))/Number.parseFloat(exchange_rate)) || 0;
                            }
                        } else {
                            
                            if(this.is_comission){
                                for(let x=0; x<this.items.length; x++){
                                    total += (Number.parseFloat(this.items[x].item.row_total)/Number.parseFloat(exchange_rate)) || 0;
                                    let household = (Number.parseFloat(this.items[x].item.household) > 0) ? this.items[x].item.household : 1; 
                                    if(Number.parseFloat(this.items[x].item.percent) >0)
                                        total += ((Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(household))/Number.parseFloat(exchange_rate)) || 0;
                                }
                            } else {
                                
                                for(let x=0; x<this.items.length; x++){
                                    total += (Number.parseFloat(this.items[x].item.row_total)/Number.parseFloat(exchange_rate)) || 0;
                                }
                            }
                        }
                    }
                    
                    return total;
                },
                total_grant() {
                    
                    let total = 0;
                    for (let x = 0; x < this.items.length; x++) {
                        
                        if(this.principle_commission){
                            
                            let household = (Number.parseFloat(this.items[x].item.household) > 0) ? this.items[x].item.household : 1;
                            total += Number.parseFloat(this.items[x].item.row_total) || 0;
                            total += (Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(household)) || 0;
                            
                        } else {
                            
                            if(this.is_comission){
                                
                                let household = (Number.parseFloat(this.items[x].item.household) > 0) ? this.items[x].item.household : 1; 
                                total += Number.parseFloat(this.items[x].item.row_total) || 0;
                                    
                                if(Number.parseFloat(this.items[x].item.percent) >0)
                                    total += (Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(household)) || 0;
    
                            } else {
                                total += Number.parseFloat(this.items[x].item.row_total) || 0;
                            }
                        }
                    }

                    return total;
                },
                sub_total() {
                    let total = 0;
                    if(!this.is_comission || this.principle_commission){
                        for (let x = 0; x < this.items.length; x++) {
                            console.log('check percent: ',this.items[x].item.percent);
                            if(this.principle_commission){
                                total += Number.parseFloat(this.items[x].item.principle_commision) || 0;
                            } else {
                                if(this.items[x].item.percent){
                                    total += Number.parseFloat(this.items[x].item.amount) || 0;
                                } else {
                                    total += Number.parseFloat(this.items[x].item.row_total) || 0;
                                }
                            }
                        }
                    } else {

                        if(this.type == 'cache'){
                            for (let x = 0; x < this.items.length; x++) {
                                if(this.items[x].item.percent){
                                    total += Number.parseFloat(this.items[x].item.amount) || 0;
                                } else {
                                    total += Number.parseFloat(this.items[x].item.row_total) || 0;
                                }
                            }
                        } else {
                            for (let x = 0; x < this.items.length; x++) {

                                if(this.items[x].item.percent){

                                    total += (Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(this.items[x].item.household)) || 0;
                                } else {
                                    total += Number.parseFloat(this.items[x].item.row_total) || 0;
                                }

                            }
                        }
                    }

                    return total;
                },
                total_service() {

                    let total = 0;
                    
                    if(this.is_comission || this.principle_commission){

                        if(this.type == 'cache'){

                            for (let x = 0; x < this.items.length; x++) {

                                total += Number.parseFloat(this.items[x].item.service_amount) || 0;
                                
                            }
                        } else {
                            for (let x = 0; x < this.items.length; x++) {
                                if(Number.parseFloat(this.items[x].item.percent) > 0)
                                total += Number.parseFloat(this.items[x].item.row_total) || 0;
                                
                            }
                        }

                    } else {
                        for (let x = 0; x < this.items.length; x++) {

                            total += Number.parseFloat(this.items[x].item.service_amount) || 0;
                            
                        }
                    }
                    return total;
                },
            },
            methods: {
                setInvoice(){
                    if(this.selected_invoice != null){
                        axios.get('{{url("invoice/commission")}}/'+this.selected_invoice.id).then(data=>{
                            
                            let invoice = data.data.invoice;
                            this.attachments = data.data.attachments != 'no' ? data.data.attachments : [];
                            this.attachments.push({title: null, file: null, main_name: null});
                            this.selected_currency = this.currencies.find(cur => cur.code == invoice.currency);
                            this.exchange_currency = this.currencies.find(cur => cur.code == invoice.exchange_currency);
                            this.invoice_data.invoice_number = invoice.invoice_no;
                            this.invoice_data.date = (invoice?.date).split(' ')[0];
                            this.invoice_data.vol_rep = invoice.vol_rep;
                            this.invoice_data.description = invoice.description;
                            this.invoice_data.purpose = invoice.purpose;
                            let invoice_details = data.data.invoice_details;
            
                            if(invoice.type == 'cashe'){
            
                                this.type = 'cache';
                                this.selected_project = null;
                                this.cash_id = invoice.project_id;
            
                            } else {
                                this.selected_project = this.projects.find(e=>e.id==invoice.project_id) || null; 
                            }
            
                            this.items = [];
                            let check_amount = 0;
                            if(invoice_details[x].amount > check_amount){
                                check_amount = invoice_details[x].amount;
                            }
                                
                            for (let x = 0; x < invoice_details.length; x++) {
                                
                                let household = (invoice_details[x].household > 0) ? invoice_details[x].household : 1;
                                let province = this.provinces.find(it => it.id == invoice_details[x].location);
                                
                                this.items.push({
                                    item: {
                                        selected_province: province,
                                        household: invoice_details[x].household,
                                        purchase_order: invoice_details[x].purchase_order,
                                        date: invoice_details[x].date,
                                        amount: (invoice_details[x].amount > 0) ? invoice_details[x].amount :(invoice_details[x].total_amount/household),
                                        show_amount: (invoice_details[x].amount > 0) ? invoice_details[x].amount :(invoice_details[x].total_amount/household).toFixed(2),
                                        percent: invoice_details[x].service_fee_percent,
                                        service_amount: invoice_details[x].service_fee_amount,
                                        row_total: invoice_details[x].total_amount
                                    }
                                });
                            }
            
                            this.items.push({
                                item: {
                                    selected_province: null,
                                    household: null,
                                    date: null,
                                    purchase_order: null,
                                    amount: null,
                                    show_amount: null,
                                    percent: null,
                                    service_amount: null,
                                    row_total: 0
                                }
                            });
                            
                            if(check_amount == 0){
                                this.disable_amount = true;
                                let amount_index =this.control_room.table.findIndex(e=>e.name=='amount')
                                this.control_room.table[amount_index].value= false;
                                this.saveSetting();
                            }
                            
                        });
                    }
                },
                changeValue(){
                    
                    this.is_comission = !this.is_comission;
                    this.check_commission = !this.check_commission;
                    
                    if(this.is_comission){
                        this.show_subtotal = true;
                        let index =this.control_room.table.findIndex(e=>e.name=='service_fee_percent')
                        this.control_room.table[index].value= true
                        this.saveSetting()
                    } else {
                        let index =this.control_room.table.findIndex(e=>e.name=='service_fee_percent')
                        this.control_room.table[index].value= false;
                        this.saveSetting();
                    }

                    if(this.is_comission){

                        for (let x = 0; x < this.items.length; x++) {

                            let service_amount = ((Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(this.items[x].item.percent) /100)) || 0;
                            let household = Number.parseFloat(this.items[x].item.household) ? Number.parseFloat(this.items[x].item.household) : 1;

                            if(service_amount > 0){

                                this.items[x].item.service_amount = service_amount;

                                if(this.type == 'cache'){

                                    this.items[x].item.row_total = (Number.parseFloat(service_amount) + Number.parseFloat(this.items[x].item.amount)) || 0;
                                } else {

                                    if(this.showTable('household')){

                                        this.items[x].item.row_total = (Number.parseFloat(service_amount) * Number.parseFloat(household)) || 0;
                                    } else {

                                        this.items[x].item.row_total = Number.parseFloat(service_amount) || 0;
                                    }
                                }

                            } else {

                                this.items[x].item.service_amount = 0;

                                if(this.type == 'cache'){

                                    this.items[x].item.row_total = Number.parseFloat(this.items[x].item.amount) || 0;

                                } else {

                                    if(this.showTable('household')){

                                        this.items[x].item.row_total = (Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(household)) || 0;
                                    } else {
                                        
                                        this.items[x].item.row_total = Number.parseFloat(this.items[x].item.amount) || 0;
                                    }
                                }
                            }
                        }

                    } else {
                        this.show_subtotal = false;

                        for (let x = 0; x < this.items.length; x++) {

                            let household = Number.parseFloat(this.items[x].item.household) ? Number.parseFloat(this.items[x].item.household) : 1;

                            if(this.type == 'cache'){

                                this.items[x].item.row_total = Number.parseFloat(this.items[x].item.amount) || 0;
                                // this.items[x].item.service_amount = (Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(this.items[x].item.percent) /100) || 0;
                                this.items[x].item.service_amount = 0;

                            } else {

                                if(this.showTable('household')){

                                    this.items[x].item.row_total = ((Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(household))) || 0;
                                    // this.items[x].item.service_amount = ((Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(this.items[x].item.percent) /100) * Number.parseFloat(this.items[x].item.household)) || 0;
                                    this.items[x].item.service_amount = 0;
                                } else {

                                    this.items[x].item.row_total = Number.parseFloat(this.items[x].item.amount) || 0;
                                    // this.items[x].item.service_amount = (Number.parseFloat(this.items[x].item.amount) * Number.parseFloat(this.items[x].item.percent) /100) || 0;
                                    this.items[x].item.service_amount = 0;
                                }
                            }
                        }
                    }
                    
                    if(this.check_commission && this.type == 'no-cashe'){
                        window.location.reload();
                    }
                    
                },
                rateChanged() {},
                principleCommission(){
                    
                    this.principle_commission = !this.principle_commission;
                    if(this.principle_commission){
                        this.show_subtotal = true;
                        let index =this.control_room.table.findIndex(e=>e.name=='service_fee_percent')
                        this.control_room.table[index].value= true;
                        index =this.control_room.table.findIndex(e=>e.name=='service_fee_amount');
                        this.control_room.table[index].value= true;
                        this.saveSetting()
                    } else {
                        this.show_subtotal = false;
                        let index =this.control_room.table.findIndex(e=>e.name=='service_fee_percent')
                        this.control_room.table[index].value= false;
                        index =this.control_room.table.findIndex(e=>e.name=='service_fee_amount');
                        this.control_room.table[index].value= false;
                        this.saveSetting();
                    }
                    
                    if(this.principle_commission){
                        for (let x = 0; x < this.items.length; x++) {
                            console.log('check amount: ', this.items[x].item.amount);
                            console.log('check this.items[x].item: ', this.items[x].item);
                            let household = (Number.parseFloat(this.items[x].item.household) > 0) ? this.items[x].item.household : 1;
                            let amount = (Number.parseFloat(this.items[x].item.amount) > 0) ? this.items[x].item.amount : 0;
                            if(amount > 0) {
                                
                                this.items[x].item.principle_commision = (household * amount) || 0;
                                let service_amount = ((Number.parseFloat(amount) * Number.parseFloat(this.items[x].item.percent) /100)) || 0;
                                this.items[x].item.service_amount = service_amount;
                                this.items[x].item.row_total = ((Number.parseFloat(amount) * Number.parseFloat(this.items[x].item.percent) /100) * Number.parseFloat(household)) || 0;
                            } else {
                                this.items[x].item.amount = this.items[x].item.row_total;
                                amount = (Number.parseFloat(this.items[x].item.amount) > 0) ? this.items[x].item.amount : 0;
                                this.items[x].item.principle_commision = (household * amount) || 0;
                                let service_amount = ((Number.parseFloat(amount) * Number.parseFloat(this.items[x].item.percent) /100)) || 0;
                                this.items[x].item.service_amount = service_amount;
                                this.items[x].item.row_total = ((Number.parseFloat(amount) * Number.parseFloat(this.items[x].item.percent) /100) * Number.parseFloat(household)) || 0;
                            }
                        }
                    } else {
                        for (let x = 0; x < this.items.length; x++) {
                            if(x < this.items.length) {
                                
                                this.items[x].item.principle_commision = 0;
                                this.items[x].item.percent = 0;
                                this.items[x].item.service_amount = 0;
                                this.items[x].item.row_total = this.items[x].item.amount;
                            }
                        }
                    }
                },
                principleCommissionTotal(index, value){
                    
                    this.items[index - 1].item.principle_commision = value;
                    let household = (Number.parseFloat(this.items[index - 1].item.household) > 0) ? this.items[index - 1].item.household : 1;
                    this.items[index - 1].item.amount = (this.items[index - 1].item.principle_commision / household);
                    this.items[index - 1].item.show_amount = (this.items[index - 1].item.principle_commision / household).toFixed(2);
                    let service_amount = ((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent) /100)) || 0;
                    this.items[index - 1].item.service_amount = service_amount;
                    this.items[index - 1].item.row_total = ((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent) /100) * Number.parseFloat(household)) || 0;
                        
                },
                sendForm() {
                    document.getElementById("userForm").submit();
                },
                setHousehold(index, value) {
                    
                    this.addRow(index);
                    this.items[index - 1].item.household = value;
                    let household = (Number.parseFloat(this.items[index - 1].item.household) > 0) ? this.items[index - 1].item.household : 1;

                    if(this.is_comission || this.principle_commission){

                        let service_amount = ((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent) /100)) || 0;
                        this.items[index - 1].item.service_amount = service_amount;
                        this.items[index - 1].item.row_total = ((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent) /100) * Number.parseFloat(household)) || 0;
                        
                        if(Number.parseFloat(this.items[index - 1].item.amount) > 0 && this.principle_commission){
                            
                            this.items[index - 1].item.principle_commision = (Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(household)) || 0;
                        }

                    } else {

                        this.items[index - 1].item.row_total = ((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(household))) || 0;
                        this.items[index - 1].item.principle_commision = 0;
                        this.items[index - 1].item.service_amount = 0;
                        // this.items[index - 1].item.service_amount = ((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent) /100) * Number.parseFloat(this.items[index - 1].item.household)) || 0;
                    }

                },
                setAmount(index, value) {
                    
                    this.addRow(index);
                    this.items[index - 1].item.amount = value;
                    this.items[index - 1].item.show_amount = value;
                    let household = (Number.parseFloat(this.items[index - 1].item.household) > 0) ? this.items[index - 1].item.household : 1;

                    if(this.is_comission || this.principle_commission){

                        let service_amount = ((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent) /100)) || 0;
                        this.items[index - 1].item.service_amount = service_amount;
                        this.items[index - 1].item.row_total = ((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent) /100) * Number.parseFloat(household)) || 0;
                        
                        if(this.principle_commission){
                            
                            this.items[index - 1].item.principle_commision = (Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(household)) || 0;
                        }
                        
                        if(service_amount > 0){


                            // if(this.type == 'cache'){
                            //     this.items[index - 1].item.row_total = ((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent) /100) + Number.parseFloat(this.items[index - 1].item.amount)) || 0;
                            // } else {

                            // }


                        } else {

                            // this.items[index - 1].item.service_amount = 0;

                            // if(this.type == 'cache'){
                            //     this.items[index - 1].item.row_total = Number.parseFloat(this.items[index - 1].item.amount) || 0;
                            // } else {

                            //     if(this.showTable('household')){

                            //         this.items[index - 1].item.row_total = (Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(household)) || 0;
                            //     } else {

                            //         this.items[index - 1].item.row_total = Number.parseFloat(this.items[index - 1].item.amount) || 0;
                            //     }
                            // }


                        }

                        
                    } else {

                        if(this.type == 'cache'){
                            this.items[index - 1].item.service_amount = 0;
                            this.items[index - 1].item.row_total = Number.parseFloat(this.items[index - 1].item.amount) || 0;
                        } else {

                            this.items[index - 1].item.service_amount = 0;
                            this.items[index - 1].item.row_total = (Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(household)) || 0;
                            // if(this.showTable('household')){

                            //     // this.items[index - 1].item.service_amount = ((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent) /100) * Number.parseFloat(household)) || 0;
                            // } else {

                            //     // this.items[index - 1].item.service_amount = ((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent) /100)) || 0;
                            //     this.items[index - 1].item.service_amount = 0;
                            //     this.items[index - 1].item.row_total = Number.parseFloat(this.items[index - 1].item.amount) || 0;

                            // }
                        }
                    } 


                }, 
                setServiceFee(index, value) {

                    this.items[index - 1].item.percent = value;
                    let service = (value > 0) ? value : 1;
                    let household = (Number.parseFloat(this.items[index - 1].item.household) > 0) ? this.items[index - 1].item.household : 1;

                    if(this.is_comission || this.showTable('service_fee_percent') || this.principle_commission){

                        this.items[index - 1].item.service_amount = (((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(service)) / 100))  || 0;
                        console.log('check type: ', this.type);
                        if(this.type == 'cache' && this.principle_commission) {
                            
                            this.items[index - 1].item.row_total = Number.parseFloat(this.items[index - 1].item.service_amount) || 0;
                        } else if(this.type == 'cache'){

                            this.items[index - 1].item.row_total = (Number.parseFloat(this.items[index - 1].item.service_amount) + Number.parseFloat(this.items[index - 1].item.amount)) || 0;
                        } else {

                            this.items[index - 1].item.row_total = (Number.parseFloat(this.items[index - 1].item.service_amount) * Number.parseFloat(household)) || 0;
                        }

                    } else {

                        this.items[index - 1].item.service_amount = 0;
                        this.items[index - 1].item.principle_commision = 0;
                        if(this.type == 'cache'){
                            this.items[index - 1].item.row_total = Number.parseFloat(this.items[index - 1].item.amount) || 0;
                        } else {

                            this.items[index - 1].item.row_total = (Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(household)) || 0;
                            // if(this.showTable('household')){



                            // } else {

                            //     // this.items[index - 1].item.service_amount = (((Number.parseFloat(this.items[index - 1].item.amount) * Number.parseFloat(this.items[index - 1].item.percent)) / 100))  || 0;
                            //     this.items[index - 1].item.service_amount = 0;

                            //     this.items[index - 1].item.row_total = Number.parseFloat(this.items[index - 1].item.amount) || 0;
                            // }
                        }


                            

                    }
                },
                setservice(index, value) {


                    if(this.is_comission){
                        
                        this.items[index - 1].item.service_amount = value;
                        this.items[index - 1].item.amount = 0;

                        if(this.showTable('household')){

                            this.items[index - 1].item.row_total = (Number.parseFloat(this.items[index - 1].item.service_amount) * Number.parseFloat(this.items[index - 1].item.household)) || 0;
                        } else {

                            this.items[index - 1].item.row_total = Number.parseFloat(this.items[index - 1].item.service_amount) || 0;
                        }

                    } else {
                        this.items[index - 1].item.service_amount = value;

                        if(this.showTable('household')){

                        } else {

                            this.items[index - 1].item.row_total = Number.parseFloat(this.items[index - 1].item.amount) || 0;
                        }

                    }

                    

                },
                setTotalAmount(index, value) {

                    this.items[index - 1].item.row_total = value;

                },
                setProvince(){
                    if(this.selected_project?.id) {
                        this.items[0].item.selected_province = this.provinces.find(e=>e.id==this.selected_project.location_id);
                        this.items[0].item.amount =  (this.selected_project.budget/ this.selected_project.total_beneficiary).toFixed(2);
                        this.getHousehold(this.selected_project.id);
                         
                    }
                    else {
                        this.items[0].item.selected_province = null;
                        this.items[0].item.household    = null;
                        this.items[0].item.amount       = null;
                        this.items[0].item.row_total    = null;
                    }
                },
                getHousehold(id){

                    if(this.type == 'cache'){

                        this.items[0].item.row_total = (this.items[0].item.amount).toFixed(2) || 0;

                    } else {

                        if(this.showTable('household')){

                            axios.get('{{url("householde")}}/'+id).then(e=>{
                                this.items[0].item.household = e.data;
                                this.items[0].item.row_total = (this.items[0].item.amount * this.items[0].item.household).toFixed(2) || 0;
                            });
                        } else {
                            this.items[0].item.row_total = (this.items[0].item.amount).toFixed(2) || 0;
                        }
                    }
                },
                showFields(name) {
                    if (
                        this.control_room.fields?.find((e) => e.name == name && e.value == true)
                    )
                        return true;
                    else return false;
                },
                showTable(name) {
                    if (
                        this.control_room.table?.find((e) => e.name == name && e.value == true)
                    )
                        return true;
                    else return false;
                },
                setControlRoom() { 
                    if (!localStorage.getItem("setting")) {
                        axios.get("{{url('/user/setting')}}").then(res => {
                            console.log(res.data);
                            let setting = res.data.find(
                                (e) => e.name == 'Invoice'
                            ).data;
                            // checkData(setting, this)
                            this.control_room.fields = setting?. [0]?.values;
                            this.control_room.table = setting?. [1]?.values
                            localStorage.setItem('setting', JSON.stringify(res.data));

                            if(this.is_comission || this.principle_commission){

                                let index =this.control_room.table.findIndex(e=>e.name=='service_fee_percent')
                                this.control_room.table[index].value= true;
                                index =this.control_room.table.findIndex(e=>e.name=='service_fee_amount')
                                this.control_room.table[index].value= true;
                            } else {
                                let index =this.control_room.table.findIndex(e=>e.name=='service_fee_percent')
                                this.control_room.table[index].value= false;
                                index =this.control_room.table.findIndex(e=>e.name=='service_fee_amount')
                                this.control_room.table[index].value= false;
                            }

                            if(this.type == 'cache'){

                                let index =this.control_room.table.findIndex(e=>e.name=='amount')
                                this.control_room.table[index].value= true;

                                index =this.control_room.table.findIndex(e=>e.name=='household')
                                this.control_room.table[index].value= false;
                            } else {
                                let index =this.control_room.table.findIndex(e=>e.name=='amount')
                                this.control_room.table[index].value= true;

                                index =this.control_room.table.findIndex(e=>e.name=='household')
                                this.control_room.table[index].value= true;
                            }
                            
                            if(this.check_amount == 0){
                                this.disable_amount = true;
                            }
                            
                            if(this.disable_amount){
                                let amount_index =this.control_room.table.findIndex(e=>e.name=='amount')
                                this.control_room.table[amount_index].value= false;
                            }
                            
                            if(this.is_default_service_fee){
                                let index =this.control_room.table.findIndex(e=>e.name=='service_fee_percent')
                                this.control_room.table[index].value= true;
                                index =this.control_room.table.findIndex(e=>e.name=='service_fee_amount')
                                this.control_room.table[index].value= true;
                            }
                            
                            this.saveSetting();


                        })
                    } else {
                        let setting = JSON.parse(localStorage.getItem("setting")).find(
                            (e) => e.name == 'Invoice'
                        ).data;
                        // checkData(setting, this);
                        this.control_room.fields = setting?. [0]?.values;
                        this.control_room.table = setting?. [1]?.values;
                         
                        if(this.is_comission || this.principle_commission){

                            let index =this.control_room.table.findIndex(e=>e.name=='service_fee_percent')
                            this.control_room.table[index].value= true;
                            index =this.control_room.table.findIndex(e=>e.name=='service_fee_amount')
                            this.control_room.table[index].value= true;
                        } else {
                            let index =this.control_room.table.findIndex(e=>e.name=='service_fee_percent')
                            this.control_room.table[index].value= false;
                            index =this.control_room.table.findIndex(e=>e.name=='service_fee_amount')
                            this.control_room.table[index].value= false;
                        }

                        if(this.type == 'cache'){

                            let index =this.control_room.table.findIndex(e=>e.name=='amount')
                            this.control_room.table[index].value= true;

                            index =this.control_room.table.findIndex(e=>e.name=='household')
                            this.control_room.table[index].value= false;
                        } else {
                            let index =this.control_room.table.findIndex(e=>e.name=='amount')
                            this.control_room.table[index].value= true;

                            index =this.control_room.table.findIndex(e=>e.name=='household')
                            this.control_room.table[index].value= true;
                        }
                        
                        if(this.check_amount == 0){
                            this.disable_amount = true;
                        }
                        
                        if(this.disable_amount){
                            let amount_index =this.control_room.table.findIndex(e=>e.name=='amount');
                            this.control_room.table[amount_index].value= false;
                        }
                        
                        if(this.is_default_service_fee){
                            let index =this.control_room.table.findIndex(e=>e.name=='service_fee_percent')
                            this.control_room.table[index].value= true;
                            index =this.control_room.table.findIndex(e=>e.name=='service_fee_amount')
                            this.control_room.table[index].value= true;
                        }
                        
                        if(this.check_house_hold){
                            let index =this.control_room.table.findIndex(e=>e.name=='household')
                            this.control_room.table[index].value= false;
                        }

                        this.saveSetting();
                    }
                },
                saveSetting() {
                    let setting = JSON.parse(localStorage.getItem("setting"));
                    let index = setting.findIndex((e) => e.name == "Invoice");
                    setting[index].data[0].values = this.control_room.fields;
                    setting[index].data[1].values = this.control_room.table;
                    axios
                        .post("/user/setting", {
                            form: JSON.stringify(setting)
                        })
                        .then((res) => {
                            localStorage.setItem("setting", JSON.stringify(setting));
                        });
                },
                searchItems: _.debounce(function (e) {
                    axios.get("{{route('item.all') }}?" +
                        "type=" + 'item'
                    )
                        .then((res) => {
                            this.itemData = res.data;
                        });
                }, 200),
                getItems() {
                    axios.get("{{route('item.all') }}")
                        .then((res) => {
                            this.itemData = res.data;
                        });
                },
                addRow(index) {
                    if ((index - 1) == this.items.length - 1) {
                        this.items.push({
                            item: {
                                selected_item: null,
                                selected_province: null,
                                amount: null,
                                purchase_order: null,
                                percent: null,
                                household: null,
                                service_amount: null,
                                row_total: 0,
                                principle_commision: 0
                            }
                        });
                    }
                },
                addAttachment(index) {
                    if ((index - 1) == this.attachments.length - 1) {
                        this.attachments.push({item: {title: null}});
                    }
                },
                deleteAttachment(index) {
                    if (this.attachments.length - 1 > 0) this.attachments.splice(index - 1, 1);
                },
                deleteItem(index) {
                    if (this.items.length - 1 > 0) this.items.splice(index - 1, 1);
                },
                getItemTotal(item = null, exchanged_rate = 1) {
                    let result = 0;
                    if (item != null && item.quantity > 0) {
                        let price = item.price;
                        let quantity = item.quantity;
                        let total = price * quantity * 1;
                        result = Number.parseFloat(total).toFixed(2);
                    }
                    return result;
                },
                /**
                 * handleSubmit
                 */
                handleSubmit(e, type = 'save') {
                    this.$validator.validate().then(valid => {

                        if (valid) {

                            let ids = [];
                            for (let i = 0; i < this.selected_role.length; i++) {
                                ids.push(this.selected_role[i].id)
                            }

                            $('#role_ids').val(ids);
                            document.getElementById('permission_id').value = selected_p;
                            e.preventDefault();
                            let url = (e.target.form == undefined) ? e.target.action : e.target.form.action;
                            let data = (e.target.form == undefined) ? $(e.target).serialize() : $(e.target.form).serialize();
                            data = new FormData(e.target.form);
                            toggleBlock(1);
                            axios.post(url, data)
                                .then(function (response) {
                                    toggleBlock(0);
                                    let message = "{{__('message.success')}}";
                                    if (response.data) {
                                        message = response.data.message;
                                    }
                                    alertify.success(message);
                                    if (type != 'save') {
                                        vm.defaultValue(e);
                                    } else {
                                        window.location.href = "{{route('user.index')}}";
                                    }
                                })
                                .catch(function (error) {
                                    toggleBlock(0);
                                    let warning = "{{__('message.error')}}";
                                    if (error.response.data) {
                                        if (error.response.data.message) {
                                            warning = error.response.data.message;
                                        }
                                        if ((error.response.status == 422) == true) {
                                            let my_error = error.response.data.errors;

                                            for (index in my_error) {

                                                alertify.error(my_error[index][0]);
                                            }

                                        }
                                    }

                                    alertify.error(warning);
                                })
                        }
                    });
                }
                /**
                 * this is used to set default value
                 */


            }
        });

    </script>

    <style>
        .vue_dropdown .vs__dropdown-toggle {
            border: none !important;
        }
    </style>

@endsection
