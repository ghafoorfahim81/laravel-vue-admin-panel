@extends('layouts.master')
@section('title', __('lang.show').' '.__('lang.invoice'))
@section('css')
<link rel="stylesheet" href="{{asset('assets/css/print.css')}}">
@endsection
@section('content')
<div class="page-content-wrapper" id="myapp" v-cloak>
  <div class="container-fluid">

    <div class="card">

      <!-- Nav tabs -->
      <div class="d-flex">
        <ul class="nav nav-tabs" role="tablist">
          <li class="nav-item" v-for="(t,index) in tabs">
            <a class="nav-link " :class="t.is_active?'active':''" @click="setActive(index)" data-toggle="tab" :href="'#'+t.tab" role="tab">
              <i :class="'fas '+t.css_class+' mr-1'"></i> <span class="d-md-inline-block">@{{t.value}}</span>
            </a>
          </li>

        </ul>
      </div>

      <div class="tab-content p-3">
        <div class="tab-pane active" id="general" role="tabpanel">

          <div class="card">
            <div class="card-body">
              <div class="container mb-5 mt-3">
                <div class="row d-flex align-items-baseline">
                  <div class="col-xl-9">
                    <p style="color: #7e8d9f;font-size: 20px;">Invoice <strong>No: #{{$invoice->invoice_no}}</strong></p>
                  </div>
                  <div class="col-xl-3 float-end">
                    <!--<a class="btn btn-light text-capitalize border-0" data-mdb-ripple-color="dark" @click="printInvoice()"><i class="fas fa-print text-primary"  ></i> Print</a>-->
                    <!--<a class="btn btn-light text-capitalize" data-mdb-ripple-color="dark"><i class="far fa-file-pdf text-danger"></i> Export</a>-->
                  </div>
                  <hr>
                </div>

                <div class="container">
                  <div class="col-md-12">
                    <div class="text-center">
                      <img src="https://apyouths.org/wp-content/uploads/2022/03/PSP-UNHCR-INDONESIA-JOB.png" height="49" alt="" loading="lazy" />

                    </div>

                  </div>


                  <div class="row">
                    <div class="col-xl-8">
                      <ul class="list-unstyled">
                        <li class="text-muted">Organization: <span style="color:#5d9fc5 ;">{{$company->name ?? ''}}</span></li>
                        <li class="text-muted">Address: <span style="color:#5d9fc5 ;">{{$company->address ?? ''}}</span></li>
                        <li class="text-muted">Phone: <span style="color:#5d9fc5 ;">{{$company->phone ?? ''}}</span></li>
                        <li class="text-muted">Project: <span style="color:#5d9fc5 ;">{{$project->name ?? ''}}</span></li>
                      </ul>
                    </div>
                    <div class="col-xl-4">
                      <p class="text-muted">Invoice</p>
                      <ul class="list-unstyled">
                        <li class="text-muted"><i class="fas fa-circle" style="color:#84B0CA ;"></i> <span class="fw-bold">No:</span>#{{$invoice->invoice_no}}</li>
                        <li class="text-muted"><i class="fas fa-circle" style="color:#84B0CA ;"></i>
                          <span class="fw-bold">Creation Date: </span>{{substr($invoice->date, 0, 10)}}
                        </li>
                        <li class="text-muted"><i class="fas fa-circle" style="color:#84B0CA ;"></i>
                          <span class="fw-bold">Currency: </span>{{$invoice->currency}}
                        </li>
                        <li class="text-muted"><i class="fas fa-circle" style="color:#84B0CA ;"></i>
                          <span class="fw-bold">Exchange Rate: </span>{{$invoice->exchange_rate}}
                        </li>
                        <li class="text-muted"><i class="fas fa-circle" style="color:#84B0CA ;"></i> <span class="me-1 fw-bold">Status:</span><span class="badge bg-warning text-black fw-bold">
                            @if($invoice->status == 0) Unpaid @else Paid @endif</span></li>
                      </ul>
                    </div>
                  </div>

                  <div class="row my-2 mx-1 justify-content-center">
                    <table class="table align-middle mb-8 bg-white">
                      <thead class="bg-light">
                        <tr>
                          <th>Location</th>
                          <th>HouseHold</th>
                          <th>Amount</th>
                          <th>Service Fee %</th>
                          <th>Service Fee $</th>
                          <th>Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr v-for="(invoice_detail, index) in invoice_details">
                          <td>
                            <p class="fw-bold mb-1">@{{invoice_detail.name}}</p>
                          </td>
                          <td>
                            <p class="fw-normal mb-1">@{{invoice_detail.household}}</p>
                          </td>
                          <td>
                            @{{invoice_detail.amount}}
                          </td>
                          <td>
                            @{{invoice_detail.service_fee_percent}}
                          </td>
                          <td>
                            @{{invoice_detail.service_fee_amount}}
                          </td>
                          <td>
                            @{{invoice_detail.total_amount}}
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div class="row">
                    <div class="col-xl-8">
                      <p class="ms-3">{!! $invoice->description !!}</p>

                    </div>
                    <div class="col-xl-3">
                      <ul class="list-unstyled">
                        <li class="text-muted ms-3"><span class="text-black me-4">SubTotal</span>@{{sub_total}}</li>
                        <li class="text-muted ms-3 mt-2"><span class="text-black me-4">Service Total</span>@{{service_total}}</li>
                      </ul>
                      <p class="text-black float-start"><span class="text-black me-3"> Grand Total</span><span style="font-size: 25px;">@{{grand_total}}</span></p>
                    </div>
                  </div>
                  <hr>

                </div>
              </div>
            </div>
          </div>




        </div>

        <div class="tab-pane" id="receipts" role="tabpanel">
          <div class="p-8">
            <table class="table align-middle mb-0 bg-white">
              <thead class="bg-light">
                <tr>
                  <th class="text-center">#</th>
                  <th>Title</th>
                  <th>Download</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(file, index) in attachments">
                  <td>
                    <div class="text-center">
                      @{{++index}}
                    </div>
                  </td>
                  <td>
                    <p class="fw-normal mb-1">@{{file.title}}</p>
                  </td>
                  <td>
                    <a :href="`{{url('invoice/download')}}/${file.file_name}/${invoice_id}`"><i class="fas fa-cloud-download-alt fa-lg"></i></a>
                  </td>
                </tr>
                <tr v-if="attachments.length == 0">
                  <td colspan="3">
                    <div class="text-center">
                      No file attached
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

    </div>
  </div>

  <!-- Tabs content -->
  <div style="visibility: hidden;" id="content_print_report">
        <div id="title">
            <img src="{{asset('header.jpg')}}" id="img_header" alt="" srcset="">
        </div>
        <table class="tbl-container" id="table-container">

            <tr>
                <th colspan="4" id="invoice">invoice</th>
            </tr>
            <tr>
                <td>Inoice No: @{{print_data.invoice_no}}</td>
                <td></td>
                <td></td>
                <td id="invoice-date">Invoice Date: @{{print_data.date}}</td>
            </tr>
            <br />
            <tr>
                <th id="organization">Organization: @{{print_data.organization}}</th>
                <td colspan="3"></td>
            </tr>
            <tr id="table-grant">
                <td>VolRep @{{print_data.vol_rep}}</td>
                <td colspan="3"></td>
            </tr>
            <tr id="table-header">
                <th>Location</th>
                <th>Date</th>
                <th>Amount in (USD)</th>
                <th>Grand total</th>
            </tr>
            <tr class="table-data" v-for="invo in invoice_details">
                <td>@{{invo.location}}</td>
                <td>@{{invo.start_date}} / @{{invo.end_date }}</td>
                <td>@{{invo.amount}}</td>
                <td>@{{invo.amount}}</td>
            </tr>
            <tr class="table-data">
                <td colspan="2">Total</td>
                <td></td>
                <td>@{{total}}</td>
            </tr>
            <tr id="table-description">
                <td colspan="4">
                    @{{print_data.details}}
                </td>
            </tr>
            <!-- <tr class="thanks">
                    <td colspan="4">Thanks and Regards</td>
                </tr>
                <tr class="thanks" id="auth">
                    <td colspan="4">Authorized signature</td>
                </tr>
                 -->
        </table>
        <div id="table-footer">
            <span>Address: Sara I Shazada, Ground Floor,
                Shop# 42, Kabul-Afghanistan- , Phone# (0) 202100960 / Mobile# 0093(0) 777 55 31 55 &nabla;&nabla;&nabla;&nabla; &nbsp;ادرس: سرای شهزاده منزل اول دوکان نمبر 42، کابل- افغانستان

            </span>
        </div>
    </div>
  <!-- end container-fluid -->
</div>
<!-- end page-content-wrapper -->


@endsection
@section('js')
<script src="{{asset('assets/js/print.js')}}"></script>

<script>
  var vm = new Vue({
    el: '#myapp',
    data: {
      invoice_id: "{{$invoice->id}}",
      tabs: [{
          tab: 'general',
          css_class: 'fa-home',
          value: 'General',
          is_active: true
        },
        {
          tab: 'receipts',
          css_class: 'fa-user',
          value: 'Attachments',
          is_active: false
        },
      ],
      invoice_details: {!!$invoice_details!!},
      sub_total: 0,
      service_total: 0,
      grand_total: 0,
      attachments: {!!$attachments!!},
      print_data: {},
      total: 0,
      id:'{!!$invoice->id!!}',
    },
    created() {
      let invoice_details = {!!$invoice_details!!};
      console.log('check', invoice_details);

      for (let x = 0; x < invoice_details.length; x++) {

        let service_amount = (invoice_details[x].service_fee_amount == null) ? 0 : Number.parseFloat(invoice_details[x].service_fee_amount);

        this.sub_total += Number.parseFloat(invoice_details[x].total_amount) - service_amount || 0;

        this.service_total += Number.parseFloat(invoice_details[x].service_fee_amount) || 0;
      }

      this.grand_total = this.sub_total + this.service_total;
    },
    methods: {
      setActive(index){

      },
       printInvoice() {
        console.log(this.id);
         axios.get("{{route('invoice.print','')}}/" + this.id)
          .then(data => {
            console.log(data);
            this.invoice_details = data.data;
            this.print_data = this.invoice_details[0]
            let total = 0;
            this.invoice_details.forEach(e => total += e.amount);
            this.total = total;
            // console.log(this.invoice_details.reduce((pre,curr)=>pre.amount+curr.amount));
            // this.total = this.invoice_details.reduce((pre,curr)=>pre.amount+curr.amount);
            console.log(total);

          }).then(() => {
            printJS({
              printable: 'content_print_report',
              type: 'html',
              style: `
                             @media print {
                                 @page {
                                 margin: 20px;
                                 size: auto;
                                 }

                                 table#table-container {
                                     border-radius: 5px;
                                     width: 100% !important;
                                     margin: 0 auto;
                                     height: 100% !important;
                                     font-family: sans-serif;
                                     border-collapse:collapse;
                                     border: 1px solid black;
                                     border:none;
                                 }
                                 table tr th {
                                     border-collapse:collapse;
                                 }
                                 // #title th{
                                 //     border: 1px solid black;
                                 //     // height:5px !important;
                                 //     font-size: large !important;
                                 //     background-color: lightgray;
                                 // }
                                 #invoice{
                                     height: 70px !important;
                                     text-align: center;
                                     padding-top:20px;
                                 }
                                 #organization{
                                     text-align: left;
                                 }
                                 #invoice-date{
                                     height: 70px !important;
                                     text-align: right;
                                 }
                                 #main-table {
                                     border: 1px solid black;
                                     // bordNer-collapse:collapse;
                                 }
                                 #table-grant{
                                     padding-bottom:10px !important;
                                 }
                                 #table-header th{
                                     border: 1px solid black;
                                     background-color: lightgray;
                                 }
                                 .table-data td{
                                     border: 1px solid black;
                                     text-align: center;
                                 }
                             #table-terms th {
                                 text-align: left;
                                 padding-top: 40px !important;
                             }
                             #table-description td {
                                 text-align: left;
                                 padding-top: 50px !important;
                                 padding-bottom: 100px !important;

                                 }
                                 #auth td{
                                     // padding-bottom: 35% !important;
                                 }
                                 #table-footer  {
                                     border-top:1px solid black;
                                     position: fixed;
                                     bottom: 0;
                                     right: 0;
                                     padding-top:10px;
                                 }
                                 #img_header{
                                     width:90%;
                                     // position:static;
                                     height:50% !important;
                                 }
                                 #title{
                                     position: fixed;
                                     top: 0;
                                     left: 0;
                                     height:10% !important;
                                     // padding-bottom:30px;
                                 }

                             }`
            });
          })
      },

    },

  });
</script>

<style>
  .vue_dropdown .vs__dropdown-toggle {
    border: none !important;
  }
</style>

@endsection
