@extends('layouts.master')
@section('title', __('lang.add').' '.__('lang.account'))
@section('css')
<link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css" />
<link href="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}" rel="stylesheet" type="text/css" />


@endsection
@section('content')
<div class="page-content-wrapper" id="myapp" v-cloak>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <form action="{{route('account.store')}}" @submit="handleSubmit($event)" method="post" id="userForm" enctype="multipart/form-data">
                        @csrf

                        <div class="card-body" style="padding-bottom: 0px">
                            <div class="">
                                <!-- <h4 class="header-title">@lang('lang.add') @lang('lang.order')</h4> -->
                                <div class="row justify-content-center">
                                    <div class="col-xl-9 col-md-9 row">
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.account_number')
                                                </label>
                                                <input type="number" name="account_number" class="form-control" autocomplete="new-password" data-vv-as="@lang('lang.password')" placeholder="@lang('lang.account_number')">
                                                <span class="help-block rq-hint">
                                                    @{{errors.first('account_number')}}</span>
                                            </div>
                                        </div>
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.name')
                                                </label>
                                                <input name="name" class="form-control" autocomplete="new-password" data-vv-as="@lang('lang.password')" placeholder="@lang('lang.name')">
                                                <span class="help-block rq-hint">
                                                    @{{errors.first('name')}}</span>
                                            </div>
                                        </div>
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.swift')
                                                </label>
                                                <input name="swift" class="form-control" autocomplete="new-password" data-vv-as="@lang('lang.password')" placeholder="@lang('lang.swift')">
                                                <span class="help-block rq-hint">
                                                    @{{errors.first('swift')}}</span>
                                            </div>
                                        </div>
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.station')
                                                </label>
                                                <input name="station" class="form-control" autocomplete="new-password" data-vv-as="@lang('lang.password')" placeholder="@lang('lang.station')">
                                                <span class="help-block rq-hint">
                                                    @{{errors.first('station')}}</span>
                                            </div>
                                        </div>
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.contact_person')
                                                </label>
                                                <input name="contact_person" class="form-control" autocomplete="new-password" data-vv-as="@lang('lang.password')" placeholder="@lang('lang.contact_person')">
                                                <span class="help-block rq-hint">
                                                    @{{errors.first('contact_person')}}</span>
                                            </div>
                                        </div>
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.email')
                                                </label>
                                                <input type="email" name="email" class="form-control" autocomplete="new-password" data-vv-as="@lang('lang.password')" placeholder="@lang('lang.email')">
                                                <span class="help-block rq-hint">
                                                    @{{errors.first('email')}}</span>
                                            </div>
                                        </div>
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.phone')
                                                </label>
                                                <input type="phone" name="phone" class="form-control" autocomplete="new-password" data-vv-as="@lang('lang.password')" placeholder="@lang('lang.phone')">
                                                <span class="help-block rq-hint">
                                                    @{{errors.first('phone')}}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-4">
                                        <div class="form-group">
                                            <label for="">@lang('lang.currency')
                                            </label>
                                            <v-select :select-on-tab="true" v-model="selected_currency" label="code" :options="currencies" placeholder="@lang('lang.select_currency')">
                                                <template v-slot:no-options="{ search, searching }">
                                                    <template v-if="searching">
                                                        @lang('lang.no_record_found_for') @{{search}}
                                                    </template>
                                                    <em class="v-select-search-hint" v-else>@lang('lang.type_to_search')</em>
                                                </template>
                                            </v-select>
                                            <input type="hidden" name="currency" :value="(selected_currency == null) ? null : selected_currency.code">
                                        </div>
                                    </div>
                                    <div class="col-xl-6">
                                        <div class="form-group">
                                            <label for="">@lang('lang.address')
                                            </label>
                                            <textarea name="address" class="form-control" id="exampleFormControlTextarea1" name="desc" rows="2">
                                                    </textarea>
                                            <span class="help-block rq-hint">
                                                @{{errors.first('address')}}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <!-- Save-Banner Start -->
                        <nav class="navbar navbar-expand-lg py-0 navbar-light bg-dark fixed-top ">
                            <div>
                                <a class="navbar-brand me-2" href="https://mdbgo.com/">
                                    <img src="https://mdbcdn.b-cdn.net/img/logo/mdb-transaprent-noshadows.webp" alt="MDB Logo" loading="lazy" style="margin-top: -1px;" />
                                </a>

                            </div>
                            <!-- Container wrapper -->
                            <div class="container">

                                <!-- Navbar brand -->


                                <!-- Toggle button -->
                                <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarButtonsExample" aria-controls="navbarButtonsExample" aria-expanded="false" aria-label="Toggle navigation">
                                    <i class="fas fa-bars"></i>
                                </button>

                                <!-- Collapsible wrapper -->
                                <div class="collapse navbar-collapse" id="navbarButtonsExample">
                                    <!-- Left links -->
                                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                                        <li class="nav-item">
                                            <a class="nav-link text-white text-xl" href="#">Unsaved Changes</a>
                                        </li>
                                    </ul>
                                    <!-- Left links -->

                                    <div class="d-flex align-items-center">
                                        <button type="button" onclick="location.href='{{route('account.index')}}'" class="btn btn-dark px-3 me-2">
                                            Cancel
                                        </button>

                                        <button type="reset" class="btn btn-dark px-3 me-2">
                                            Reset
                                        </button>
                                        <button type="submit" class="btn btn-info" type="button">

                                            <span :class="spinner" class="spinner-border-sm" role="status" aria-hidden="true"></span>
                                            <span class="ml-2">Save Changes</span>
                                        </button>
                                    </div>
                                </div>
                                <!-- Collapsible wrapper -->
                            </div>
                            <!-- Container wrapper -->
                        </nav>
                        <!-- Save-Banner End -->
                    </form>
                </div>

            </div>

        </div>
        <!-- end row -->
    </div>
    <!-- end container-fluid -->
</div>
<!-- end page-content-wrapper -->


@endsection
@section('js')


<script>
    var vm = new Vue({
        el: '#myapp',
        data: {
            currencies: [],
            selected_currency: null,
            spinner: 'spinner-border',
            disabled: true,
        },
        mounted: function() {
            axios.get("{{route('currency.default')}}").
            then(data => this.currencies = data.data);
        },
        computed: {

        },
        methods: {
            /**
             * handleSubmit
             */
            handleSubmit(e, type = 'save') {
                console.log('type', type);
                this.$validator.validate().then(valid => {

                    if (valid) {


                        document.getElementById('permission_id').value = selected_p;
                        e.preventDefault();
                        let url = (e.target.form == undefined) ? e.target.action : e.target.form.action;
                        let data = (e.target.form == undefined) ? $(e.target).serialize() : $(e.target.form).serialize();
                        data = new FormData(e.target.form);
                        toggleBlock(1);
                        axios.post(url, data)
                            .then(function(response) {
                                toggleBlock(0);
                                let message = "{{__('message.success')}}";
                                if (response.data) {
                                    message = response.data.message;
                                }
                                alertify.success(message);
                                if (type != 'save') {
                                    vm.defaultValue(e);
                                    window.location.href = "{{route('account.index')}}";
                                } else {
                                    window.location.href = "{{route('account.index')}}";
                                }
                            })
                            .catch(function(error) {
                                toggleBlock(0);
                                let warning = "{{__('message.error')}}";
                                if (error.response.data) {
                                    if (error.response.data.message) {
                                        warning = error.response.data.message;
                                    }
                                    if ((error.response.status == 422) == true) {
                                        let my_error = error.response.data.errors;

                                        for (index in my_error) {

                                            alertify.error(my_error[index][0]);
                                        }

                                    }
                                }

                                alertify.error(warning);
                            })
                    }
                });
            }
        }
    });
</script>

<style>
    .vue_dropdown .vs__dropdown-toggle {
        border: none !important;
    }
</style>

@endsection