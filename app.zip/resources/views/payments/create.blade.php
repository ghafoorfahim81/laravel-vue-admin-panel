@extends('layouts.master')
@section('title', __('lang.add').' '.__('lang.payment'))
@section('css')
    <link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css"/>
    <link href="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}" rel="stylesheet" type="text/css"/>

@endsection
@section('content')
    <div class="page-content-wrapper" id="myapp" v-cloak>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <form action="{{route('payment.store')}}" method="post" id="userForm"
                              enctype="multipart/form-data">
                            @csrf
                            <div class="card-body" style="padding-bottom: 0px">
                                <div class="">
                                    <!-- <h4 class="header-title">@lang('lang.add') @lang('lang.order')</h4> -->
                                    <div class="row">
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.project')
                                                </label>
                                                <v-select :select-on-tab="true"
                                                          v-model="selected_project"
                                                          label="name"
                                                          :disabled="change_form"
                                                          :options="projects" placeholder="select project"
                                                >

                                                    <template v-slot:no-options="{ search, searching }">
                                                        <template v-if="searching">
                                                            @lang('lang.no_record_found_for') @{{search}}
                                                        </template>
                                                        <em class="v-select-search-hint"
                                                            v-else>@lang('lang.type_to_search')</em>
                                                    </template>
                                                </v-select>
                                                <input type="hidden" name="project_id"
                                                       :value="selected_project?selected_project.id:null">
                                            </div>
                                        </div>

                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.date')
                                                </label>
                                                <input type="date" name="date" value="<?php echo date('Y-m-d'); ?>"
                                                       class="form-control" id="email"
                                                       v-validate="'required'" data-vv-as="@lang('lang.date')"
                                                       placeholder="@lang('lang.date')" autocomplete="new-email">

                                            </div>
                                        </div>
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.location')
                                                </label>
                                                <v-select :select-on-tab="true"
                                                          v-model="selected_province"
                                                          label="name"
                                                          :disabled="change_form"
                                                          :options="provinces" placeholder="@lang('lang.location')"
                                                >
                                                    <template v-slot:no-options="{ search, searching }">
                                                        <template v-if="searching">
                                                            @lang('lang.no_record_found_for') @{{search}}
                                                        </template>
                                                        <em class="v-select-search-hint"
                                                            v-else>@lang('lang.type_to_search')</em>
                                                    </template>
                                                </v-select>
                                                <input type="hidden" name="location_id"
                                                       :value="selected_province?selected_province.id:null">
                                            </div>
                                        </div>
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.currency')
                                                </label>
                                                <v-select :select-on-tab="true"
                                                          v-model="selected_currency"
                                                          label="code"
                                                          :options="currencies" placeholder="@lang('lang.currency')"
                                                >
                                                    <template v-slot:no-options="{ search, searching }">
                                                        <template v-if="searching">
                                                            @lang('lang.no_record_found_for') @{{search}}
                                                        </template>
                                                        <em class="v-select-search-hint"
                                                            v-else>@lang('lang.type_to_search')</em>
                                                    </template>
                                                </v-select>
                                                <input type="hidden" name="currency"
                                                       :value="selected_currency?selected_currency.code:null">
                                            </div>
                                        </div>

                                        <div class="col-xl-4 py-4 mt-2">

                                        </div>
                                        <div class="col-xl-4 py-4 mt-2">
                                            <div class="w-full shadow-4 rounded-sm p-2 border">
                                                <div class="row justify-around">
                                                    <span class="font-weight-bold text-xl col-7">Grand Total</span>
                                                    <span
                                                        class="font-weight-bold text-xl col text-end">@{{grandTotal}}</span>
                                                </div>
                                                <div v-if="change_form">
                                                    <div class="row justify-around">
                                                        <span
                                                            class="font-weight-bold text-xl col-7">LC Amount Total</span>
                                                        <span
                                                            class="font-weight-bold text-xl col text-end">@{{lcTotal}}</span>
                                                    </div>
                                                    <div class="row justify-around">
                                                        <span
                                                            class="font-weight-bold text-xl col-7">Commission Total</span>
                                                        <span class="font-weight-bold text-xl col text-end">@{{comissionTotal}}</span>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- end of permission -->
                                </div>
                                <div class="table-responsive rounded-sm shadow-4 ">
                                    <table class="table mb-0">
                                        <thead class="bg-light-blue-7 text-white">
                                        <tr>
                                            <th>@lang('lang.no_of_receipant')</th>
                                            <th class="p-2">@lang('lang.amount')</th>
                                            <th class="p-2">@lang('lang.total')</th>

                                            <th class="p-2"><i class="far fa-trash-alt" style="color:red"></i></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr v-for="(item, index) in items">
                                            <td class="p-0 border-right align-middle"><input type="number"
                                                                                             class="form-control border border-white"
                                                                                             @click="addRow(index)"
                                                                                             @focus="$event.target.select()"
                                                                                             v-model="
                                                                    item.item.quantity" name="quantity[]"></td>
                                            <td class="p-0 border-right align-middle">
                                                <input type="number" @focus="$event.target.select()"
                                                       class="form-control border border-white" v-model="
                                                                    item.item.amount
                                                               " name="amount[]">
                                            </td>

                                            <td class="p-0 border-right align-middle">
                                                @{{getItemTotal(
                                                item.item
                                                )}}
                                            </td>
                                            <td class="p-0 border-right align-middle text-center"><i
                                                    class="far fa-trash-alt" style="color:red"
                                                    v-on:click="deleteItem(index,'unops')"></i></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>


                            <div class="card-footer text-right">
                                <button class="btn btn-info" type="submit"><span class="ml-2">Save Changes</span>
                                </button>


                            </div>

                            <!--  <save-banner @click="handleSubmit($event)" @cancelRoute="$router.push({ name: '/receipt'})" /> -->
                        </form>
                    </div>

                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- end container-fluid -->
    </div>
    <!-- end page-content-wrapper -->

@endsection
@section('js')

    <script>

        var vm = new Vue({
            el: '#myapp',
            data: {
                projects: {!!$projects!!},
                currencies: {!!$currencies!!},
                provinces: {!!$provinces!!},
                selected_project: null,
                selected_company: null,
                selected_currency: {!! $selected_currency !!},
                selected_province: null,
                change_form: false,
                items: [
                    {item: {quantity: 0, amount: 0}},
                    {item: {quantity: 0, amount: 0}},
                    {item: {quantity: 0, amount: 0}},

                ],
            },
            mounted: function () {
            },
            computed: {
                grandTotal() {
                    let total = 0;
                    for (let x = 0; x < this.items.length; x++) {
                        total += Number.parseFloat(this.items[x].item.quantity) * Number.parseFloat(this.items[x].item.amount);
                    }
                    return total;
                }
            },
            methods: {
                formChange() {
                    if (this.change_form) {
                        this.selected_province = null
                        this.selected_project = null
                    }
                    console.log('sssss', this.change_form)
                },
                getItems() {
                    axios.get("{{url('searchItem') }}?" +
                        "type=" + 'item'
                    )
                        .then((res) => {
                            this.itemData = res.data;
                        });
                },

                addRow(index) {
                    if (this.items[index + 1] == undefined) {
                        this.items.push({item: {quantity: 0, amount: 0}});

                    }

                },
                deleteItem(index, type = 'unops') {
                    if (type == 'unops') {
                        if (this.items.length - 1 > 0) this.items.splice(index, 1);
                    }
                },
                getItemTotal(item = null) {
                    let result = 0;
                    if (item != null && item.amount > 0) {
                        let amount = item.amount;
                        let quantity = item.quantity;
                        let total = Number.parseFloat(amount) * Number.parseFloat(quantity);
                        result = Number.parseFloat(total).toFixed(2);
                    }
                    return result;
                },
                /**
                 * handleSubmit
                 */
                handleSubmit(e, type = 'save') {
                    this.$validator.validate().then(valid => {
                        if (valid) {
                            let ids = [];
                            eventDefault();
                            let url = (e.target.form == undefined) ? e.target.action : e.target.form.action;
                            let data = (e.target.form == undefined) ? $(e.target).serialize() : $(e.target.form).serialize();
                            data = new FormData(e.target.form);
                            toggleBlock(1);
                            axios.post(url, data)
                                .then(function (response) {
                                    toggleBlock(0);
                                    let message = "{{__('message.success')}}";
                                    if (response.data) {
                                        message = response.data.message;
                                    }
                                    alertify.success(message);
                                    if (type != 'save') {
                                        vm.defaultValue(e);
                                    } else {
                                        window.location.href = "{{route('receipt.index')}}";
                                    }
                                })
                                .catch(function (error) {
                                    toggleBlock(0);
                                    let warning = "{{__('message.error')}}";
                                    if (error.response.data) {
                                        if (error.response.data.message) {
                                            warning = error.response.data.message;
                                        }
                                        if ((error.response.status == 422) == true) {
                                            let my_error = error.response.data.errors;

                                            for (index in my_error) {

                                                alertify.error(my_error[index][0]);
                                            }

                                        }
                                    }

                                    alertify.error(warning);
                                })
                        }
                    });
                },
                /**
                 * this is used to set default value
                 */


            }
        });

    </script>

    <style>
        .vue_dropdown .vs__dropdown-toggle {
            border: none !important;
        }
    </style>

@endsection
