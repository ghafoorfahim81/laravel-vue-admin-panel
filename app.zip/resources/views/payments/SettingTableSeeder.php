<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Setting;
use Hash;

class SettingTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        if(count(Setting::all()) == 0) {
           $setting =  new Setting;
           $setting->referral_password = Hash::make('referral@@!!');
           $setting->save();
        }
    }
}
