@extends('layouts.master')
@section('title', __('lang.edit').' '.__('lang.user'))
@section('css')
<link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css" />


@endsection
@section('content')
<div class="page-content">

    <!-- Page-Title -->
    <div class="page-title-box">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h4 class="page-title mb-1">Starter page</h4>
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Pages</a></li>
                    <li class="breadcrumb-item active">Starter</li>
                    </ol>
                </div>
                <div class="col-md-4">
                    <div class="float-right d-none d-md-block">
                        <div class="dropdown">
                            <button class="btn btn-light btn-rounded dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="mdi mdi-settings-outline mr-1"></i> Settings
                            </button>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated">
                                <a class="dropdown-item" href="#">Action</a>
                                <a class="dropdown-item" href="#">Another action</a>
                                <a class="dropdown-item" href="#">Something else here</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#">Separated link</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- end page title end breadcrumb -->

    <div class="page-content-wrapper" id="myapp" v-cloak>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                    <form action="{{route('user.update',$user->id)}}" @submit="handleSubmit($event)" method="post" class="form-horizontal" accept-charset="utf-8" enctype="multipart/form-data">
                    @csrf
                    @method('patch')
                        <input type="hidden" name="permission_id" id="permission_id">
                        <div class="card-body" style="padding-bottom: 0px">
                            <div class="card-body client-nav">
                                <h4 class="header-title">@lang('lang.edit') @lang('lang.user')</h4>
                                <div class="row">
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.name')
                                                <span class="rq">*</span>
                                                </label>
                                                <input type="text" name="name" value="{{$user->name}}" class="form-control" id="" v-validate="'required'" data-vv-as="@lang('lang.name')"  placeholder="@lang('lang.name')" >
                                                <span class="help-block rq-hint">
                                                    @{{errors.first('name')}}</span>
                                            </div>
                                        </div>
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.email')
                                                <span class="rq">*</span>
                                                </label>
                                                <input type="text" name="email" value="{{$user->email}}" class="form-control" id=""  v-validate="'required'" data-vv-as="@lang('lang.email')" placeholder="@lang('lang.email')" >
                                                <span class="help-block rq-hint">
                                                    @{{errors.first('email')}}</span>
                                            </div>
                                        </div>



                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.role')
                                                <span class="rq">*</span>
                                                </label>

                                                <v-select :select-on-tab="true"
                                                        v-model="selected_role"
                                                        multiple
                                                        label="name"
                                                        :options="role" placeholder="@lang('lang.role')"
                                                    >

                                                        <template v-slot:no-options="{ search, searching }">
                                                            <template v-if="searching">
                                                                @lang('lang.no_record_found_for') @{{search}}
                                                            </template>
                                                            <em class="v-select-search-hint" v-else>@lang('lang.type_to_search')</em>
                                                        </template>
                                                    </v-select>
                                                    <input type="hidden" v-model="selected_role" name="role_ids" id="role_ids" v-validate="'required'" data-vv-as="@lang('lang.role')" class="form-control" placeholder="@lang('lang.role')" />
                                                    <span class="help-block rq-hint">
                                                    @{{errors.first('role_ids')}}</span>

                                            </div>
                                        </div>


                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.password')
                                                <span class="rq">*</span>
                                                </label>
                                                <input type="password" name="password"  class="form-control" id=""   placeholder="@lang('lang.password')" >
                                                <span class="help-block rq-hint">
                                                    @{{errors.first('password')}}</span>

                                            </div>
                                        </div>


                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.confirm_password')
                                                <span class="rq">*</span>
                                                </label>
                                                <input type="confirm_password" name="confirm_password"  class="form-control" id=""  placeholder="@lang('lang.confirm_password')" >
                                                 <span class="help-block rq-hint">
                                                    @{{errors.first('confirm_password')}}</span>

                                            </div>
                                        </div>

                                        <div class="col-xl-4">
                                            <div class="form-group">
                                            <label for=""></label>
                                            <br>
                                               <input type="checkbox" name="is_psychologist" v-model="is_psychologist" class="" id=""  placeholder="@lang('lang.is_psychologist')" >

                                                <label for="">@lang('lang.is_psychologist')</label>
                                                <span class="help-block rq-hint">
                                                    @{{errors.first('is_psychologist')}}</span>

                                            </div>
                                        </div>


                                    </div>
                                    <!-- permision -->
                                    <div class="row">
                                        <div class="col-xl-12">
                                            <div class="form-group">
                                                <input type="checkbox" name="extra_permission" v-model="extra_permission" class="" id="" >

                                                <label for="">@lang('lang.permission')</label>


                                            </div>
                                        </div>




                                        <div v-if="extra_permission">
                                            <div class="col-xl-12" v-for="(item,g_index) of permission_group">
                                                <div class="card">
                                                    <h5 class="card-header bg-transparent border-bottom mt-0">
                                                    <input type="checkbox" @click="checkPoint(item.permission_group_id,0,'parent')" id="item.permission_group_name" :checked="item.checked">

                                                    @{{item.permission_group_name}}</h5>
                                                    <div class="card-body">
                                                        <span v-for="permessions of item.permissions">
                                                            <!-- <h4 class="card-title font-size-16 mt-0">Special title treatment</h4> -->
                                                            <p class="card-text">
                                                            <input type="checkbox" @click="checkPoint(item.permission_group_id,permessions.permission_id,'child')" id="jack" value="permessions.permission_name"  :checked="permessions.checked">

                                                            @{{permessions.permission_name}}</p>
                                                            <!-- <a href="#" class="btn btn-primary">Go somewhere</a> -->
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <!-- end of permission -->






                            </div>
                        </div>

                            <div class="card-footer ">
                                <button class="btn btn-md btn-primary" type="button" @click="handleSubmit($event)" ><span hidden id="btn-loading" class="spinner-border spinner-border-sm" user="status" aria-hidden="true"></span>  @lang('lang.save')</button>
                                <button class="btn btn-md btn-danger " type="button" onclick="location.href='{{route('user.index')}}'">@lang('lang.cancel')</button>

                            </div>

                        </form>
                    </div>

                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- end container-fluid -->
    </div>
    <!-- end page-content-wrapper -->
</div>
<!-- End Page-content -->
@endsection
@section('js')
<script>
    var permission_group = {!! $permission_data !!};

var vm=new Vue({
    el:'#myapp',
    data:{
        permission_group:permission_group,
        permission: [],
        selected_permission:[],
        select_all:false,

        role:{!! $role !!},
        user:{!! $user !!},
        selected_role:[],
        userRole:{!! $userRole !!},
        extra_permission:false,
        is_psychologist:false,
        form:{
            name:null,
            email:null,
            password:null,
            confirm_password:null,
            role_ids:[],
        }

  },
  mounted:function(){

    if(this.userRole.length)
    {
        this.selected_role=this.userRole;
    }

    this.form.name=this.user.name;
    this.form.email=this.user.email;

    if(this.user.extra_permission)
    {
        this.extra_permission=true;
    }
    if(this.user.is_psychologist)
    {
        this.is_psychologist=true;
    }


  },
  methods:{

        /**
     * handleSubmit
     */
    handleSubmit(e,type='save')
    {
        this.$validator.validate().then(valid => {

        if (valid) {
            //e.target.form.submit()
            e.preventDefault();
            let ids = [];
            for (let i = 0; i < this.selected_role.length; i++) {
                ids.push(this.selected_role[i].id)

            }

            $('#role_ids').val(ids);

            let selected_p = [];
            for (var i = 0; i < this.permission_group.length; i++)
            {
                for (var m = 0; m < this.permission_group[i].permissions.length; m++) {

                if(this.permission_group[i].permissions[m].checked)
                {
                    selected_p.push(this.permission_group[i].permissions[m].permission_id);
                }
                }

            }
            document.getElementById('permission_id').value=selected_p;

              let url=(e.target.form==undefined)?e.target.action:e.target.form.action;
            let data =(e.target.form==undefined)?$(e.target).serialize():$(e.target.form).serialize();
            data = new FormData(e.target.form);
            toggleBlock(1);
            axios.post(url,data)
            .then(function(response){
                toggleBlock(0);
                let message="{{__('message.success')}}";
                if(response.data)
                {
                    message=response.data.message;
                }
                alertify.success(message);
                if(type !='save')
                {
                    vm.defaultValue(e);
                }
                else
                {
                    window.location.href="{{route('user.index')}}";
                }
            })
            .catch(function(error){
                toggleBlock(0);
                let warning="{{__('message.error')}}";
                if(error.response.data)
                {
                    if(error.response.data.message)
                    {
                        warning=error.response.data.message;
                    }
                    if((error.response.status==422)==true)
                    {
                        let my_error=error.response.data.errors;

                        for(index in my_error)
                        {

                            alertify.error(my_error[index][0]);
                        }

                    }
                }

                alertify.error(warning);
            })
        }
    });
    },



     //handle check and uncheck or permission
     checkPoint(p_g_id, p_id, type) {

        if (type == 'all') {
        this.select_all = !this.select_all;
        if (this.select_all == true) {

            for (var i = 0; i < this.permission_group.length; i++) {
            for (var m = 0; m < this.permission_group[i].permissions.length; m++) {

                this.permission_group[i].permissions[m].checked = true;
            }
            this.permission_group[i].checked = true;

            }
        }
        else {
            for (var i = 0; i < this.permission_group.length; i++) {
            for (var m = 0; m < this.permission_group[i].permissions.length; m++) {

                this.permission_group[i].permissions[m].checked = false;
            }
            this.permission_group[i].checked = false;

            }
        }
        }
        //begin parent
        if (type == 'parent') {
        for (var i = 0; i < this.permission_group.length; i++) {
            if (this.permission_group[i].permission_group_id == p_g_id) {
            this.permission_group[i].checked = !this.permission_group[i].checked;
            var flag = this.permission_group[i].checked;
            for (var m = 0; m < this.permission_group[i].permissions.length; m++) {

                this.permission_group[i].permissions[m].checked = flag;
            }
            }
        }
        }

        // end parent


        //begin child

        if (type == 'child') {
        for (var i = 0; i < this.permission_group.length; i++) {

            let flag_temp=false;
            for (var m = 0; m < this.permission_group[i].permissions.length; m++) {
                if (p_id == this.permission_group[i].permissions[m].permission_id) {
                    var temp = !this.permission_group[i].permissions[m].checked;
                    this.permission_group[i].permissions[m].checked = temp;
                }

                if(this.permission_group[i].permissions[m].checked==false)
                {
                    flag_temp=true;
                    this.permission_group[i].checked=false;
                }


            }

            if(flag_temp==false)
            {
                this.permission_group[i].checked=true;
            }

        }
        }
        // end child


        let check_all_check=false;
        for (var i = 0; i < this.permission_group.length; i++)
        {
            for (var m = 0; m < this.permission_group[i].permissions.length; m++)
            {

                if(this.permission_group[i].permissions[m].checked==false)
                {
                    check_all_check=true;
                }
            }

        }

        if(check_all_check==true)
        {
            // not check all
            this.select_all=false;
        }
        else
        {
            this.select_all=true;
        }

        },




  }
 });
</script>


@endsection
