@extends('layouts.master')
@section('title', __('lang.backup_list'))
@section('css')
<link href="{{asset('css/modal.css')}}" rel="stylesheet" type="text/css" />


@endsection
@section('content')

        <div class="page-content-wrapper" id="app" v-cloak>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card">
                            <input type="hidden" name="permission_id" id="permission_id">
                            <div class="card-body" style="padding-bottom: 0px">
                                <div class="card-body client-nav">
                                    <div class="row pb-2">
                                        <div class="col-sm-12 col-md-2 form-inline">
                                            <div class="form-group">
                                                @if(hasPermission(['backup_create']))
                                                    <button @click="addNew('backup')" class="btn btn-info btn-sm waves-effect waves-light" type="button">@lang('lang.add') @lang('lang.backup')
                                                        <i class="mdi mdi-plus-thick"></i></button>&nbsp
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-sm-12 col-md-3 offset-7 form-inline">
                                            <div class="form-group">



                                            </div>
                                        </div>
                                    </div>

                                    <div class=" ">
                                            <datatable ref="child" :per-page="{{perPage()}}" :no-record-found-text="'@lang('lang.no_record_found')'"
                                                       :per-page-text="'@lang('lang.show')'" :showing-text="'@lang('lang.showing')'"
                                                       :from-text="'@lang('lang.from')'" :to-text="'@lang('lang.to')'" :record-text="'@lang('lang.record')'"
                                                       :app-per-page="{!! perPage(1) !!}"  :columns="columns" :data="apiData"
                                                       @pagination-change-page="getRecord" :limit="1" :filterRecord="getRecord">
                                            <template slot="tbody">
                                                <tbody>
                                                <tr v-for="(record,index) in apiData.data" :key="record.id">
                                                    <td> @{{record.file_name}} </td>
                                                    <td> @{{record.file_size}} </td>
                                                    <td> @{{record.date}} </td>
                                                    <td class="button-items">
                                                        <div class="btn-group" role="group" style="width: 180px; text-align:center">
                                                            @if(hasPermission(['backup_show']))
                                                            <a  class="btn btn-info btn-sm" :href="`{{url('/')}}/backupDownload/${record.file_name}`" data-toggle="tooltip" data-placement="top" title="View">
                                                                <i class="fa fa-download"></i>
                                                            </a>&nbsp;

                                                            @endif

                                                            @if(hasPermission(['backup_delete']))
                                                                    <a  class="btn btn-danger btn-sm" @click="deleteRecord(record.file_name)"
                                                                data-toggle="tooltip" data-placement="top" title="Delete">
                                                                <i style="color: white" class="mdi mdi-delete"></i>
                                                                </a>
                                                            @endif
                                                        </div>
                                                    </td>
                                                </tr>

                                                </tbody>

                                            </template>
                                        </datatable>
                                    </div>
                                </div>
                            </div>

                            <div class="card-footer ">
                            </div>

                        </div>

                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- end container-fluid -->
        </div>
        <!-- end page-content-wrapper -->







<!-- begin new backup modal -->


<div id="backup-modal" v-cloak>
    <simple-modal :report-title="'@lang('lang.backup')'"  v-if="is_show" @close="closeModal">

        <div slot="body">
            <form action="{{route('backup.store')}}" id="backup-modal-form" @submit="addbackup('backup-modal-form',$event)"  method="post"  class="form-horizontal" accept-charset="utf-8" enctype="multipart/form-data">
            @csrf
            <input type="submit" style="display:none">
            <div class="row">
                <span><span style="color:red">@lang('lang.note')</span>: @lang('lang.required_note')</span><br>
                  <br>
            </div>
            <div class="row">

                <div class="col-xl-6">
                    <div class="form-group">
                        <label for="">@lang('lang.name')
                        <span class="rq">*</span>
                        </label>
                        <input type="name" name="name" class="form-control"    placeholder="@lang('lang.name')" >

                    </div>
                </div>



            </div>
            </form>

        </div>



        <div slot="footer">
            <button class="btn btn-info" @click="addbackup('backup-modal-form')">
                @lang('lang.add')
            </button>
            <button class="btn btn-danger" @click="closeModal">
                @lang('lang.cancel')
            </button>
        </div>

    </simple-modal>





</div>
<!-- end new backup modal -->

@endsection
@include('shared.simple_modal')

@section('js')
    <script>

        //Vue.component('pagination', require('laravel-vue-pagination'));
        var vm=new Vue({
            el:'#app',
            data(){
                return{
                url:'{{route("backup.index")}}?',
                    columns: [
                        {
                            label: "@lang('lang.name')",
                            name: 'name',
                        },
                        {
                            label: "@lang('lang.file_size')",
                            name: 'file_size',
                        },
                        {
                            label: "@lang('lang.date')",
                            name: 'date',
                            sort: true,
                            activeSort:true,
                            order_direction:'desc',
                        },
                        {
                            label: "@lang('lang.actions')",
                            name: 'action',
                            sort: false
                        }
                    ],

                    apiData:{},
                    appPerPage:{!! perPage(1) !!},
                    perPage:"{{perPage()}}",
                    page:1
                }

            },
            mounted:function(){
                this.getRecord();
            },
            methods:{

                /**
                 * get record from api
                 */

                getRecord:_.debounce((page=vm.page)=>
                {
                    axios.get(vm.url+
                        '&current_page='+
                        page+'&per_page='+vm.perPage)
                        .then((response)=>{
                            if(response.data)
                            {
                                vm.page=response.data.current_page;
                            }
                            vm.apiData=response.data;
                        })
                        .catch((error)=>{
                            console.log(error);
                        });
                },200),

                // delete record
                deleteRecord(id)
                {
                    deleteItem(`backup/${id}`);
                },

                addNew(type)
                {

                    if(type=='backup')
                    {
                        backupModal.$data.is_show=true;
                    }

                },

            }
        });










    //  modal new member

    var backupModal=new Vue({
        el:'#backup-modal',
        data:{
            is_show:false,
        },
        mounted:function(){
        },
        methods:
        {
            closeModal()
            {
                this.is_show=!this.is_show;
            },


            // add new item category
            addbackup(formId,e=null)
            {
                if(e!=null)
                {
                    e.preventDefault();
                }
                if (valid=1) {

                    let form=$('#'+formId);
                    form=form[0];
                    let url=form.action;
                    let data =$('#'+formId).serialize();

                    toggleBlock(1);
                    axios.post(url,data)
                    .then(function(response){


                        toggleBlock(0);
                        let message="{{__('message.created_success')}}";
                        alertify.success(message);
                        vm.getRecord();
                        backupModal.closeModal();


                    })
                    .catch(function(error){
                        toggleBlock(0);
                        let warning="{{__('message.warning')}}";
                        alertify.error(warning);
                    })
                }

            },


        }
    });
    // end modal member



    </script>
@endsection
