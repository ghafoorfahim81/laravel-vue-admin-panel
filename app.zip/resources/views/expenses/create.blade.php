@extends('layouts.master')
@section('title', __('lang.add').' '.__('lang.expense'))
@section('css')
<link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css" />
<link href="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}" rel="stylesheet" type="text/css" />


@endsection
@section('content')
<div class="page-content-wrapper" id="myapp" v-cloak>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <form action="{{route('expense.store')}}" method="post" id="userForm" enctype="multipart/form-data">
                        @csrf

                        <div class="card-body" style="padding-bottom: 0px">
                            <div class="">
                                <!-- <h4 class="header-title">@lang('lang.add') @lang('lang.order')</h4> -->
                                <div class="row justify-content-center">
                                    <div class="row">
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.date')
                                                </label>
                                                <input type="date" name="date" value="<?php echo date('Y-m-d'); ?>" class="form-control" autocomplete="new-password" data-vv-as="@lang('lang.password')" placeholder="@lang('lang.date')">
                                                <span class="help-block rq-hint">
                                                    @{{errors.first('date')}}</span>
                                            </div>
                                        </div>

                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.category')
                                                </label>
                                                <v-select :select-on-tab="true" v-model="selected_category" label="name" :options="categories" placeholder="@lang('lang.select_category')">
                                                    <template v-slot:no-options="{ search, searching }">
                                                        <template v-if="searching">
                                                            @lang('lang.no_record_found_for') @{{search}}
                                                        </template>
                                                        <em class="v-select-search-hint" v-else>@lang('lang.type_to_search')</em>
                                                    </template>
                                                </v-select>
                                                <input type="hidden" name="category_id" :value="(selected_category == null) ? null : selected_category.id">
                                            </div>
                                        </div>
                                        <div class="col-xl-4" >
                                            <div class="form-group">
                                                <label for="">@lang('lang.currency')
                                                </label>
                                                <v-select :select-on-tab="true"
                                                v-model="selected_currency"
                                                label="code"
                                                :options="currencies"
                                                placeholder="@lang('lang.select_currency')"
                                                >
                                                <template v-slot:no-options="{ search, searching }">
                                                    <template v-if="searching">
                                                        @lang('lang.no_record_found_for') @{{search}}
                                                    </template>
                                                    <em class="v-select-search-hint"
                                                    v-else>@lang('lang.type_to_search')</em>
                                                </template>
                                            </v-select>
                                            <input type="hidden" name="currency"
                                            :value="(selected_currency == null) ? null : selected_currency.code">
                                        </div>
                                    </div>
                                        <div class="col-xl-2">
                                            <div class="form-group">
                                                <label for="">@lang('lang.rate')
                                                </label>
                                                <input type="double" name="rate" id="rate" class="form-control" autocomplete="new-rate" data-vv-as="@lang('lang.rate')" placeholder="@lang('lang.rate')">
                                                <span class="help-block rq-hint">
                                                    @{{errors.first('rate')}}</span>
                                            </div>
                                        </div>

                                        <div class="col-xl-8">
                                            <div class="form-group">
                                                <label for="">@lang('lang.description')
                                                </label>
                                                <textarea name="details" class="form-control" id="exampleFormControlTextarea1" name="desc" rows="2">
                                                    </textarea>
                                                <span class="help-block rq-hint">
                                                    @{{errors.first('description')}}</span>
                                            </div>
                                        </div>


                                        <div class="col-xl-4 pb-3" style="    align-self: self-end;">

                                            <div class="w-full shadow-4 rounded-sm p-3 border">
                                                <div class="row justify-around">
                                                    <span class="font-weight-bold text-xl col-7">Grand Total</span>
                                                    <span class="font-weight-bold text-xl col text-end">@{{total}}</span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                <!-- end page title end breadcrumb -->

                <div class="">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">

                                        <h4 class="header-title">Add Item</h4>
                                        <!-- <p class="card-title-desc">This is an experimental awesome solution for responsive tables with complex data.</p> -->

                                        <div class="table-rep-plugin">
                                            <div class="table-responsive mb-0" data-pattern="priority-columns">
                                                <table id="tech-companies-1" class="table table-striped">
                                                    <thead>
                                                        <tr>
                                                            <th>No</th>
                                                            <th data-priority="3">Amount</th>
                                                            <th data-priority="1">Description</th>
                                                            <th data-priority="1">actions</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr v-for="(item, index) in items">
                                                            <th>@{{index+1}}</th>
                                                            <td><input class="form-control" type="number" name="amount[]" id="" v-model="item.amount" @click="add(index)"></td>
                                                            <td><input class="form-control ml-2" name="description[]" id="" v-model="item.description"></td>
                                                            <td class="text-center">
                                                                <button type="button" class="btn-danger btn-rounded" type="button" @click="remove(index)"><i class="mdi mdi-trash-can"></i></button>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>

                                        </div>

                                    </div>

                                </div>
                                <div class="text-right pb-3">


                                    <button type="submit" class="btn btn-info">
                                        <span class="spinner-border-sm" role="status" aria-hidden="true"></span>
                                        <span class="ml-2">Save Changes</span>
                                    </button>


                                </div>
                            </div> <!-- end col -->

                        </div> <!-- end row -->

                    </div>

                    <!-- end container-fluid -->
                </div>
                <!-- end page-content-wrapper -->

                <!-- Save-Banner Start -->

                <!-- Save-Banner End -->
                </form>
            </div>

        </div>

    </div>
    <!-- end row -->
</div>
<!-- end container-fluid -->
</div>
<!-- end page-content-wrapper -->


@endsection
@section('js')


<script>
    let home_currency = {!!$home_currency!!}
    var vm = new Vue({
        el: '#myapp',
        data: {
            date: null,
            currencies: [],
            selected_currency: null,
            categories: [],
            selected_category: null,
            spinner: 'spinner-border',
            disabled: true,
            items: [{
                description: null,
                amount: null
            }]
        },
        mounted() {
            console.log('home_currency', home_currency);

            axios.get("{{route('categories')}}")
                .then(data => this.categories = data.data)
                .then(() => {
                    axios.get("{{route('currency.default')}}").
                    then(data => this.currencies = data.data)
                        .then(() => {
                            // this.selected_currency = home_currency;
                            this.selected_currency = this.currencies.find(e=>e.code == home_currency.code);
                            rate.value = home_currency.exchange_rate
                        })
                });
        },
        computed: {
            total() {
                let sum = 0;
                this.items.forEach(e => {
                    if (e.amount != null)
                        sum += Number(e.amount);
                });
                return sum;
            }
        },
        methods: {
            /**
             * handleSubmit
             */
            handleSubmit(e, type = 'save') {
                console.log('type', type);
                this.$validator.validate().then(valid => {

                    if (valid) {


                        document.getElementById('permission_id').value = selected_p;
                        e.preventDefault();
                        // let url = "{{route('expense.store')}}";
                        let url = (e.target.form == undefined) ? e.target.action : e.target.form.action;
                        let data = (e.target.form == undefined) ? $(e.target).serialize() : $(e.target.form).serialize();
                        data = new FormData(e.target.form);
                        toggleBlock(1);
                        axios.post(url, data)
                            .then(function(response) {
                                toggleBlock(0);
                                let message = "{{__('message.success')}}";
                                if (response.data) {
                                    message = response.data.message;
                                }
                                alertify.success(message);
                                if (type != 'save') {
                                    vm.defaultValue(e);
                                    window.location.href = "{{route('expense.index')}}";
                                } else {
                                    window.location.href = "{{route('expense.index')}}";
                                }
                            })
                            .catch(function(error) {
                                toggleBlock(0);
                                let warning = "{{__('message.error')}}";
                                if (error.response.data) {
                                    if (error.response.data.message) {
                                        warning = error.response.data.message;
                                    }
                                    if ((error.response.status == 422) == true) {
                                        let my_error = error.response.data.errors;

                                        for (index in my_error) {

                                            alertify.error(my_error[index][0]);
                                        }

                                    }
                                }

                                alertify.error(warning);
                            })
                    }
                });
            },
            remove(index = 0) {
                if (index > 0)
                    this.items.splice(index, 1);
            },
            add(index = 0) {
                if (this.items.length - 1 == index)
                    this.items.push({
                        description: null,
                        amount: null
                    })
            },
            getRate() {
                // console.log('this.selected_currency',this.selected_currency.id);
                axios.get('/getRate/' + this.selected_currency.id).then(data => rate.value = data.data.exchange_rate)
            }
        }
    });
</script>

<style>
    .vue_dropdown .vs__dropdown-toggle {
        border: none !important;
    }
</style>

@endsection