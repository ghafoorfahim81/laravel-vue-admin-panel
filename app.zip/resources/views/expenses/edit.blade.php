@extends('layouts.master')
@section('title', __('lang.edit').' '.__('lang.expense'))
@section('css')
<link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css" />
<link href="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}" rel="stylesheet" type="text/css" />


@endsection
@section('content')
<div class="page-content-wrapper" id="myapp" v-cloak>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <form action="{{route('expense.update', $id)}}" @submit="handleSubmit($event)" method="post" id="userForm" enctype="multipart/form-data">
                        @csrf
                        @method('patch')
                        <div class="card-body" style="padding-bottom: 0px">
                            <div class="">
                                <!-- <h4 class="header-title">@lang('lang.add') @lang('lang.order')</h4> -->
                                <div class="row justify-content-center">
                                    <div class="row">
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.date')
                                                </label>
                                                <input type="date" name="date" v-model="date" class="form-control" autocomplete="new-password" data-vv-as="@lang('lang.password')" id="date" placeholder="@lang('lang.date')">
                                                <span class="help-block rq-hint">
                                                    @{{errors.first('date')}}</span>
                                            </div>
                                        </div>

                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.category')
                                                </label>
                                                <v-select :select-on-tab="true" v-model="selected_category" label="name" :options="categories" placeholder="@lang('lang.select_category')">
                                                    <template v-slot:no-options="{ search, searching }">
                                                        <template v-if="searching">
                                                            @lang('lang.no_record_found_for') @{{search}}
                                                        </template>
                                                        <em class="v-select-search-hint" v-else>@lang('lang.type_to_search')</em>
                                                    </template>
                                                </v-select>
                                                <input type="hidden" name="category_id" :value="(selected_category == null) ? null : selected_category.id">
                                            </div>
                                        </div>
                                        <div class="col-xl-2">
                                            <div class="form-group">
                                                <label for="">@lang('lang.currency')
                                                </label>
                                                <v-select :select-on-tab="true"
                                                          v-model="selected_currency"
                                                          label="code"
                                                          :options="currencies" placeholder="@lang('lang.currency')"
                                                >
                                                    <template v-slot:no-options="{ search, searching }">
                                                        <template v-if="searching">
                                                            @lang('lang.no_record_found_for') @{{search}}
                                                        </template>
                                                        <em class="v-select-search-hint"
                                                            v-else>@lang('lang.type_to_search')</em>
                                                    </template>
                                                </v-select>
                                                <input type="hidden" name="currency"
                                                       :value="selected_currency?selected_currency.code:null">
                                            </div>
                                        </div>
                                        <div class="col-xl-2">
                                            <div class="form-group">
                                                <label for="">@lang('lang.rate')
                                                </label>
                                                <input type="double" name="rate" id="rate" class="form-control" autocomplete="new-rate" data-vv-as="@lang('lang.rate')" v-model="rate" placeholder="@lang('lang.rate')">
                                                <span class="help-block rq-hint">
                                                    @{{errors.first('rate')}}</span>
                                            </div>
                                        </div>

                                        <div class="col-xl-8">
                                            <div class="form-group">
                                                <label for="">@lang('lang.description')
                                                </label>
                                                <textarea name="details" id="details" class="form-control" name="desc" rows="2">
                                                    </textarea>
                                                <span class="help-block rq-hint">
                                                    @{{errors.first('description')}}</span>
                                            </div>
                                        </div>
                                        <div class="col-xl-2">
                                            <div class="form-group mt-4">
                                                <button type="button" class="btn btn-info mr-2">
                                                    Total <span class="badge badge-primary ml-1">@{{total}}</span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title end breadcrumb -->

                        <div class="">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="card">
                                            <div class="card-body">

                                                <h4 class="header-title">Add Item</h4>
                                                <!-- <p class="card-title-desc">This is an experimental awesome solution for responsive tables with complex data.</p> -->

                                                <div class="table-rep-plugin">
                                                    <div class="table-responsive mb-0" data-pattern="priority-columns">
                                                        <table id="tech-companies-1" class="table table-striped">
                                                            <thead>
                                                                <tr>
                                                                    <th>No</th>
                                                                    <th data-priority="3">Amount</th>
                                                                    <th data-priority="1">Description</th>
                                                                    <th data-priority="1">actions</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr v-for="(item, index) in items">
                                                                    <th>@{{index+1}}</th>
                                                                    <td><input class="form-control" type="number" name="amount[]" id="" v-model="item.amount" @click="add(index)"></td>
                                                                    <td><input class="form-control" name="description[]" id="" v-model="item.description"></td>
                                                                    <td>
                                                                        <button class="btn-danger btn-rounded " type="button" @click="remove(index)"><i class="mdi mdi-trash-can"></i></button>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div> <!-- end col -->
                                </div> <!-- end row -->
                            </div>
                            <!-- end container-fluid -->
                        </div>
                        <!-- end page-content-wrapper -->

                        <!-- Save-Banner Start -->
                        <nav class="navbar navbar-expand-lg py-0 navbar-light bg-dark fixed-top ">
                            <div>
                                <a class="navbar-brand me-2" href="https://mdbgo.com/">
                                    <img src="https://mdbcdn.b-cdn.net/img/logo/mdb-transaprent-noshadows.webp" alt="MDB Logo" loading="lazy" style="margin-top: -1px;" />
                                </a>

                            </div>
                            <!-- Container wrapper -->
                            <div class="container">

                                <!-- Navbar brand -->


                                <!-- Toggle button -->
                                <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarButtonsExample" aria-controls="navbarButtonsExample" aria-expanded="false" aria-label="Toggle navigation">
                                    <i class="fas fa-bars"></i>
                                </button>

                                <!-- Collapsible wrapper -->
                                <div class="collapse navbar-collapse" id="navbarButtonsExample">
                                    <!-- Left links -->
                                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                                        <li class="nav-item">
                                            <a class="nav-link text-white text-xl" href="#">Unsaved Changes</a>
                                        </li>
                                    </ul>
                                    <!-- Left links -->

                                    <div class="d-flex align-items-center">
                                        <button type="button" onclick="location.href='{{route('expense.index')}}'" class="btn btn-dark px-3 me-2">
                                            Cancel
                                        </button>

                                        <button type="reset" class="btn btn-dark px-3 me-2">
                                            Reset
                                        </button>
                                        <button type="submit" class="btn btn-info" type="button">

                                            <span :class="spinner" class="spinner-border-sm" role="status" aria-hidden="true"></span>
                                            <span class="ml-2">Save Changes</span>
                                        </button>
                                    </div>
                                </div>
                                <!-- Collapsible wrapper -->
                            </div>
                            <!-- Container wrapper -->
                        </nav>
                        <!-- Save-Banner End -->
                    </form>
                </div>

            </div>

        </div>
        <!-- end row -->
    </div>
    <!-- end container-fluid -->
</div>
<!-- end page-content-wrapper -->


@endsection
@section('js')

<script>
    let expense = '{!!$expense!!}';
    var vm = new Vue({
        el: '#myapp',
        data: {
            date:null,
            currencies: [],
            selected_currency: null,
            rate:0,
            categories: [],
            selected_category: null,
            spinner: 'spinner-border',
            disabled: true,
            items: []
        },
        mounted: function() {
            console.log('expense', JSON.parse(expense));
            expense = JSON.parse(expense);
            axios.get("{{route('categories')}}")
                .then(data => this.categories = data.data)
                .then(() => {
                    axios.get("{{route('currency.default')}}").
                    then(data => this.currencies = data.data)
                        .then(() => {
                            this.selected_category = this.categories.filter(e=>e.id==expense[0].category_id);
                            console.log('test:', this.selected_category);
                            this.selected_currency = this.currencies.find(e=>e.code==expense[0].currency)
                            this.rate = expense[0].rate;
                            this.date = (expense[0]?.date).split(' ')[0];
                            document.getElementById('details').value = expense[0]?.details;
                            if (expense[0].amount!=null || expense[0].amount>0) {
                                expense.forEach(e => {
                                    this.items.push({
                                        description: e.description,
                                        amount: e.amount
                                    })
                                })
                            } else {
                                this.items.push({
                                        description: null,
                                        amount: null
                                    })
                            }
                        })
                });
        },
        computed: {
            total() {
                let sum = 0;
                this.items.forEach(e => {
                    if (e.amount != null)
                        sum += Number(e.amount);
                });
                return sum;
            }
        },
        methods: {
            /**
             * handleSubmit
             */
            handleSubmit(e, type = 'save') {
                console.log('type', type);
                this.$validator.validate().then(valid => {

                    if (valid) {


                        document.getElementById('permission_id').value = selected_p;
                        e.preventDefault();
                        // let url = "{{route('expense.store')}}";
                        let url = (e.target.form == undefined) ? e.target.action : e.target.form.action;
                        let data = (e.target.form == undefined) ? $(e.target).serialize() : $(e.target.form).serialize();
                        console.log('data are: ', data);
                        data = new FormData();
                        let category_id = (this.selected_category) ? this.selected_category.id: null;
                        data.append('cat_id', category_id);
                        data.append('data', e.target.form);
                        // return false;
                        toggleBlock(1);
                        axios.post(url, data)
                            .then(function(response) {
                                toggleBlock(0);
                                let message = "{{__('message.success')}}";
                                if (response.data) {
                                    message = response.data.message;
                                }
                                alertify.success(message);
                                if (type != 'save') {
                                    vm.defaultValue(e);
                                    window.location.href = "{{route('expense.index')}}";
                                } else {
                                    window.location.href = "{{route('expense.index')}}";
                                }
                            })
                            .catch(function(error) {
                                toggleBlock(0);
                                let warning = "{{__('message.error')}}";
                                if (error.response.data) {
                                    if (error.response.data.message) {
                                        warning = error.response.data.message;
                                    }
                                    if ((error.response.status == 422) == true) {
                                        let my_error = error.response.data.errors;

                                        for (index in my_error) {

                                            alertify.error(my_error[index][0]);
                                        }

                                    }
                                }

                                alertify.error(warning);
                            })
                    }
                });
            },
            remove(index = 0) {
                if (index > 0)
                    this.items.splice(index, 1);
            },
            add(index = 0) {
                if (this.items.length - 1 == index)
                    this.items.push({
                        description: null,
                        amount: null
                    })
            },
            getRate() {
                // console.log('this.selected_currency',this.selected_currency.id);
                axios.get('/getRate/' + this.selected_currency.id).then(data => rate.value = data.data.exchange_rate)
            },
        }
    });
</script>

<style>
    .vue_dropdown .vs__dropdown-toggle {
        border: none !important;
    }
</style>

@endsection