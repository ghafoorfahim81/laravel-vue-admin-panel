@extends('layouts.master')
@section('title', __('lang.view').' '.__('lang.expense'))
@section('css')
<link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css" />
<link href="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}" rel="stylesheet" type="text/css" />


@endsection
@section('content')
<div class="page-content-wrapper" id="myapp" v-cloak>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                        <div class="card-body" style="padding-bottom: 0px">
                            <div class="">
                                <!-- <h4 class="header-title">@lang('lang.add') @lang('lang.order')</h4> -->
                                <div class="row justify-content-center">
                                    <div class="row">
                                        <div class="col-xl-3">
                                            <div class="form-group">
                                                <label for=""><span class="title">@lang('lang.date'):</span> @{{date}}
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-xl-3">
                                            <div class="form-group">
                                                <label for=""><span class="title">@lang('lang.category'):</span> @{{selected_category[0].name}}
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-xl-3">
                                            <div class="form-group">
                                                <label for=""><span class="title">@lang('lang.currency'):</span> @{{selected_currency.code}}
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-xl-3">
                                            <div class="form-group">
                                                <label for=""><span class="title">@lang('lang.rate'):</span> @{{rate}}
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-xl-8">
                                            <div class="form-group">
                                                <label for=""><span class="title">@lang('lang.description'):</span> @{{description}}
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-xl-2">
                                            <div class="form-group mt-4">
                                                <button type="button" class="btn btn-info mr-2">
                                                    Total <span class="badge badge-primary ml-1">@{{total}}</span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title end breadcrumb -->

                        <div class="">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="card">
                                            <div class="card-body">

                                                <!-- <p class="card-title-desc">This is an experimental awesome solution for responsive tables with complex data.</p> -->

                                                <div class="table-rep-plugin">
                                                    <div class="table-responsive mb-0" data-pattern="priority-columns">
                                                        <table id="tech-companies-1" class="table table-striped">
                                                            <thead>
                                                                <tr>
                                                                    <th>No</th>
                                                                    <th data-priority="3">Amount</th>
                                                                    <th data-priority="1">Description</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr v-for="(item, index) in items">
                                                                    <th>@{{index+1}}</th>
                                                                    <td>@{{item.amount}}</td>
                                                                    <td>@{{item.description}}</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div> <!-- end col -->
                                </div> <!-- end row -->
                            </div>
                            <!-- end container-fluid -->
                        </div>
                        <!-- end page-content-wrapper -->

                        <!-- Save-Banner End -->
                </div>

            </div>

        </div>
        <!-- end row -->
    </div>
    <!-- end container-fluid -->
</div>
<!-- end page-content-wrapper -->


@endsection
@section('js')

<script>
    let expense = '{!!$expense!!}';
    var vm = new Vue({
        el: '#myapp',
        data: {
            date:null,
            currencies: [],
            selected_currency: null,
            rate:0,
            categories: [],
            selected_category: null,
            spinner: 'spinner-border',
            disabled: true,
            items: [],
            description:''
        },
        mounted: function() {
            console.log('expense', JSON.parse(expense));
            expense = JSON.parse(expense);
            axios.get("{{route('categories')}}")
                .then(data => this.categories = data.data)
                .then(() => {
                    axios.get("{{route('currency.default')}}").
                    then(data => this.currencies = data.data)
                        .then(() => {
                            this.selected_category = this.categories.filter(e=>e.id==expense[0].category_id);
                            console.log('test:', expense[0]?.details);
                            this.selected_currency = this.currencies.find(e=>e.code==expense[0].currency)
                            this.rate = expense[0].rate;
                            this.date = (expense[0]?.date).split(' ')[0];
                            this.description = expense[0]?.details;
                            if (expense[0].amount!=null || expense[0].amount>0) {
                                expense.forEach(e => {
                                    this.items.push({
                                        description: e.description,
                                        amount: e.amount
                                    })
                                })
                            } else {
                                this.items.push({
                                        description: null,
                                        amount: null
                                    })
                            }
                        })
                });
        },
        computed: {
            total() {
                let sum = 0;
                this.items.forEach(e => {
                    if (e.amount != null)
                        sum += Number(e.amount);
                });
                return sum;
            }
        },
        methods: {

        }
    });
</script>
<style>
    .title {
        font-weight: bolder
    }
</style>
@endsection
