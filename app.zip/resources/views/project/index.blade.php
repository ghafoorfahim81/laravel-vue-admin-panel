@extends('layouts.master')
@section('title', __('lang.project_list'))
@section('css')


@endsection
@section('content')

<div class="page-content-wrapper" id="app">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div style="display: flex;">
                        <div class="row m-4">
                            <div class="col-sm-12 col-md-2 form-inline">
                                <div class="form-group">
                                    @if(hasPermission(['project_create']))
                                    <button onclick="location.href='{{route('project.create')}}'" class="btn btn-info btn-sm waves-effect waves-light" type="button">@lang('lang.add') @lang('lang.project')
                                        <i class="mdi mdi-plus-thick"></i></button>&nbsp
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <ul class="nav nav-tabs mt-2" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" style="font-size: 15px;" data-toggle="tab" href="#started" role="tab">
                                        <i class="fas fa-hands-helping"></i>
                                        <span class="d-md-inline-block" @click="getRecord()">Started Projects</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link " style="font-size: 15px;" data-toggle="tab" href="#pending" role="tab">
                                        <i class="fas fa-exclamation-circle"></i>
                                        <span class="d-md-inline-block" @click="getRecordPending()">Pending Projects</span>
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" style="font-size: 15px;" data-toggle="tab" href="#finished" role="tab">
                                        <i class="fas fa-check"></i>
                                        <span class="d-md-inline-block" @click="getRecordFinished()">Finished Projects</span>
                                    </a>
                                </li>

                            </ul>
                        </div>

                        <!-- Tab panes -->
                        <div class="tab-content ">
                            <!-- Tab 1 Content Start -->
                            <div class="tab-pane " id="pending" role="tabpanel">
                                <div class="" style="padding-bottom: 0px">
                                    <div class="card-body client-nav">
                                        <div class=" text-right pb-2">
                                            <button type="button" @click="exortToExcelSingle('pending_project')" class="btn btn-success btn-sm">
                                                <i class="fas fa-file-excel"></i>
                                                <span class="ml-1">Excel</span>
                                            </button>
                                            <button type="button" @click="exortToPDF('pending_project')" class="btn btn-danger btn-sm ml-1">
                                                <i class="fas fa-file-pdf"></i>
                                                <span class="ml-1">PDF</span>
                                            </button>
                                        </div>
                                        <div class=" ">
                                            <datatable ref="child" :per-page="{{perPage()}}" :no-record-found-text="'@lang('lang.no_record_found')'" :per-page-text="'@lang('lang.show')'" :showing-text="'@lang('lang.showing')'" :from-text="'@lang('lang.from')'" :to-text="'@lang('lang.to')'" :record-text="'@lang('lang.record')'" :app-per-page="{!! perPage(1) !!}" :columns="all_columns[1]" :data="apiData_pending" @pagination-change-page="getRecordPending" :limit="1" :filterRecord="getRecordPending" :multiple-select="true" :selected-rows="selectedRows" @delete-method-action="deleteRecord">
                                                <template slot="tbody">
                                                    <tbody v-show="!apiData_started.data">
                                                        <tr v-for="skeleton in 4">


                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                    <tbody v-show="pending_show">
                                                        <tr v-for="(record,index) in apiData_pending.data" :key="record.id">
                                                            <td>
                                                                <input type="checkbox" class="" v-model="selectedRows" :value="record.id" :id="`checked-${record.id}}`">

                                                            </td>
                                                            <td> @{{++index}}</td>
                                                            <td v-if="record.code.length > 10"> @{{record.code.substr(0,10)}} ...</td>
                                                            <td v-else> @{{record.code}}</td>
                                                            <td> @{{record.name}}</td>
                                                            <td> @{{record.total_beneficiary}}</td>
                                                            <td> @{{record.start_date.substr(0,10)}}</td>
                                                            <td> @{{record.end_date.substr(0,10)}}</td>
                                                            <td> @{{record.location}}</td>
                                                            <td class="">
                                                                <div class="p-1" role="group" style="width: 180px; text-align: center;">
                                                                    @if(hasPermission(['project_view']))
                                                                    <a class="btn btn-info btn-sm" :href="`{{url('/project')}}/${record.id}`" data-toggle="tooltip" data-placement="top" title="View">
                                                                        <i class="mdi mdi-eye"></i>
                                                                    </a>&nbsp;
                                                                    @endif
                                                                    @if(hasPermission(['project_edit']))
                                                                    <a class="btn btn-primary btn-sm" :href="`{{url('/project/edit')}}/${record.id}`" data-toggle="tooltip" data-placement="top" title="Edit">
                                                                        <i class="dripicons-document-edit"></i>
                                                                    </a>&nbsp;
                                                                    @endif
                                                                    @if(hasPermission(['project_delete']))
                                                                    <a class="btn btn-danger btn-sm" @click="deleteRecord(record.id)" data-toggle="tooltip" data-placement="top" title="Delete">
                                                                        <i style="color: white" class="mdi mdi-delete"></i>
                                                                    </a>
                                                                    @endif


                                                                    <!-- <input v-else class="form-check-input" type="checkbox" checked="false"> -->
                                                                </div>
                                                            </td>
                                                        </tr>

                                                    </tbody>

                                                </template>
                                            </datatable>
                                            {{-- <Pagination align="center" :limit="1" :data="records" @pagination-change-page="getRecords"></Pagination>--}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Tab 1 Content End -->
                            <!-- Tab 2 Content Start -->
                            <div class="tab-pane active" id="started" role="tabpanel">
                                <div class="" style="padding-bottom: 0px">
                                    <div class="card-body client-nav">
                                        <div class=" text-right pb-2">
                                            <button type="button" @click="exortToExcelSingle('started_project')" class="btn btn-success btn-sm">
                                                <i class="fas fa-file-excel"></i>
                                                <span class="ml-1">Excel</span>
                                            </button>
                                            <button type="button" @click="exortToPDF('started_project')" class="btn btn-danger btn-sm ml-1">
                                                <i class="fas fa-file-pdf"></i>
                                                <span class="ml-1">PDF</span>
                                            </button>
                                        </div>
                                        <div class=" ">
                                            <datatable ref="child" :per-page="{{perPage()}}" :no-record-found-text="'@lang('lang.no_record_found')'" :per-page-text="'@lang('lang.show')'" :showing-text="'@lang('lang.showing')'" :from-text="'@lang('lang.from')'" :to-text="'@lang('lang.to')'" :record-text="'@lang('lang.record')'" :app-per-page="{!! perPage(1) !!}" :columns="all_columns[1]" :data="apiData_started" @pagination-change-page="getRecord" :limit="1" :filterRecord="getRecord" :multiple-select="true" :selected-rows="selectedRows" @delete-method-action="deleteRecord">
                                                <template slot="tbody">
                                                    <tbody v-show="!apiData_started.data">
                                                        <tr v-for="skeleton in 4">


                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>
                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                        </tr>
                                                    </tbody>
                                                    <tbody v-show="apiData_started.data">
                                                        <tr v-for="(record,index) in apiData_started.data" :key="record.id">
                                                            <td>
                                                                <input type="checkbox" class="" v-model="selectedRows" :value="record.id" :id="`checked-${record.id}}`">

                                                            </td>
                                                            <td> @{{++index}}</td>
                                                            <td v-if="record.code.length > 10"> @{{record.code.substr(0,10)}} ...</td>
                                                            <td v-else> @{{record.code}}</td>
                                                            <td> @{{record.name}}</td>
                                                            <td> @{{record.total_beneficiary}}</td>
                                                            <td> @{{record.start_date.substr(0,10)}}</td>
                                                            <td> @{{record.end_date.substr(0,10)}}</td>
                                                            <td> @{{record.location}}</td>

                                                            <td class="">
                                                                <div class="p-1" role="group" style="width: 180px; text-align: center;">
                                                                    @if(hasPermission(['project_view']))
                                                                    <a class="btn btn-info btn-sm" :href="`{{url('/project')}}/${record.id}`" data-toggle="tooltip" data-placement="top" title="View">
                                                                        <i class="mdi mdi-eye"></i>
                                                                    </a>&nbsp;
                                                                    @endif
                                                                    @if(hasPermission(['project_edit']))
                                                                    <a class="btn btn-primary btn-sm" :href="`{{url('/project/edit')}}/${record.id}`" data-toggle="tooltip" data-placement="top" title="Edit">
                                                                        <i class="dripicons-document-edit"></i>
                                                                    </a>&nbsp;
                                                                    @endif
                                                                    @if(hasPermission(['project_delete']))
                                                                    <a class="btn btn-danger btn-sm" @click="deleteRecord(record.id)" data-toggle="tooltip" data-placement="top" title="Delete">
                                                                        <i style="color: white" class="mdi mdi-delete"></i>
                                                                    </a>
                                                                    @endif
                                                                </div>
                                                            </td>
                                                        </tr>

                                                    </tbody>

                                                </template>
                                            </datatable>
                                            {{-- <Pagination align="center" :limit="1" :data="records" @pagination-change-page="getRecords"></Pagination>--}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Tab 2 Content End -->
                            <!-- Tab 3 Content Start -->
                            <div class="tab-pane" id="finished" role="tabpanel">
                                <div class="" style="padding-bottom: 0px">
                                    <div class="card-body client-nav">
                                        <div class=" text-right pb-2">
                                            <button type="button" @click="exortToExcelSingle('finish_project')" class="btn btn-success btn-sm">
                                                <i class="fas fa-file-excel"></i>
                                                <span class="ml-1">Excel</span>
                                            </button>
                                            <button type="button" @click="exortToPDF('finish_project')" class="btn btn-danger btn-sm ml-1">
                                                <i class="fas fa-file-pdf"></i>
                                                <span class="ml-1">PDF</span>
                                            </button>
                                        </div>
                                        <div class=" ">
                                            <datatable ref="child" :per-page="{{perPage()}}" :no-record-found-text="'@lang('lang.no_record_found')'" :per-page-text="'@lang('lang.show')'" :showing-text="'@lang('lang.showing')'" :from-text="'@lang('lang.from')'" :to-text="'@lang('lang.to')'" :record-text="'@lang('lang.record')'" :app-per-page="{!! perPage(1) !!}" :columns="all_columns[0]" :data="apiData_finished" @pagination-change-page="getRecordFinished" :limit="1" :filterRecord="getRecordFinished" :multiple-select="true" :selected-rows="selectedRows" @delete-method-action="deleteRecord">
                                                <template slot="tbody">
                                                    <tbody v-show="!apiData_finished.data">
                                                        <tr v-for="skeleton in 4">


                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>

                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>
                                                            <td>
                                                                <skeleton-loader-vue type="rect" :height="15" :width="50" class="m-3" animation="fade" />
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                    <tbody v-show="apiData_finished.data">
                                                        <tr v-for="(record,index) in apiData_finished.data" :key="record.id">
                                                            <td>
                                                                <input type="checkbox" class="" v-model="selectedRows" :value="record.id" :id="`checked-${record.id}}`">

                                                            </td>
                                                            <td> @{{++index}}</td>
                                                            <td v-if="record.code.length > 10"> @{{record.code.substr(0,10)}} ...</td>
                                                            <td v-else> @{{record.code}}</td>
                                                            <td> @{{record.name}}</td>
                                                            <td> @{{record.total_beneficiary}}</td>
                                                            <td> @{{record.start_date.substr(0,10)}}</td>
                                                            <td> @{{record.end_date.substr(0,10)}}</td>
                                                            <td> @{{record.location}}</td>
                                                            <td>
                                                                <input class="form-check-input" type="checkbox" :checked="Number.parseFloat(record.invoice)" disabled>
                                                            </td>
                                                            <td class="">
                                                                <div class="p-1" role="group" style="width: 230px; text-align:center">
                                                                    @if(hasPermission(['project_view']))
                                                                    <a style="padding: 0.375rem 0.6rem" class="btn btn-info btn-sm" :href="`{{url('/project')}}/${record.id}`" data-toggle="tooltip" data-placement="top" title="View">
                                                                        <i class="mdi mdi-eye"></i>
                                                                    </a>&nbsp;
                                                                    @endif
                                                                    @if(hasPermission(['project_edit']))
                                                                    <a style="padding: 0.375rem 0.6rem" class="btn btn-primary btn-sm" :href="`{{url('/project/edit')}}/${record.id}`" data-toggle="tooltip" data-placement="top" title="Edit">
                                                                        <i class="dripicons-document-edit"></i>
                                                                    </a>&nbsp;
                                                                    @endif
                                                                    @if(hasPermission(['project_delete']))
                                                                    <a style="padding: 0.375rem 0.6rem" class="btn btn-danger btn-sm" @click="deleteRecord(record.id)" data-toggle="tooltip" data-placement="top" title="Delete">
                                                                        <i style="color: white" class="mdi mdi-delete"></i>
                                                                    </a>
                                                                    @endif 
                                                                    @if(hasPermission(['invoice_create']))
                                                                    <a style="padding: 0.375rem 0.6rem" class="btn btn-primary btn-sm" :href="`{{url('/invoice/create')}}?project_id=${record.id}`" data-toggle="tooltip" data-placement="top" title="Add">
                                                                        <i class="mdi mdi-plus-thick"></i>
                                                                    </a>&nbsp;
                                                                    @endif
                                                                </div>
                                                            </td>
                                                        </tr>

                                                    </tbody>

                                                </template>
                                            </datatable>
                                            {{-- <Pagination align="center" :limit="1" :data="records" @pagination-change-page="getRecords"></Pagination>--}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Tab 3 Content End -->
                        </div>

                        <div class="card-footer ">
                        </div>

                    </div>

                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- end container-fluid -->
    </div>
    <!-- end page-content-wrapper -->

    @endsection
    @section('js')
    <script>
    //Vue.component('pagination', require('laravel-vue-pagination'));
    var vm = new Vue({
        el: '#app',
        components: {
            'skeleton-loader-vue': window.VueSkeletonLoader,
        },
        data() {
            return {
                url: '{{route("project.index")}}?',
                // columns:[],
                all_columns: [
                [{
                    label: "#",
                    name: '#',
                    sort: false,
                },
                {
                    label: "@lang('lang.code')",
                    name: 'projects.code',
                    sort: true,
                    // activeSort: true,
                    order_direction: 'desc',
                },
                {
                    label: "@lang('lang.name')",
                    name: 'projects.name',
                    sort: true,
                    // activeSort: true,
                    order_direction: 'desc',
                },
                 {
                    label: "@lang('lang.house')",
                    name: 'provinces.name',
                    sort: true,
                    // activeSort: true,
                    order_direction: 'desc',
                },
                {
                    label: "@lang('lang.start_date')",
                    name: 'projects.start_date',
                    sort: false,
                    // activeSort: false,
                    order_direction: 'desc',
                },
                {
                    label: "@lang('lang.end_date')",
                    name: 'projects.end_date',
                    sort: false,
                    // activeSort: false,
                    order_direction: 'desc',
                },
                {
                    label: "@lang('lang.province')",
                    name: 'provinces.name',
                    sort: true,
                    // activeSort: true,
                    order_direction: 'desc',
                },

               
                {
                    label: "@lang('lang.status')",
                    name: 'invoices.project_id',
                    sort: true,
                    // activeSort: true,
                    order_direction: 'desc',
                },
                {
                    label: "@lang('lang.actions')",
                    name: 'action',
                    sort: false
                }
                ],
                [{
                    label: "#",
                    name: '#',
                    sort: false,
                },
                {
                    label: "@lang('lang.code')",
                    name: 'projects.code',
                    sort: true,
                    // activeSort: true,
                    order_direction: 'desc',
                },
                {
                    label: "@lang('lang.name')",
                    name: 'projects.name',
                    sort: true,
                    // activeSort: true,
                    order_direction: 'desc',
                },
                 {
                    label: "@lang('lang.house')",
                    name: 'provinces.name',
                    sort: true,
                    // activeSort: true,
                    order_direction: 'desc',
                },
                {
                    label: "@lang('lang.start_date')",
                    name: 'projects.start_date',
                    sort: false,
                    // activeSort: false,
                    order_direction: 'desc',
                },
                {
                    label: "@lang('lang.end_date')",
                    name: 'projects.end_date',
                    sort: false,
                    // activeSort: false,
                    order_direction: 'desc',
                },
                {
                    label: "@lang('lang.province')",
                    name: 'provinces.name',
                    sort: true,
                    // activeSort: true,
                    order_direction: 'desc',
                },
               
                {
                    label: "@lang('lang.actions')",
                    name: 'action',
                    sort: false
                }
                ]
                ],
                pending_show: false,
                apiData_pending: {},
                apiData_started: {},
                apiData_finished: {},
                appPerPage: '{!! perPage(1) !!}',
                perPage: "{{perPage()}}",
                page: 1,
                selectedRows: [],
                project: {
                    code: null,
                    name: null,
                    province_id: null,
                    desc: null,
                    id: null,
                    start_date: null,
                    end_date: null
                },
                provinces: {!!$provinces!!},
                project_index: null,

            }

        },
        mounted() {
            this.getRecord();
        },
        methods: {
            getRecord: _.debounce((page = vm.page) => {
                let type = 'started';
                axios.get(vm.url +
                    '&current_page=' +
                    page + '&per_page=' + vm.perPage + '&project_type=' + type)
                .then((response) => {
                    if (response.data) {
                        vm.page = response.data.current_page;
                    }
                    vm.apiData_started = response.data;
                })
                .catch((error) => {
                    console.log(error);
                });
            }, 200),
            getRecordPending: _.debounce((page = vm.page) => {
                let type = 'pending';
                axios.get(vm.url +
                    '&current_page=' +
                    page + '&per_page=' + vm.perPage + '&project_type=' + type)
                .then((response) => {
                    if (response.data) {
                        vm.pending_show = true;
                        vm.page = response.data.current_page;
                    }
                    vm.apiData_pending = response.data;
                })
                .catch((error) => {
                    console.log(error);
                });
            }, 200),
            getRecordFinished: _.debounce((page = vm.page) => {
                let type = 'finished';
                axios.get(vm.url +
                    '&current_page=' +
                    page + '&per_page=' + vm.perPage + '&project_type=' + type)
                .then((response) => {
                    if (response.data) {
                        vm.page = response.data.current_page;
                    }
                    console.log('test finished projects: ', response.data);
                    vm.apiData_finished = response.data;
                })
                .catch((error) => {
                    console.log(error);
                });
            }, 200),
            exortToExcelSingle(type, id = null) {
                new Promise((resolve, reject) => {
                    let data = [];
                    const formData = new FormData();
                    if (type == 'pending_project') {
                        data = vm.apiData_pending.data;
                    } else if (type == 'started_project') {
                        data = vm.apiData_started.data;
                    } else {
                        data = vm.apiData_finished.data;
                    }
                    formData.append("data", JSON.stringify(data));
                    axios({
                        method: "post",
                        url: "excel?type=" + type,
                        responseType: "blob",
                        data: formData
                    }).then(response => {
                        console.log('for test:', response.data);
                        resolve('response');

                        let Fformat = ".xlsx";
                        var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                        var fileLink = document.createElement("a");
                        fileLink.href = fileURL;
                        fileLink.setAttribute("download", type + ".xlsx");
                        document.body.appendChild(fileLink);
                        fileLink.click();
                    })
                    .catch((error) => {
                        reject(error);
                        console.log(error);
                    });
                }).then(() => resolve('data')).catch(e => reject(e));
            },
            exortToPDF(type, id = null) {
                // new Promise((resolve, reject)=>{
                    let data = [];
                    const formData = new FormData();
                    if (type == 'pending_project') {
                        data = vm.apiData_pending.data;
                    } else if (type == 'started_project') {
                        data = vm.apiData_started.data;
                    } else {
                        data = vm.apiData_finished.data;
                    }
                    formData.append("data", JSON.stringify(data));
                    axios({
                        method: "post",
                        url: "pdf?type=" + type,
                        responseType: "blob",
                        data: formData
                    }).then(response => {
                        console.log('for test:', response.data);
                        // resolve('response');

                        var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                        var fileLink = document.createElement("a");
                        fileLink.href = fileURL;
                        fileLink.setAttribute("download", type + ".pdf");
                        document.body.appendChild(fileLink);
                        fileLink.click();
                    })
                    .catch((error) => {
                        // reject(error);
                        console.log(error);
                    });
                // }).then(()=>resolve('data')).catch(e=>reject(e));
            },
            // delete record
            deleteRecord(id = null) {
                if (id && id != null) {
                    deleteItem(`project/${id}`);
                    this.selectedRows = [];
                } else {
                    deleteItem(`project/${this.selectedRows}`, this.selectedRows);
                    this.selectedRows = [];
                }
            },
            create() {
                axios.post("{{route('project.store')}}",
                    this.project
                    )
                .then((response) => {
                    console.log('chec', response);
                    $('#create_modal').modal('hide');
                    this.project.name = null;
                    this.project.id = null;
                    this.project.desc = null;
                    this.project.start_date = null;
                    this.project.end_date = null;
                    this.project.province_id = null;
                    this.getRecord();
                })
                .catch((error) => {

                });
            },
        }
    });
</script>
@endsection