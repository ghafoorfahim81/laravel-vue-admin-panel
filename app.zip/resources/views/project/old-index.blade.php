@extends('layouts.master')
@section('title', __('lang.project_list'))
@section('css')


@endsection
@section('content')

    <div class="page-content-wrapper" id="app">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <input type="hidden" name="permission_id" id="permission_id">
                        <div class="card-body" style="padding-bottom: 0px">
                            <div class="card-body client-nav">
                                <div class="row pb-2">
                                    <div class="col-sm-12 col-md-2 form-inline">
                                        <div class="form-group">
                                            @if(hasPermission(['role_create']))
                                                <button onclick="location.href='{{route('project.create')}}'"
                                                        class="btn btn-info btn-sm waves-effect waves-light"
                                                        type="button">@lang('lang.add') @lang('lang.project')
                                                    <i class="mdi mdi-plus-thick"></i></button>&nbsp
                                            @endif
                                        </div>
                                    </div>
                                </div>

                                <div class=" ">
                                    <datatable ref="child" :per-page="{{perPage()}}"
                                               :no-record-found-text="'@lang('lang.no_record_found')'"
                                               :per-page-text="'@lang('lang.show')'"
                                               :showing-text="'@lang('lang.showing')'"
                                               :from-text="'@lang('lang.from')'" :to-text="'@lang('lang.to')'"
                                               :record-text="'@lang('lang.record')'"
                                               :app-per-page="{!! perPage(1) !!}" :columns="columns" :data="apiData"
                                               @pagination-change-page="getRecord" :limit="1"
                                               :filterRecord="getRecord"
                                               :multiple-select="true"
                                               :selected-rows="selectedRows"
                                               @delete-method-action="deleteRecord"
                                               >
                                        <template slot="tbody">
                                        <tbody v-show="!apiData.data">
                                            <tr v-for="skeleton in 4">
                                                

                                                <td>
                                                    <skeleton-loader-vue
                                                        type="rect"
                                                        :height="15"
                                                        :width="50"
                                                        class="m-3"
                                                        animation="fade"
                                                        />
                                                </td>

                                                <td>
                                                    <skeleton-loader-vue
                                                        type="rect"
                                                        :height="15"
                                                        :width="50"
                                                        class="m-3"
                                                        animation="fade"
                                                        />
                                                </td>

                                                <td>
                                                    <skeleton-loader-vue
                                                        type="rect"
                                                        :height="15"
                                                        :width="50"
                                                        class="m-3"
                                                        animation="fade"
                                                        />
                                                </td>

                                                <td>
                                                    <skeleton-loader-vue
                                                        type="rect"
                                                        :height="15"
                                                        :width="50"
                                                        class="m-3"
                                                        animation="fade"
                                                        />
                                                </td>

                                                <td>
                                                    <skeleton-loader-vue
                                                        type="rect"
                                                        :height="15"
                                                        :width="50"
                                                        class="m-3"
                                                        animation="fade"
                                                        />
                                                </td>

                                                <td>
                                                    <skeleton-loader-vue
                                                        type="rect"
                                                        :height="15"
                                                        :width="50"
                                                        class="m-3"
                                                        animation="fade"
                                                        />
                                                </td>

                                                <td>
                                                    <skeleton-loader-vue
                                                        type="rect"
                                                        :height="15"
                                                        :width="50"
                                                        class="m-3"
                                                        animation="fade"
                                                        />
                                                </td>

                                                <td>
                                                    <skeleton-loader-vue
                                                        type="rect"
                                                        :height="15"
                                                        :width="50"
                                                        class="m-3"
                                                        animation="fade"
                                                        />
                                                </td>
                                            </tr>
                                        </tbody>
                                            <tbody v-show="apiData.data">
                                            <tr v-for="(record,index) in apiData.data" :key="record.id">
                                                <td>
                                                    <input type="checkbox" class="" v-model="selectedRows"
                                                           :value="record.id" :id="`checked-${record.id}}`">

                                                </td>
                                                <td> @{{++index}}</td>
                                                <td> @{{record.code}}</td>
                                                <td> @{{record.name}}</td>
                                                <td> @{{record.start_date.substr(0,10)}}</td>
                                                <td> @{{record.end_date.substr(0,10)}}</td>
                                                <td> @{{record.description}}</td>
                                                <td> @{{record.province}}</td>
                                                <td class="">
                                                    <div class="p-1" role="group" style="width: 180px; text-align: center;">
                                                        @if(hasPermission(['role_view']))
                                                            <a class="btn btn-info btn-sm"
                                                               :href="`{{url('role/')}}/${record.id}`"
                                                               data-toggle="tooltip" data-placement="top"
                                                               title="View">
                                                                <i class="mdi mdi-eye"></i>
                                                            </a>&nbsp;
                                                        @endif
                                                        @if(hasPermission(['role_edit']))
                                                            <a 
                                                                class="btn btn-primary btn-sm"
                                                               href="#"
                                                               @click="edit(record.id, index)"
                                                               data-toggle="tooltip"
                                                               data-placement="top" title="Edit">
                                                                <i class="dripicons-document-edit"></i>
                                                            </a>&nbsp;
                                                        @endif 
                                                        @if(hasPermission(['role_delete']))
                                                            <a class="btn btn-danger btn-sm"
                                                               @click="deleteRecord(record.id)"
                                                               data-toggle="tooltip" data-placement="top"
                                                               title="Delete">
                                                                <i style="color: white" class="mdi mdi-delete"></i>
                                                            </a>
                                                        @endif
                                                    </div>
                                                </td>
                                            </tr>

                                            </tbody>

                                        </template>
                                    </datatable>
                                    {{--                                        <Pagination align="center" :limit="1" :data="records" @pagination-change-page="getRecords"></Pagination>--}}
                                </div>
                            </div>
                        </div>

                        <div class="card-footer ">
                        </div>

                    </div>

                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- end container-fluid -->
        <!-- edit project start-->
        <div class="modal fade" id="edit_model" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Project</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="col-xl-12">
                        <div class="form-group">
                            <label for="">Code
                                <span class="rq">*</span>
                            </label>
                            <input type="text" v-model="project.code" name="desc" class="form-control"
                                   id="desc" 
                                   autocomplete="new-desc"
                                   placeholder="@lang('lang.code')">
                            <span class="help-block rq-hint">
                            </span>

                        </div>
                    </div>
                    <div class="col-xl-12">
                        <div class="form-group">
                            <label for="">Name
                                <span class="rq">*</span>
                            </label>
                            <input type="text" v-model="project.name" name="desc" class="form-control"
                                   id="desc" 
                                   autocomplete="new-desc"
                                   placeholder="@lang('lang.name')">
                            <span class="help-block rq-hint">
                            </span>

                        </div>
                    </div>
                    <div class="col-xl-12">
                        <div class="form-group">
                            <label for="">Province
                                <span class="rq">*</span>
                            </label>
                            <select class="form-control" id="exampleFormControlSelect1" v-model="project.province_id">
                              <option></option>
                              <option v-for="(province, index) in provinces" :value="province.id" >@{{province.name}}</option>
                            </select>
                            <span class="help-block rq-hint">
                            </span>

                        </div>
                    </div>
                    <div class="col-xl-12">
                        <div class="form-group">
                            <label for="">@lang('lang.start_date')
                            </label>
                           <input type="date" name="date" class="form-control" id="email" data-vv-as="@lang('lang.date')"
                                   placeholder="@lang('lang.date')" autocomplete="new-email" v-model="project.start_date">
                            <span class="help-block rq-hint">
                            @{{errors.first('date')}}</span>
                        </div>
                    </div>
                    <div class="col-xl-12">
                        <div class="form-group">
                            <label for="">@lang('lang.end_date')
                            </label>
                           <input type="date" name="date" class="form-control" id="email" data-vv-as="@lang('lang.date')"
                                   placeholder="@lang('lang.date')" autocomplete="new-email" v-model="project.end_date">
                            <span class="help-block rq-hint">
                            @{{errors.first('date')}}</span>
                        </div>
                    </div>
                    <div class="col-xl-12">
                        <div class="form-group">
                            <label for="">Description
                                <span class="rq">*</span>
                            </label>
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" v-model="project.desc">
                                
                            </textarea>
                            <span class="help-block rq-hint">
                            </span>

                        </div>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" @click="update" class="btn btn-primary" data-dismiss="modal" :disabled="!project.name || !project.start_date || !project.province_id || !project.end_date">Update </button>
                  </div>
                </div>
              </div>
        </div> 
        <!-- edit project end -->
        <!-- create project start -->
        <div class="modal fade" id="create_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Create Project</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="col-xl-12">
                        <div class="form-group">
                            <label for="">Code
                                <span class="rq">*</span>
                            </label>
                            <input type="text" v-model="project.code" name="desc" class="form-control"
                                   id="desc" 
                                   autocomplete="new-desc"
                                   placeholder="@lang('lang.code')">
                            <span class="help-block rq-hint">
                            </span>

                        </div>
                    </div>
                    <div class="col-xl-12">
                        <div class="form-group">
                            <label for="">Name
                                <span class="rq">*</span>
                            </label>
                            <input type="text" v-model="project.name" name="desc" class="form-control"
                                   id="desc" 
                                   autocomplete="new-desc"
                                   placeholder="@lang('lang.name')">
                            <span class="help-block rq-hint">
                            </span>

                        </div>
                    </div>
                    <div class="col-xl-12">
                        <div class="form-group">
                            <label for="">Province
                                <span class="rq">*</span>
                            </label>
                            <select class="form-control" id="exampleFormControlSelect1" v-model="project.province_id">
                              <option></option>
                              <option v-for="(province, index) in provinces" :value="province.id" >@{{province.name}}</option>
                            </select>
                            <span class="help-block rq-hint">
                            </span>

                        </div>
                    </div>
                    <div class="col-xl-12">
                        <div class="form-group">
                            <label for="">@lang('lang.start_date')
                            </label>
                           <input type="date" name="date" class="form-control" id="email" data-vv-as="@lang('lang.date')"
                                   placeholder="@lang('lang.date')" autocomplete="new-email" v-model="project.start_date">
                            <span class="help-block rq-hint">
                            @{{errors.first('date')}}</span>
                        </div>
                    </div>
                    <div class="col-xl-12">
                        <div class="form-group">
                            <label for="">@lang('lang.end_date')
                            </label>
                           <input type="date" name="date" class="form-control" id="email" data-vv-as="@lang('lang.date')"
                                   placeholder="@lang('lang.date')" autocomplete="new-email" v-model="project.end_date">
                            <span class="help-block rq-hint">
                            @{{errors.first('date')}}</span>
                        </div>
                    </div>
                    <div class="col-xl-12">
                        <div class="form-group">
                            <label for="">Description
                                <span class="rq">*</span>
                            </label>
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" v-model="project.desc">
                                
                            </textarea>
                            <span class="help-block rq-hint">
                            </span>

                        </div>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" @click="create" class="btn btn-primary" data-dismiss="modal" :disabled="!project.name || !project.start_date || !project.province_id || !project.end_date">Save Project</button>
                  </div>
                </div>
              </div>
        </div>
        <!-- create project end -->
    </div>
    <!-- end page-content-wrapper -->

@endsection
@section('js')
    <script>

        //Vue.component('pagination', require('laravel-vue-pagination'));
        var vm = new Vue({
            el: '#app',
            components: {
            'skeleton-loader-vue': window.VueSkeletonLoader,
        },
            data() {
                return {
                    url: '{{route("project.index")}}?',
                    columns: [
                        {
                            label: "#",
                            name: '#',
                            sort: false,
                        },
                        {
                            label: "@lang('lang.code')",
                            name: 'projects.code',
                            sort: true,
                            activeSort: true,
                            order_direction: 'desc',
                        },
                        {
                            label: "@lang('lang.name')",
                            name: 'projects.name',
                            sort: true,
                            activeSort: true,
                            order_direction: 'desc',
                        },
                        {
                            label: "@lang('lang.start_date')",
                            name: 'projects.start_date',
                            sort: false,
                            activeSort: false,
                            order_direction: 'desc',
                        },
                        {
                            label: "@lang('lang.end_date')",
                            name: 'projects.end_date',
                            sort: false,
                            activeSort: false,
                            order_direction: 'desc',
                        },
                        {
                            label: "@lang('lang.description')",
                            name: 'projects.description',
                            sort: true,
                            activeSort: true,
                            order_direction: 'desc',
                        },
                        {
                            label: "@lang('lang.province')",
                            name: 'provinces.name',
                            sort: true,
                            activeSort: true,
                            order_direction: 'desc',
                        },
                        {
                            label: "@lang('lang.actions')",
                            name: 'action',
                            sort: false
                        }
                    ],

                    apiData: {},
                    appPerPage:{!! perPage(1) !!},
                    perPage: "{{perPage()}}",
                    page: 1,
                    selectedRows: [],
                    project: {
                        code: null,
                        name: null,
                        province_id: null,
                        desc: null,
                        id: null,
                        start_date: null,
                        end_date: null
                    },
                    provinces: {!! $provinces !!},
                    project_index: null,
                }

            },
            mounted: function () {
                this.getRecord();
            },
            methods: {
                getRecord: _.debounce((page = vm.page) => {
                    axios.get(vm.url +
                        '&current_page=' +
                        page + '&per_page=' + vm.perPage)
                        .then((response) => {
                            if (response.data) {
                                vm.page = response.data.current_page;
                            }
                            vm.apiData = response.data;
                        })
                        .catch((error) => {
                            console.log(error);
                        });
                }, 200),

                // delete record
                deleteRecord(id=null) {
                    if (id && id != null) {
                        deleteItem(`role/${id}`);
                        this.selectedRows=[];
                    } else {
                        deleteItem(`role/${this.selectedRows}`);
                        this.selectedRows=[];
                    }
                },
                create(){
                    axios.post("{{route('project.store')}}", 
                            this.project
                        )
                        .then((response) => {
                            console.log('chec', response);
                            $('#create_modal').modal('hide');
                            this.project.name  = null;
                            this.project.id    = null;
                            this.project.desc  = null;
                            this.project.start_date  = null;
                            this.project.end_date  = null;
                            this.project.province_id  = null;
                            this.getRecord();
                        })
                        .catch((error) => {
                            
                        });
                },
                edit(id, index){
                    this.project_index = index;
                    console.log('chkec', id);
                    axios.post("{{route('project.edit')}}", {id: id})
                        .then((response) => {
                            console.log('chec', response);
                            this.project.name  = response.data.name;
                            this.project.id    = response.data.id;
                            this.project.desc  = response.data.description;
                            this.project.province_id  = response.data.province_id;
                            $('#edit_model').modal('show');
                        })
                        .catch((error) => {
                            
                        });
                },
                update(){
                    axios.post("{{route('project.update')}}", this.project)
                        .then((response) => {
                            $('#edit_model').modal('hide');
                            this.project.name  = null;
                            this.project.id    = null;
                            this.project.desc  = null;
                            this.project.province_id  = null;
                            this.getRecord();
                        })
                        .catch((error) => {
                            
                        });
                },
            }
        });

    </script>
@endsection
