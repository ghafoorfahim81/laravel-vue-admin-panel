<html>

<style>
    .main-table {
        border: 2px solid black;
    }

    .main-table th {
        border: 2px solid black;
        word-break: break-all;
    }

    table, th, td {
        border: 2px solid black;
    }

    .imageAlign {
        display: table-cell;
        height: 300px;
        text-align: right;
        width: 300px;
        vertical-align: middle;
    }
</style>
<body>

    <table class="main-table">
        <thead>

            <tr>
                <th colspan="10"
                style="font-weight: bold; height: 30px;text-align: center;font-size: 18px;background-color: #84acb6">Project Details  </th> 
            </tr>        
            <tr>
                <th style="text-align: center" width="90px" bgcolor="#84acb6">@lang('lang.projectCode')</th>
                <th style="text-align: center" width="70px" bgcolor="#84acb6">@lang('lang.province')</th>
                <th style="text-align: center" width="124px" bgcolor="#84acb6">@lang('lang.clientFocalPoint')</th>
                <th style="text-align: center" width="120px" bgcolor="#84acb6">@lang('lang.clientCode')</th>
                <th style="text-align: center" width="142px" bgcolor="#84acb6">@lang('lang.dateOfReg')</th>
                <th style="text-align: center" width="100px" bgcolor="#84acb6">@lang('lang.clientName')</th>
                <th style="text-align: center" width="120px" bgcolor="#84acb6">@lang('lang.lastNameFamily')</th>
                <th style="text-align: center" width="100px" bgcolor="#84acb6">@lang('lang.maritalStatus')</th>
                <th style="text-align: center" width="70px" bgcolor="#84acb6">@lang('lang.gender')</th> 
            </tr>

        </thead>
        <tbody>
           <tr>
            <td>Dom</td>
            <td>6000</td>
        </tr>
        <tr class="active-row">
            <td>Melissa</td>
            <td>5150</td>
        </tr>

    </tbody>
</table>
</body>
</html>
