@extends('layouts.master')
@section('title', __('lang.show').' '.__('lang.project'))
@section('content')
    <div class="page-content-wrapper" id="myapp" v-cloak>
        <div class="card mx-3">
            <div class="card-body">
                <div class="container mb-5 mt-3">
                    <div class="row d-flex align-items-baseline">
                        <div class="">
                            <div class="row">
                                <div class="">
                                    <h6 class="text_color">Project ID: #{{$project->code}}</h6>
                                    <hr class="mt-0 mb-4">
                                    <div class="row pt-1">

                                        <div class="col-xl-6">
                                            <ul class="list-group">

                                                <div class="ml-3 rounded-4 shadow-5 mb-3">
                                                    <a class="btn-floating btn-tw btn-sm">
                                                        <button type="button" class="btn btn-info btn-floating btn-sm">
                                                            <i class="fas fa-briefcase"></i>
                                                        </button>
                                                    </a>
                                                    <span class="font-weight-bold ml-2">Project Name:
        <span class="ml-4 fw-normal text-info">{{$project->name}}</span>
</span>
                                                </div>

                                                <div class="ml-3 rounded-4 shadow-5 mb-3">
                                                    <a class="btn-floating btn-tw btn-sm">
                                                        <button type="button" class="btn btn-info btn-floating btn-sm">
                                                            <i class="fas fa-map-marker-alt"></i>
                                                        </button>
                                                    </a>
                                                    <span class="font-weight-bold ml-2">Province:
        <span class="ml-4 fw-normal text-info">{{$province->name}}</span></span>
                                                </div>

                                                <div class="ml-3 rounded-4 shadow-5 mb-3">
                                                    <a class="btn-floating btn-tw btn-sm">
                                                        <button type="button" class="btn btn-info btn-floating btn-sm">
                                                            <i class="fas fa-file-invoice-dollar"></i>
                                                        </button>
                                                    </a>
                                                    <span class="font-weight-bold ml-2">Total Beneficiary:
        <span class="ml-4 fw-normal text-info">{{$project->total_beneficiary}}</span></span>
                                                </div>

                                                <div class="ml-3 rounded-4 shadow-5 mb-3">
                                                    <a class="btn-floating btn-tw btn-sm">
                                                        <button type="button" class="btn btn-info btn-floating btn-sm">
                                                            <i class="fas fa-check-double"></i>
                                                        </button>
                                                    </a>
                                                    <span class="font-weight-bold ml-2">Paid Beneficiaries:
        <span class="ml-4 fw-normal text-info">@{{paidBinificiaries}}</span></span>
                                                </div>


                                                <div class="ml-3 rounded-4 shadow-5 mb-3">
                                                    <a class="btn-floating btn-tw btn-sm">
                                                        <button type="button" class="btn btn-info btn-floating btn-sm">
                                                            <i class="fas fa-times"></i>
                                                        </button>
                                                    </a>
                                                    <span class="font-weight-bold ml-2">Un paid Beneficiaries:
        <span class="ml-4 fw-normal text-info">@{{unPaidBinificiaries}}</span></span>
                                                </div>


                                                <div class="ml-3 rounded-4 shadow-5 mb-3">
                                                    <a class="btn-floating btn-tw btn-sm">
                                                        <button type="button" class="btn btn-info btn-floating btn-sm">
                                                            <i class="fas fa-times"></i>
                                                        </button>
                                                    </a>
                                                    <span class="font-weight-bold ml-2">Status:
        <span
            class="ml-4 fw-normal text-info">{{ ($project->status == 'finished') ? 'Closed' : $project->status }}</span></span>
                                                </div>
                                                <div class="ml-3 rounded-4 shadow-5 mb-3">
                                                    <a type="button" href="{{url('final_report/'.$project->id)}}"
                                                       class="btn btn-success btn-sm" style="">
                                                        <i class="fas fa-file-excel"></i> <span class="ml-1">Final Report</span></a>
                                                </div>

                                            </ul>
                                        </div>
                                        <div class="col-xl-6">
                                            <ul class="list-group">

                                                <div class="ml-3 rounded-4 shadow-5 mb-3">
                                                    <a class="btn-floating btn-tw btn-sm">
                                                        <button type="button" class="btn btn-info btn-floating btn-sm">
                                                            <i class="fas fa-hashtag"></i>
                                                        </button>
                                                    </a>
                                                    <span class="font-weight-bold ml-2">Code:
        <span class="ml-4 fw-normal text-info">#{{$project->code}}</span></span>
                                                </div>

                                                <div class="ml-3 rounded-4 shadow-5 mb-3">
                                                    <a class="btn-floating btn-tw btn-sm">
                                                        <button type="button" class="btn btn-info btn-floating btn-sm">
                                                            <i class="far fa-calendar"></i>
                                                        </button>
                                                    </a>
                                                    <span class="font-weight-bold ml-2">From Date:
        <span class="ml-4 fw-normal text-info"> {{substr($project->start_date, 0, 10)}}</span></span>
                                                </div>

                                                <div class="ml-3 rounded-4 shadow-5 mb-3">
                                                    <a class="btn-floating btn-tw btn-sm">
                                                        <button type="button" class="btn btn-info btn-floating btn-sm">
                                                            <i class="far fa-calendar-check"></i>
                                                        </button>
                                                    </a>
                                                    <span class="font-weight-bold ml-2">To Date:
        <span class="ml-4 fw-normal text-info"> {{substr($project->end_date, 0, 10)}}</span></span>
                                                </div>

                                                <div class="ml-3 rounded-4 shadow-5 mb-3">
                                                    <a class="btn-floating btn-tw btn-sm">
                                                        <button type="button" class="btn btn-info btn-floating btn-sm">
                                                            <i class="fas fa-dollar-sign"></i>
                                                        </button>
                                                    </a>
                                                    <span class="font-weight-bold ml-2">Budget:
        <span class="ml-4 fw-normal text-info">{{$project->budget}}</span></span>
                                                </div>

                                                <div class="ml-3 rounded-4 shadow-5 mb-3">
                                                    <a class="btn-floating btn-tw btn-sm">
                                                        <button type="button" class="btn btn-info btn-floating btn-sm">
                                                            <i class="fas fa-hand-holding-usd"></i>
                                                        </button>
                                                    </a>
                                                    <span class="font-weight-bold ml-2">Paid Amount:
        <span class="ml-4 fw-normal text-info"> @{{paidAmount}}</span></span>
                                                </div>


                                            </ul>
                                        </div>
                                    </div>

                                </div>
                                @if(hasPermission(['payment_create']))
                                    @include('project.payment')
                                    @include('project.add_payment_modal')
                                    @include('project.edit_payment_modal')
                                @endif
                                <form action="{{route('project.files')}}" method="post" id="userForm"
                                      enctype="multipart/form-data">
                                    @csrf
                                    <div class="p-8">
                                        <table class="table align-middle mb-0 bg-white">
                                            <thead class="bg-light">
                                            <tr>
                                                <th class="text-center">#</th>
                                                <th>Attachment Title</th>
                                                <th>Download</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr v-for="(file, index) in files">
                                                <td>
                                                    <div class="text-center">
                                                        @{{++index}}
                                                    </div>
                                                </td>
                                                <td>
                                                    <p class="fw-normal mb-1">@{{file.file}}</p>
                                                </td>
                                                <td>
                                                    <a :href="`{{url('project/download')}}/${file.main_name}/${project_id}`"><i
                                                            class="fas fa-cloud-download-alt fa-lg"></i></a>
                                                </td>
                                            </tr>
                                            <tr v-for="(item, index) in items">
                                                <th class="p-0 text-center border-right align-middle" scope="row">
                                                    @{{++index}}
                                                </th>
                                                <td class="p-0 border-right align-middle">
                                                    <input type="file" class="form-control-sm" name="attach_file[]"
                                                           id="customFile" @click="addRow(index)"/>

                                                </td>
                                                <td class="p-0 text-center align-middle"><i class="far fa-trash-alt"
                                                                                            style="color:red"
                                                                                            v-on:click="deleteItem(index)"></i>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-12">
                                            <div class="card-footer text-right pr-0 bg-white">
                                                <input type="hidden" class="form-control-sm" name="project_id"
                                                       value="{{$project->id}}" id="customFile"/>
                                                <button class="btn btn-info" type="submit">
                                                    <span class="ml-2">Save Files</span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                <hr>
                                <div class="row">
                                    <div class="col-xl-10">
                                        <strong>Project Description: </strong>
                                        <p>{{$project->description}}.</p>
                                    </div>
                                    <div class="col-xl-2">
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tabs content -->

            <!-- end container-fluid -->
        </div>
        <!-- end page-content-wrapper -->

        @endsection
        @section('js')

            <script>

                var vm = new Vue({
                    el: '#myapp',
                    components: {
                        'skeleton-loader-vue': window.VueSkeletonLoader,
                    },
                    data: {
                        project_id: "{{$project->id}}",
                        projectData: {!!$project!!},
                        allBinificiary: {!! $project->total_beneficiary !!},
                        paidBinificiaries: {!! $paidBinificiaries !!},
                        unPaidBinificiaries: {!! $project->total_beneficiary-$paidBinificiaries !!},
                        paidAmount: {!! $paidAmount !!},
                        tabs: [
                            {tab: 'general', css_class: 'fa-home', value: 'General', is_active: true},
                            {tab: 'receipts', css_class: 'fa-user', value: 'Attachments', is_active: false},
                        ],
                        files: {!! $files !!},
                        control_room: {
                            fields: null,
                            table: null
                        },
                        showEditModal: true,
                        payment_items: [
                            {item: {quantity: 0, amount: 0}},
                            {item: {quantity: 0, amount: 0}},
                            {item: {quantity: 0, amount: 0}},

                        ],
                        edit_items: [],
                        paymentForm: {
                            project_id: "{{$project->id}}",
                            date: new Date().toISOString().substr(0, 10),
                        },
                        editPaymentForm: {
                            project_id: "{{$project->id}}",
                            payment_id: null,
                            date: new Date().toISOString().substr(0, 10),
                        },
                        items: [
                            {
                                item: {
                                    selected_item: null,
                                    quantity: null,
                                    price: null
                                }
                            },
                            {
                                item: {
                                    selected_item: null,
                                    quantity: null,
                                    price: null
                                }
                            },
                            {
                                item: {
                                    selected_item: null,
                                    quantity: null,
                                    price: null
                                }
                            },
                        ],
                        //    payment codes
                        url: '{{route("payment.index")}}?',
                        columns: [
                            {
                                label: "#",
                                name: '#',
                                sort: false,
                            },

                            {
                                label: "beneficiaries",
                                name: 'payments.beneficiaries',
                                sort: true,
                                activeSort: true,
                                order_direction: 'desc',
                            },
                            {
                                label: "@lang('lang.date')",
                                name: 'payments.date',
                                sort: true,
                                activeSort: true,
                                order_direction: 'desc',
                            },
                            {
                                label: "@lang('lang.amount')",
                                name: 'payments.amount',
                                sort: true,
                                activeSort: true,
                                order_direction: 'desc',
                            },
                            {
                                label: "@lang('lang.actions')",
                                name: 'action',
                                sort: false
                            }
                        ],

                        apiData: {},
                        appPerPage: {!! perPage(1) !!},
                        perPage: "{{perPage()}}",
                        page: 1,
                        selectedRows: [],
                    },
                    computed: {
                        grandTotal() {
                            let total = 0;
                            for (let x = 0; x < this.payment_items.length; x++) {
                                total += Number.parseFloat(this.payment_items[x].item.quantity) * Number.parseFloat(this.payment_items[x].item.amount);
                            }
                            return total;
                        },
                        editGrandTotal() {
                            let total = 0;
                            for (let x = 0; x < this.edit_items.length; x++) {
                                total += Number.parseFloat(this.edit_items[x].item.quantity) * Number.parseFloat(this.edit_items[x].item.amount);
                            }
                            return total;
                        }
                    },
                    mounted: function () {
                        this.getRecord();
                    },
                    methods: {
                        savePayment() {
                            const formData = new FormData();
                            formData.append("items", JSON.stringify(this.payment_items));
                            formData.append("payment", JSON.stringify(this.paymentForm));
                            axios.post('/payment/store', formData, {}).then(res => {
                                this.paidBinificiaries = res.data.paidBinificiaries;
                                this.paidAmount = res.data.paidAmount;
                                this.unPaidBinificiaries = this.allBinificiary - this.paidBinificiaries;
                                this.payment_items = [{item: {quantity: 0, amount: 0}}];
                                this.getRecord();

                            })
                        },
                        findProjectAmount(index) {
                            this.payment_items[index].item.amount = this.projectData.budget / this.projectData.total_beneficiary;
                            // for (let x = 0; x < this.payment_items.length; x++) {

                            //     total += Number.parseFloat(this.payment_items[x].item.quantity) * Number.parseFloat(this.payment_items[x].item.amount);
                            // }
                        },
                        editPayment(id = 0) {
                            window.location = "{{route('payment.edit','')}}" + "/" + id;

                            {{--this.is_update = true;--}}
                            {{--$('#edit_modal').modal('show')--}}
                            {{--axios.get("{{route('payment.edit','')}}" + "/" + id).then(res => {--}}
                            {{--    console.log('data is ', res.data)--}}
                            {{--    let paymentDetails = res.data.payment_details;--}}
                            {{--    this.editPaymentForm.date = res.data.payment.date;--}}
                            {{--    this.editPaymentForm.payment_id = res.data.payment.id--}}
                            {{--    for (let x = 0; x < paymentDetails.length; x++) {--}}
                            {{--        this.edit_items.push({--}}
                            {{--            item: {--}}
                            {{--                quantity: paymentDetails[x].quantity,--}}
                            {{--                amount: paymentDetails[x].amount,--}}
                            {{--            }--}}
                            {{--        });--}}
                            {{--    }--}}
                            {{--    this.edit_items.push({item: {quantity: 0, amount: 0}});--}}

                            {{--})--}}
                        },
                        updatePayment() {
                            // $('#edit_modal').modal('hide');
                            console.log('ssss')
                            const formData = new FormData();
                            formData.append("items", JSON.stringify(this.edit_items));
                            formData.append("payment", JSON.stringify(this.editPaymentForm));
                            axios.patch("{{route('payment.update','')}}" + "/" + this.editPaymentForm.payment_id, formData).then(() => {
                                this.getRecord();
                            });
                        },
                        getItemTotal(item = null) {
                            let result = 0;
                            if (item != null && item.amount > 0) {
                                let amount = item.amount;
                                let quantity = item.quantity;
                                let total = Number.parseFloat(amount) * Number.parseFloat(quantity);
                                result = Number.parseFloat(total).toFixed(2);
                            }
                            return result;
                        },

                        addEditPaymentRow(index) {
                            if (this.edit_items[index + 1] == undefined) {
                                this.edit_items.push({item: {quantity: 0, amount: 0}});
                            }
                        },
                        addPaymentRow(index) {
                            if (this.payment_items[index + 1] == undefined) {
                                this.payment_items.push({item: {quantity: 0, amount: 0}});
                            }
                        },
                        addRow(index) {
                            if ((this.items.length - 1) == (index - 1)) {
                                this.items.push({
                                    item: {
                                        selected_item: null,
                                        quantity: null,
                                        price: null
                                    }
                                });
                            }
                        },
                        deletePaymentEdit(index) {
                            if (this.edit_items.length - 1 > 0) this.edit_items.splice(index - 1, 1);
                        },
                        deletePayment(index) {
                            if (this.payment_items.length - 1 > 0) this.payment_items.splice(index - 1, 1);
                        },
                        deleteItem(index) {
                            if (this.items.length - 1 > 0) this.items.splice(index - 1, 1);
                        },
                        showTable(name) {
                            if (
                                this.control_room.table?.find((e) => e.name == name && e.value == true)
                            )
                                return true;
                            else return false;
                        },
                        getRecord: _.debounce((page = vm.page) => {
                            let project_id = "{!!$project->id!!}";
                            axios.get(vm.url +
                                '&current_page=' + page +
                                '&project_id=' + project_id +
                                '&per_page=' + vm.perPage)
                                .then((response) => {
                                    if (response.data) {
                                        vm.page = response.data.current_page;
                                    }
                                    vm.apiData = response.data;
                                })
                                .catch((error) => {
                                    console.log(error);
                                });
                        }, 200),

                        // delete record
                        deleteRecord(id = null) {
                            if (id && id != null) {
                                console.log('modi');
                                deleteItem(`{!!url('payment')!!}/${id}`);
                                this.selectedRows = [];
                            } else {
                                deleteItem(`payment/multiple`, this.selectedRows);
                                this.selectedRows = [];
                            }
                        },
                        // send data for editing
                        editRecord(url = null, id = null) {
                            if (url != null && id != null) {
                                var url = "{{url('/')}}" + "/" + url + "/edit/" + id;

                                window.location = url;
                            }
                        }
                    }
                });

            </script>

            <style>
                .vue_dropdown .vs__dropdown-toggle {
                    border: none !important;
                }
            </style>

@endsection
