
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>


    </style>
</head>

<body>

    <table width="1200px" style="font-family: arial, sans-serif; border-collapse: collapse; width: 100%;">
        <tr >
            <td bgcolor="lightgray" width="300px" style=" text-align: center; padding: 18px;" colspan="4"><b style="margin: 7px;font-size: 50px;">Afghan Sharq MSP</b></td>
        </tr>
        <tr>
            <th width="300px" style="font-weight: bold; text-align: left; padding: 4px;">Address:</th>
            <td width="900px" style="text-align: left; padding: 4px;"  colspan="3">Shop# 42 Ground flour Sarai Shahzada Kabul, Afghanistan</td>
        </tr>
        <tr>
            <th width="300px" style="font-weight: bold; text-align: left; padding: 4px;">Email:</th>
            <td width="900px" style="text-align: left; padding: 4px;"  colspan="3">afghansharqmspkabul@gmail.com - ab.alokozay@gmail.com</td>
        </tr>
        <tr>
            <th width="300px" style="font-weight: bold; text-align: left; padding: 4px;">Phone:</th>
            <td width="900px" style="text-align: left; padding: 4px;"  colspan="3">020-2100960 - 0777816565</td>
        </tr>
        <tr>
            <th width="1200px" style="font-weight: bold; text-align: center;"  colspan="4">Summary Report</th>
        </tr>
        <tr>
            <th width="1200px" style="font-weight: bold; text-align: center; text-align: center;" colspan="4">Direct Cash Reconciliation Report</th>
        </tr>

        <tr>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: left; padding: 4px;">Project Name:</th>
            <td width="300px" style="border: 1px solid #000000; text-align: left; padding: 4px;" >
                {{$project->name}}</td>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: left; padding: 4px;"></th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: left; padding: 4px;"></th>
        </tr>
        <tr>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: left; padding: 4px;">Location:</th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: left; padding: 4px;">
                {{$project->province}}</th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: left; padding: 4px;"></th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: left; padding: 4px;"></th>
        </tr>
        <tr>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: left; padding: 4px;">Number of Recepients:</th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: left; padding: 4px;">{{$project->total_beneficiary}} HH</th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: left; padding: 4px;"></th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: left; padding: 4px;"></th>
        </tr>
        <tr>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: left; padding: 4px;">Cycle:</th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: left; padding: 4px;"><?php
                $createDate = new DateTime($project->start_date);
                $strip = $createDate->format('Y-m-d');
                ?>
                {{$strip}}</th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: left; padding: 4px;"></th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: left; padding: 4px;"></th>
        </tr>
        <tr>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: left; padding: 4px;">Transfer Value:</th>
            <th width="300px" style="font-weight: bold; text-align: right;">{{$project->budget}}</th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: left; padding: 4px;">{{$project->currency}}</th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: left; padding: 4px;"></th>
        </tr>

        <tr>
            <td width="1200px" style="border: 1px solid #000000; text-align: left; padding: 4px;"  colspan="4">&nbsp;</td>
        </tr>
        <tr bgcolor="lightgray">
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; padding: 8px; text-align: center;">No Of Recepients</th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; padding: 8px; text-align: center;">Months/Entitlement Amount ({{$project->currency}})</th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; padding: 8px; text-align: center;">Disbursement Request Amount</th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; padding: 8px; text-align: center;">Balance</th>
        </tr>
        <tr>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: right; padding: 4px;">{{$project->total_beneficiary}}</th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: right; padding: 4px;">{{$project->budget/$project->total_beneficiary}}</th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: right; padding: 4px;">{{($project->budget/$project->total_beneficiary)*$project->total_beneficiary}}</th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: right; padding: 4px;">-</th>
        </tr>
        <tr>
            <th width="1200px" style="border: 1px solid #000000;font-weight: bold; padding: 8px; text-align: center;" colspan="4">Actual Disbursement Report</th>
        </tr>
        <tr bgcolor="lightgray">
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; padding: 8px; text-align: center;">Actual Recepients</th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; padding: 8px; text-align: center;">Months/Entitlement Amount (AFN)</th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; padding: 8px; text-align: center;">Distributed Amount</th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; padding: 8px; text-align: center;">Balance</th>
        </tr>
        <tr>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: right; padding: 4px;">{{$paidBinificiaries}}</th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: right; padding: 4px;">{{$project->budget/$project->total_beneficiary}}</th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: right; padding: 4px;">{{($project->budget/$project->total_beneficiary)*$paidBinificiaries}}</th>
            <th width="300px" style="font-weight: bold; border: 1px solid #000000; text-align: right; padding: 4px;">{{$project->budget-($project->budget/$project->total_beneficiary)*$paidBinificiaries}}</th>
        </tr>
        <tr>
            <td width="1200px" style="text-align: left; padding: 4px;"  colspan="4">&nbsp;</td>
        </tr>
        <tr>
            <th width="300px" style="font-weight: bold; text-align: left; padding: 4px;">Prepaired by:</th>
            <th width="300px" style="font-weight: bold; text-align: left; padding: 4px;"></th>
            <th width="300px" style="font-weight: bold; text-align: left; padding: 4px;"></th>
            <th width="300px" style="font-weight: bold; text-align: left; padding: 4px;">Reviewed by:</th>
        </tr>
        <tr>
            <td width="300px" style="text-align: left; padding: 4px;" >Afghan Sharq</td>
            <td width="300px" style="text-align: left; padding: 4px;" >Name: _Rahmat ullah Kargar</td>
            <td width="300px" style="text-align: left; padding: 4px;" ></td>
            <td width="300px" style="text-align: left; padding: 4px;" >WFP CBT Focal Point</td>
        </tr>
        <tr>
            <td width="300px" style="text-align: left; padding: 4px;" >&nbsp;</td>
            <td width="300px" style="text-align: left; padding: 4px;" >&nbsp;</td>
            <td width="300px" style="text-align: left; padding: 4px;" >&nbsp;</td>
            <td width="300px" style="text-align: left; padding: 4px;" >&nbsp;</td>
        </tr>

        <tr>
            <td width="300px" style="padding: 4px; text-align: right;" >Signature</td>
            <td width="300px" style="text-align: left; padding: 4px; border-bottom: solid 1px black"></td>
            <td width="300px" style="text-align: left; padding: 4px;" ></td>
            <td width="300px" style="text-align: left; padding: 4px;" ></td>
        </tr>

        <tr>
            <td width="300px" style="text-align: left; padding: 4px;" >&nbsp;</td>
            <td width="300px" style="text-align: left; padding: 4px;" >&nbsp;</td>
            <td width="300px" style="text-align: left; padding: 4px;" >&nbsp;</td>
            <th width="300px" style="font-weight: bold; text-align: left; padding: 4px;">Endorsed by:</th>
        </tr>

        <tr>
            <td width="300px" style="text-align: right; padding: 4px;">Stamp</td>
            <td width="300px" style="text-align: left; padding: 4px; border-bottom: solid 1px black"></td>
            <td width="300px" style="text-align: left; padding: 4px;" ></td>
            <td width="300px" style="text-align: left; padding: 4px;" >Head of AO/SO</td>
        </tr>


    </table>

</body>

</html>
