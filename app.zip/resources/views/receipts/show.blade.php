@extends('layouts.master')
@section('title', 'Receipt Details')
@section('css')
    <link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css"/>
    <link href="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}" rel="stylesheet" type="text/css"/>

@endsection
@section('content')
    <div class="page-content-wrapper" id="myapp" v-cloak>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">

                        <div class="card-body" style="padding-bottom: 0px">
                            <div class="">
                                <!-- <h4 class="header-title"> @lang('lang.receipt') Details</h4> -->
                                <div class="row">
                                    <div class="col-xl-4" >
                                        <div class="form-group">
                                            <label for="">Receipt Number
                                            </label>
                                            <input type="number" name="receipt_no" class="form-control"
                                                   value="{{$receipt->receipt_no}}"
                                                   readonly
                                                   data-vv-as="receipt number"
                                                   placeholder="receipt number">
                                            <span class="help-block rq-hint">
                                                            @{{errors.first('receipt_number')}}
                                                        </span>


                                        </div>
                                    </div>
                                    <div class="col-xl-4">
                                        <div class="form-group">
                                            <label for="">@lang('lang.date')
                                            </label>
                                            <input type="text" readonly  value="<?php echo date('Y-m-d'); ?>" v-model="date" class="form-control" id="validate-date"
                                                   v-validate="'required'"  data-vv-as="@lang('lang.date')"
                                                   placeholder="@lang('lang.date')" autocomplete="new-email">

                                        </div>
                                    </div>
                                    <div class="col-xl-4">
                                        <div class="form-group">
                                            <label for="">@lang('lang.description')
                                            </label>
                                            <textarea name="description" readonly cols="37" >{{$receipt->description}}</textarea>
                                        </div>
                                    </div>
                                    <div class="col-xl-4 py-4 mt-2">
                                        <div class="w-full shadow-4 rounded-sm p-2 border">
                                            <div class="row justify-around">
                                                <span class="font-weight-bold text-xl col-7">Grand Total</span>
                                                <span
                                                    class="font-weight-bold text-xl col text-end">@{{grandTotal}}</span>
                                            </div>
                                            <div v-if="change_form">
                                                <div class="row justify-around">
                                                <span
                                                    class="font-weight-bold text-xl col-7">LC Amount Total</span>
                                                    <span
                                                        class="font-weight-bold text-xl col text-end">@{{lcTotal}}</span>
                                                </div>
                                                <div class="row justify-around">
                                                <span
                                                    class="font-weight-bold text-xl col-7">Commission Total</span>
                                                    <span class="font-weight-bold text-xl col text-end">@{{comissionTotal}}</span>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <!-- end of permission -->
                            </div>
                            <div class="table-responsive rounded-sm shadow-4 ">
                                <table class="table mb-0">
                                    <thead class="bg-light-blue-7 text-white" v-if="!change_form">
                                    <tr>
                                        {{--                                            <th class="p-2">#</th>--}}
                                        <th class="p-2">@lang('lang.invoice_no')</th>
                                        <th class="p-2">@lang('lang.project')</th>
                                        <th class="p-2">@lang('lang.pay_date')</th>
                                        <th class="p-2">@lang('lang.currency')</th>
                                        <th class="p-2">@lang('lang.amount')</th> 
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr v-for="(item, index) in receiptDetails" v-if="item.amount>=0">
                                        <td class="p-0 border-right text-center">
                                            <span>@{{item.invoice_no}}</span>
                                        </td>
                                        <td class="p-0 border-right text-center">
                                            <span>@{{item.project}}</span>
                                        </td>
                                        <td class="p-0 border-right text-center">
                                            <span>@{{item.pay_date}}</span>
                                        </td>
                                        <td class="p-0 border-right text-center">
                                            <span>@{{item.currency}}</span>
                                        </td>
                                        <td class="p-0 border-right text-center">
                                            <span>@{{item.amount}}</span>
                                        </td> 
                                    </tr>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card-footer text-right">
                            <button class="btn btn-info" type="submit"><span class="ml-2" @click="checkDate()">Save Changes</span>
                            </button>
                        </div>

                        <!--  <save-banner @click="handleSubmit($event)" @cancelRoute="$router.push({ name: '/receipt'})" /> -->
                    </div>

                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- end container-fluid -->
    </div>
    <!-- end page-content-wrapper -->

@endsection
@section('js')

    <script>

        var vm = new Vue({
            el: '#myapp',
            data: {
                receipt: {!!$receipt!!},
                date:"{!! $receipt->date !!}",
                receiptDetails: {!!$receiptDetails!!},
            },
            mounted: function () {

            },
            computed: {

                grandTotal() {
                    let total = 0;
                    for (let x = 0; x < this.receiptDetails.length; x++) {

                        total += Number.parseFloat(this.receiptDetails[x].amount);

                    }
                    return total;
                },
            },
            methods: {



            }
        });

    </script>

    <style>
        .vue_dropdown .vs__dropdown-toggle {
            border: none !important;
        }
    </style>

@endsection
