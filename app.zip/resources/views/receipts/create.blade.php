@extends('layouts.master')
@section('title', __('lang.add').' '.__('lang.receipt'))
@section('css')
    <link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css"/>
    <link href="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}" rel="stylesheet" type="text/css"/>

@endsection
@section('content')
    <div class="page-content-wrapper" id="myapp" v-cloak>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <form action="{{route('receipt.store')}}" method="post" id="userForm"
                              enctype="multipart/form-data" >
                            @csrf
                            <div class="card-body" style="padding-bottom: 0px">
                                <div class="">
                                    <!-- <h4 class="header-title">@lang('lang.add') @lang('lang.receipt')</h4> -->
                                    <div class="row">
                                        <div class="col-xl-4" >
                                                    <div class="form-group">
                                                        <label for="">@lang('lang.receipt_number')
                                                        </label>
                                                        <input type="number" name="receipt_no" class="form-control"
                                                               autocomplete="new-password"
                                                               data-vv-as="@lang('lang.receipt_number')"
                                                               placeholder="@lang('lang.receipt_number')">
                                                        <span class="help-block rq-hint">
                                                            @{{errors.first('receipt_number')}}
                                                        </span>
                                                    </div>
                                                </div>
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.date')
                                                </label>
                                                <input type="date" name="date" @input="checkDate()" required value="<?php echo date('Y-m-d'); ?>" v-model="date" class="form-control" id="validate-date"
                                                       v-validate="'required'" @change="dateChanges" data-vv-as="@lang('lang.date')"
                                                       placeholder="@lang('lang.date')" autocomplete="new-email">

                                            </div>
                                        </div>
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.description')
                                                </label>
                                                <textarea name="description" id="" cols="37" ></textarea>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 py-4 mt-2">
                                            <div class="w-full shadow-4 rounded-sm p-2 border">
                                                <div class="row justify-around">
                                                    <span class="font-weight-bold text-xl col-7">Grand Total</span>
                                                    <span
                                                        class="font-weight-bold text-xl col text-end">@{{grandTotal}}</span>
                                                </div>
                                                <div v-if="change_form">
                                                    <div class="row justify-around">
                                                <span
                                                    class="font-weight-bold text-xl col-7">LC Amount Total</span>
                                                        <span
                                                            class="font-weight-bold text-xl col text-end">@{{lcTotal}}</span>
                                                    </div>
                                                    <div class="row justify-around">
                                                <span
                                                    class="font-weight-bold text-xl col-7">Commission Total</span>
                                                        <span class="font-weight-bold text-xl col text-end">@{{comissionTotal}}</span>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- end of permission -->
                                </div>
                                <div class="table-responsive rounded-sm shadow-4 ">
                                    <table class="table mb-0">
                                        <thead class="bg-light-blue-7 text-white" v-if="!change_form">
                                        <tr>
                                            {{--                                            <th class="p-2">#</th>--}}
                                            <th class="p-2">@lang('lang.invoice_no')</th>
                                            <th class="p-2">@lang('lang.project')</th>
                                            <th class="p-2">@lang('lang.pay_date')</th>
                                            <th class="p-2">@lang('lang.currency')</th>
                                            <th class="p-2">@lang('lang.amount')</th>
                                            <th class="p-2">@lang('lang.select')</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr v-for="(item, index) in invoiceLists" v-if="item.amount>=0">
                                            <td class="p-0 border-right text-center">
                                                <span>@{{item.invoice_no}}</span>
                                                <input type="hidden" name="invoice_no[]" :value="item.invoice_no">
                                                <input type="hidden" name="invoice_id[]" :value="item.id">
                                                <input type="hidden" name="transaction_id[]" :value="item.transaction_id">
                                            </td>
                                            <td class="p-0 border-right text-center">
                                                @{{ item.project }}
                                                <input type="hidden" name="location_id[]" :value="item.province_id">
                                            </td>
                                            <td class="p-0 border-right text-center">
                                                <input type="date" class="form-control border border-white" 
                                                       v-model="item.pay_date" name="pay_date[]">
                                            </td>
                                            <td class="p-0 border-right text-center">
                                                <span>@{{item.currency}}</span>
                                                <input type="hidden" name="currency[]" :value="item.currency">
                                            </td>
                                            <td class="p-0">
                                                <input type="number" name="amount[]" class="form-control"
                                                       :value="item.amount" @input="amountChange(index,$event)"  min="0"
                                                       step="any">
                                            </td>
                                            <td class="p-0 border-right  text-center">
                                                <div class="custom-control custom-checkbox custom-control-inline">
                                                    <input type="checkbox"  class="custom-control-input" :id="'invoice-' + index"
                                                           v-model="item.status" :value="item.status?'true':'false'"  :checked="Number.parseFloat(item.status)">
                                                    <label class="custom-control-label"
                                                           :for="'invoice-' + index"> </label>
                                                    <input type="hidden" name="status[]" :value="item.status?'true':'false'">
                                                </div>
                                            </td>
                                        </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="card-footer text-right">
                                <button class="btn btn-info" type="submit"><span class="ml-2" @click="checkDate()">Save Changes</span>
                                </button>
                            </div>

                            <!--  <save-banner @click="handleSubmit($event)" @cancelRoute="$router.push({ name: '/receipt'})" /> -->
                        </form>
                    </div>

                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- end container-fluid -->
    </div>
    <!-- end page-content-wrapper -->

@endsection
@section('js')

    <script>

        var vm = new Vue({
            el: '#myapp',
            data: {
                invoiceLists: {!!$invoices!!},
                payment_account: null,
                selected_company: null,
                selected_currency: null,
                selected_ben_account: null,
                change_form: false,
                date:null,
                invoices: [
                    {item: {}},
                    {item: {}},
                ],
                counter: 0,
                // invoices:
                // {!!$invoices!!}  ,

                form: {}
            },
            mounted: function () {
            },
            computed: {
                grandTotal() {
                    let total = 0;
                    for (let x = 0; x < this.invoiceLists.length; x++) {
                        if (this.invoiceLists[x].status) {
                            total += Number.parseFloat(this.invoiceLists[x].amount);
                        }
                    }
                    return total;
                },
                lcTotal() {
                    let total = 0;

                    for (let x = 0; x < this.unhcrItem.length; x++) {
                        total += Number.parseFloat(this.unhcrItem[x].item.lc_amount);
                    }
                    return total;

                },
                comissionTotal() {
                    let total = 0;

                    for (let x = 0; x < this.unhcrItem.length; x++) {
                        total += Number.parseFloat(this.unhcrItem[x].item.commission_charges);
                    }
                    return total;

                }


            },
            methods: {
                checkDate(){
                    if(this.date==null) {
                        document.getElementById('validate-date').style.borderColor="red";
                    }else document.getElementById('validate-date').style.borderColor="black";
                },
                dateChanges(){  
                    for (let x = 0; x < this.invoiceLists.length; x++) {
                         this.invoiceLists[x].pay_date = this.date;
                    }
                },
                formChange() {
                    if (this.change_form) {
                        this.selected_ben_account = null
                        this.payment_account = null
                    }
                    console.log('sssss', this.change_form)
                },
                amountChange(index, e) {
                    this.invoiceLists[index].amount = e.target.value;
                },

                addRow(index, type = 'unops') {
                    if (type == 'unops') {
                        if (this.invoices[index + 1] == undefined) {
                            this.invoices.push({
                                item: {
                                    advice_no: null,
                                    invoice_no: null,
                                    due_date: null,
                                    transaction_no: null,
                                    pay_date: null,
                                    pm: null,
                                    currency: null,
                                    amount: 0
                                }
                            });
                        }
                    }

                },
                deleteItem(index, type = 'unops') {
                    if (type == 'unops') {
                        if (this.invoices.length - 1 > 0) this.invoices.splice(index, 1);
                    }
                },
                getItemTotal(item = null) {
                    let result = 0;
                    if (item != null && item.lc_amount > 0) {
                        let amount = item.lc_amount;
                        let comission = item.commission_charges;
                        let total = Number.parseFloat(amount) + Number.parseFloat(comission);
                        result = Number.parseFloat(total).toFixed(2);
                    }
                    return result;
                },


            }
        });

    </script>

    <style>
        .vue_dropdown .vs__dropdown-toggle {
            border: none !important;
        }
    </style>

@endsection
