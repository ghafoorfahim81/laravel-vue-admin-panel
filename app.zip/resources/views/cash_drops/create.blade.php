@extends('layouts.master')
@section('title','Cash drop Create')
@section('css')
    <link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css"/>
    <link href="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}" rel="stylesheet" type="text/css"/>

@endsection
@section('content')
    <div class="page-content-wrapper" id="myapp" v-cloak>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <form action="{{route('cash_drop.store')}}" method="post" id="userForm"
                              enctype="multipart/form-data">
                            @csrf
                            <div class="card-body" style="padding-bottom: 0px">
                                <div class="">
                                    <!-- <h4 class="header-title">@lang('lang.add') @lang('lang.order')</h4> -->
                                    <div class="row">
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.organization')
                                                </label>
                                                <input type="text" readonly v-model="selected_organization"
                                                       class="form-control">
                                                <input type="hidden" name="project_id"
                                                       :value="selected_organization?selected_organization.id:null">
                                            </div>
                                        </div>

                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.date')
                                                </label>
                                                <input type="date" name="date" value="<?php echo date('Y-m-d'); ?>" class="form-control" id="email"
                                                       v-validate="'required'" data-vv-as="@lang('lang.date')"
                                                       placeholder="@lang('lang.date')" autocomplete="new-email">

                                            </div>
                                        </div>
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.province')
                                                </label>
                                                <v-select :select-on-tab="true" v-model="selected_province" label="name" :options="provinces" placeholder="@lang('lang.selectProvince')">
                                                    <template v-slot:no-options="{ search, searching }">
                                                        <template v-if="searching">
                                                            @lang('lang.no_record_found_for') @{{search}}
                                                        </template>
                                                        <em class="v-select-search-hint" v-else>@lang('lang.type_to_search')</em>
                                                    </template>
                                                </v-select>
                                                <input type="hidden" name="province" :value="(selected_province == null) ? null : selected_province.id">

                                            </div>
                                        </div>
                                        <div class="col-xl-2">
                                            <div class="form-group">
                                                <label for="">@lang('lang.currency')
                                                </label>
                                                <v-select :select-on-tab="true"
                                                          v-model="selected_currency"
                                                          label="code"
                                                          :options="currencies" placeholder="@lang('lang.currency')"
                                                >
                                                    <template v-slot:no-options="{ search, searching }">
                                                        <template v-if="searching">
                                                            @lang('lang.no_record_found_for') @{{search}}
                                                        </template>
                                                        <em class="v-select-search-hint"
                                                            v-else>@lang('lang.type_to_search')</em>
                                                    </template>
                                                </v-select>
                                                <input type="hidden" name="currency"
                                                       :value="selected_currency?selected_currency.code:null">
                                            </div>
                                        </div>

                                        <div class="col-xl-2">
                                            <div class="form-group">
                                                <label for="">@lang('lang.rate')
                                                </label>
                                                <input type="number" name="rate" class="form-control"
                                                       :value="selected_currency?selected_currency.rate:1">
                                            </div>
                                        </div>
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.request_id')
                                                </label>
                                                <input type="text" name="request_id" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-xl-4">
                                            <div class="form-group">
                                                <label for="">@lang('lang.amount')
                                                </label>
                                                <input type="number" name="amount" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group">
                                                <label for="">@lang('lang.purpose')
                                                </label>
                                                <textarea name="purpose" id="" rows="5" class="form-control"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end of permission -->
                                </div>
                                <div class="table-responsive rounded-sm shadow-4 ">

                                    <table class="table mb-0 ">
                                        <thead class="bg-light-blue-7 text-white">
                                            <tr>
                                                <th class="text-center p-2">#</th>
                                                <th class="p-2">Attachment</th>
                                                <th class="text-center p-2">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr v-for="(item, index) in items">
                                                <th class="p-0 text-center border-right align-middle" scope="row">@{{++index}}</th>
                                                <td class="p-0 border-right align-middle">
                                                    <input type="file" class="form-control-sm" name="attach_file[]" id="customFile" @click="addRow(index)" />
                                                </td>
                                                <td class="p-0 text-center align-middle"><i class="far fa-trash-alt" style="color:red" v-on:click="deleteItem(index)"></i></td>
                                            </tr> 
    
                                        </tbody>
                                    </table>
                                </div>
                            </div>


                            <div class="card-footer text-right" v-show="selected_province">
                                <button class="btn btn-info" type="submit"><span class="ml-2" :disabled="!selected_province">Save Changes</span>
                                </button>


                            </div>

                            <!--  <save-banner @click="handleSubmit($event)" @cancelRoute="$router.push({ name: '/receipt'})" /> -->
                        </form>
                    </div>

                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- end container-fluid -->
    </div>
    <!-- end page-content-wrapper -->

@endsection
@section('js')

    <script>

        var vm = new Vue({
            el: '#myapp',
            data: {
                {{--companies: {!!$companies!!},--}}
                currencies: {!!$currencies!!},
                provinces: {!!$provinces!!},
                selected_organization: "{!! $companies['name'] !!}",
                selected_company: null,
                selected_currency: {!! $selected_currency !!},
                selected_province: null,
                change_form: false,
                items: [
            {
                item: {
                    selected_item: null,
                    quantity: null,
                    price: null
                }
            },
            {
                item: {
                    selected_item: null,
                    quantity: null,
                    price: null
                }
            },
            {
                item: {
                    selected_item: null,
                    quantity: null,
                    price: null
                }
            },
            ], 
            },
            mounted: function () {
            },
            computed: {
                grandTotal() {
                    let total = 0;
                    for (let x = 0; x < this.items.length; x++) {
                        total += Number.parseFloat(this.items[x].item.quantity) * Number.parseFloat(this.items[x].item.amount);
                    }
                    return total;
                }


            },
            methods: {
                
                formChange() {
                    if (this.change_form) {
                        this.selected_province = null
                        this.selected_project = null
                    }
                    console.log('sssss', this.change_form)
                },
                getItems() {
                    axios.get("{{url('searchItem') }}?" +
                        "type=" + 'item'
                    )
                        .then((res) => {
                            this.itemData = res.data;
                        });
                },

                addRow(index) {
                    if (this.items[index + 1] == undefined) {
                        this.items.push({item: {quantity: 0, amount: 0}});

                    }

                },
                deleteItem(index, type = 'unops') {
                    if (type == 'unops') {
                        if (this.items.length - 1 > 0) this.items.splice(index, 1);
                    }
                },
                getItemTotal(item = null) {
                    let result = 0;
                    if (item != null && item.amount > 0) {
                        let amount = item.amount;
                        let quantity = item.quantity;
                        let total = Number.parseFloat(amount) * Number.parseFloat(quantity);
                        result = Number.parseFloat(total).toFixed(2);
                    }
                    return result;
                },
                /**
                 * handleSubmit
                 */
                handleSubmit(e, type = 'save') {
                    this.$validator.validate().then(valid => {
                        if (valid) {
                            let ids = [];
                            eventDefault();
                            let url = (e.target.form == undefined) ? e.target.action : e.target.form.action;
                            let data = (e.target.form == undefined) ? $(e.target).serialize() : $(e.target.form).serialize();
                            data = new FormData(e.target.form);
                            toggleBlock(1);
                            axios.post(url, data)
                                .then(function (response) {
                                    toggleBlock(0);
                                    let message = "{{__('message.success')}}";
                                    if (response.data) {
                                        message = response.data.message;
                                    }
                                    alertify.success(message);
                                    if (type != 'save') {
                                        vm.defaultValue(e);
                                    } else {
                                        window.location.href = "{{route('receipt.index')}}";
                                    }
                                })
                                .catch(function (error) {
                                    toggleBlock(0);
                                    let warning = "{{__('message.error')}}";
                                    if (error.response.data) {
                                        if (error.response.data.message) {
                                            warning = error.response.data.message;
                                        }
                                        if ((error.response.status == 422) == true) {
                                            let my_error = error.response.data.errors;

                                            for (index in my_error) {

                                                alertify.error(my_error[index][0]);
                                            }

                                        }
                                    }

                                    alertify.error(warning);
                                })
                        }
                    });
                },
                /**
                 * this is used to set default value
                 */


            }
        });

    </script>

    <style>
        .vue_dropdown .vs__dropdown-toggle {
            border: none !important;
        }
    </style>

@endsection
