@extends('layouts.master')
@section('title', __('lang.show').' '.__('lang.invoice'))
@section('css')
<link rel="stylesheet" href="{{asset('assets/css/print.css')}}">
@endsection
@section('content')
<div class="page-content-wrapper"  >
  <div class="container-fluid">

    <div class="card" id="app" v-cloak>

      <!-- Nav tabs -->
       
      <div class="tab-content p-3">
        <div class="tab-pane active" id="general" role="tabpanel">

          <div class="card">
            <div class="card-body">
              <div class="container mb-5 mt-3">
                
                <div class="container">
                  <div class="col-md-12">
                    <div class="text-center">
                      <img src="https://apyouths.org/wp-content/uploads/2022/03/PSP-UNHCR-INDONESIA-JOB.png" height="49" alt="" loading="lazy" />

                    </div>

                  </div>
                  <div class="row">
                    <div class="col-xl-8">
                      <ul class="list-unstyled">
                        <li class="text-muted">Organization: <span style="color:#5d9fc5 ;">{{$cash_drop->company}}</span></li>
                        <li class="text-muted">Date: <span style="color:#5d9fc5 ;">{{substr($cash_drop->date, 0, 10)}}</span></li>
                        <li class="text-muted">Province: <span style="color:#5d9fc5 ;">{{$cash_drop->province}}</span></li>
                         <li class="text-muted"><i class="fas fa-circle" style="color:#84B0CA ;"></i> <span class="me-1 fw-bold">Purpose:</span><span class="badge bg-warning text-black fw-bold">
                            {{$cash_drop->purpose}}</span></li>
                      </ul>
                    </div>
                    <div class="col-xl-4"> 
                      <ul class="list-unstyled">
                        <li class="text-muted"><i class="fas fa-circle" style="color:#84B0CA ;"></i> <span class="fw-bold">Currency:</span>{{$cash_drop->currency}}</li>
                        <li class="text-muted"><i class="fas fa-circle" style="color:#84B0CA ;"></i>
                          <span class="fw-bold">Rate: </span>{{$cash_drop->rate}}
                        </li>
                        <li class="text-muted"><i class="fas fa-circle" style="color:#84B0CA ;"></i>
                          <span class="fw-bold">Request Id: </span>{{$cash_drop->request_id}}
                        </li>
                        <li class="text-muted"><i class="fas fa-circle" style="color:#84B0CA ;"></i>
                          <span class="fw-bold">Amount: </span>{{$cash_drop->amount}}
                        </li>
                        
                      </ul>
                    </div>
                  </div>

                  <div class="row my-2 mx-1 justify-content-center">
                    <table class="table align-middle mb-8 bg-white">
                      <thead class="bg-light">
                        <tr>
                          <th>Location</th> 
                          <th>Amount</th>
                          <th>Service Fee %</th>
                          <th>Service Fee $</th>
                          <th>Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        @foreach($invoice_detail as $invoice)
                        <tr>
                          <td>
                            <p class="fw-bold mb-1">{{$invoice->location}}</p>
                          </td> 
                          <td>
                            {{$invoice->amount}}
                          </td>
                          <td>
                            {{$invoice->service_fee_percent}}
                          </td>
                          <td>
                            {{$invoice->service_fee_amount}}
                          </td>
                          <td>
                            {{$invoice->total_amount}}
                          </td>
                        </tr>
                        @endforeach
                      </tbody>
                    </table>
                  </div>

                  <form action="{{route('cash_drop.files')}}" method="post" id="userForm"
                  enctype="multipart/form-data">
                @csrf
                <div class="p-8">
                    <table class="table align-middle mb-0 bg-white">
                        <thead class="bg-light">
                        <tr>
                            <th class="text-center">#</th>
                            <th>Attachment Title</th>
                            <th>Download</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr v-for="(file, index) in files">
                            <td>
                                <div class="text-center">
                                    @{{++index}}
                                </div>
                            </td>
                            <td>
                                <p class="fw-normal mb-1">@{{file.file}}</p>
                            </td>
                            <td>
                                <a :href="`{{url('cash_drop/download')}}/${file.main_name}/${cash_drop_id}`"><i
                                        class="fas fa-cloud-download-alt fa-lg"></i></a>
                            </td>
                        </tr>
                        <tr v-for="(item, index) in items">
                            <th class="p-0 text-center border-right align-middle" scope="row">@{{++index}}</th>
                            <td class="p-0 border-right align-middle">
                                <input type="file" class="form-control-sm" name="attach_file[]" id="customFile" @click="addRow(index)" />

                            </td>
                            <td class="p-0 text-center align-middle"><i class="far fa-trash-alt" style="color:red" v-on:click="deleteItem(index)"></i></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card-footer text-right pr-0 bg-white">
                            <input type="hidden" class="form-control-sm" name="cash_drop_id" value="{{$cash_drop->id}}" id="customFile" />
                            <button class="btn btn-info" type="submit">
                                <span class="ml-2">Save Files</span>
                            </button>
                        </div>
                    </div>
                </div>
            </form>
                   
                  <hr>

                </div>
              </div>
            </div>
          </div>




        </div>
 
      </div>

    </div>
  </div>

  <!-- Tabs content -->
 
  <!-- end container-fluid -->
</div>
<!-- end page-content-wrapper -->


@endsection
@section('js')
<script src="{{asset('assets/js/print.js')}}"></script>
<script>

  var vm = new Vue({
      el: '#app',
      components: {
          'skeleton-loader-vue': window.VueSkeletonLoader,
      },
      data: {
        cash_drop_id: "{{$cash_drop->id}}",
           
          files: {!! $files !!},
        
          edit_items: [], 
          
          items: [
              {
                  item: {
                      selected_item: null,
                      quantity: null,
                      price: null
                  }
              },
              {
                  item: {
                      selected_item: null,
                      quantity: null,
                      price: null
                  }
              },
              {
                  item: {
                      selected_item: null,
                      quantity: null,
                      price: null
                  }
              },
          ], 
      },
      computed: {
          
      },
      mounted: function () { 
      },
      methods: {
            
          addRow(index) {
              if ((this.items.length - 1) == (index - 1)) {
                  this.items.push({
                      item: {
                          selected_item: null,
                          quantity: null,
                          price: null
                      }
                  });
              }
          }, 
          deleteItem(index) {
              if (this.items.length - 1 > 0) this.items.splice(index - 1, 1);
          },
         
         

       
      }
  });

</script>

<style>
  .vue_dropdown .vs__dropdown-toggle {
    border: none !important;
  }
</style>

@endsection