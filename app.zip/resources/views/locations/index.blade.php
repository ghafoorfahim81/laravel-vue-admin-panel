@extends('layouts.master')
@section('title', 'Location List')
@section('css')

<link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css"/>
@endsection
@section('content')


<div class="page-content-wrapper" id="app">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <input type="hidden" name="permission_id" id="permission_id">
                    <div class="card-body" style="padding-bottom: 0px">
                        <div class="card-body client-nav">
                            <div class="row pb-2">
                                <div class="col-sm-12 col-md-2 form-inline">
                                    <div class="form-group">
                                        <button type="button" class="btn btn-primary btn-sm waves-effect waves-light"
                                                data-toggle="modal" data-target="#add_modal"
                                                @click="is_update=false; reset()">Add location</button>&nbsp
                                    </div>
                                </div>
                            </div>


                            <div class=" ">
                                <datatable ref="child" :per-page="{{perPage()}}" :no-record-found-text="'@lang('lang.no_record_found')'" :per-page-text="'@lang('lang.show')'" :showing-text="'@lang('lang.showing')'" :from-text="'@lang('lang.from')'" :to-text="'@lang('lang.to')'" :record-text="'@lang('lang.record')'" :app-per-page="{!! perPage(1) !!}" :columns="columns" :data="apiData" @pagination-change-page="getRecord" :limit="1" :filterRecord="getRecord" :multiple-select="true" :selected-rows="selectedRows" @delete-method-action="deleteRecord">
                                    <template slot="tbody">
                                        <tbody v-show="!apiData.data">
                                            <tr v-for="skeleton in 4">
                                                <td>
                                                    <skeleton-loader-vue
                                                        type="rect"
                                                        :height="15"
                                                        :width="50"
                                                        class="m-3"
                                                        animation="fade"
                                                        />
                                                </td>

                                                <td>
                                                <skeleton-loader-vue
                                                        type="circle"
                                                        :height="65"
                                                        :width="65"
                                                        class="m-3"
                                                        animation="fade"
                                                        />
                                                </td>

                                                <td>
                                                    <skeleton-loader-vue
                                                        type="rect"
                                                        :height="15"
                                                        :width="50"
                                                        class="m-3"
                                                        animation="fade"
                                                        />
                                                </td>

                                                <td>
                                                    <skeleton-loader-vue
                                                        type="rect"
                                                        :height="15"
                                                        :width="50"
                                                        class="m-3"
                                                        animation="fade"
                                                        />
                                                </td>

                                                <td>
                                                    <skeleton-loader-vue
                                                        type="rect"
                                                        :height="15"
                                                        :width="50"
                                                        class="m-3"
                                                        animation="fade"
                                                        />
                                                </td>
                                            </tr>
                                        </tbody>
                                        <tbody v-show="apiData.data">
                                            <tr v-for="(record,index) in apiData.data" :key="record.id">
                                                <td>
                                                    <input type="checkbox" class="" v-model="selectedRows" :value="record.id" :id="`checked-${record.id}}`">

                                                </td>
                                                <td> @{{++index}}</td>
                                                <td> @{{record.name}}</td>
                                                <td> @{{record.zone}}</td>
                                                <td class="">
                                                    <div class="p-1" role="group" style="width: 180px; text-align: center;">

                                                        @if(hasPermission(['category_edit']))

                                                        <button type="button" class="btn btn-primary btn-sm" @click="showUpdateModal(record.id)"><i class="dripicons-document-edit"></i></button>&nbsp
                                                        @endif
                                                        @if(hasPermission(['category_delete']))
                                                        <a class="btn btn-danger btn-sm" @click="deleteRecord(record.id)" data-toggle="tooltip" data-placement="top" title="Delete">
                                                            <i style="color: white" class="mdi mdi-delete"></i>
                                                        </a>
                                                        @endif
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>

                                    </template>
                                </datatable>
                                <Pagination align="center" :limit="1" :data="apiData" @pagination-change-page="getRecord"></Pagination>
                            </div>
                        </div>
                    </div>

                    <div class="card-footer ">
                    </div>

                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
    <!-- end container-fluid -->
    <!-- Small modal -->

    <div class="modal fade bs-example-modal-center" id="add_modal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered"  >
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title mt-0" v-if="is_update">Update location</h5>
                    <h5 class="modal-title mt-0" v-else>Create location</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" @click="hideModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- <select v-model="selected_expense_category" @change="save()" class="form-control" aria-label="Default select example">
                        <option :value="c" v-for="c in currencies">@{{c.name}}</option>
                    </select> -->
                    <input type="text" placeholder="@lang('lang.name')" class="form-control mb-2" v-model="form.name">
                    <v-select :select-on-tab="true"
                              v-model="selected_zone"
                              label="name"
                              :options="zones"
                              placeholder="Zone"
                    >
                        <template v-slot:no-options="{ search, searching }">
                            <template v-if="searching">
                                @lang('lang.no_record_found_for') @{{search}}
                            </template>
                            <em class="v-select-search-hint"
                                v-else>@lang('lang.type_to_search')</em>
                        </template>
                    </v-select>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal" @click="hideModal()">Close</button>
                    <button type="button" class="btn btn-primary waves-effect waves-light" @click="update()" data-dismiss="modal" v-if="is_update">Update</button>
                    <button type="button" class="btn btn-primary waves-effect waves-light" :disabled="!form.name" @click="save()" data-dismiss="modal" v-else>Save changes</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

@endsection
@section('js')
<script>
    //Vue.component('pagination', require('laravel-vue-pagination'));
    var vm = new Vue({
        el: '#app',
        components: {
            'skeleton-loader-vue': window.VueSkeletonLoader,
        },
        data() {
            return {
                url: '{{route("provinces.index")}}?',
                columns: [
                    {
                        label: "Number",
                        name: 'id',
                        sort: false,
                    },
                    {
                        label: "@lang('lang.name')",
                        name: 'name',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    },
                    {
                        label: "zone",
                        name: 'zone',
                        sort: true,
                        activeSort: true,
                        order_direction: 'desc',
                    },
                    {
                        label: "@lang('lang.actions')",
                        name: 'action',
                        sort: false
                    }
                ],

                apiData: {},
                appPerPage: '{!!perPage(1) !!}',
                perPage: "{{perPage()}}",
                zones: {!! $zones !!},
                page: 1,
                selected_zone: null,
                selectedRows: [],
                form:{
                    name:null,
                    zone_id:null,
                },
                is_update:false,
            }

        },
        mounted() {
            this.getRecord();

        },
        methods: {
            save() {
                $('#add_modal').modal('hide')
                this.form.zone_id   = this.selected_zone?.id;
                axios.post("{{route('location.store')}}", this.form).then(()=>{
                    this.reset();
                    this.getRecord();
                });
            },
            update() {
                $('#add_modal').modal('hide');
                this.form.zone_id   = this.selected_zone?.id;
                axios.patch("{{route('location.update','')}}"+"/"+this.form.id, this.form).then(()=>{
                    this.is_update = false;
                    this.reset();
                    this.getRecord();
                });
            },
            reset(){
                this.form.name          = null;
                this.selected_zone      = null;
            },
            showUpdateModal(id=0){
                this.is_update = true;
                axios.get("{{route('location.edit','')}}"+"/"+id).then(data=>{
                    this.form = data.data;
                    this.selected_zone = this.zones.find(inv => inv.id == data.data.zone_id);
                })
                $('#add_modal').modal('show')
            },
            hideModal(){
                $('#add_modal').modal('hide');
                this.reset();
            },
            /**
             * get record from api
             */
            showFilterModal() {
                $('#filterModal').modal('show');
                this.getProvinces();
            },
            getRecord: _.debounce((page = vm.page) => {
                axios.get(vm.url +
                        '&current_page=' +
                        page + '&per_page=' + vm.perPage)
                    .then((response) => {
                        console.log('response',response);
                        if (response.data) {
                            vm.page = response.data.current_page;
                        }
                        vm.apiData = response.data;


                    })
                    .catch((error) => {
                        console.log(error);
                    });
            }, 200),

            // delete record
            deleteRecord(id = null) {

                if (id && id != null) {
                    deleteItem(`location/${id}`);
                    this.selectedRows = [];
                } else {
                    deleteItem(`location/multiple`, this.selectedRows);
                    this.selectedRows = [];
                }

            },
            // send data for editing
            editRecord(url = null, id = null) {
                if (url != null && id != null) {
                    var url = "{{url('/')}}" + "/" + url + "/edit/" + id;

                    window.location = url;
                }
            }
        }
    });
</script>
@endsection
