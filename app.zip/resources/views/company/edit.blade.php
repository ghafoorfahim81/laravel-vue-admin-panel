@extends('layouts.master')
@section('title', __('lang.edit').' '.__('lang.company'))
@section('css')
    <link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css"/>
    <link href="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}" rel="stylesheet" type="text/css"/>

 
@endsection
@section('content')


        <div class="page-content-wrapper" id="myapp">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card">
                            <form action="{{route('company.update', $company->id)}}" enctype="multipart/form-data" method="post">
                                @csrf
                                @method('patch')
                                <div class="card-body" style="padding-bottom: 0px">
                                    <div class="card-body client-nav">


                                        <div class="row">

                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="">Name
                                                    <span class="rq">*</span>
                                                    </label>
                                                    <input type="text" name="name" value="{{$company->name}}" class="form-control" id="name"
                                                           placeholder="@lang('lang.name')">
                                                    
                                                </div>
                                            </div>

                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="">Email
                                                        
                                                    </label>
                                                    <input type="text" name="email" class="form-control"
                                                           id="email" 
                                                           value="{{$company->email}}"
                                                           autocomplete="new-email"
                                                           placeholder="@lang('lang.email')">
                                                    <span class="help-block rq-hint">
                                                    </span>

                                                </div>
                                            </div>
                                            

                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="">Phone
                                                        
                                                    </label>
                                                    <input type="text" name="phone" class="form-control" id="phone" value="{{$company->phone}}"
                                                           placeholder="@lang('lang.phone')">
                                                    
                                                </div>
                                            </div>

                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="">Address
                                                        
                                                    </label>
                                                    <input type="text" name="address" 
                                                            class="form-control" 
                                                            id="address"
                                                            value="{{$company->address}}"
                                                            placeholder="@lang('lang.address')" autocomplete="new-address">
                                                    <span class="help-block rq-hint">
                                                    </span>
                                                </div>
                                            </div>

                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="">Description
                                                        
                                                    </label>
                                                    <input type="text" name="desc" class="form-control"
                                                           id="desc" 
                                                           value="{{$company->desc}}"
                                                           autocomplete="new-desc"
                                                           placeholder="@lang('lang.description')">
                                                    <span class="help-block rq-hint">
                                                    </span>

                                                </div>
                                            </div>

                                            <div class="col-xl-4">
                                                 <div class="form-group">
                                                    <label for="">@lang('lang.currency')
                                                    </label>
                                                    <v-select :select-on-tab="true"
                                                      v-model="selected_currency" 
                                                      label="code" 
                                                      :options="currencies" placeholder="@lang('lang.select_currency')"
                                                        >
                                                        <template v-slot:no-options="{ search, searching }">
                                                            <template v-if="searching">
                                                                @lang('lang.no_record_found_for') @{{search}}
                                                            </template>
                                                            <em class="v-select-search-hint"
                                                                v-else>@lang('lang.type_to_search')</em>
                                                        </template>
                                                    </v-select>
                                                    <input type="hidden" name="currency" :value="(selected_currency == null) ? null : selected_currency.code">
                                                </div>
                                            </div>

                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="">Invoice Description
                                                    </label>
                                                    <textarea id="elm1" name="invoice_desc">{{$company->invoice_desc}}
                                                    </textarea>
                                                    <span class="help-block rq-hint">
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="">Invoice Purpose
                                                    </label>
                                                    <textarea class="form-control" name="purpose" rows="7">{{$company->invoice_propuse}}
                                                    </textarea>
                                                    <span class="help-block rq-hint">
                                                    </span>
                                                </div>
                                            </div> 
                                            <div class="col-xl-4">
                                                <div class="has-success">
                                                    <label class="control-label">@lang('lang.logo')
                                                        
                                                    </label>
                                                    <div>
                                                        <div class="fileinput fileinput-new" data-provides="fileinput">
                                                            <div class="fileinput-new thumbnail"
                                                                 style="width: 200px; height: 150px;">
                                                                <img src="{{asset('no_image.png')}}" alt=""/></div>
                                                            <div class="fileinput-preview fileinput-exists thumbnail"
                                                                 style="max-width: 200px; max-height: 150px;"></div>
                                                            <div>
                                                    <span class="btn default btn-file">
                                                        <span class="fileinput-new"> @lang('lang.select_image') </span>
                                                        <span class="fileinput-exists"> @lang('lang.change') </span>
                                                        <input type="file" name="photo"> </span>
                                                                <a href="javascript:;" class="btn red fileinput-exists"
                                                                   data-dismiss="fileinput"> @lang('lang.remove') </a>
                                                            </div>
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                            </div>

                                        </div>



                                    </div>
                                </div>

                                <div class="card-footer ">
                                    <button class="btn btn-md btn-primary" type="submit" >
                                        <span hidden id="btn-loading" class="spinner-border spinner-border-sm"
                                              user="status" aria-hidden="true"></span> @lang('lang.save')</button>
                                    <button class="btn btn-md btn-danger" type="reset">@lang('lang.reset')</button>
                                    <button class="btn btn-md btn-danger" type="button"
                                            onclick="location.href='{{route('company.index')}}'">@lang('lang.cancel')</button>

                                </div>

                            </form>
                        </div>

                    </div>
                </div>
                <!-- end row -->
            </div>

            <!-- <div class="facebook-card">
    <skeleton-loader-vue
      type="circle"
      :width="200"
      :height="200"
      animation="fade"
    />
  </div> -->
            <!-- end container-fluid -->
        </div>
        <!-- end page-content-wrapper -->


@endsection
@section('js')
    <script src="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.js')}}" type="text/javascript"></script>
    <!--tinymce js-->
        <script src="{{ asset('assets/libs/tinymce/tinymce.min.js') }}"></script>

        <!--ck editor js-->
        <script src="{{ asset('assets/libs/ckeditor4/ckeditor.js') }}"></script>

        <!-- init js -->
        <script src="{{ asset('assets/js/pages/form-editor.init.js') }}"></script>

    <script>
      
        var vm = new Vue({
            el: '#myapp',
            data: {
                spinner: 'spinner-border',
                disabled: true,
                currencies:{!!$currencies!!},
                selected_currency:null,
            },
            components: {
                'skeleton-loader-vue': window.VueSkeletonLoader,
            },
            mounted(){
                let home_currency = {!! $home_currency !!};
                this.selected_currency = this.currencies.find(currency => currency.code == home_currency.code);
            },
            methods: {

            }
        });

    </script>

@endsection
