@extends('layouts.master')
@section('title')
Companies Profile
@endsection
@section('css')
@endsection
@section('content')
    <div id="dashboardApp">
        <section style="background-color: #f4f5f7;">
            <div class="container">
                <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class=" mb-3 mb-lg-0">
                        <div class="card mb-3" style="border-radius: .5rem;">
                            <div class="row g-0">
                                <div class="col-md-3 gradient-custom text-center text-white"
                                     >
                                    <!-- <img
                                        src="{{url('storage/logos/'.$company->logo)}}"
                                        alt="{{$company->name}}" class="img-fluid my-5 rounded bordered-2" style="width: 80px;"/> -->
                                        <img src="{{url('storage/logos/'.$company->logo)}}"
                                        class="img-fluid my-3 rounded "
                                        style="width: 200px; border-radius: 3% !important; border: 3px solid white; box-shadow: rgba(17, 17, 26, 0.1) 0px 4px 16px, rgba(17, 17, 26, 0.1) 0px 8px 24px, rgba(17, 17, 26, 0.1) 0px 16px 56px;"/>
                                    <h5 class="text-info">{{$company->name}}</h5>
                                    <h5>Balance: <span class="text-info">{{$balance}} {{homeCurrency()['symbol']}}</span> </h5>
                                    <p>Web Designer</p>
                                    <i class="far fa-edit mb-5"></i>
                                </div>
                                <div class="col-md-9">
                                    <div class="card-body p-4">
                                        <h6>Information</h6>
                                        <hr class="mt-0 mb-4">
                                        <div class="row pt-1">

                                            <ul class="list-group">

                                                <div class="ml-3 rounded-4 shadow-5 mb-3">
                                                    <a class="btn-floating btn-tw btn-sm">
                                                    <button type="button" class="btn btn-info btn-floating btn-sm">
                                                        <i class="fas fa-briefcase"></i>
                                                        </button>
                                                    </a>
                                                    <span class="font-weight-bold ml-2">Company Name:
                                                        <span class="ml-4 fw-normal text-info">{{$company->name}}</span>
                                                </span>
                                                </div>

                                                <div class="ml-3 rounded-4 shadow-5 mb-3">
                                                    <a class="btn-floating btn-tw btn-sm">
                                                    <button type="button" class="btn btn-info btn-floating btn-sm">
                                                        <i class="fas fa-envelope"></i>
                                                    </button>
                                                    </a>
                                                    <span class="font-weight-bold ml-2">Email:
                                                        <span class="ml-4 fw-normal text-info">{{$company->email}}</span></span>
                                                </div>

                                                <div class="ml-3 rounded-4 shadow-5 mb-3">
                                                    <a class="btn-floating btn-tw btn-sm">
                                                    <button type="button" class="btn btn-info btn-floating btn-sm">
                                                                <i class="fas fa-phone"></i>
                                                    </button>
                                                    </a>
                                                    <span class="font-weight-bold ml-2">Phone:
                                                        <span class="ml-4 fw-normal text-info">{{$company->phone}}</span></span>
                                                </div>




                                                <div class="ml-3 rounded-4 shadow-5 mb-3">
                                                    <a class="btn-floating btn-tw btn-sm">
                                                    <button type="button" class="btn btn-info btn-floating btn-sm">
                                                                <i class="fas fa-map-marker-alt"></i>
                                                    </button>
                                                    </a>
                                                    <span class="font-weight-bold ml-2">Address:
                                                        <span class="ml-4 fw-normal text-info">{{$company->address}}</span></span>
                                                </div>
                                                <div class="ml-3 rounded-4 shadow-5 mb-3">
                                                    <a class="btn-floating btn-tw btn-sm">
                                                    <button type="button" class="btn btn-info btn-floating btn-sm">
                                                        <i class="fas fa-dollar-sign"></i>
                                                    </button>
                                                    </a> 
                                                    <span class="font-weight-bold ml-2">Currency:
                                                        <span class="ml-4 fw-normal text-info">{{homeCurrency()['code']}}</span></span>
                                                </div>

                                                <div class="ml-3 rounded-4 shadow-5 mb-3">
                                                    <a class="btn-floating btn-tw btn-sm">
                                                    <button type="button" class="btn btn-info btn-floating btn-sm">
                                                                <i class="fas fa-comment-alt"></i>
                                                    </button>
                                                    </a>
                                                    <span class="font-weight-bold ml-2">Description:
                                                        <span class="ml-4 fw-normal text-info">{{$company->description}} </span></span>
                                                </div>


                                            </ul>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@section('js')
    @section('js')

        <script>
            var vm = new Vue({
                el: '#app',
                data: {},
                mounted: function () {

                },
                computed: {},
                methods: {}
            });

        </script>


    @endsection
