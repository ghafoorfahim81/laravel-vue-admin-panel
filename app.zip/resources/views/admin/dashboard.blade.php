@extends('layouts.master')
@section('title')

@endsection
@section('css')

@endsection
@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">

                </div>
            </div>
        </div>
    </div>
    <!-- end row -->

</div>
<!-- end container-fluid -->
@endsection
@section('js')

@endsection
