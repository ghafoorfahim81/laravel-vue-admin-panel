@extends('layouts.master')
@section('title')
Analytics Dashboard
@endsection
@section('css')
<style>

    .customCard {
        box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;
        border-radius: 5px;
        border: solid lightblue 2px;
    }

    .custom_design_new_blue {
        background-image: linear-gradient(to bottom right, #5761B2, #1FC5A8);
        box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;
        border-radius: 5px;
        border: solid white 2px;
    }

    .custom_design_blue {
        background: linear-gradient(40deg, #45cafc, #303f9f) !important;
        box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;
        border-radius: 5px;
        border: solid white 2px;
    }

    .custom_design_purple {
        background-image: linear-gradient(120deg, #f093fb 0, #f5576c 100%);
        box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;
        border-radius: 5px;
        border: solid white 2px;
    }

    .custom_design_orange {
        background: linear-gradient(40deg, #ffd86f, #fc6262) !important;
        box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;
        border-radius: 5px;
        border: solid white 2px;
    }

    .custom_design_cyan {
        background-image: linear-gradient(120deg, #84fab0 0, #8fd3f4 100%);
        box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;
        border-radius: 5px;
        border: solid white 2px;
    }

    .skeleton__custom {
        box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;
        border-radius: 5px;
        border: solid white 2px;
    }

    .grow {
        transition: all .5s ease-in-out;
    }

    .grow:hover {
        transform: scale(1.07);
    }

    .highcharts-credits {
        display: none;
    }
</style>
@endsection
@section('content')
<div id="dashboardApp">
    <main class="px-4">
        <div class="container-fluid p-0" id="app" v-cloak>
            <div class="row" v-show="skeleton">
                <div class="col-xl-3 col-sm-6 col-12" v-for="skeleton in 4">
                    <skeleton-loader-vue
                    type="rect"
                    class="skeleton__custom"
                    :height="160"
                    :width="280"
                    animation="wave"
                    />
                </div>

<<<<<<< HEAD
                <div class="col-xl-12 col-sm-12 col-12" style="margin-top:30px">
                    <skeleton-loader-vue
                    type="rect"
                    class="skeleton__custom"
                    :height="350"
                    :width="1210"
                    animation="wave"
                    />
=======
                <div class="row" v-show="!skeleton">
                    @if(hasPermission(['admin_dashboard']))
                        <div class="col-xl-3 col-sm-6 col-12">
                            <div class="card custom_design_blue grow">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col mt-0">
                                            <h5 class="card-title text-white">Invoice</h5>
                                        </div>

                                        <div class="col-auto">
                                            <div class="stat text-primary">
                                                <i class="align-middle" data-feather="truck"></i>
                                            </div>
                                        </div>
                                    </div>

                                    <h3 class="mt-1 mb-3 text-light">
                                        @{{invoices>0?invoices.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g,
                                        ","):0}} {{homeCurrency()['symbol']}}</h3>
                                    <div class="mb-0">
                                        <div class="text-white row justify-content-end">
                                            @if(hasPermission(['invoice_list']))
                                                <a style="text-decoration: none;" class="text-white"
                                                   href=" {{ route('invoice.index') }} ">
                                                    Open Details
                                                </a>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-sm-6 col-12">
                            <div class="card custom_design_purple grow">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col mt-0">
                                            <h5 class="card-title text-white">Receipt</h5>
                                        </div>

                                        <div class="col-auto">
                                            <div class="stat text-primary">
                                                <i class="align-middle" data-feather="users"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <h3 class="mt-1 mb-3 text-light">
                                        @{{receipts>0?receipts.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g,
                                        ","):0}} {{homeCurrency()['symbol']}}</h3>
                                    <div class="mb-0">
                                        <div class="text-white row justify-content-end">
                                            @if(hasPermission(['receipt_list']))
                                                <a style="text-decoration: none;" class="text-white"
                                                   href=" {{ route('receipt.index') }} ">
                                                    Open Details
                                                </a>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-sm-6 col-12">
                            <div class="card custom_design_orange grow">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col mt-0">
                                            <h5 class="card-title text-white">Expense</h5>
                                        </div>

                                        <div class="col-auto">
                                            <div class="stat text-primary">
                                                <i class="align-middle" data-feather="shopping-cart"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <h3 class="mt-1 mb-3 text-light">
                                        @{{expenses>0?expenses.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g,
                                        ","):0}} {{homeCurrency()['symbol']}}</h3>
                                    <div class="mb-0">
                                        <div class="text-white row justify-content-end">
                                            @if(hasPermission(['expense_list']))
                                                <a style="text-decoration: none;" class="text-white"
                                                   href=" {{ route('expense.index') }} ">
                                                    Open Details
                                                </a>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-sm-6 col-12">
                            <div class="card custom_design_cyan grow">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col mt-0">
                                            <h5 class="card-title text-white">Income</h5>
                                        </div>

                                        <div class="col-auto">
                                            <div class="stat text-primary">
                                                <i class="align-middle" data-feather="shopping-cart"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <h3 class="mt-1 mb-3 text-light">
                                        @{{income.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g,
                                        ",")}} {{homeCurrency()['symbol']}}</h3>
                                    <div class="mb-0">
                                        <div class="text-white row justify-content-end">
                                            @if(hasPermission(['balance_sheet']))
                                                <a style="text-decoration: none;" class="text-white"
                                                   href=" {{ route('reports.index') }} ">
                                                    Open Details
                                                </a>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif
                    @if(hasPermission(['organization_dashboard']))

                        <div class="col-xl-3 col-sm-6 col-12">
                            <div class="card custom_design_cyan grow">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col mt-0">
                                            <h5 class="card-title text-white">Started project</h5>
                                        </div>

                                        <div class="col-auto">
                                            <div class="stat text-primary">
                                                <i class="align-middle" data-feather="shopping-cart"></i>
                                            </div>
                                        </div>
                                    </div>
                                        <div class="row">
                                        <div class="col-xl-6"><h3 class="mt-1 mb-3 text-light">
                                        {{$started_projects?$started_projects:0}}</h3></div>
                                        <div class="col-xl-6 text-light align-self-center">Amount: 89</div>
                                    </div>
                                    <div class="mb-0">
                                        <a style="text-decoration: none;" class="text-white"
                                           data-toggle="collapse" @click="filterProjects('started')"
                                           href="#collapseExample" role="button"
                                           aria-expanded="false" aria-controls="collapseExample">
                                            Open Details
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-sm-6 col-12">
                            <div class="card custom_design_orange grow">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col mt-0">
                                            <h5 class="card-title text-white">Pending Project</h5>
                                        </div>

                                        <div class="col-auto">
                                            <div class="stat text-primary">
                                                <i class="align-middle" data-feather="shopping-cart"></i>
                                            </div>
                                        </div>
                                    </div>
                                        <div class="row">
                                        <div class="col-xl-6"><h3 class="mt-1 mb-3 text-light">
                                        {{$pending_projects?$pending_projects:0}}</h3></div>
                                        <div class="col-xl-6 text-light align-self-center">Amount: 89</div>
                                    </div>
                                    <div class="mb-0">
                                        <a style="text-decoration: none;" class="text-white"
                                           data-toggle="collapse" @click="filterProjects('pending')"
                                           href="#collapseExample" role="button"
                                           aria-expanded="false" aria-controls="collapseExample">
                                            Open Details
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-sm-6 col-12">
                            <div class="card custom_design_purple grow">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col mt-0">
                                            <h5 class="card-title text-white">Finished Project</h5>
                                        </div>

                                        <div class="col-auto">
                                            <div class="stat text-primary">
                                                <i class="align-middle" data-feather="users"></i>
                                            </div>
                                        </div>
                                    </div>
                                        <div class="row">
                                        <div class="col-xl-6"><h3 class="mt-1 mb-3 text-light">
                                        {{$finished_projects?$finished_projects:0}}</h3></div>
                                        <div class="col-xl-6 text-light align-self-center">Amount: 89</div>
                                    </div>
                                    <div class="mb-0">
                                        <a style="text-decoration: none;" class="text-white"
                                           data-toggle="collapse" @click="filterProjects('finished')"
                                           href="#collapseExample" role="button"
                                           aria-expanded="false" aria-controls="collapseExample">
                                            Open Details
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-sm-6 col-12">
                            <div class="card custom_design_blue grow">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col mt-0">
                                            <h5 class="card-title text-white">Paid Invoices</h5>
                                        </div>

                                        

                                        <div class="col-auto">
                                            <div class="stat text-primary">
                                                <i class="align-middle" data-feather="truck"></i>
                                            </div>
                                        </div>
                                    </div>

                                        <div class="row">
                                        <div class="col-xl-6"><h3 class="mt-1 mb-3 text-light">
                                        {{$paidInvoices?$paidInvoices:0}}</h3></div>
                                        <div class="col-xl-6 text-light align-self-center">Amount: 89</div>
                                    </div>
                                    <div class="mb-0">
                                        <a style="text-decoration: none;" class="text-white"
                                           data-toggle="collapse" @click="filterInvoices(1)"
                                           href="#invoiceCollapse" role="button"
                                           aria-expanded="false" aria-controls="invoiceCollapse">
                                            Open Details
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif

                    <div class="collapse" id="collapseExample">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                <h4 class="header-title col">@{{ project_type }} Project</h4>
                                <!-- <div class="col">
                                    <button class="col">aSad</div>
                                    <button class="col">aSad</div>
                                </div> -->
                                </div>
                                <div class="table-responsive">
                                    <table class="table mb-0">
                                        <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Code</th>
                                            <th>Name</th>
                                            <th>Started date</th>
                                            <th>End date</th>
                                            <th>Province</th>
                                            <th>Exports</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr v-for="(project,index) in projects">
                                            <th scope="row">@{{ ++index }}</th>
                                            <td>@{{ project.code }}</td>
                                            <td>@{{ project.name }}</td>
                                            <td>@{{ project.start_date }}</td>
                                            <td>@{{ project.end_date }}</td>
                                            <td>@{{ project.location }}</td>

                                            <td>
                                            <div class="row">
                                            <button type="button" class="btn btn-success btn-floating btn-sm">
                                                <i class="fas fa-file-excel"></i>
                                                </button>
                                                <button type="button" class="btn btn-danger btn-floating btn-sm ml-1">
                                                <i class="fas fa-file-pdf"></i>
                                                </button>
                                            </div> 
                                            </td>
                                        </tr>
                                        <tr v-if="projects.length<=0">
                                            <td colspan="7" class="text-center">No record found</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="collapse" id="invoiceCollapse">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="header-title">@{{ invoice_type }} Invoices </h4>
                                <div class="table-responsive">
                                    <table class="table mb-0">
                                        <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Number</th>
                                            <th>Project</th>
                                            <th>Date</th>
                                            <th>Amount</th>
                                            <th>Currency</th>
                                            <th>Exports</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr v-for="(invoice,index) in invoices">
                                            <th scope="row">@{{ ++index }}</th>
                                            <td>@{{ invoice.invoice_no }}</td>
                                            <td>@{{ invoice.project}}</td>
                                            <td>@{{ invoice.date }}</td>
                                            <td>@{{ invoice.amount }}</td>
                                            <td>@{{ invoice.currency }}</td>
                                            <td>
                                            <div class="row">
                                            <button type="button" class="btn btn-success btn-floating btn-sm">
                                                <i class="fas fa-file-excel"></i>
                                                </button>
                                                <button type="button" class="btn btn-danger btn-floating btn-sm ml-1">
                                                <i class="fas fa-file-pdf"></i>
                                                </button>
                                            </div> 
                                            </td>
                                        </tr>
                                        <tr v-if="invoices.length<=0">
                                            <td colspan="7" class="text-center">No record found</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-xl-12">
                        <div class="row">
                            <div class="col-xl-9">
                                <div class="customCard">
                                    <div id="afgMap"></div>

                                </div>
                                <br>
                                
                            </div>
                            
                                <div class="col-xl-3 col-sm-6 col-12">
                                @if(hasPermission(['organization_dashboard']))
                                    <div class="card custom_design_orange grow">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col mt-0">
                                                    <h5 class="card-title text-white">Un Paid Invoices</h5>
                                                </div>

                                                <div class="col-auto">
                                                    <div class="stat text-primary">
                                                        <i class="align-middle" data-feather="shopping-cart"></i>
                                                    </div>
                                                </div>
                                            </div>
                                                <div class="row">
                                        <div class="col-xl-6"><h3 class="mt-1 mb-3 text-light">
                                        {{$unPaidInvoices?$unPaidInvoices:0}}</h3></div>
                                        <div class="col-xl-6 text-light align-self-center">Amount: 89</div>
                                    </div>
                                            <div class="mb-0">
                                                <a style="text-decoration: none;" class="text-white"
                                                   data-toggle="collapse" @click="filterInvoices(0)"
                                                   href="#invoiceCollapse" role="button"
                                                   aria-expanded="false" aria-controls="invoiceCollapse">
                                                    Open Details
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                @endif
                                
                                
                                @if(hasPermission(['admin_dashboard']))
                                <div class="card custom_design_new_blue grow">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col mt-0">
                                                    <h5 class="card-title text-white">Commission</h5>
                                                </div>

                                                <div class="col-auto">
                                                    <div class="stat text-primary">
                                                        <i class="align-middle" data-feather="shopping-cart"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col">
                                                <h3 class="mt-1 mb-3 text-light">
                                                @{{commissions.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g,
                                                ",")}} {{homeCurrency()['symbol']}} </h3>
                                                </div>
                                                <div class="col-xl-6 text-light align-self-center">Amount: 89</div>
                                            </div>
                                                

                                            
                                                
                                            <div class="mb-0">
                                                <div class="text-white row justify-content-end">
                                                    <a style="text-decoration: none;" class="text-white"
                                                       href=" {{ route('reports.index') }} ">
                                                        Open Details
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                            
                        

                                    <div class="card custom_design_new_blue grow">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col mt-0">
                                                    <h5 class="card-title text-white">Total Beneficiary</h5>
                                                </div>

                                                <div class="col-auto">
                                                    <div class="stat text-primary">
                                                        <i class="align-middle" data-feather="shopping-cart"></i>
                                                    </div>
                                                </div>
                                            </div>
                                                <div class="row">
                                        <div class="col-xl-6"><h3 class="mt-1 mb-3 text-light">
                                        {{$binificiaries?$binificiaries:0}}</h3></div>
                                        <div class="col-xl-6 text-light align-self-center">Amount: 89</div>
                                    </div>
                                            <div class="mb-0">
                                                <div class="text-white row justify-content-end">
                                                    <a style="text-decoration: none;" class="text-white"
                                                       data-toggle="collapse"
                                                       href="#benificiaryColl" role="button"
                                                       aria-expanded="false" aria-controls="benificiaryColl">
                                                        Open Details
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endif
                            </div>

                                </div>
                        </div>
                    </div>
                    <div class="collapse" id="benificiaryColl">
                    <div class="card">
                                <div class="card-body">
                                    <h4 class="header-title"> Beneficiary</h4>
                                    <div class="table-responsive">
                                        <table class="table mb-0">
                                            <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Project</th>
                                                <th>Amount</th>
                                                <th>Exports</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr v-for="(project,index) in projectList">
                                                <th scope="row">@{{ ++index }}</th>
                                                <td>@{{ project.name }}</td>
                                                <td>@{{ project.total_beneficiary }}</td>
                                                <td>
                                                <div class="row">
                                                <button type="button" class="btn btn-success btn-floating btn-sm">
                                                    <i class="fas fa-file-excel"></i>
                                                    </button>
                                                    <button type="button" class="btn btn-danger btn-floating btn-sm ml-1">
                                                    <i class="fas fa-file-pdf"></i>
                                                    </button>
                                                </div> 
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                </div>
    </div>
>>>>>>> 573b5908179e1c05e87cebea459aa658d05a4b36
                </div>
            </div>

            <div class="row" v-show="!skeleton">
                @if(hasPermission(['admin_dashboard']))
                <div class="col-xl-3 col-sm-6 col-12">
                    <div class="card custom_design_blue grow">
                        <div class="card-body">
                            <div class="row">
                                <div class="col mt-0">
                                    <h5 class="card-title text-white">Invoice</h5>
                                </div>

                                <div class="col-auto">
                                    <div class="stat text-primary">
                                        <i class="align-middle" data-feather="truck"></i>
                                    </div>
                                </div>
                            </div>

                            <h3 class="mt-1 mb-3 text-light">
                                @{{invoices>0?invoices.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g,
                            ","):0}} {{homeCurrency()['symbol']}}</h3>
                            <div class="mb-0">
                                <div class="text-white row justify-content-end">
                                    @if(hasPermission(['invoice_list']))
                                    <a style="text-decoration: none;" class="text-white"
                                    href=" {{ route('invoice.index') }} ">
                                    Open Details
                                </a>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-sm-6 col-12">
                <div class="card custom_design_purple grow">
                    <div class="card-body">
                        <div class="row">
                            <div class="col mt-0">
                                <h5 class="card-title text-white">Receipt</h5>
                            </div>

                            <div class="col-auto">
                                <div class="stat text-primary">
                                    <i class="align-middle" data-feather="users"></i>
                                </div>
                            </div>
                        </div>
                        <h3 class="mt-1 mb-3 text-light">
                            @{{receipts>0?receipts.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g,
                        ","):0}} {{homeCurrency()['symbol']}}</h3>
                        <div class="mb-0">
                            <div class="text-white row justify-content-end">
                                @if(hasPermission(['receipt_list']))
                                <a style="text-decoration: none;" class="text-white"
                                href=" {{ route('receipt.index') }} ">
                                Open Details
                            </a>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-sm-6 col-12">
            <div class="card custom_design_orange grow">
                <div class="card-body">
                    <div class="row">
                        <div class="col mt-0">
                            <h5 class="card-title text-white">Expense</h5>
                        </div>

                        <div class="col-auto">
                            <div class="stat text-primary">
                                <i class="align-middle" data-feather="shopping-cart"></i>
                            </div>
                        </div>
                    </div>
                    <h3 class="mt-1 mb-3 text-light">
                        @{{expenses>0?expenses.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g,
                    ","):0}} {{homeCurrency()['symbol']}}</h3>
                    <div class="mb-0">
                        <div class="text-white row justify-content-end">
                            @if(hasPermission(['expense_list']))
                            <a style="text-decoration: none;" class="text-white"
                            href=" {{ route('expense.index') }} ">
                            Open Details
                        </a>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-sm-6 col-12">
        <div class="card custom_design_cyan grow">
            <div class="card-body">
                <div class="row">
                    <div class="col mt-0">
                        <h5 class="card-title text-white">Income</h5>
                    </div>

                    <div class="col-auto">
                        <div class="stat text-primary">
                            <i class="align-middle" data-feather="shopping-cart"></i>
                        </div>
                    </div>
                </div>
                <h3 class="mt-1 mb-3 text-light">
                    @{{income.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g,
                ",")}} {{homeCurrency()['symbol']}}</h3>
                <div class="mb-0">
                    <div class="text-white row justify-content-end">
                        @if(hasPermission(['balance_sheet']))
                        <a style="text-decoration: none;" class="text-white"
                        href=" {{ route('reports.index') }} ">
                        Open Details
                    </a>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endif
@if(hasPermission(['organization_dashboard']))

<div class="col-xl-3 col-sm-6 col-12">
    <div class="card custom_design_cyan grow">
        <div class="card-body">
            <div class="row">
                <div class="col mt-0">
                    <h5 class="card-title text-white">Started project</h5>
                </div>

                <div class="col-auto">
                    <div class="stat text-primary">
                        <i class="align-middle" data-feather="shopping-cart"></i>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-6"><h3 class="mt-1 mb-3 text-light">
                {{$started_projects?$started_projects:0}}</h3></div>
                <div class="col-xl-6 text-light align-self-center">Amount: 89</div>
            </div>
            <div class="mb-0">
                <a style="text-decoration: none;" class="text-white"
                data-toggle="collapse" @click="filterProjects('started')"
                href="#collapseExample" role="button"
                aria-expanded="false" aria-controls="collapseExample">
                Open Details
            </a>
        </div>
    </div>
</div>
</div>

<div class="col-xl-3 col-sm-6 col-12">
    <div class="card custom_design_orange grow">
        <div class="card-body">
            <div class="row">
                <div class="col mt-0">
                    <h5 class="card-title text-white">Pending Project</h5>
                </div>

                <div class="col-auto">
                    <div class="stat text-primary">
                        <i class="align-middle" data-feather="shopping-cart"></i>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-6"><h3 class="mt-1 mb-3 text-light">
                {{$pending_projects?$pending_projects:0}}</h3></div>
                <div class="col-xl-6 text-light align-self-center">Amount: 89</div>
            </div>
            <div class="mb-0">
                <a style="text-decoration: none;" class="text-white"
                data-toggle="collapse" @click="filterProjects('pending')"
                href="#collapseExample" role="button"
                aria-expanded="false" aria-controls="collapseExample">
                Open Details
            </a>
        </div>
    </div>
</div>
</div>
<div class="col-xl-3 col-sm-6 col-12">
    <div class="card custom_design_purple grow">
        <div class="card-body">
            <div class="row">
                <div class="col mt-0">
                    <h5 class="card-title text-white">Finished Project</h5>
                </div>

                <div class="col-auto">
                    <div class="stat text-primary">
                        <i class="align-middle" data-feather="users"></i>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-6"><h3 class="mt-1 mb-3 text-light">
                {{$finished_projects?$finished_projects:0}}</h3></div>
                <div class="col-xl-6 text-light align-self-center">Amount: 89</div>
            </div>
            <div class="mb-0">
                <a style="text-decoration: none;" class="text-white"
                data-toggle="collapse" @click="filterProjects('finished')"
                href="#collapseExample" role="button"
                aria-expanded="false" aria-controls="collapseExample">
                Open Details
            </a>
        </div>
    </div>
</div>
</div>
<div class="col-xl-3 col-sm-6 col-12">
    <div class="card custom_design_blue grow">
        <div class="card-body">
            <div class="row">
                <div class="col mt-0">
                    <h5 class="card-title text-white">Paid Invoices</h5>
                </div>



                <div class="col-auto">
                    <div class="stat text-primary">
                        <i class="align-middle" data-feather="truck"></i>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-6"><h3 class="mt-1 mb-3 text-light">
                {{$paidInvoices?$paidInvoices:0}}</h3></div>
                <div class="col-xl-6 text-light align-self-center">Amount: 89</div>
            </div>
            <div class="mb-0">
                <a style="text-decoration: none;" class="text-white"
                data-toggle="collapse" @click="filterInvoices(1)"
                href="#invoiceCollapse" role="button"
                aria-expanded="false" aria-controls="invoiceCollapse">
                Open Details
            </a>
        </div>
    </div>
</div>
</div>
@endif

<div class="collapse" id="collapseExample">
    <div class="card">
        <div class="card-body">
            <h4 class="header-title">@{{ project_type }} Project</h4>
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Code</th>
                            <th>Name</th>
                            <th>Started date</th>
                            <th>End date</th>
                            <th>Province</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(project,index) in projects">
                            <th scope="row">@{{ ++index }}</th>
                            <td>@{{ project.code }}</td>
                            <td>@{{ project.name }}</td>
                            <td>@{{ project.start_date }}</td>
                            <td>@{{ project.end_date }}</td>
                            <td>@{{ project.location }}</td>

                            <td>
                             <div class="row">
                                 <button type="button" class="btn btn-danger btn-floating btn-sm">
                                    <i class="fas fa-magic"></i>
                                </button>
                                <!-- <button type="button" class="btn btn-dark btn-floating btn-sm">
                                    <i class="fab fa-apple"></i>
                                </button> -->
                                <a href="{{ url('pdf', ['type' => 'all_project','id'=>`${project.id}`]) }}"
                                   class="btn btn-dark btn-floating btn-sm" style="float: right;">
                                   <i class="fa fa-download"></i> PDF
                               </a>
                           </div> 
                       </td>
                   </tr>
                   <tr v-if="projects.length<=0">
                    <td colspan="6" class="text-center">No record found</td>
                </tr> 
            </tbody>
        </table>
    </div>

</div>
</div>
</div>
<div class="collapse" id="invoiceCollapse">
    <div class="card">
        <div class="card-body">
            <h4 class="header-title">@{{ invoice_type }} Invoices </h4>
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Number</th>
                            <th>Project</th>
                            <th>Date</th>
                            <th>Amount</th>
                            <th>Currency</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(invoice,index) in invoices">
                            <th scope="row">@{{ ++index }}</th>
                            <td>@{{ invoice.invoice_no }}</td>
                            <td>@{{ invoice.project}}</td>
                            <td>@{{ invoice.date }}</td>
                            <td>@{{ invoice.amount }}</td>
                            <td>@{{ invoice.currency }}</td>
                        </tr>
                        <tr v-if="invoices.length<=0">
                            <td colspan="6" class="text-center">No record found</td>
                        </tr>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>
<div class="col-xl-12">
    <div class="row">
        <div class="col-xl-9">
            <div class="customCard">
                <div id="afgMap"></div>

            </div>
            <br>

        </div>

        <div class="col-xl-3 col-sm-6 col-12">
            @if(hasPermission(['organization_dashboard']))
            <div class="card custom_design_orange grow">
                <div class="card-body">
                    <div class="row">
                        <div class="col mt-0">
                            <h5 class="card-title text-white">Un Paid Invoices</h5>
                        </div>

                        <div class="col-auto">
                            <div class="stat text-primary">
                                <i class="align-middle" data-feather="shopping-cart"></i>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xl-6"><h3 class="mt-1 mb-3 text-light">
                        {{$unPaidInvoices?$unPaidInvoices:0}}</h3></div>
                        <div class="col-xl-6 text-light align-self-center">Amount: 89</div>
                    </div>
                    <div class="mb-0">
                        <a style="text-decoration: none;" class="text-white"
                        data-toggle="collapse" @click="filterInvoices(0)"
                        href="#invoiceCollapse" role="button"
                        aria-expanded="false" aria-controls="invoiceCollapse">
                        Open Details
                    </a>
                </div>
            </div>
        </div>
        @endif


        @if(hasPermission(['admin_dashboard']))
        <div class="card custom_design_new_blue grow">
            <div class="card-body">
                <div class="row">
                    <div class="col mt-0">
                        <h5 class="card-title text-white">Commission</h5>
                    </div>

                    <div class="col-auto">
                        <div class="stat text-primary">
                            <i class="align-middle" data-feather="shopping-cart"></i>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <h3 class="mt-1 mb-3 text-light">
                            @{{commissions.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g,
                        ",")}} {{homeCurrency()['symbol']}} </h3>
                    </div>
                    <div class="col-xl-6 text-light align-self-center">Amount: 89</div>
                </div>




                <div class="mb-0">
                    <div class="text-white row justify-content-end">
                        <a style="text-decoration: none;" class="text-white"
                        href=" {{ route('reports.index') }} ">
                        Open Details
                    </a>
                </div>
            </div>
        </div>
    </div>




    <div class="card custom_design_new_blue grow">
        <div class="card-body">
            <div class="row">
                <div class="col mt-0">
                    <h5 class="card-title text-white">Total Beneficiary</h5>
                </div>

                <div class="col-auto">
                    <div class="stat text-primary">
                        <i class="align-middle" data-feather="shopping-cart"></i>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-6"><h3 class="mt-1 mb-3 text-light">
                {{$binificiaries?$binificiaries:0}}</h3></div>
                <div class="col-xl-6 text-light align-self-center">Amount: 89</div>
            </div>
            <div class="mb-0">
                <div class="text-white row justify-content-end">
                    <a style="text-decoration: none;" class="text-white"
                    data-toggle="collapse"
                    href="#benificiaryColl" role="button"
                    aria-expanded="false" aria-controls="benificiaryColl">
                    Open Details
                </a>
            </div>
        </div>
    </div>
</div>
@endif
</div>

</div>
</div>
</div>
<div class="collapse" id="benificiaryColl">
    <div class="card">
        <div class="card-body">
            <h4 class="header-title"> Beneficiary</h4>
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Project</th>
                            <th>Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(project,index) in projectList">
                            <th scope="row">@{{ ++index }}</th>
                            <td>@{{ project.name }}</td>
                            <td>@{{ project.total_beneficiary }}</td>
                        </tr>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>
</div>
</main>


</div>
@endsection
@section('js')

<script src="{{asset('plugins/map/highmaps.js')}}"></script>
<script src="{{asset('plugins/map/exporting.js')}}"></script>
<script src="{{asset('plugins/map/highcharts.js')}}"></script>

<!-- Chart JS -->

<script type="text/javascript" src="{{asset('plugins/map/loader.js') }}"></script>

<script>
    var myChar = {};

    var vm = new Vue({
        el: '#dashboardApp',
        components: {
            'skeleton-loader-vue': window.VueSkeletonLoader,
        },
        data() {

            return {
                skeleton: true,
                receipts: {!! $totalReceipts>0?$totalReceipts:0 !!},
                invoices: {!! $totalInvoices>0?$totalInvoices:0 !!},
                income: {!! $income !!},
                expenses: {!! $totalExpenses>0?$totalExpenses:0 !!},
                commissions: {!! $commissions>0?$commissions:0 !!},
                projectList: {!! $projects !!},
                invoiceList: {!! $invoices !!},
                province: [],
                projects: [],
                invoices: [],
                project_type: 'started',
                invoice_type: 'Paid',
                provinces: {!!$provinces!!},
                clientCountByProvince: [],

                selectedProvince: '',
                clientCountByProvince: [],

                selectedProvinceId: ''

            }
        },
        watch: {},
        mounted: function () {
            this.firstDashboardLoad()
        },
        created() {

        },
        computed: {},
        methods: {
            filterProjects(type) {
                this.projects = this.projectList.filter(invoice => invoice.status == type);
                this.project_type = type;

            },
            filterInvoices(type) {
                this.invoices = this.invoiceList.filter(pro => pro.status == type);
                this.project_type = type == 1 ? 'Paid' : 'Un Paid';

            },
            drawProgressBar(proId) {
                axios.get("{{route('dashboardData')}}" + `?province_id=${proId}`)
                .then((response) => {

                    vm.clientsByType = [];
                    vm.clientTotalByPro = 0;
                    vm.clientsByType = response.data.clientTotalBytype;
                    vm.clientTotalByPro = response.data.clientTotalByPro;
                })
                .catch((error) => {
                    console.log(error);
                });
            },
            getWellbiengsData(province_id = '') {
                axios.get("{{route('dashboardData')}}",
                {
                    params: {

                        report_type: 'wellbeing_report',
                        province_id: province_id
                    }
                })
                .then((response) => {

                    vm.genderPositiveData = [];
                    vm.genderNegativeData = [];
                    let postiveData = response.data.positiveData;
                    let negativeData = response.data.negativeData;

                    if (postiveData != undefined) {
                        for (var m = 0; m < postiveData.length; m++) {


                            let tuple = Object.freeze([postiveData[m].ageType,
                                postiveData[m].total_client]);
                            vm.genderPositiveData.push(tuple);
                        }
                    }


                    if (negativeData != undefined) {
                        for (var m = 0; m < negativeData.length; m++) {


                            let tuple = Object.freeze([negativeData[m].ageType,
                                negativeData[m].total_client]);
                            vm.genderNegativeData.push(tuple);
                        }
                    }

                    this.darawGenderPositiveChart(this.genderPositiveData);
                    this.darawGenderNegativeChart(this.genderNegativeData);
                })
                .catch((error) => {
                    console.log(error);
                });

            },
            firstDashboardLoad() {
                axios.get("{{route('dashboardData')}}")
                .then((response) => {
                    this.skeleton = false;
                    vm.province = response.data.province;

                    vm.clientCountByProvince = response.data.clientCountByProvince;
                    vm.clientsTotalAllPro = response.data.clientsTotalAllPro;

                    let monthsName = response.data.keyss;
                    let totalMonths = response.data.valuess;
                    this.monthlyChartd(monthsName, totalMonths);

                    if (response.data.clientsTotalByTypeAllPro != undefined) {
                        vm.clientsTotalByTypeAllPro = response.data.clientsTotalByTypeAllPro;

                    }
                    this.$forceUpdate();


                })
                .catch((error) => {
                    console.log(error);
                });

            },
                // get satisfaction survey

                // get satisfaction survey
                getSatisfactionSurvey(province_id = null) {
                    axios.get("{{route('dashboardData')}}",
                    {
                        params: {
                            report_type: 'satisfaction_survey',
                            province_id: province_id
                        }
                    })
                    .then((response) => {
                        vm.surveyData = {
                            survey_total: response.data.survey_total,
                            survey: response.data.survey,
                            genderDisaggregation: response.data.genderDisaggregation
                        };
                        vm.genderDisaggregationData = [];
                        if (vm.surveyData.genderDisaggregation != undefined) {
                            for (var m = 0; m < vm.surveyData.genderDisaggregation.length; m++) {


                                let tuple = Object.freeze([vm.surveyData.genderDisaggregation[m].ageType,
                                    vm.surveyData.genderDisaggregation[m].total_survey]);
                                this.genderDisaggregationData.push(tuple);
                            }
                        }
                        let tempData = this.genderDisaggregationData;
                        this.darawGenderChart(tempData);


                    })
                    .catch((error) => {
                        console.log(error);
                    });

                },


                // Monthly Bar Chart


                // update gender disaggregation
                updategenderDisaggregationChart(score) {

                    if (score) {

                        axios.get("{{route('dashboardData')}}",
                        {
                            params: {

                                report_type: 'gender_disaggregation_by_score',
                                score: score,
                                province_id: vm.selectedProvinceId
                            }
                        })
                        .then((response) => {
                            let record = response.data;

                            vm.genderDisaggregationData = [];
                            if (record != undefined) {
                                for (var m = 0; m < record.length; m++) {


                                    let tuple = Object.freeze([record[m].ageType,
                                        record[m].total_survey]);
                                    this.genderDisaggregationData.push(tuple);
                                }
                            }
                            let tempData = this.genderDisaggregationData;
                            this.darawGenderChart(tempData);


                        })
                        .catch((error) => {
                            console.log(error);
                        });
                    }
                },

            },

        });

axios.get("{{asset('plugins/map/af-all.topo.json')}}")
.then((response) => {
    var topology = response.data;


    let data = [
    ['af-kt', 340], ['af-pk', 11], ['af-gz', 12], ['af-bd', 13],
    ['af-nr', 201], ['af-kr', 300], ['af-kz', 400], ['af-ng', 488],
    ['af-tk', 218], ['af-bl', 19], ['af-kb', 600], ['af-kp', 800],
    ['af-pj', 20000], ['af-la', 1002], ['af-lw', 1005], ['af-pv', 1007],
    ['af-sm', 156], ['af-vr', 133], ['af-pt', 105], ['af-bg', 123],
    ['af-hr', 200], ['af-bk', 10008], ['af-jw', 6002], ['af-bm', 444444],
    ['af-gr', 34], ['af-fb', 523], ['af-sp', 36], ['af-fh', 10010],
    ['af-hm', 5002], ['af-nm', 0], ['af-dy', 5007], ['af-oz', 10000],
    ['af-kd', 10002], ['af-zb', 10001]
    ];


    for (var i = 0; i < data.length; i++) {

        let f_province = _.find(vm.clientCountByProvince, (f) => f.proCode === data[i][0]);

        data[i][1] = 0;
        if (f_province) {
            data[i][1] = f_province.clientsTotal;
        } else {


        }


    }


                // Create the chart
                var chart = Highcharts.mapChart('afgMap', {

                    chart: {
                        map: topology,

                    },

                    title: {
                        text: '',
                        style: {
                            display: 'none'
                        }
                    },
                    subtitle: {
                        text: '',
                        style: {
                            display: 'none'
                        }
                    },
                    mapNavigation: {
                        enabled: true,
                        buttonOptions: {
                            verticalAlign: 'top'
                        },
                        enableDoubleClickZoomTo: true
                    },

                    legend: {
                        title: {
                            style: {
                                color: ( // theme
                                    Highcharts.defaultOptions &&
                                    Highcharts.defaultOptions.legend &&
                                    Highcharts.defaultOptions.legend.title &&
                                    Highcharts.defaultOptions.legend.title.style &&
                                    Highcharts.defaultOptions.legend.title.style.color
                                    ) || 'black'
                            }
                        },
                        align: 'left',
                        verticalAlign: 'bottom',
                        floating: true,
                        layout: 'horzintal',
                        valueDecimals: 0,
                        backgroundColor: ( // theme
                            Highcharts.defaultOptions &&
                            Highcharts.defaultOptions.legend &&
                            Highcharts.defaultOptions.legend.backgroundColor
                            ) || 'rgba(255, 255, 255, 0.1)',
                        symbolRadius: 0,
                        symbolHeight: 14
                    },
                    // colorAxis: {
                    //     min: 10,
                    // },
                    colorAxis: {
                        dataClasses: [{
                            to: 0
                        }, {
                            from: 1,
                            to: 100
                        }, {
                            from: 101,
                            to: 500
                        }, {
                            from: 501,
                            to: 1000
                        }, {
                            from: 1001,
                            to: 5000
                        }, {
                            from: 5001,
                            to: 10000
                        }, {
                            to: 10001
                        }]
                    },
                    series: [{
                        joinBy: ['hc-key'],
                        animation: {
                            duration: 1000
                        },
                        point: {
                            events: {
                                // load: function () {
                                // this.mapZoom(0.5, 100, 100);
                                // },
                                click: function () {
                                    var point = this;
                                    let f_province_id = _.find(vm.province, (f) => f.dashboard_client_code === point['hc-key']);

                                    let proId = f_province_id.id;
                                    vm.selectedProvince = point['hc-key'];
                                    vm.selectedProvinceId = proId;

                                    vm.drawProgressBar(proId);
                                    vm.getSatisfactionSurvey(proId);
                                    vm.getWellbiengsData(proId);

                                    point.zoomTo();
                                    point.select();
                                }
                            }
                        },
                        data: data.map(elem => {
                            if (elem[1] == 0) {
                                elem.push('#FFFFFF')
                            } else if (elem[1] > 0 && elem[1] < 100) {
                                elem.push('#DEEAF6');
                            } else if (elem[1] > 101 && elem[1] < 500) {
                                elem.push('#BDD6EE');
                            } else if (elem[1] > 501 && elem[1] < 1000) {
                                elem.push('#9CC2E5')
                            } else if (elem[1] > 1001 && elem[1] < 5000) {
                                elem.push('#5B9BD5')
                            } else if (elem[1] > 5001 && elem[1] < 10000) {
                                elem.push('#2E74B5')
                            } else {
                                elem.push('#1F4EAB')
                            }

                            return elem;
                        }),

                        keys: ['hc-key', 'value', 'color'],
                        name: 'Total Project',
                        states: {
                            hover: {
                                color: '#FCFFC5'
                            },
                            select: {
                                color: '#a4edba'
                            }
                        },
                        dataLabels: {
                            enabled: true,
                            format: '{point.name}'
                        }
                    }]
                });

var select = document.getElementById('selectmap');
select.addEventListener('change', (e) => {

    var point = chart.series[0].points;
    vm.selectedProvince = '';
    vm.selectedProvinceId = '';
    if (e.target.value == 'all' || e.target.value == '') {

        vm.firstDashboardLoad();
        vm.drawProgressBar();
        vm.getSatisfactionSurvey();
        vm.getWellbiengsData();

        chart.zoomOut();
    }
    for (var i = 0; i < point.length; i++) {
        if (point[i]['hc-key'] == e.target.value) {

            let f_province_id = _.find(vm.province, (f) => f.dashboard_client_code === point[i]['hc-key']);

            if (f_province_id) {
                let proId = f_province_id.id;
                                // console.log('proid',proId);
                                let findPoint = point[i]['hc-key'];

                                vm.selectedProvince = findPoint;
                                vm.selectedProvinceId = proId;

                                vm.drawProgressBar(proId);
                                vm.getSatisfactionSurvey(proId);
                                vm.getWellbiengsData(proId);

                                point[i].zoomTo();
                                point[i].select();
                                axios.get("{{route('dashboardData')}}" + `?province_id=${proId}`)
                                .then((response) => {

                                    vm.clientsByType = response.data.clientTotalBytype;
                                    vm.clientTotalByPro = response.data.clientTotalByPro;


                                })
                                .catch((error) => {
                                    console.log(error);
                                });
                            }
                        }
                    }

                    //
                });

})
.catch((error) => {
    console.log(error);
});


</script>
@endsection
