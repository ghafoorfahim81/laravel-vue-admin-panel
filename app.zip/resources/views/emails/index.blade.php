<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Email Sending</title>
</head>
<body>

	<h1>This email is from Shopify</h1>
	<p>{{$data['body']}}</p>
</body>
</html>