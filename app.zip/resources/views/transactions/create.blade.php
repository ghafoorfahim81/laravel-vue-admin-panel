@extends('layouts.master')
@section('title', __('lang.add').' '.__('lang.transaction'))
@section('css')
    <link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css"/>


@endsection
@section('content')
    <div class="page-content">

    

        <div class="page-content-wrapper" id="myapp" v-cloak>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card">
                            <form action="{{route('user.store')}}" @submit="handleSubmit($event)" method="post"
                                  id="userForm">
                                @csrf
                                <input type="hidden" name="permission_id" id="permission_id">
                                <div class="card-body" style="padding-bottom: 0px">
                                    <div class="card-body client-nav">
                                        <h4 class="header-title">@lang('lang.add') @lang('lang.user')</h4>


                                        <div class="row">
                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="">@lang('lang.name')</label>
                                                    <input type="text" name="name" class="form-control" id=""
                                                           v-validate="'required'" data-vv-as="@lang('lang.name')"
                                                           placeholder="@lang('lang.name')">
                                                    <span class="help-block rq-hint">
                                                    @{{errors.first('name')}}</span>
                                                </div>
                                            </div>


                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="">@lang('lang.email')</label>
                                                    <input type="text" name="email" class="form-control" id=""
                                                           v-validate="'required'" data-vv-as="@lang('lang.email')"
                                                           placeholder="@lang('lang.email')">
                                                    <span class="help-block rq-hint">
                                                    @{{errors.first('email')}}</span>
                                                </div>
                                            </div>


                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="">@lang('lang.role')</label>

                                                    <v-select :select-on-tab="true"
                                                              v-model="selected_role"
                                                              multiple
                                                              label="name"
                                                              :options="role" placeholder="@lang('lang.role')"
                                                    >

                                                        <template v-slot:no-options="{ search, searching }">
                                                            <template v-if="searching">
                                                                @lang('lang.no_record_found_for') @{{search}}
                                                            </template>
                                                            <em class="v-select-search-hint"
                                                                v-else>@lang('lang.type_to_search')</em>
                                                        </template>
                                                    </v-select>
                                                    <input type="hidden" v-model="selected_role" name="role_ids"
                                                           id="role_ids" v-validate="'required'"
                                                           data-vv-as="@lang('lang.role')" class="form-control"
                                                           placeholder="@lang('lang.role')"/>
                                                    <span class="help-block rq-hint">
                                                    @{{errors.first('role_ids')}}</span>

                                                </div>
                                            </div>


                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="">@lang('lang.password')</label>
                                                    <input type="password" name="password" class="form-control" id=""
                                                           v-validate="'required'" data-vv-as="@lang('lang.password')"
                                                           placeholder="@lang('lang.password')">
                                                    <span class="help-block rq-hint">
                                                    @{{errors.first('password')}}</span>

                                                </div>
                                            </div>


                                            <div class="col-xl-4">
                                                <div class="form-group">
                                                    <label for="">@lang('lang.confirm_password')</label>
                                                    <input type="confirm_password" name="confirm_password"
                                                           class="form-control" id="" v-validate="'required'"
                                                           data-vv-as="@lang('lang.confirm_password')"
                                                           placeholder="@lang('lang.confirm_password')">
                                                    <span class="help-block rq-hint">
                                                    @{{errors.first('confirm_password')}}</span>

                                                </div>
                                            </div>

                                        </div>


                                    </div>
                                </div>

                                <div class="card-footer ">
                                    <button class="btn btn-md btn-primary" type="button" @click="handleSubmit($event)">
                                        <span hidden id="btn-loading" class="spinner-border spinner-border-sm"
                                              user="status" aria-hidden="true"></span> @lang('lang.save')</button>
                                    <button class="btn btn-md btn-danger" type="reset">@lang('lang.reset')</button>
                                    <button class="btn btn-md btn-danger" type="button"
                                            onclick="location.href='{{route('user.index')}}'">@lang('lang.cancel')</button>

                                </div>

                            </form>
                        </div>

                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- end container-fluid -->
        </div>
        <!-- end page-content-wrapper -->
    </div>
    <!-- End Page-content -->
@endsection
@section('js')
    <script>
        //Vue.component('pagination', require('laravel-vue-pagination'));
        var vm = new Vue({
            el: '#myapp',
            data: {

            }
        });

    </script>

@endsection
