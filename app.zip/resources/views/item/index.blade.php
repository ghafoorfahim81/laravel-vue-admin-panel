@extends('layouts.master')
@section('title', __('lang.beneficiary_list'))
@section('css')


@endsection
@section('content')

    <div class="page-content-wrapper" id="app">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <input type="hidden" name="permission_id" id="permission_id">
                        <div class="card-body" style="padding-bottom: 0px">
                            <div class="card-body client-nav">
                                <div class="row pb-2">
                                    <div class="col-sm-12 col-md-2 form-inline">
                                        <div class="form-group">
                                        @if(hasPermission(['beneficialy_create']))
                                                <button data-toggle="modal" data-target="#create_modal"
                                                        class="btn btn-info btn-sm waves-effect waves-light"
                                                        type="button">@lang('lang.add') @lang('lang.beneficiary')
                                                    <i class="mdi mdi-plus-thick"></i></button>&nbsp
                                        @endif
                                            
                                        </div>
                                    </div>
                                </div>

                                <div class=" ">
                                    <datatable ref="child" :per-page="{{perPage()}}"
                                               :no-record-found-text="'@lang('lang.no_record_found')'"
                                               :per-page-text="'@lang('lang.show')'"
                                               :showing-text="'@lang('lang.showing')'"
                                               :from-text="'@lang('lang.from')'" :to-text="'@lang('lang.to')'"
                                               :record-text="'@lang('lang.record')'"
                                               :app-per-page="{!! perPage(1) !!}" :columns="columns" :data="apiData"
                                               @pagination-change-page="getRecord" :limit="1"
                                               :filterRecord="getRecord"
                                               :multiple-select="true"
                                               :selected-rows="selectedRows"
                                               @delete-method-action="deleteRecord"
                                               >
                                        <template slot="tbody">
                                        <tbody v-show="!apiData.data">
                                            <tr v-for="skeleton in 15">
                                                

                                                <td>
                                                    <skeleton-loader-vue
                                                        type="rect"
                                                        :height="15"
                                                        :width="50"
                                                        class="m-3"
                                                        animation="fade"
                                                        />
                                                </td>

                                                <td>
                                                    <skeleton-loader-vue
                                                        type="rect"
                                                        :height="15"
                                                        :width="50"
                                                        class="m-3"
                                                        animation="fade"
                                                        />
                                                </td>

                                                <td>
                                                    <skeleton-loader-vue
                                                        type="rect"
                                                        :height="15"
                                                        :width="50"
                                                        class="m-3"
                                                        animation="fade"
                                                        />
                                                </td>

                                                <td>
                                                    <skeleton-loader-vue
                                                        type="rect"
                                                        :height="15"
                                                        :width="50"
                                                        class="m-3"
                                                        animation="fade"
                                                        />
                                                </td>

                                                <td>
                                                    <skeleton-loader-vue
                                                        type="rect"
                                                        :height="15"
                                                        :width="50"
                                                        class="m-3"
                                                        animation="fade"
                                                        />
                                                </td>

                                                
                                               
                                            </tr>
                                        </tbody>
                                            <tbody v-show="apiData.data">
                                            <tr v-for="(record,index) in apiData.data" :key="record.id">
                                                <td>
                                                    <input type="checkbox" class="" v-model="selectedRows"
                                                           :value="record.id" :id="`checked-${record.id}}`">

                                                </td>
                                                <td> @{{++index}}</td>
                                                <td> @{{record.name}}</td>
                                                <td> @{{record.description}}</td>
                                                <td class="button-items">
                                                    <div class="p-1" role="group" style="width: 180px; text-align: center;">
                                                    @if(hasPermission(['beneficialy_view']))
                                                            <a class="btn btn-info btn-sm"
                                                               :href="`{{url('role/')}}/${record.id}`"
                                                               data-toggle="tooltip" data-placement="top"
                                                               title="View">
                                                                <i class="mdi mdi-eye"></i>
                                                            </a>&nbsp;
                                                            @endif
                                                            @if(hasPermission(['beneficialy_edit']))
                                                            <a 
                                                                class="btn btn-primary btn-sm"
                                                               href="#"
                                                               @click="edit(record.id, index)"
                                                               data-toggle="tooltip"
                                                               data-placement="top" title="Edit">
                                                                <i class="dripicons-document-edit"></i>
                                                            </a>&nbsp;
                                                            @endif
                                                            @if(hasPermission(['beneficialy_delete']))
                                                            <a class="btn btn-danger btn-sm"
                                                               @click="deleteRecord(record.id)"
                                                               data-toggle="tooltip" data-placement="top"
                                                               title="Delete">
                                                                <i style="color: white" class="mdi mdi-delete"></i>
                                                            </a>
                                                            @endif
                                                    </div>
                                                </td>
                                            </tr>

                                            </tbody>

                                        </template>
                                    </datatable>
                                    {{--                                        <Pagination align="center" :limit="1" :data="records" @pagination-change-page="getRecords"></Pagination>--}}
                                </div>
                            </div>
                        </div>

                        <div class="card-footer ">
                        </div>

                    </div>

                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- end container-fluid -->
        <!-- edit item start-->
        <div class="modal fade" id="edit_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">@lang('lang.edit') @lang('lang.beneficiary')</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="col-xl-12">
                        <div class="form-group">
                            <label for="">@lang('lang.name')
                                <span class="rq">*</span>
                            </label>
                            <input type="text" v-model="item.name" name="desc" class="form-control"
                                   id="desc" 
                                   autocomplete="new-desc"
                                   placeholder="@lang('lang.name')">
                            <span class="help-block rq-hint">
                            </span>

                        </div>
                    </div>
                    <div class="col-xl-12">
                        <div class="form-group">
                            <label for="">@lang('lang.description')
                                <span class="rq">*</span>
                            </label>
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" v-model="item.desc">
                            </textarea>
                            <span class="help-block rq-hint">
                            </span>

                        </div>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" @click="updateItem">@lang('lang.update') @lang('lang.beneficiary')</button>
                  </div>
                </div>
              </div>
        </div>
        <!-- edit item end -->
        <!-- create item start -->
        <div class="modal fade" id="create_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">@lang('lang.create') @lang('lang.beneficiary')</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="col-xl-12">
                        <div class="form-group">
                            <label for="">@lang('lang.name')
                                <span class="rq">*</span>
                            </label>
                            <input type="text" v-model="item.name" name="desc" class="form-control"
                                   id="desc" 
                                   autocomplete="new-desc"
                                   placeholder="@lang('lang.name')">
                            <span class="help-block rq-hint">
                            </span>

                        </div>
                    </div>
                    <div class="col-xl-12">
                        <div class="form-group">
                            <label for="">@lang('lang.description')
                                <span class="rq">*</span>
                            </label>
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" v-model="item.desc">
                            </textarea>
                            <span class="help-block rq-hint">
                            </span>

                        </div>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">@lang('lang.close')</button>
                    <button type="button" @click="create" class="btn btn-primary">@lang('lang.save') @lang('lang.beneficiary')</button>
                  </div>
                </div>
              </div>
        </div>
        <!-- create item end -->
    </div>
    <!-- end page-content-wrapper -->

@endsection
@section('js')
    <script>

        //Vue.component('pagination', require('laravel-vue-pagination'));
        var vm = new Vue({
            el: '#app',
            components: {
            'skeleton-loader-vue': window.VueSkeletonLoader,
        },
            data() {
                return {
                    item: {
                        name: null,
                        desc: null,
                        id: null
                    },
                    url: '{{route("item.index")}}?',
                    columns: [
                        {
                            label: "#",
                            name: '#',
                            sort: false,
                        },
                        {
                            label: "@lang('lang.name')",
                            name: 'items.name',
                            sort: true,
                            activeSort: true,
                            order_direction: 'desc',
                        },
                        {
                            label: "@lang('lang.description')",
                            name: 'items.description',
                            sort: true,
                            activeSort: true,
                            order_direction: 'desc',
                        },
                        {
                            label: "@lang('lang.actions')",
                            name: 'action',
                            sort: false
                        }
                    ],

                    apiData: {},
                    appPerPage:{!! perPage(1) !!},
                    perPage: "{{perPage()}}",
                    page: 1,
                    selectedRows: [],
                }
 
            },
            mounted: function () {
                this.getRecord();
            },
            methods: {
                getRecord: _.debounce((page = vm.page) => {
                    axios.get(vm.url +
                        '&current_page=' +
                        page + '&per_page=' + vm.perPage)
                        .then((response) => {
                            if (response.data) {
                                vm.page = response.data.current_page;
                            }
                            vm.apiData = response.data;
                        })
                        .catch((error) => {
                            console.log(error);
                        });
                }, 200),

                // delete record
                deleteRecord(id=null) {
                    if (id && id != null) {
                        deleteItem(`role/${id}`);
                        this.selectedRows=[];
                    } else {
                        deleteItem(`role/${this.selectedRows}`);
                        this.selectedRows=[];
                    }
                },
                create(){
                    console.log('chkec');
                    axios.post("{{route('item.store')}}", 
                            this.item
                        )
                        .then((response) => {
                            console.log('chec', response);
                            this.item.name = null;
                            this.item.desc = null;
                            this.getRecord();
                            $('#create_modal').modal('hide');
                        })
                        .catch((error) => {
                            
                        });
                },
                edit(id, index){
                    this.item_index = index;
                    console.log('chkec', id);
                    axios.post("{{route('item.edit')}}", {id: id})
                        .then((response) => {
                            console.log('chec', response);
                            this.item.name  = response.data.name;
                            this.item.id    = response.data.id;
                            this.item.desc  = response.data.description;
                            $('#edit_modal').modal('show');
                        })
                        .catch((error) => {
                            
                        });
                },
                updateItem(){
                    axios.post("{{route('item.update')}}", this.item)
                        .then((response) => {
                            this.items[this.item_index].name        = this.item.name;
                            this.items[this.item_index].description = this.item.desc;
                            console.log('chec', response);
                            $('#edit_modal').modal('hide');
                        })
                        .catch((error) => {
                            
                        });
                },
            }
        });

    </script>
@endsection
