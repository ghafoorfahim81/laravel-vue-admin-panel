@extends('layouts.master')
@section('title', __('lang.add').' '.__('lang.user'))
@section('css')
    <link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css"/>
    <link href="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}" rel="stylesheet" type="text/css"/>


@endsection
@section('content')


        <div class="page-content-wrapper" id="item_create">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card">

                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                              Launch demo modal
                            </button>

                            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Create Item</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                    <div class="col-xl-12">
                                        <div class="form-group">
                                            <label for="">Name
                                                <span class="rq">*</span>
                                            </label>
                                            <input type="text" v-model="item.name" name="desc" class="form-control"
                                                   id="desc" 
                                                   autocomplete="new-desc"
                                                   placeholder="@lang('lang.name')">
                                            <span class="help-block rq-hint">
                                            </span>

                                        </div>
                                    </div>
                                    <div class="col-xl-12">
                                        <div class="form-group">
                                            <label for="">Description
                                                <span class="rq">*</span>
                                            </label>
                                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" v-model="item.desc">
                                            </textarea>
                                            <span class="help-block rq-hint">
                                            </span>

                                        </div>
                                    </div>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="button" @click="createItem" class="btn btn-primary">Save Project</button>
                                  </div>
                                </div>
                              </div>
                            </div>
                                

                        </div>

                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- end container-fluid -->
        </div>
        <!-- end page-content-wrapper -->


@endsection
@section('js')
    <script src="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.js')}}" type="text/javascript"></script>
    <script>
      /*
        Example kicking off the UI. Obviously, adapt this to your specific needs.
        Assumes you have a <div id="q-app"></div> in your <body> above
       */
      var project_app = new Vue({
            el: '#item_create',
            data: {
                item: {
                    name: null,
                    desc: null
                },
            },
            mounted: function() {

            },
            methods: {
                createItem(){
                    console.log('chkec');
                    axios.post("{{route('item.store')}}", 
                            this.item
                        )
                        .then((response) => {
                            console.log('chec', response);
                            this.item.name = null;
                            this.item.desc = null;
                        })
                        .catch((error) => {
                            
                        });
                }
            }
        });
    </script>


@endsection
