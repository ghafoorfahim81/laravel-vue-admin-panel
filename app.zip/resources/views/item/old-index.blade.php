@extends('layouts.master')
@section('title', __('lang.add').' '.__('lang.user'))
@section('css')
    <link href="{{ asset('css/vue-select.css') }}" rel="stylesheet" type="text/css"/>
    <link href="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}" rel="stylesheet" type="text/css"/>


@endsection
@section('content')

<div>
    <div class="page-content-wrapper" id="item_index">
        <div class="container-fluid">
            <table class="table">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Name</th>
                  <th scope="col">Descrition</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(element, index) in items">
                  <th scope="row" >@{{index +1}}</th>
                  <td>@{{element.name}}</td>
                  <td>@{{element.description}}</td>
                  <td>
                        <button type="button" class="btn btn-primary" @click="edit(element.id, index)">
                            edit
                        </button>
                    </td>
                </tr>
              </tbody>
            </table>  
        </div>
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Item</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="col-xl-12">
                        <div class="form-group">
                            <label for="">Name
                                <span class="rq">*</span>
                            </label>
                            <input type="text" v-model="item.name" name="desc" class="form-control"
                                   id="desc" 
                                   autocomplete="new-desc"
                                   placeholder="@lang('lang.name')">
                            <span class="help-block rq-hint">
                            </span>

                        </div>
                    </div>
                    <div class="col-xl-12">
                        <div class="form-group">
                            <label for="">Description
                                <span class="rq">*</span>
                            </label>
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" v-model="item.desc">
                            </textarea>
                            <span class="help-block rq-hint">
                            </span>

                        </div>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" @click="updateItem">Save Project</button>
                  </div>
                </div>
              </div>
        </div>
    </div>
</div>


@endsection
@section('js') 
    <script src="{{asset('plugins/bootstrap-fileinput/bootstrap-fileinput.js')}}" type="text/javascript"></script>
    <script>
      /*
        Example kicking off the UI. Obviously, adapt this to your specific needs.
        Assumes you have a <div id="q-app"></div> in your <body> above
       */
      var item_app = new Vue({
            el: '#item_index',
            data: {
                
                item: {
                    name: null,
                    desc: null,
                    id: null
                },
                items: {!! $items !!}
            },
            mounted: function() {
                
            },
            methods: {
                edit(id, index){
                    this.item_index = index;
                    console.log('chkec', id);
                    axios.post("{{route('item.edit')}}", {id: id})
                        .then((response) => {
                            console.log('chec', response);
                            this.item.name  = response.data.name;
                            this.item.id    = response.data.id;
                            this.item.desc  = response.data.description;
                            $('#exampleModal').modal('show');
                        })
                        .catch((error) => {
                            
                        });
                },
                updateItem(){
                    axios.post("{{route('item.update')}}", this.item)
                        .then((response) => {
                            this.items[this.item_index].name        = this.item.name;
                            this.items[this.item_index].description = this.item.desc;
                            console.log('chec', response);
                            $('#exampleModal').modal('hide');
                        })
                        .catch((error) => {
                            
                        });
                },
            }
        });
    </script>


@endsection
