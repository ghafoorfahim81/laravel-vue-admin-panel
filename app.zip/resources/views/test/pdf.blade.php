<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style>
        .pie-chart {
            width: 600px;
            height: 400px;
            margin: 0 auto;
        }

    </style>
    {{-- make sure you are using http, and not https --}}
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>

   
</head>

<body onload="init()">

    <h2 style="text-align: center; ">Generate PDF with Graph in Laravel</h2>
    <div id="chart_div" class="pie-chart"></div>
    <h2 style="text-align: center; ">MyNotePaper.com</h2>

</body>

</html>
